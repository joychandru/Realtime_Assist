package com.insurance.app;

/* renamed from: com.insurance.app.R */
public final class C0012R {

    /* renamed from: com.insurance.app.R.attr */
    public static final class attr {
    }

    /* renamed from: com.insurance.app.R.drawable */
    public static final class drawable {
        public static final int logo = 2130837504;
    }

    /* renamed from: com.insurance.app.R.id */
    public static final class id {
        public static final int button_ChangeCamera = 2131230721;
        public static final int button_capture = 2131230722;
        public static final int button_flash = 2131230723;
        public static final int camera_preview = 2131230720;
        public static final int imageView = 2131230725;
        public static final int menu_settings = 2131230727;
        public static final int webView1 = 2131230726;
        public static final int zoomControls = 2131230724;
    }

    /* renamed from: com.insurance.app.R.layout */
    public static final class layout {
        public static final int activity_camera_port = 2130903040;
        public static final int imagepreview = 2130903041;
        public static final int webview = 2130903042;
    }

    /* renamed from: com.insurance.app.R.menu */
    public static final class menu {
        public static final int activity_main = 2131165184;
    }

    /* renamed from: com.insurance.app.R.raw */
    public static final class raw {
        public static final int template = 2130968576;
    }

    /* renamed from: com.insurance.app.R.string */
    public static final class string {
        public static final int app_name = 2131034112;
        public static final int menu_settings = 2131034113;
    }

    /* renamed from: com.insurance.app.R.style */
    public static final class style {
        public static final int AppBaseTheme = 2131099648;
        public static final int AppTheme = 2131099649;
    }
}

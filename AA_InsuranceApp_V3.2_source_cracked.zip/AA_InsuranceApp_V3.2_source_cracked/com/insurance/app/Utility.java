package com.insurance.app;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import com.itextpdf.text.pdf.PdfObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Utility {
    public static ProgressDialog progDlg;

    /* renamed from: com.insurance.app.Utility.1 */
    class C00181 implements FilenameFilter {
        C00181() {
        }

        public boolean accept(File dir, String fileName) {
            if (fileName.endsWith(".jpg") || fileName.endsWith(".png")) {
                return true;
            }
            return false;
        }
    }

    /* renamed from: com.insurance.app.Utility.2 */
    class C00192 implements Comparator<File> {
        private final /* synthetic */ Map val$staticLastModifiedTimes;

        C00192(Map map) {
            this.val$staticLastModifiedTimes = map;
        }

        public int compare(File f1, File f2) {
            return ((Long) this.val$staticLastModifiedTimes.get(f2)).compareTo((Long) this.val$staticLastModifiedTimes.get(f1));
        }
    }

    /* renamed from: com.insurance.app.Utility.3 */
    class C00203 implements FilenameFilter {
        C00203() {
        }

        public boolean accept(File dir, String fileName) {
            if (fileName.startsWith("ID_") && dir.isDirectory()) {
                return true;
            }
            return false;
        }
    }

    /* renamed from: com.insurance.app.Utility.4 */
    class C00214 implements Comparator<File> {
        private final /* synthetic */ Map val$staticLastModifiedTimes;

        C00214(Map map) {
            this.val$staticLastModifiedTimes = map;
        }

        public int compare(File f1, File f2) {
            return ((Long) this.val$staticLastModifiedTimes.get(f2)).compareTo((Long) this.val$staticLastModifiedTimes.get(f1));
        }
    }

    /* renamed from: com.insurance.app.Utility.5 */
    class C00225 implements FilenameFilter {
        C00225() {
        }

        public boolean accept(File dir, String fileName) {
            return new File(dir, fileName).isDirectory();
        }
    }

    public static List<File> getFiles(String directoryName) throws FileNotFoundException {
        File folder = new File(directoryName);
        Log.e("GETFILES", "FPATH:" + folder.getAbsolutePath());
        List<File> out = null;
        if (folder.exists()) {
            out = Arrays.asList(folder.listFiles(new C00181()));
            Map<File, Long> staticLastModifiedTimes = new HashMap();
            for (File f : out) {
                staticLastModifiedTimes.put(f, Long.valueOf(f.lastModified()));
            }
            Collections.sort(out, new C00192(staticLastModifiedTimes));
        } else {
            Log.d("Generate image", "getFiles : Folder not exist");
        }
        return out;
    }

    public static List<File> getIncidentFolders(String directoryName) throws FileNotFoundException {
        File folder = new File(directoryName);
        Log.e("GETFILES", "FPATH:" + folder.getAbsolutePath());
        List<File> out = null;
        if (folder.exists()) {
            out = Arrays.asList(folder.listFiles(new C00203()));
            Map<File, Long> staticLastModifiedTimes = new HashMap();
            for (File f : out) {
                staticLastModifiedTimes.put(f, Long.valueOf(f.lastModified()));
            }
            Collections.sort(out, new C00214(staticLastModifiedTimes));
        } else {
            Log.d("Generate image", "getFiles : Folder not exist");
        }
        return out;
    }

    public static List<File> getFolders(String directoryName, boolean isFolder) throws FileNotFoundException {
        File folder = new File(directoryName);
        Log.e("GETFILES", "FPATH:" + folder.getAbsolutePath());
        if (folder.exists()) {
            return Arrays.asList(folder.listFiles(new C00225()));
        }
        Log.d("Generate image", "getFiles : Folder not exist");
        return null;
    }

    public static String getImageDate(File file) {
        try {
            Log.e("UTILITY", "dateString:" + file.lastModified());
            return new SimpleDateFormat(Constants.TEMPLATE_DATE_FORMAT_TO).format(Long.valueOf(file.lastModified()));
        } catch (Exception e) {
            return PdfObject.NOTHING;
        }
    }

    public static String convertImageToBase64(File file) {
        String encodedImage = null;
        try {
            Bitmap bmp = BitmapFactory.decodeStream(new BufferedInputStream(new FileInputStream(file)));
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bmp.compress(CompressFormat.JPEG, 100, stream);
            encodedImage = Base64.encodeToString(stream.toByteArray(), 0);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return encodedImage;
    }

    public static final void showActivityIndicator(Context context, String message, String title) {
        progDlg = new ProgressDialog(context);
        if (message == null || message.length() <= 0) {
            progDlg.setMessage("Please wait..");
        } else {
            progDlg.setMessage(message);
        }
        progDlg.setIndeterminate(true);
        progDlg.setCancelable(true);
        if (title == null || title.length() <= 0) {
            progDlg.setTitle(Constants.STR_APP_NAME);
        } else {
            progDlg.setTitle(title);
        }
        progDlg.setCancelable(false);
        progDlg.show();
    }

    public static final void hideActivityIndicator() {
        try {
            if (progDlg != null) {
                progDlg.dismiss();
                progDlg.cancel();
                progDlg = null;
            }
        } catch (Exception e) {
        }
    }

    public static String getApplicationFolder(Context context) {
        String appPath = PdfObject.NOTHING;
        try {
            appPath = new StringBuilder(String.valueOf(context.getFilesDir().getAbsolutePath())).append(File.separator).append(Constants.STR_APP_FOLDER).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return appPath;
    }
}

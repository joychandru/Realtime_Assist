package com.insurance.app;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.provider.Settings.Secure;
import android.util.Log;

public class GetLocation {
    private static final String TAG = "Debug";
    private Context context;
    private Boolean flag;

    public GetLocation(Activity myActivity) {
        this.flag = Boolean.valueOf(false);
        this.context = myActivity;
    }

    public GetLocation(Context context) {
        this.flag = Boolean.valueOf(false);
        this.context = context;
    }

    public Location getLocationData() {
        this.flag = displayGpsStatus();
        if (this.flag.booleanValue()) {
            Log.v(TAG, "onClick");
            return getLastKnownLocation();
        }
        Log.d("Gps Status!!", "Your GPS is: OFF");
        return null;
    }

    public Boolean displayGpsStatus() {
        if (Secure.isLocationProviderEnabled(this.context.getContentResolver(), "gps")) {
            return Boolean.valueOf(true);
        }
        return Boolean.valueOf(false);
    }

    private Location getLastKnownLocation() {
        LocationManager locationManager = (LocationManager) this.context.getApplicationContext().getSystemService("location");
        Location bestLocation = null;
        for (String provider : locationManager.getProviders(true)) {
            Location l = locationManager.getLastKnownLocation(provider);
            if (l != null && (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy())) {
                bestLocation = l;
            }
        }
        return bestLocation;
    }
}

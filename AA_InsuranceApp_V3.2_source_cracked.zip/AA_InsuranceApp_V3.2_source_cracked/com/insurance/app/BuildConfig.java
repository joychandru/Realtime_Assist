package com.insurance.app;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}

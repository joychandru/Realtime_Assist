package com.itextpdf.text;

import com.itextpdf.text.log.Level;
import com.itextpdf.text.log.Logger;
import com.itextpdf.text.log.LoggerFactory;
import com.itextpdf.text.pdf.BaseFont;
import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

public class FontFactoryImp implements FontProvider {
    private static final Logger LOGGER;
    private static String[] TTFamilyOrder;
    public boolean defaultEmbedding;
    public String defaultEncoding;
    private final Hashtable<String, ArrayList<String>> fontFamilies;
    private final Hashtable<String, String> trueTypeFonts;

    static {
        LOGGER = LoggerFactory.getLogger(FontFactoryImp.class);
        TTFamilyOrder = new String[]{"3", "1", "1033", "3", "0", "1033", "1", "0", "0", "0", "3", "0"};
    }

    public FontFactoryImp() {
        this.trueTypeFonts = new Hashtable();
        this.fontFamilies = new Hashtable();
        this.defaultEncoding = BaseFont.WINANSI;
        this.defaultEmbedding = false;
        this.trueTypeFonts.put(BaseFont.COURIER.toLowerCase(), BaseFont.COURIER);
        this.trueTypeFonts.put(BaseFont.COURIER_BOLD.toLowerCase(), BaseFont.COURIER_BOLD);
        this.trueTypeFonts.put(BaseFont.COURIER_OBLIQUE.toLowerCase(), BaseFont.COURIER_OBLIQUE);
        this.trueTypeFonts.put(BaseFont.COURIER_BOLDOBLIQUE.toLowerCase(), BaseFont.COURIER_BOLDOBLIQUE);
        this.trueTypeFonts.put(BaseFont.HELVETICA.toLowerCase(), BaseFont.HELVETICA);
        this.trueTypeFonts.put(BaseFont.HELVETICA_BOLD.toLowerCase(), BaseFont.HELVETICA_BOLD);
        this.trueTypeFonts.put(BaseFont.HELVETICA_OBLIQUE.toLowerCase(), BaseFont.HELVETICA_OBLIQUE);
        this.trueTypeFonts.put(BaseFont.HELVETICA_BOLDOBLIQUE.toLowerCase(), BaseFont.HELVETICA_BOLDOBLIQUE);
        this.trueTypeFonts.put(BaseFont.SYMBOL.toLowerCase(), BaseFont.SYMBOL);
        this.trueTypeFonts.put(BaseFont.TIMES_ROMAN.toLowerCase(), BaseFont.TIMES_ROMAN);
        this.trueTypeFonts.put(BaseFont.TIMES_BOLD.toLowerCase(), BaseFont.TIMES_BOLD);
        this.trueTypeFonts.put(BaseFont.TIMES_ITALIC.toLowerCase(), BaseFont.TIMES_ITALIC);
        this.trueTypeFonts.put(BaseFont.TIMES_BOLDITALIC.toLowerCase(), BaseFont.TIMES_BOLDITALIC);
        this.trueTypeFonts.put(BaseFont.ZAPFDINGBATS.toLowerCase(), BaseFont.ZAPFDINGBATS);
        ArrayList<String> tmp = new ArrayList();
        tmp.add(BaseFont.COURIER);
        tmp.add(BaseFont.COURIER_BOLD);
        tmp.add(BaseFont.COURIER_OBLIQUE);
        tmp.add(BaseFont.COURIER_BOLDOBLIQUE);
        this.fontFamilies.put(BaseFont.COURIER.toLowerCase(), tmp);
        tmp = new ArrayList();
        tmp.add(BaseFont.HELVETICA);
        tmp.add(BaseFont.HELVETICA_BOLD);
        tmp.add(BaseFont.HELVETICA_OBLIQUE);
        tmp.add(BaseFont.HELVETICA_BOLDOBLIQUE);
        this.fontFamilies.put(BaseFont.HELVETICA.toLowerCase(), tmp);
        tmp = new ArrayList();
        tmp.add(BaseFont.SYMBOL);
        this.fontFamilies.put(BaseFont.SYMBOL.toLowerCase(), tmp);
        tmp = new ArrayList();
        tmp.add(BaseFont.TIMES_ROMAN);
        tmp.add(BaseFont.TIMES_BOLD);
        tmp.add(BaseFont.TIMES_ITALIC);
        tmp.add(BaseFont.TIMES_BOLDITALIC);
        this.fontFamilies.put(FontFactory.TIMES.toLowerCase(), tmp);
        this.fontFamilies.put(BaseFont.TIMES_ROMAN.toLowerCase(), tmp);
        tmp = new ArrayList();
        tmp.add(BaseFont.ZAPFDINGBATS);
        this.fontFamilies.put(BaseFont.ZAPFDINGBATS.toLowerCase(), tmp);
    }

    public Font getFont(String fontname, String encoding, boolean embedded, float size, int style, BaseColor color) {
        return getFont(fontname, encoding, embedded, size, style, color, true);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.itextpdf.text.Font getFont(java.lang.String r23, java.lang.String r24, boolean r25, float r26, int r27, com.itextpdf.text.BaseColor r28, boolean r29) {
        /*
        r22 = this;
        if (r23 != 0) goto L_0x0010;
    L_0x0002:
        r3 = new com.itextpdf.text.Font;
        r4 = com.itextpdf.text.Font.FontFamily.UNDEFINED;
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r3.<init>(r4, r0, r1, r2);
    L_0x000f:
        return r3;
    L_0x0010:
        r18 = r23.toLowerCase();
        r0 = r22;
        r3 = r0.fontFamilies;
        r0 = r18;
        r21 = r3.get(r0);
        r21 = (java.util.ArrayList) r21;
        if (r21 == 0) goto L_0x0079;
    L_0x0022:
        monitor-enter(r21);
        r3 = -1;
        r0 = r27;
        if (r0 != r3) goto L_0x00b4;
    L_0x0028:
        r20 = 0;
    L_0x002a:
        r14 = 0;
        r13 = 0;
        r15 = r21.iterator();	 Catch:{ all -> 0x00b8 }
    L_0x0030:
        r3 = r15.hasNext();	 Catch:{ all -> 0x00b8 }
        if (r3 == 0) goto L_0x006d;
    L_0x0036:
        r12 = r15.next();	 Catch:{ all -> 0x00b8 }
        r12 = (java.lang.String) r12;	 Catch:{ all -> 0x00b8 }
        r17 = r12.toLowerCase();	 Catch:{ all -> 0x00b8 }
        r14 = 0;
        r3 = "bold";
        r0 = r17;
        r3 = r0.indexOf(r3);	 Catch:{ all -> 0x00b8 }
        r4 = -1;
        if (r3 == r4) goto L_0x004e;
    L_0x004c:
        r14 = r14 | 1;
    L_0x004e:
        r3 = "italic";
        r0 = r17;
        r3 = r0.indexOf(r3);	 Catch:{ all -> 0x00b8 }
        r4 = -1;
        if (r3 != r4) goto L_0x0064;
    L_0x0059:
        r3 = "oblique";
        r0 = r17;
        r3 = r0.indexOf(r3);	 Catch:{ all -> 0x00b8 }
        r4 = -1;
        if (r3 == r4) goto L_0x0066;
    L_0x0064:
        r14 = r14 | 2;
    L_0x0066:
        r3 = r20 & 3;
        if (r3 != r14) goto L_0x0030;
    L_0x006a:
        r23 = r12;
        r13 = 1;
    L_0x006d:
        r3 = -1;
        r0 = r27;
        if (r0 == r3) goto L_0x0078;
    L_0x0072:
        if (r13 == 0) goto L_0x0078;
    L_0x0074:
        r3 = r14 ^ -1;
        r27 = r27 & r3;
    L_0x0078:
        monitor-exit(r21);	 Catch:{ all -> 0x00b8 }
    L_0x0079:
        r10 = 0;
        r7 = 0;
        r8 = 0;
        r9 = 1;
        r3 = r23;
        r4 = r24;
        r5 = r25;
        r6 = r29;
        r10 = com.itextpdf.text.pdf.BaseFont.createFont(r3, r4, r5, r6, r7, r8, r9);	 Catch:{ DocumentException -> 0x00f6, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
    L_0x0089:
        if (r10 != 0) goto L_0x00c9;
    L_0x008b:
        r0 = r22;
        r3 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r4 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r3 = r3.get(r4);	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r0 = r3;
        r0 = (java.lang.String) r0;	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r23 = r0;
        if (r23 != 0) goto L_0x00bb;
    L_0x009e:
        r3 = new com.itextpdf.text.Font;	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r4 = com.itextpdf.text.Font.FontFamily.UNDEFINED;	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r3.<init>(r4, r0, r1, r2);	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
        goto L_0x000f;
    L_0x00ad:
        r11 = move-exception;
        r3 = new com.itextpdf.text.ExceptionConverter;
        r3.<init>(r11);
        throw r3;
    L_0x00b4:
        r20 = r27;
        goto L_0x002a;
    L_0x00b8:
        r3 = move-exception;
        monitor-exit(r21);	 Catch:{ all -> 0x00b8 }
        throw r3;
    L_0x00bb:
        r7 = 0;
        r8 = 0;
        r3 = r23;
        r4 = r24;
        r5 = r25;
        r6 = r29;
        r10 = com.itextpdf.text.pdf.BaseFont.createFont(r3, r4, r5, r6, r7, r8);	 Catch:{ DocumentException -> 0x00ad, IOException -> 0x00d6, NullPointerException -> 0x00e6 }
    L_0x00c9:
        r3 = new com.itextpdf.text.Font;
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r3.<init>(r10, r0, r1, r2);
        goto L_0x000f;
    L_0x00d6:
        r16 = move-exception;
        r3 = new com.itextpdf.text.Font;
        r4 = com.itextpdf.text.Font.FontFamily.UNDEFINED;
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r3.<init>(r4, r0, r1, r2);
        goto L_0x000f;
    L_0x00e6:
        r19 = move-exception;
        r3 = new com.itextpdf.text.Font;
        r4 = com.itextpdf.text.Font.FontFamily.UNDEFINED;
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r3.<init>(r4, r0, r1, r2);
        goto L_0x000f;
    L_0x00f6:
        r3 = move-exception;
        goto L_0x0089;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.FontFactoryImp.getFont(java.lang.String, java.lang.String, boolean, float, int, com.itextpdf.text.BaseColor, boolean):com.itextpdf.text.Font");
    }

    public Font getFont(String fontname, String encoding, boolean embedded, float size, int style) {
        return getFont(fontname, encoding, embedded, size, style, null);
    }

    public Font getFont(String fontname, String encoding, boolean embedded, float size) {
        return getFont(fontname, encoding, embedded, size, -1, null);
    }

    public Font getFont(String fontname, String encoding, boolean embedded) {
        return getFont(fontname, encoding, embedded, -1.0f, -1, null);
    }

    public Font getFont(String fontname, String encoding, float size, int style, BaseColor color) {
        return getFont(fontname, encoding, this.defaultEmbedding, size, style, color);
    }

    public Font getFont(String fontname, String encoding, float size, int style) {
        return getFont(fontname, encoding, this.defaultEmbedding, size, style, null);
    }

    public Font getFont(String fontname, String encoding, float size) {
        return getFont(fontname, encoding, this.defaultEmbedding, size, -1, null);
    }

    public Font getFont(String fontname, float size, BaseColor color) {
        return getFont(fontname, this.defaultEncoding, this.defaultEmbedding, size, -1, color);
    }

    public Font getFont(String fontname, String encoding) {
        return getFont(fontname, encoding, this.defaultEmbedding, -1.0f, -1, null);
    }

    public Font getFont(String fontname, float size, int style, BaseColor color) {
        return getFont(fontname, this.defaultEncoding, this.defaultEmbedding, size, style, color);
    }

    public Font getFont(String fontname, float size, int style) {
        return getFont(fontname, this.defaultEncoding, this.defaultEmbedding, size, style, null);
    }

    public Font getFont(String fontname, float size) {
        return getFont(fontname, this.defaultEncoding, this.defaultEmbedding, size, -1, null);
    }

    public Font getFont(String fontname) {
        return getFont(fontname, this.defaultEncoding, this.defaultEmbedding, -1.0f, -1, null);
    }

    public void registerFamily(String familyName, String fullName, String path) {
        if (path != null) {
            this.trueTypeFonts.put(fullName, path);
        }
        synchronized (this.fontFamilies) {
            ArrayList<String> tmp = (ArrayList) this.fontFamilies.get(familyName);
            if (tmp == null) {
                tmp = new ArrayList();
                this.fontFamilies.put(familyName, tmp);
            }
        }
        synchronized (tmp) {
            if (!tmp.contains(fullName)) {
                int fullNameLength = fullName.length();
                boolean inserted = false;
                for (int j = 0; j < tmp.size(); j++) {
                    if (((String) tmp.get(j)).length() >= fullNameLength) {
                        tmp.add(j, fullName);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted) {
                    tmp.add(fullName);
                }
            }
        }
    }

    public void register(String path) {
        register(path, null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void register(java.lang.String r23, java.lang.String r24) {
        /*
        r22 = this;
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".ttf";
        r18 = r18.endsWith(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 != 0) goto L_0x0024;
    L_0x000c:
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".otf";
        r18 = r18.endsWith(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 != 0) goto L_0x0024;
    L_0x0018:
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".ttc,";
        r18 = r18.indexOf(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 <= 0) goto L_0x015d;
    L_0x0024:
        r18 = "Cp1252";
        r19 = 0;
        r0 = r23;
        r1 = r18;
        r2 = r19;
        r3 = com.itextpdf.text.pdf.BaseFont.getAllFontNames(r0, r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r22;
        r0 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r0;
        r18 = 0;
        r18 = r3[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = (java.lang.String) r18;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r19;
        r1 = r18;
        r2 = r23;
        r0.put(r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r24 == 0) goto L_0x0060;
    L_0x004d:
        r0 = r22;
        r0 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r19 = r24.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r1 = r19;
        r2 = r23;
        r0.put(r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x0060:
        r18 = 2;
        r18 = r3[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = (java.lang.String[][]) r18;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r0 = (java.lang.String[][]) r0;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r16 = r0;
        r4 = r16;
        r14 = r4.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r10 = 0;
    L_0x0070:
        if (r10 >= r14) goto L_0x008e;
    L_0x0072:
        r15 = r4[r10];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r22;
        r0 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r19 = 3;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r19.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r1 = r19;
        r2 = r23;
        r0.put(r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r10 = r10 + 1;
        goto L_0x0070;
    L_0x008e:
        r8 = 0;
        r7 = 0;
        r18 = 1;
        r18 = r3[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = (java.lang.String[][]) r18;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r0 = (java.lang.String[][]) r0;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r16 = r0;
        r12 = 0;
    L_0x009d:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r0 = r0.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r0 = r18;
        if (r12 >= r0) goto L_0x00f1;
    L_0x00a8:
        r4 = r16;
        r14 = r4.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r10 = 0;
    L_0x00ac:
        if (r10 >= r14) goto L_0x00eb;
    L_0x00ae:
        r15 = r4[r10];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18[r12];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 0;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x00ee;
    L_0x00be:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r12 + 1;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 1;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x00ee;
    L_0x00ce:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r12 + 2;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 2;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x00ee;
    L_0x00de:
        r18 = 3;
        r18 = r15[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r7 = r18.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r12 = r0.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x00eb:
        r12 = r12 + 3;
        goto L_0x009d;
    L_0x00ee:
        r10 = r10 + 1;
        goto L_0x00ac;
    L_0x00f1:
        if (r7 == 0) goto L_0x021a;
    L_0x00f3:
        r13 = "";
        r18 = 2;
        r18 = r3[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = (java.lang.String[][]) r18;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r0 = (java.lang.String[][]) r0;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r16 = r0;
        r4 = r16;
        r14 = r4.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r10 = 0;
    L_0x0105:
        if (r10 >= r14) goto L_0x021a;
    L_0x0107:
        r15 = r4[r10];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r12 = 0;
    L_0x010a:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r0 = r0.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r0 = r18;
        if (r12 >= r0) goto L_0x015a;
    L_0x0115:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18[r12];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 0;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x014d;
    L_0x0123:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r12 + 1;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 1;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x014d;
    L_0x0133:
        r18 = TTFamilyOrder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = r12 + 2;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 2;
        r19 = r15[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.equals(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x014d;
    L_0x0143:
        r18 = 3;
        r8 = r15[r18];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r8.equals(r13);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x0150;
    L_0x014d:
        r12 = r12 + 3;
        goto L_0x010a;
    L_0x0150:
        r13 = r8;
        r18 = 0;
        r0 = r22;
        r1 = r18;
        r0.registerFamily(r7, r8, r1);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x015a:
        r10 = r10 + 1;
        goto L_0x0105;
    L_0x015d:
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".ttc";
        r18 = r18.endsWith(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x01a7;
    L_0x0169:
        if (r24 == 0) goto L_0x0172;
    L_0x016b:
        r18 = LOGGER;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = "You can't define an alias for a true type collection.";
        r18.error(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x0172:
        r16 = com.itextpdf.text.pdf.BaseFont.enumerateTTCNames(r23);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r9 = 0;
    L_0x0177:
        r0 = r16;
        r0 = r0.length;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r0 = r18;
        if (r9 >= r0) goto L_0x021a;
    L_0x0180:
        r18 = new java.lang.StringBuilder;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18.<init>();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r1 = r23;
        r18 = r0.append(r1);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ",";
        r18 = r18.append(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r18;
        r18 = r0.append(r9);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.toString();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r22;
        r1 = r18;
        r0.register(r1);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r9 = r9 + 1;
        goto L_0x0177;
    L_0x01a7:
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".afm";
        r18 = r18.endsWith(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 != 0) goto L_0x01bf;
    L_0x01b3:
        r18 = r23.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = ".pfm";
        r18 = r18.endsWith(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x021a;
    L_0x01bf:
        r18 = "Cp1252";
        r19 = 0;
        r0 = r23;
        r1 = r18;
        r2 = r19;
        r5 = com.itextpdf.text.pdf.BaseFont.createFont(r0, r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r5.getFullFontName();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 0;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 3;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r8 = r18.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r5.getFamilyFontName();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 0;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = 3;
        r18 = r18[r19];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r7 = r18.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r5.getPostscriptFontName();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r17 = r18.toLowerCase();	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = 0;
        r0 = r22;
        r1 = r18;
        r0.registerFamily(r7, r8, r1);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r22;
        r0 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r0 = r18;
        r1 = r17;
        r2 = r23;
        r0.put(r1, r2);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r0 = r22;
        r0 = r0.trueTypeFonts;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r0;
        r0 = r18;
        r1 = r23;
        r0.put(r8, r1);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x021a:
        r18 = LOGGER;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = com.itextpdf.text.log.Level.TRACE;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18 = r18.isLogging(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        if (r18 == 0) goto L_0x023b;
    L_0x0224:
        r18 = LOGGER;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = "Registered %s";
        r20 = 1;
        r0 = r20;
        r0 = new java.lang.Object[r0];	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r20 = r0;
        r21 = 0;
        r20[r21] = r23;	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r19 = java.lang.String.format(r19, r20);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
        r18.trace(r19);	 Catch:{ DocumentException -> 0x023c, IOException -> 0x0245 }
    L_0x023b:
        return;
    L_0x023c:
        r6 = move-exception;
        r18 = new com.itextpdf.text.ExceptionConverter;
        r0 = r18;
        r0.<init>(r6);
        throw r18;
    L_0x0245:
        r11 = move-exception;
        r18 = new com.itextpdf.text.ExceptionConverter;
        r0 = r18;
        r0.<init>(r11);
        throw r18;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.FontFactoryImp.register(java.lang.String, java.lang.String):void");
    }

    public int registerDirectory(String dir) {
        return registerDirectory(dir, false);
    }

    public int registerDirectory(String dir, boolean scanSubdirectories) {
        if (LOGGER.isLogging(Level.DEBUG)) {
            LOGGER.debug(String.format("Registering directory %s, looking for fonts", new Object[]{dir}));
        }
        int count = 0;
        try {
            File file = new File(dir);
            if (!file.exists() || !file.isDirectory()) {
                return 0;
            }
            String[] files = file.list();
            if (files == null) {
                return 0;
            }
            int k = 0;
            File file2 = file;
            while (k < files.length) {
                try {
                    file = new File(dir, files[k]);
                    try {
                        if (!file.isDirectory()) {
                            String name = file.getPath();
                            String suffix = name.length() < 4 ? null : name.substring(name.length() - 4).toLowerCase();
                            if (".afm".equals(suffix) || ".pfm".equals(suffix)) {
                                if (new File(name.substring(0, name.length() - 4) + ".pfb").exists()) {
                                    register(name, null);
                                    count++;
                                }
                            } else if (".ttf".equals(suffix) || ".otf".equals(suffix) || ".ttc".equals(suffix)) {
                                register(name, null);
                                count++;
                            }
                        } else if (scanSubdirectories) {
                            count += registerDirectory(file.getAbsolutePath(), true);
                        }
                    } catch (Exception e) {
                    }
                } catch (Exception e2) {
                    file = file2;
                }
                k++;
                file2 = file;
            }
            return count;
        } catch (Exception e3) {
        }
    }

    public int registerDirectories() {
        int count = 0;
        String windir = System.getenv("windir");
        String fileseparator = System.getProperty("file.separator");
        if (!(windir == null || fileseparator == null)) {
            count = 0 + registerDirectory(windir + fileseparator + "fonts");
        }
        return ((((((count + registerDirectory("/usr/share/X11/fonts", true)) + registerDirectory("/usr/X/lib/X11/fonts", true)) + registerDirectory("/usr/openwin/lib/X11/fonts", true)) + registerDirectory("/usr/share/fonts", true)) + registerDirectory("/usr/X11R6/lib/X11/fonts", true)) + registerDirectory("/Library/Fonts")) + registerDirectory("/System/Library/Fonts");
    }

    public Set<String> getRegisteredFonts() {
        return this.trueTypeFonts.keySet();
    }

    public Set<String> getRegisteredFamilies() {
        return this.fontFamilies.keySet();
    }

    public boolean isRegistered(String fontname) {
        return this.trueTypeFonts.containsKey(fontname.toLowerCase());
    }
}

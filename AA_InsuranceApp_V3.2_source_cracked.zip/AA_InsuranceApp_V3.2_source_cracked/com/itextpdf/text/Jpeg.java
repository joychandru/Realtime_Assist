package com.itextpdf.text;

import com.itextpdf.text.pdf.PdfContentParser;
import com.itextpdf.xmp.XMPError;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Jpeg extends Image {
    public static final byte[] JFIF_ID;
    public static final int M_APP0 = 224;
    public static final int M_APP2 = 226;
    public static final int M_APPD = 237;
    public static final int M_APPE = 238;
    public static final int NOPARAM_MARKER = 2;
    public static final int[] NOPARAM_MARKERS;
    public static final int NOT_A_MARKER = -1;
    public static final byte[] PS_8BIM_RESO;
    public static final int UNSUPPORTED_MARKER = 1;
    public static final int[] UNSUPPORTED_MARKERS;
    public static final int VALID_MARKER = 0;
    public static final int[] VALID_MARKERS;
    private byte[][] icc;

    static {
        VALID_MARKERS = new int[]{192, 193, 194};
        UNSUPPORTED_MARKERS = new int[]{195, 197, 198, 199, PdfContentParser.COMMAND_TYPE, XMPError.BADXML, XMPError.BADRDF, XMPError.BADXMP, 205, 206, 207};
        NOPARAM_MARKERS = new int[]{208, 209, 210, 211, 212, 213, 214, 215, 216, UNSUPPORTED_MARKER};
        JFIF_ID = new byte[]{(byte) 74, (byte) 70, (byte) 73, (byte) 70, (byte) 0};
        PS_8BIM_RESO = new byte[]{(byte) 56, (byte) 66, (byte) 73, (byte) 77, (byte) 3, (byte) -19};
    }

    Jpeg(Image image) {
        super(image);
    }

    public Jpeg(URL url) throws BadElementException, IOException {
        super(url);
        processParameters();
    }

    public Jpeg(byte[] img) throws BadElementException, IOException {
        super((URL) null);
        this.rawData = img;
        this.originalData = img;
        processParameters();
    }

    public Jpeg(byte[] img, float width, float height) throws BadElementException, IOException {
        this(img);
        this.scaledWidth = width;
        this.scaledHeight = height;
    }

    private static final int getShort(InputStream is) throws IOException {
        return (is.read() << 8) + is.read();
    }

    private static final int marker(int marker) {
        int i;
        for (i = 0; i < VALID_MARKERS.length; i += UNSUPPORTED_MARKER) {
            if (marker == VALID_MARKERS[i]) {
                return 0;
            }
        }
        for (i = 0; i < NOPARAM_MARKERS.length; i += UNSUPPORTED_MARKER) {
            if (marker == NOPARAM_MARKERS[i]) {
                return NOPARAM_MARKER;
            }
        }
        for (i = 0; i < UNSUPPORTED_MARKERS.length; i += UNSUPPORTED_MARKER) {
            if (marker == UNSUPPORTED_MARKERS[i]) {
                return UNSUPPORTED_MARKER;
            }
        }
        return NOT_A_MARKER;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void processParameters() throws com.itextpdf.text.BadElementException, java.io.IOException {
        /*
        r39 = this;
        r34 = 32;
        r0 = r34;
        r1 = r39;
        r1.type = r0;
        r34 = 1;
        r0 = r34;
        r1 = r39;
        r1.originalType = r0;
        r18 = 0;
        r0 = r39;
        r0 = r0.rawData;	 Catch:{ all -> 0x005e }
        r34 = r0;
        if (r34 != 0) goto L_0x0065;
    L_0x001a:
        r0 = r39;
        r0 = r0.url;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r18 = r34.openStream();	 Catch:{ all -> 0x005e }
        r0 = r39;
        r0 = r0.url;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r13 = r34.toString();	 Catch:{ all -> 0x005e }
    L_0x002e:
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r35 = 255; // 0xff float:3.57E-43 double:1.26E-321;
        r0 = r34;
        r1 = r35;
        if (r0 != r1) goto L_0x0046;
    L_0x003a:
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r35 = 216; // 0xd8 float:3.03E-43 double:1.067E-321;
        r0 = r34;
        r1 = r35;
        if (r0 == r1) goto L_0x0079;
    L_0x0046:
        r34 = new com.itextpdf.text.BadElementException;	 Catch:{ all -> 0x005e }
        r35 = "1.is.not.a.valid.jpeg.file";
        r36 = 1;
        r0 = r36;
        r0 = new java.lang.Object[r0];	 Catch:{ all -> 0x005e }
        r36 = r0;
        r37 = 0;
        r36[r37] = r13;	 Catch:{ all -> 0x005e }
        r35 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r35, r36);	 Catch:{ all -> 0x005e }
        r34.<init>(r35);	 Catch:{ all -> 0x005e }
        throw r34;	 Catch:{ all -> 0x005e }
    L_0x005e:
        r34 = move-exception;
    L_0x005f:
        if (r18 == 0) goto L_0x0064;
    L_0x0061:
        r18.close();
    L_0x0064:
        throw r34;
    L_0x0065:
        r19 = new java.io.ByteArrayInputStream;	 Catch:{ all -> 0x005e }
        r0 = r39;
        r0 = r0.rawData;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r19;
        r1 = r34;
        r0.<init>(r1);	 Catch:{ all -> 0x005e }
        r13 = "Byte array";
        r18 = r19;
        goto L_0x002e;
    L_0x0079:
        r15 = 1;
    L_0x007a:
        r33 = r18.read();	 Catch:{ all -> 0x005e }
        if (r33 >= 0) goto L_0x0094;
    L_0x0080:
        r34 = new java.io.IOException;	 Catch:{ all -> 0x005e }
        r35 = "premature.eof.while.reading.jpg";
        r36 = 0;
        r0 = r36;
        r0 = new java.lang.Object[r0];	 Catch:{ all -> 0x005e }
        r36 = r0;
        r35 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r35, r36);	 Catch:{ all -> 0x005e }
        r34.<init>(r35);	 Catch:{ all -> 0x005e }
        throw r34;	 Catch:{ all -> 0x005e }
    L_0x0094:
        r34 = 255; // 0xff float:3.57E-43 double:1.26E-321;
        r0 = r33;
        r1 = r34;
        if (r0 != r1) goto L_0x007a;
    L_0x009c:
        r23 = r18.read();	 Catch:{ all -> 0x005e }
        if (r15 == 0) goto L_0x0191;
    L_0x00a2:
        r34 = 224; // 0xe0 float:3.14E-43 double:1.107E-321;
        r0 = r23;
        r1 = r34;
        if (r0 != r1) goto L_0x0191;
    L_0x00aa:
        r15 = 0;
        r22 = getShort(r18);	 Catch:{ all -> 0x005e }
        r34 = 16;
        r0 = r22;
        r1 = r34;
        if (r0 >= r1) goto L_0x00c1;
    L_0x00b7:
        r34 = r22 + -2;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x00c1:
        r34 = JFIF_ID;	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r6 = new byte[r0];	 Catch:{ all -> 0x005e }
        r0 = r18;
        r27 = r0.read(r6);	 Catch:{ all -> 0x005e }
        r0 = r6.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r27;
        r1 = r34;
        if (r0 == r1) goto L_0x00f3;
    L_0x00db:
        r34 = new com.itextpdf.text.BadElementException;	 Catch:{ all -> 0x005e }
        r35 = "1.corrupted.jfif.marker";
        r36 = 1;
        r0 = r36;
        r0 = new java.lang.Object[r0];	 Catch:{ all -> 0x005e }
        r36 = r0;
        r37 = 0;
        r36[r37] = r13;	 Catch:{ all -> 0x005e }
        r35 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r35, r36);	 Catch:{ all -> 0x005e }
        r34.<init>(r35);	 Catch:{ all -> 0x005e }
        throw r34;	 Catch:{ all -> 0x005e }
    L_0x00f3:
        r16 = 1;
        r21 = 0;
    L_0x00f7:
        r0 = r6.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r21;
        r1 = r34;
        if (r0 >= r1) goto L_0x010e;
    L_0x0100:
        r34 = r6[r21];	 Catch:{ all -> 0x005e }
        r35 = JFIF_ID;	 Catch:{ all -> 0x005e }
        r35 = r35[r21];	 Catch:{ all -> 0x005e }
        r0 = r34;
        r1 = r35;
        if (r0 == r1) goto L_0x0120;
    L_0x010c:
        r16 = 0;
    L_0x010e:
        if (r16 != 0) goto L_0x0123;
    L_0x0110:
        r34 = r22 + -2;
        r0 = r6.length;	 Catch:{ all -> 0x005e }
        r35 = r0;
        r34 = r34 - r35;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x0120:
        r21 = r21 + 1;
        goto L_0x00f7;
    L_0x0123:
        r34 = 2;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        r30 = r18.read();	 Catch:{ all -> 0x005e }
        r11 = getShort(r18);	 Catch:{ all -> 0x005e }
        r12 = getShort(r18);	 Catch:{ all -> 0x005e }
        r34 = 1;
        r0 = r30;
        r1 = r34;
        if (r0 != r1) goto L_0x015a;
    L_0x0140:
        r0 = r39;
        r0.dpiX = r11;	 Catch:{ all -> 0x005e }
        r0 = r39;
        r0.dpiY = r12;	 Catch:{ all -> 0x005e }
    L_0x0148:
        r34 = r22 + -2;
        r0 = r6.length;	 Catch:{ all -> 0x005e }
        r35 = r0;
        r34 = r34 - r35;
        r34 = r34 + -7;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x015a:
        r34 = 2;
        r0 = r30;
        r1 = r34;
        if (r0 != r1) goto L_0x0148;
    L_0x0162:
        r0 = (float) r11;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 1076006748; // 0x40228f5c float:2.54 double:5.31617969E-315;
        r34 = r34 * r35;
        r35 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r34 = r34 + r35;
        r0 = r34;
        r0 = (int) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r1 = r39;
        r1.dpiX = r0;	 Catch:{ all -> 0x005e }
        r0 = (float) r12;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 1076006748; // 0x40228f5c float:2.54 double:5.31617969E-315;
        r34 = r34 * r35;
        r35 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r34 = r34 + r35;
        r0 = r34;
        r0 = (int) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r1 = r39;
        r1.dpiY = r0;	 Catch:{ all -> 0x005e }
        goto L_0x0148;
    L_0x0191:
        r34 = 238; // 0xee float:3.34E-43 double:1.176E-321;
        r0 = r23;
        r1 = r34;
        if (r0 != r1) goto L_0x01e9;
    L_0x0199:
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r22 = r34 + -2;
        r0 = r22;
        r9 = new byte[r0];	 Catch:{ all -> 0x005e }
        r21 = 0;
    L_0x01a5:
        r0 = r21;
        r1 = r22;
        if (r0 >= r1) goto L_0x01b9;
    L_0x01ab:
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = (byte) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r9[r21] = r34;	 Catch:{ all -> 0x005e }
        r21 = r21 + 1;
        goto L_0x01a5;
    L_0x01b9:
        r0 = r9.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 12;
        r0 = r34;
        r1 = r35;
        if (r0 < r1) goto L_0x007a;
    L_0x01c4:
        r5 = new java.lang.String;	 Catch:{ all -> 0x005e }
        r34 = 0;
        r35 = 5;
        r36 = "ISO-8859-1";
        r0 = r34;
        r1 = r35;
        r2 = r36;
        r5.<init>(r9, r0, r1, r2);	 Catch:{ all -> 0x005e }
        r34 = "Adobe";
        r0 = r34;
        r34 = r5.equals(r0);	 Catch:{ all -> 0x005e }
        if (r34 == 0) goto L_0x007a;
    L_0x01df:
        r34 = 1;
        r0 = r34;
        r1 = r39;
        r1.invert = r0;	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x01e9:
        r34 = 226; // 0xe2 float:3.17E-43 double:1.117E-321;
        r0 = r23;
        r1 = r34;
        if (r0 != r1) goto L_0x0278;
    L_0x01f1:
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r22 = r34 + -2;
        r0 = r22;
        r7 = new byte[r0];	 Catch:{ all -> 0x005e }
        r21 = 0;
    L_0x01fd:
        r0 = r21;
        r1 = r22;
        if (r0 >= r1) goto L_0x0211;
    L_0x0203:
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = (byte) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r7[r21] = r34;	 Catch:{ all -> 0x005e }
        r21 = r21 + 1;
        goto L_0x01fd;
    L_0x0211:
        r0 = r7.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 14;
        r0 = r34;
        r1 = r35;
        if (r0 < r1) goto L_0x007a;
    L_0x021c:
        r4 = new java.lang.String;	 Catch:{ all -> 0x005e }
        r34 = 0;
        r35 = 11;
        r36 = "ISO-8859-1";
        r0 = r34;
        r1 = r35;
        r2 = r36;
        r4.<init>(r7, r0, r1, r2);	 Catch:{ all -> 0x005e }
        r34 = "ICC_PROFILE";
        r0 = r34;
        r34 = r4.equals(r0);	 Catch:{ all -> 0x005e }
        if (r34 == 0) goto L_0x007a;
    L_0x0237:
        r34 = 12;
        r34 = r7[r34];	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0 & 255;
        r26 = r0;
        r34 = 13;
        r34 = r7[r34];	 Catch:{ all -> 0x005e }
        r0 = r34;
        r10 = r0 & 255;
        r34 = 1;
        r0 = r26;
        r1 = r34;
        if (r0 >= r1) goto L_0x0253;
    L_0x0251:
        r26 = 1;
    L_0x0253:
        r34 = 1;
        r0 = r34;
        if (r10 >= r0) goto L_0x025a;
    L_0x0259:
        r10 = 1;
    L_0x025a:
        r0 = r39;
        r0 = r0.icc;	 Catch:{ all -> 0x005e }
        r34 = r0;
        if (r34 != 0) goto L_0x026c;
    L_0x0262:
        r0 = new byte[r10][];	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r1 = r39;
        r1.icc = r0;	 Catch:{ all -> 0x005e }
    L_0x026c:
        r0 = r39;
        r0 = r0.icc;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = r26 + -1;
        r34[r35] = r7;	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x0278:
        r34 = 237; // 0xed float:3.32E-43 double:1.17E-321;
        r0 = r23;
        r1 = r34;
        if (r0 != r1) goto L_0x03ff;
    L_0x0280:
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r22 = r34 + -2;
        r0 = r22;
        r8 = new byte[r0];	 Catch:{ all -> 0x005e }
        r21 = 0;
    L_0x028c:
        r0 = r21;
        r1 = r22;
        if (r0 >= r1) goto L_0x02a0;
    L_0x0292:
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = (byte) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r8[r21] = r34;	 Catch:{ all -> 0x005e }
        r21 = r21 + 1;
        goto L_0x028c;
    L_0x02a0:
        r21 = 0;
        r21 = 0;
    L_0x02a4:
        r34 = PS_8BIM_RESO;	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r34 = r22 - r34;
        r0 = r21;
        r1 = r34;
        if (r0 >= r1) goto L_0x02d6;
    L_0x02b3:
        r16 = 1;
        r20 = 0;
    L_0x02b7:
        r34 = PS_8BIM_RESO;	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r20;
        r1 = r34;
        if (r0 >= r1) goto L_0x02d4;
    L_0x02c4:
        r34 = r21 + r20;
        r34 = r8[r34];	 Catch:{ all -> 0x005e }
        r35 = PS_8BIM_RESO;	 Catch:{ all -> 0x005e }
        r35 = r35[r20];	 Catch:{ all -> 0x005e }
        r0 = r34;
        r1 = r35;
        if (r0 == r1) goto L_0x03f2;
    L_0x02d2:
        r16 = 0;
    L_0x02d4:
        if (r16 == 0) goto L_0x03f6;
    L_0x02d6:
        r34 = PS_8BIM_RESO;	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r21 = r21 + r34;
        r34 = PS_8BIM_RESO;	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = r0.length;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r34 = r22 - r34;
        r0 = r21;
        r1 = r34;
        if (r0 >= r1) goto L_0x007a;
    L_0x02ee:
        r25 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r25 + 1;
        r0 = r34;
        r0 = (byte) r0;	 Catch:{ all -> 0x005e }
        r25 = r0;
        r34 = r25 % 2;
        r35 = 1;
        r0 = r34;
        r1 = r35;
        if (r0 != r1) goto L_0x0308;
    L_0x0301:
        r34 = r25 + 1;
        r0 = r34;
        r0 = (byte) r0;	 Catch:{ all -> 0x005e }
        r25 = r0;
    L_0x0308:
        r21 = r21 + r25;
        r34 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r34 << 24;
        r35 = r21 + 1;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r35 = r35 << 16;
        r34 = r34 + r35;
        r35 = r21 + 2;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r35 = r35 << 8;
        r34 = r34 + r35;
        r35 = r21 + 3;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r28 = r34 + r35;
        r34 = 16;
        r0 = r28;
        r1 = r34;
        if (r0 != r1) goto L_0x007a;
    L_0x032c:
        r21 = r21 + 4;
        r34 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r34 << 8;
        r35 = r21 + 1;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r0 = r35;
        r0 = r0 & 255;
        r35 = r0;
        r11 = r34 + r35;
        r21 = r21 + 2;
        r21 = r21 + 2;
        r34 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r34 << 8;
        r35 = r21 + 1;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r0 = r35;
        r0 = r0 & 255;
        r35 = r0;
        r31 = r34 + r35;
        r21 = r21 + 2;
        r21 = r21 + 2;
        r34 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r34 << 8;
        r35 = r21 + 1;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r0 = r35;
        r0 = r0 & 255;
        r35 = r0;
        r12 = r34 + r35;
        r21 = r21 + 2;
        r21 = r21 + 2;
        r34 = r8[r21];	 Catch:{ all -> 0x005e }
        r34 = r34 << 8;
        r35 = r21 + 1;
        r35 = r8[r35];	 Catch:{ all -> 0x005e }
        r0 = r35;
        r0 = r0 & 255;
        r35 = r0;
        r32 = r34 + r35;
        r34 = 1;
        r0 = r31;
        r1 = r34;
        if (r0 == r1) goto L_0x038a;
    L_0x0382:
        r34 = 2;
        r0 = r31;
        r1 = r34;
        if (r0 != r1) goto L_0x03b3;
    L_0x038a:
        r34 = 2;
        r0 = r31;
        r1 = r34;
        if (r0 != r1) goto L_0x03a1;
    L_0x0392:
        r0 = (float) r11;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 1076006748; // 0x40228f5c float:2.54 double:5.31617969E-315;
        r34 = r34 * r35;
        r35 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r34 = r34 + r35;
        r0 = r34;
        r11 = (int) r0;	 Catch:{ all -> 0x005e }
    L_0x03a1:
        r0 = r39;
        r0 = r0.dpiX;	 Catch:{ all -> 0x005e }
        r34 = r0;
        if (r34 == 0) goto L_0x03fa;
    L_0x03a9:
        r0 = r39;
        r0 = r0.dpiX;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        if (r0 == r11) goto L_0x03fa;
    L_0x03b3:
        r34 = 1;
        r0 = r32;
        r1 = r34;
        if (r0 == r1) goto L_0x03c3;
    L_0x03bb:
        r34 = 2;
        r0 = r32;
        r1 = r34;
        if (r0 != r1) goto L_0x007a;
    L_0x03c3:
        r34 = 2;
        r0 = r32;
        r1 = r34;
        if (r0 != r1) goto L_0x03da;
    L_0x03cb:
        r0 = (float) r12;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r35 = 1076006748; // 0x40228f5c float:2.54 double:5.31617969E-315;
        r34 = r34 * r35;
        r35 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r34 = r34 + r35;
        r0 = r34;
        r12 = (int) r0;	 Catch:{ all -> 0x005e }
    L_0x03da:
        r0 = r39;
        r0 = r0.dpiY;	 Catch:{ all -> 0x005e }
        r34 = r0;
        if (r34 == 0) goto L_0x03ec;
    L_0x03e2:
        r0 = r39;
        r0 = r0.dpiY;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        if (r0 != r12) goto L_0x007a;
    L_0x03ec:
        r0 = r39;
        r0.dpiY = r12;	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x03f2:
        r20 = r20 + 1;
        goto L_0x02b7;
    L_0x03f6:
        r21 = r21 + 1;
        goto L_0x02a4;
    L_0x03fa:
        r0 = r39;
        r0.dpiX = r11;	 Catch:{ all -> 0x005e }
        goto L_0x03b3;
    L_0x03ff:
        r15 = 0;
        r24 = marker(r23);	 Catch:{ all -> 0x005e }
        if (r24 != 0) goto L_0x04c8;
    L_0x0406:
        r34 = 2;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r35 = 8;
        r0 = r34;
        r1 = r35;
        if (r0 == r1) goto L_0x0433;
    L_0x041b:
        r34 = new com.itextpdf.text.BadElementException;	 Catch:{ all -> 0x005e }
        r35 = "1.must.have.8.bits.per.component";
        r36 = 1;
        r0 = r36;
        r0 = new java.lang.Object[r0];	 Catch:{ all -> 0x005e }
        r36 = r0;
        r37 = 0;
        r36[r37] = r13;	 Catch:{ all -> 0x005e }
        r35 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r35, r36);	 Catch:{ all -> 0x005e }
        r34.<init>(r35);	 Catch:{ all -> 0x005e }
        throw r34;	 Catch:{ all -> 0x005e }
    L_0x0433:
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = (float) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r1 = r39;
        r1.scaledHeight = r0;	 Catch:{ all -> 0x005e }
        r0 = r39;
        r0 = r0.scaledHeight;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r39;
        r1 = r34;
        r0.setTop(r1);	 Catch:{ all -> 0x005e }
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r0 = r34;
        r0 = (float) r0;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r34;
        r1 = r39;
        r1.scaledWidth = r0;	 Catch:{ all -> 0x005e }
        r0 = r39;
        r0 = r0.scaledWidth;	 Catch:{ all -> 0x005e }
        r34 = r0;
        r0 = r39;
        r1 = r34;
        r0.setRight(r1);	 Catch:{ all -> 0x005e }
        r34 = r18.read();	 Catch:{ all -> 0x005e }
        r0 = r34;
        r1 = r39;
        r1.colorspace = r0;	 Catch:{ all -> 0x005e }
        r34 = 8;
        r0 = r34;
        r1 = r39;
        r1.bpc = r0;	 Catch:{ all -> 0x005e }
        if (r18 == 0) goto L_0x0482;
    L_0x047f:
        r18.close();
    L_0x0482:
        r34 = r39.getWidth();
        r0 = r34;
        r1 = r39;
        r1.plainWidth = r0;
        r34 = r39.getHeight();
        r0 = r34;
        r1 = r39;
        r1.plainHeight = r0;
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        if (r34 == 0) goto L_0x04c7;
    L_0x049e:
        r29 = 0;
        r21 = 0;
    L_0x04a2:
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r0 = r34;
        r0 = r0.length;
        r34 = r0;
        r0 = r21;
        r1 = r34;
        if (r0 >= r1) goto L_0x051b;
    L_0x04b3:
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r34 = r34[r21];
        if (r34 != 0) goto L_0x0507;
    L_0x04bd:
        r34 = 0;
        r34 = (byte[][]) r34;
        r0 = r34;
        r1 = r39;
        r1.icc = r0;
    L_0x04c7:
        return;
    L_0x04c8:
        r34 = 1;
        r0 = r24;
        r1 = r34;
        if (r0 != r1) goto L_0x04f0;
    L_0x04d0:
        r34 = new com.itextpdf.text.BadElementException;	 Catch:{ all -> 0x005e }
        r35 = "1.unsupported.jpeg.marker.2";
        r36 = 2;
        r0 = r36;
        r0 = new java.lang.Object[r0];	 Catch:{ all -> 0x005e }
        r36 = r0;
        r37 = 0;
        r36[r37] = r13;	 Catch:{ all -> 0x005e }
        r37 = 1;
        r38 = java.lang.String.valueOf(r23);	 Catch:{ all -> 0x005e }
        r36[r37] = r38;	 Catch:{ all -> 0x005e }
        r35 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r35, r36);	 Catch:{ all -> 0x005e }
        r34.<init>(r35);	 Catch:{ all -> 0x005e }
        throw r34;	 Catch:{ all -> 0x005e }
    L_0x04f0:
        r34 = 2;
        r0 = r24;
        r1 = r34;
        if (r0 == r1) goto L_0x007a;
    L_0x04f8:
        r34 = getShort(r18);	 Catch:{ all -> 0x005e }
        r34 = r34 + -2;
        r0 = r18;
        r1 = r34;
        com.itextpdf.text.Utilities.skip(r0, r1);	 Catch:{ all -> 0x005e }
        goto L_0x007a;
    L_0x0507:
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r34 = r34[r21];
        r0 = r34;
        r0 = r0.length;
        r34 = r0;
        r34 = r34 + -14;
        r29 = r29 + r34;
        r21 = r21 + 1;
        goto L_0x04a2;
    L_0x051b:
        r0 = r29;
        r14 = new byte[r0];
        r29 = 0;
        r21 = 0;
    L_0x0523:
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r0 = r34;
        r0 = r0.length;
        r34 = r0;
        r0 = r21;
        r1 = r34;
        if (r0 >= r1) goto L_0x056c;
    L_0x0534:
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r34 = r34[r21];
        r35 = 14;
        r0 = r39;
        r0 = r0.icc;
        r36 = r0;
        r36 = r36[r21];
        r0 = r36;
        r0 = r0.length;
        r36 = r0;
        r36 = r36 + -14;
        r0 = r34;
        r1 = r35;
        r2 = r29;
        r3 = r36;
        java.lang.System.arraycopy(r0, r1, r14, r2, r3);
        r0 = r39;
        r0 = r0.icc;
        r34 = r0;
        r34 = r34[r21];
        r0 = r34;
        r0 = r0.length;
        r34 = r0;
        r34 = r34 + -14;
        r29 = r29 + r34;
        r21 = r21 + 1;
        goto L_0x0523;
    L_0x056c:
        r0 = r39;
        r0 = r0.colorspace;	 Catch:{ IllegalArgumentException -> 0x058b }
        r34 = r0;
        r0 = r34;
        r17 = com.itextpdf.text.pdf.ICC_Profile.getInstance(r14, r0);	 Catch:{ IllegalArgumentException -> 0x058b }
        r0 = r39;
        r1 = r17;
        r0.tagICC(r1);	 Catch:{ IllegalArgumentException -> 0x058b }
    L_0x057f:
        r34 = 0;
        r34 = (byte[][]) r34;
        r0 = r34;
        r1 = r39;
        r1.icc = r0;
        goto L_0x04c7;
    L_0x058b:
        r34 = move-exception;
        goto L_0x057f;
    L_0x058d:
        r34 = move-exception;
        r18 = r19;
        goto L_0x005f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.Jpeg.processParameters():void");
    }
}

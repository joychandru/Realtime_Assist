package com.itextpdf.text.log;

public class LoggerFactory {
    private static LoggerFactory myself;
    private Logger logger;

    static {
        myself = new LoggerFactory();
    }

    public static Logger getLogger(Class<?> klass) {
        return myself.logger.getLogger((Class) klass);
    }

    public static Logger getLogger(String name) {
        return myself.logger.getLogger(name);
    }

    public static LoggerFactory getInstance() {
        return myself;
    }

    private LoggerFactory() {
        this.logger = new NoOpLogger();
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public Logger logger() {
        return this.logger;
    }
}

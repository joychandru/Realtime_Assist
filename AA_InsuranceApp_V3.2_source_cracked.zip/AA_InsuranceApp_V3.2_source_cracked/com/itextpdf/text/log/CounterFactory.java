package com.itextpdf.text.log;

public class CounterFactory {
    private static CounterFactory myself;
    private Counter counter;

    static {
        myself = new CounterFactory();
    }

    private CounterFactory() {
        this.counter = new NoOpCounter();
    }

    public static CounterFactory getInstance() {
        return myself;
    }

    public static Counter getCounter(Class<?> klass) {
        return myself.counter.getCounter(klass);
    }

    public Counter getCounter() {
        return this.counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }
}

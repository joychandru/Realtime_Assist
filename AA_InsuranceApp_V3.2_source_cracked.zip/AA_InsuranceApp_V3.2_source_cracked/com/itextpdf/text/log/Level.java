package com.itextpdf.text.log;

public enum Level {
    ERROR,
    WARN,
    INFO,
    DEBUG,
    TRACE
}

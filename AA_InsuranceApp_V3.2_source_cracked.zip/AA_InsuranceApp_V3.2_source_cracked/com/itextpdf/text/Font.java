package com.itextpdf.text;

import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.text.html.HtmlUtilities;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfObject;

public class Font implements Comparable<Font> {
    public static final int BOLD = 1;
    public static final int BOLDITALIC = 3;
    public static final int DEFAULTSIZE = 12;
    public static final int ITALIC = 2;
    public static final int NORMAL = 0;
    public static final int STRIKETHRU = 8;
    public static final int UNDEFINED = -1;
    public static final int UNDERLINE = 4;
    private BaseFont baseFont;
    private BaseColor color;
    private FontFamily family;
    private float size;
    private int style;

    /* renamed from: com.itextpdf.text.Font.1 */
    static /* synthetic */ class C00291 {
        static final /* synthetic */ int[] $SwitchMap$com$itextpdf$text$Font$FontFamily;

        static {
            $SwitchMap$com$itextpdf$text$Font$FontFamily = new int[FontFamily.values().length];
            try {
                $SwitchMap$com$itextpdf$text$Font$FontFamily[FontFamily.COURIER.ordinal()] = Font.BOLD;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$itextpdf$text$Font$FontFamily[FontFamily.HELVETICA.ordinal()] = Font.ITALIC;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$itextpdf$text$Font$FontFamily[FontFamily.TIMES_ROMAN.ordinal()] = Font.BOLDITALIC;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$itextpdf$text$Font$FontFamily[FontFamily.SYMBOL.ordinal()] = Font.UNDERLINE;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$itextpdf$text$Font$FontFamily[FontFamily.ZAPFDINGBATS.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }

    public enum FontFamily {
        COURIER,
        HELVETICA,
        TIMES_ROMAN,
        SYMBOL,
        ZAPFDINGBATS,
        UNDEFINED
    }

    public enum FontStyle {
        NORMAL(HtmlTags.NORMAL),
        BOLD(HtmlTags.BOLD),
        ITALIC(HtmlTags.ITALIC),
        OBLIQUE(HtmlTags.OBLIQUE),
        UNDERLINE(HtmlTags.UNDERLINE),
        LINETHROUGH(HtmlTags.LINETHROUGH);
        
        private String code;

        private FontStyle(String code) {
            this.code = code;
        }

        public String getValue() {
            return this.code;
        }
    }

    public Font(Font other) {
        this.family = FontFamily.UNDEFINED;
        this.size = -1.0f;
        this.style = UNDEFINED;
        this.color = null;
        this.baseFont = null;
        this.family = other.family;
        this.size = other.size;
        this.style = other.style;
        this.color = other.color;
        this.baseFont = other.baseFont;
    }

    public Font(FontFamily family, float size, int style, BaseColor color) {
        this.family = FontFamily.UNDEFINED;
        this.size = -1.0f;
        this.style = UNDEFINED;
        this.color = null;
        this.baseFont = null;
        this.family = family;
        this.size = size;
        this.style = style;
        this.color = color;
    }

    public Font(BaseFont bf, float size, int style, BaseColor color) {
        this.family = FontFamily.UNDEFINED;
        this.size = -1.0f;
        this.style = UNDEFINED;
        this.color = null;
        this.baseFont = null;
        this.baseFont = bf;
        this.size = size;
        this.style = style;
        this.color = color;
    }

    public Font(BaseFont bf, float size, int style) {
        this(bf, size, style, null);
    }

    public Font(BaseFont bf, float size) {
        this(bf, size, (int) UNDEFINED, null);
    }

    public Font(BaseFont bf) {
        this(bf, -1.0f, (int) UNDEFINED, null);
    }

    public Font(FontFamily family, float size, int style) {
        this(family, size, style, null);
    }

    public Font(FontFamily family, float size) {
        this(family, size, (int) UNDEFINED, null);
    }

    public Font(FontFamily family) {
        this(family, -1.0f, (int) UNDEFINED, null);
    }

    public Font() {
        this(FontFamily.UNDEFINED, -1.0f, (int) UNDEFINED, null);
    }

    public int compareTo(Font font) {
        if (font == null) {
            return UNDEFINED;
        }
        try {
            if (this.baseFont != null && !this.baseFont.equals(font.getBaseFont())) {
                return -2;
            }
            if (this.family != font.getFamily()) {
                return BOLD;
            }
            if (this.size != font.getSize()) {
                return ITALIC;
            }
            if (this.style != font.getStyle()) {
                return BOLDITALIC;
            }
            if (this.color == null) {
                if (font.color != null) {
                    return UNDERLINE;
                }
                return NORMAL;
            } else if (font.color == null) {
                return UNDERLINE;
            } else {
                if (this.color.equals(font.getColor())) {
                    return NORMAL;
                }
                return UNDERLINE;
            }
        } catch (ClassCastException e) {
            return -3;
        }
    }

    public FontFamily getFamily() {
        return this.family;
    }

    public String getFamilyname() {
        String tmp = Meta.UNKNOWN;
        switch (C00291.$SwitchMap$com$itextpdf$text$Font$FontFamily[getFamily().ordinal()]) {
            case BOLD /*1*/:
                return BaseFont.COURIER;
            case ITALIC /*2*/:
                return BaseFont.HELVETICA;
            case BOLDITALIC /*3*/:
                return BaseFont.TIMES_ROMAN;
            case UNDERLINE /*4*/:
                return BaseFont.SYMBOL;
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                return BaseFont.ZAPFDINGBATS;
            default:
                if (this.baseFont != null) {
                    String[][] arr$ = this.baseFont.getFamilyFontName();
                    int len$ = arr$.length;
                    for (int i$ = NORMAL; i$ < len$; i$ += BOLD) {
                        String[] name = arr$[i$];
                        if ("0".equals(name[ITALIC])) {
                            return name[BOLDITALIC];
                        }
                        if ("1033".equals(name[ITALIC])) {
                            tmp = name[BOLDITALIC];
                        }
                        if (PdfObject.NOTHING.equals(name[ITALIC])) {
                            tmp = name[BOLDITALIC];
                        }
                    }
                }
                return tmp;
        }
    }

    public void setFamily(String family) {
        this.family = getFamily(family);
    }

    public static FontFamily getFamily(String family) {
        if (family.equalsIgnoreCase(BaseFont.COURIER)) {
            return FontFamily.COURIER;
        }
        if (family.equalsIgnoreCase(BaseFont.HELVETICA)) {
            return FontFamily.HELVETICA;
        }
        if (family.equalsIgnoreCase(BaseFont.TIMES_ROMAN)) {
            return FontFamily.TIMES_ROMAN;
        }
        if (family.equalsIgnoreCase(BaseFont.SYMBOL)) {
            return FontFamily.SYMBOL;
        }
        if (family.equalsIgnoreCase(BaseFont.ZAPFDINGBATS)) {
            return FontFamily.ZAPFDINGBATS;
        }
        return FontFamily.UNDEFINED;
    }

    public float getSize() {
        return this.size;
    }

    public float getCalculatedSize() {
        float s = this.size;
        if (s == -1.0f) {
            return HtmlUtilities.DEFAULT_FONT_SIZE;
        }
        return s;
    }

    public float getCalculatedLeading(float linespacing) {
        return getCalculatedSize() * linespacing;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public int getStyle() {
        return this.style;
    }

    public int getCalculatedStyle() {
        int style = this.style;
        if (style == UNDEFINED) {
            style = NORMAL;
        }
        return (this.baseFont != null || this.family == FontFamily.SYMBOL || this.family == FontFamily.ZAPFDINGBATS) ? style : style & -4;
    }

    public boolean isBold() {
        boolean z = true;
        if (this.style == UNDEFINED) {
            return false;
        }
        if ((this.style & BOLD) != BOLD) {
            z = false;
        }
        return z;
    }

    public boolean isItalic() {
        if (this.style != UNDEFINED && (this.style & ITALIC) == ITALIC) {
            return true;
        }
        return false;
    }

    public boolean isUnderlined() {
        if (this.style != UNDEFINED && (this.style & UNDERLINE) == UNDERLINE) {
            return true;
        }
        return false;
    }

    public boolean isStrikethru() {
        if (this.style != UNDEFINED && (this.style & STRIKETHRU) == STRIKETHRU) {
            return true;
        }
        return false;
    }

    public void setStyle(int style) {
        this.style = style;
    }

    public void setStyle(String style) {
        if (this.style == UNDEFINED) {
            this.style = NORMAL;
        }
        this.style |= getStyleValue(style);
    }

    public static int getStyleValue(String style) {
        int s = NORMAL;
        if (style.indexOf(FontStyle.NORMAL.getValue()) != UNDEFINED) {
            s = NORMAL | NORMAL;
        }
        if (style.indexOf(FontStyle.BOLD.getValue()) != UNDEFINED) {
            s |= BOLD;
        }
        if (style.indexOf(FontStyle.ITALIC.getValue()) != UNDEFINED) {
            s |= ITALIC;
        }
        if (style.indexOf(FontStyle.OBLIQUE.getValue()) != UNDEFINED) {
            s |= ITALIC;
        }
        if (style.indexOf(FontStyle.UNDERLINE.getValue()) != UNDEFINED) {
            s |= UNDERLINE;
        }
        if (style.indexOf(FontStyle.LINETHROUGH.getValue()) != UNDEFINED) {
            return s | STRIKETHRU;
        }
        return s;
    }

    public BaseColor getColor() {
        return this.color;
    }

    public void setColor(BaseColor color) {
        this.color = color;
    }

    public void setColor(int red, int green, int blue) {
        this.color = new BaseColor(red, green, blue);
    }

    public BaseFont getBaseFont() {
        return this.baseFont;
    }

    public BaseFont getCalculatedBaseFont(boolean specialEncoding) {
        if (this.baseFont != null) {
            return this.baseFont;
        }
        int style = this.style;
        if (style == UNDEFINED) {
            style = NORMAL;
        }
        String fontName = BaseFont.HELVETICA;
        String encoding = BaseFont.WINANSI;
        switch (C00291.$SwitchMap$com$itextpdf$text$Font$FontFamily[this.family.ordinal()]) {
            case BOLD /*1*/:
                switch (style & BOLDITALIC) {
                    case BOLD /*1*/:
                        fontName = BaseFont.COURIER_BOLD;
                        break;
                    case ITALIC /*2*/:
                        fontName = BaseFont.COURIER_OBLIQUE;
                        break;
                    case BOLDITALIC /*3*/:
                        fontName = BaseFont.COURIER_BOLDOBLIQUE;
                        break;
                    default:
                        fontName = BaseFont.COURIER;
                        break;
                }
            case BOLDITALIC /*3*/:
                switch (style & BOLDITALIC) {
                    case BOLD /*1*/:
                        fontName = BaseFont.TIMES_BOLD;
                        break;
                    case ITALIC /*2*/:
                        fontName = BaseFont.TIMES_ITALIC;
                        break;
                    case BOLDITALIC /*3*/:
                        fontName = BaseFont.TIMES_BOLDITALIC;
                        break;
                    default:
                        fontName = BaseFont.TIMES_ROMAN;
                        break;
                }
            case UNDERLINE /*4*/:
                fontName = BaseFont.SYMBOL;
                if (specialEncoding) {
                    encoding = BaseFont.SYMBOL;
                    break;
                }
                break;
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                fontName = BaseFont.ZAPFDINGBATS;
                if (specialEncoding) {
                    encoding = BaseFont.ZAPFDINGBATS;
                    break;
                }
                break;
            default:
                switch (style & BOLDITALIC) {
                    case BOLD /*1*/:
                        fontName = BaseFont.HELVETICA_BOLD;
                        break;
                    case ITALIC /*2*/:
                        fontName = BaseFont.HELVETICA_OBLIQUE;
                        break;
                    case BOLDITALIC /*3*/:
                        fontName = BaseFont.HELVETICA_BOLDOBLIQUE;
                        break;
                    default:
                        fontName = BaseFont.HELVETICA;
                        break;
                }
        }
        try {
            return BaseFont.createFont(fontName, encoding, false);
        } catch (Exception ee) {
            throw new ExceptionConverter(ee);
        }
    }

    public boolean isStandardFont() {
        return this.family == FontFamily.UNDEFINED && this.size == -1.0f && this.style == UNDEFINED && this.color == null && this.baseFont == null;
    }

    public Font difference(Font font) {
        if (font == null) {
            return this;
        }
        float dSize = font.size;
        if (dSize == -1.0f) {
            dSize = this.size;
        }
        int dStyle = UNDEFINED;
        int style1 = this.style;
        int style2 = font.getStyle();
        if (!(style1 == UNDEFINED && style2 == UNDEFINED)) {
            if (style1 == UNDEFINED) {
                style1 = NORMAL;
            }
            if (style2 == UNDEFINED) {
                style2 = NORMAL;
            }
            dStyle = style1 | style2;
        }
        BaseColor dColor = font.color;
        if (dColor == null) {
            dColor = this.color;
        }
        if (font.baseFont != null) {
            this(font.baseFont, dSize, dStyle, dColor);
            return this;
        } else if (font.getFamily() != FontFamily.UNDEFINED) {
            this(font.family, dSize, dStyle, dColor);
            return this;
        } else if (this.baseFont == null) {
            return new Font(this.family, dSize, dStyle, dColor);
        } else {
            if (dStyle == style1) {
                return new Font(this.baseFont, dSize, dStyle, dColor);
            }
            return FontFactory.getFont(getFamilyname(), dSize, dStyle, dColor);
        }
    }
}

package com.itextpdf.text.pdf;

import com.itextpdf.text.DocWriter;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.util.HashMap;

public class PdfEncodings {
    static HashMap<String, ExtraEncoding> extraEncodings;
    static final IntHashtable pdfEncoding;
    static final char[] pdfEncodingByteToChar;
    static final IntHashtable winansi;
    static final char[] winansiByteToChar;

    private static class Cp437Conversion implements ExtraEncoding {
        private static IntHashtable c2b;
        private static final char[] table;

        private Cp437Conversion() {
        }

        static {
            c2b = new IntHashtable();
            table = new char[]{Barcode128.CODE_C, '\u00fc', '\u00e9', '\u00e2', '\u00e4', '\u00e0', '\u00e5', '\u00e7', '\u00ea', '\u00eb', '\u00e8', '\u00ef', '\u00ee', '\u00ec', Barcode128.FNC3, Barcode128.FNC2, '\u00c9', '\u00e6', Barcode128.SHIFT, '\u00f4', '\u00f6', '\u00f2', '\u00fb', '\u00f9', '\u00ff', '\u00d6', '\u00dc', '\u00a2', '\u00a3', '\u00a5', '\u20a7', '\u0192', '\u00e1', '\u00ed', '\u00f3', '\u00fa', '\u00f1', '\u00d1', '\u00aa', '\u00ba', '\u00bf', '\u2310', '\u00ac', '\u00bd', '\u00bc', '\u00a1', '\u00ab', '\u00bb', '\u2591', '\u2592', '\u2593', '\u2502', '\u2524', '\u2561', '\u2562', '\u2556', '\u2555', '\u2563', '\u2551', '\u2557', '\u255d', '\u255c', '\u255b', '\u2510', '\u2514', '\u2534', '\u252c', '\u251c', '\u2500', '\u253c', '\u255e', '\u255f', '\u255a', '\u2554', '\u2569', '\u2566', '\u2560', '\u2550', '\u256c', '\u2567', '\u2568', '\u2564', '\u2565', '\u2559', '\u2558', '\u2552', '\u2553', '\u256b', '\u256a', '\u2518', '\u250c', '\u2588', '\u2584', '\u258c', '\u2590', '\u2580', '\u03b1', '\u00df', '\u0393', '\u03c0', '\u03a3', '\u03c3', '\u00b5', '\u03c4', '\u03a6', '\u0398', '\u03a9', '\u03b4', '\u221e', '\u03c6', '\u03b5', '\u2229', '\u2261', '\u00b1', '\u2265', '\u2264', '\u2320', '\u2321', '\u00f7', '\u2248', '\u00b0', '\u2219', '\u00b7', '\u221a', '\u207f', '\u00b2', '\u25a0', '\u00a0'};
            for (int k = 0; k < table.length; k++) {
                c2b.put(table[k], k + PdfWriter.PageModeUseOutlines);
            }
        }

        public byte[] charToByte(String text, String encoding) {
            char[] cc = text.toCharArray();
            byte[] b = new byte[cc.length];
            int len = cc.length;
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                char c = cc[k];
                if (c < '\u0080') {
                    ptr2 = ptr + 1;
                    b[ptr] = (byte) c;
                } else {
                    byte v = (byte) c2b.get(c);
                    if (v != null) {
                        ptr2 = ptr + 1;
                        b[ptr] = v;
                    } else {
                        ptr2 = ptr;
                    }
                }
                k++;
                ptr = ptr2;
            }
            if (ptr == len) {
                return b;
            }
            byte[] b2 = new byte[ptr];
            System.arraycopy(b, 0, b2, 0, ptr);
            return b2;
        }

        public byte[] charToByte(char char1, String encoding) {
            if (char1 < '\u0080') {
                return new byte[]{(byte) char1};
            }
            if (((byte) c2b.get(char1)) == null) {
                return new byte[0];
            }
            return new byte[]{(byte) c2b.get(char1)};
        }

        public String byteToChar(byte[] b, String encoding) {
            int len = b.length;
            char[] cc = new char[len];
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                int c = b[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                if (c < 32) {
                    ptr2 = ptr;
                } else if (c < PdfWriter.PageModeUseOutlines) {
                    ptr2 = ptr + 1;
                    cc[ptr] = (char) c;
                } else {
                    ptr2 = ptr + 1;
                    cc[ptr] = table[c - 128];
                }
                k++;
                ptr = ptr2;
            }
            return new String(cc, 0, ptr);
        }
    }

    private static class SymbolConversion implements ExtraEncoding {
        private static final IntHashtable t1;
        private static final IntHashtable t2;
        private static final char[] table1;
        private static final char[] table2;
        private final char[] byteToChar;
        private IntHashtable translation;

        static {
            int k;
            t1 = new IntHashtable();
            t2 = new IntHashtable();
            table1 = new char[]{'\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', ' ', '!', '\u2200', '#', '\u2203', '%', '&', '\u220b', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', PdfWriter.VERSION_1_2, PdfWriter.VERSION_1_3, PdfWriter.VERSION_1_4, PdfWriter.VERSION_1_5, PdfWriter.VERSION_1_6, PdfWriter.VERSION_1_7, '8', '9', ':', ';', '<', '=', '>', '?', '\u2245', '\u0391', '\u0392', '\u03a7', '\u0394', '\u0395', '\u03a6', '\u0393', '\u0397', '\u0399', '\u03d1', '\u039a', '\u039b', '\u039c', '\u039d', '\u039f', '\u03a0', '\u0398', '\u03a1', '\u03a3', '\u03a4', '\u03a5', '\u03c2', '\u03a9', '\u039e', '\u03a8', '\u0396', '[', '\u2234', ']', '\u22a5', '_', '\u0305', '\u03b1', '\u03b2', '\u03c7', '\u03b4', '\u03b5', '\u03d5', '\u03b3', '\u03b7', '\u03b9', '\u03c6', '\u03ba', '\u03bb', '\u03bc', '\u03bd', '\u03bf', '\u03c0', '\u03b8', '\u03c1', '\u03c3', '\u03c4', '\u03c5', '\u03d6', '\u03c9', '\u03be', '\u03c8', '\u03b6', '{', '|', '}', '~', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u20ac', '\u03d2', '\u2032', '\u2264', '\u2044', '\u221e', '\u0192', '\u2663', '\u2666', '\u2665', '\u2660', '\u2194', '\u2190', '\u2191', '\u2192', '\u2193', '\u00b0', '\u00b1', '\u2033', '\u2265', '\u00d7', '\u221d', '\u2202', '\u2022', '\u00f7', '\u2260', '\u2261', '\u2248', '\u2026', '\u2502', '\u2500', '\u21b5', '\u2135', '\u2111', '\u211c', '\u2118', '\u2297', '\u2295', '\u2205', '\u2229', '\u222a', '\u2283', '\u2287', '\u2284', '\u2282', '\u2286', '\u2208', '\u2209', '\u2220', '\u2207', '\u00ae', '\u00a9', '\u2122', '\u220f', '\u221a', '\u22c5', '\u00ac', '\u2227', '\u2228', '\u21d4', '\u21d0', '\u21d1', '\u21d2', '\u21d3', '\u25ca', '\u2329', '\u0000', '\u0000', '\u0000', '\u2211', '\u239b', '\u239c', '\u239d', '\u23a1', '\u23a2', '\u23a3', '\u23a7', '\u23a8', '\u23a9', '\u23aa', '\u0000', '\u232a', '\u222b', '\u2320', '\u23ae', '\u2321', '\u239e', '\u239f', '\u23a0', '\u23a4', '\u23a5', '\u23a6', '\u23ab', '\u23ac', '\u23ad', '\u0000'};
            table2 = new char[]{'\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', ' ', '\u2701', '\u2702', '\u2703', '\u2704', '\u260e', '\u2706', '\u2707', '\u2708', '\u2709', '\u261b', '\u261e', '\u270c', '\u270d', '\u270e', '\u270f', '\u2710', '\u2711', '\u2712', '\u2713', '\u2714', '\u2715', '\u2716', '\u2717', '\u2718', '\u2719', '\u271a', '\u271b', '\u271c', '\u271d', '\u271e', '\u271f', '\u2720', '\u2721', '\u2722', '\u2723', '\u2724', '\u2725', '\u2726', '\u2727', '\u2605', '\u2729', '\u272a', '\u272b', '\u272c', '\u272d', '\u272e', '\u272f', '\u2730', '\u2731', '\u2732', '\u2733', '\u2734', '\u2735', '\u2736', '\u2737', '\u2738', '\u2739', '\u273a', '\u273b', '\u273c', '\u273d', '\u273e', '\u273f', '\u2740', '\u2741', '\u2742', '\u2743', '\u2744', '\u2745', '\u2746', '\u2747', '\u2748', '\u2749', '\u274a', '\u274b', '\u25cf', '\u274d', '\u25a0', '\u274f', '\u2750', '\u2751', '\u2752', '\u25b2', '\u25bc', '\u25c6', '\u2756', '\u25d7', '\u2758', '\u2759', '\u275a', '\u275b', '\u275c', '\u275d', '\u275e', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u0000', '\u2761', '\u2762', '\u2763', '\u2764', '\u2765', '\u2766', '\u2767', '\u2663', '\u2666', '\u2665', '\u2660', '\u2460', '\u2461', '\u2462', '\u2463', '\u2464', '\u2465', '\u2466', '\u2467', '\u2468', '\u2469', '\u2776', '\u2777', '\u2778', '\u2779', '\u277a', '\u277b', '\u277c', '\u277d', '\u277e', '\u277f', '\u2780', '\u2781', '\u2782', '\u2783', '\u2784', '\u2785', '\u2786', '\u2787', '\u2788', '\u2789', '\u278a', '\u278b', '\u278c', '\u278d', '\u278e', '\u278f', '\u2790', '\u2791', '\u2792', '\u2793', '\u2794', '\u2192', '\u2194', '\u2195', '\u2798', '\u2799', '\u279a', '\u279b', '\u279c', '\u279d', '\u279e', '\u279f', '\u27a0', '\u27a1', '\u27a2', '\u27a3', '\u27a4', '\u27a5', '\u27a6', '\u27a7', '\u27a8', '\u27a9', '\u27aa', '\u27ab', '\u27ac', '\u27ad', '\u27ae', '\u27af', '\u0000', '\u27b1', '\u27b2', '\u27b3', '\u27b4', '\u27b5', '\u27b6', '\u27b7', '\u27b8', '\u27b9', '\u27ba', '\u27bb', '\u27bc', '\u27bd', '\u27be', '\u0000'};
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                int v = table1[k];
                if (v != 0) {
                    t1.put(v, k);
                }
            }
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                v = table2[k];
                if (v != 0) {
                    t2.put(v, k);
                }
            }
        }

        SymbolConversion(boolean symbol) {
            if (symbol) {
                this.translation = t1;
                this.byteToChar = table1;
                return;
            }
            this.translation = t2;
            this.byteToChar = table2;
        }

        public byte[] charToByte(String text, String encoding) {
            char[] cc = text.toCharArray();
            byte[] b = new byte[cc.length];
            int len = cc.length;
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                byte v = (byte) this.translation.get(cc[k]);
                if (v != null) {
                    ptr2 = ptr + 1;
                    b[ptr] = v;
                } else {
                    ptr2 = ptr;
                }
                k++;
                ptr = ptr2;
            }
            if (ptr == len) {
                return b;
            }
            byte[] b2 = new byte[ptr];
            System.arraycopy(b, 0, b2, 0, ptr);
            return b2;
        }

        public byte[] charToByte(char char1, String encoding) {
            if (((byte) this.translation.get(char1)) == null) {
                return new byte[0];
            }
            return new byte[]{(byte) this.translation.get(char1)};
        }

        public String byteToChar(byte[] b, String encoding) {
            int len = b.length;
            char[] cc = new char[len];
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2 = ptr + 1;
                cc[ptr] = this.byteToChar[b[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                k++;
                ptr = ptr2;
            }
            return new String(cc, 0, ptr);
        }
    }

    private static class SymbolTTConversion implements ExtraEncoding {
        private SymbolTTConversion() {
        }

        public byte[] charToByte(char char1, String encoding) {
            if ((char1 & 65280) != 0 && (char1 & 65280) != 61440) {
                return new byte[0];
            }
            return new byte[]{(byte) char1};
        }

        public byte[] charToByte(String text, String encoding) {
            char[] ch = text.toCharArray();
            byte[] b = new byte[ch.length];
            int len = ch.length;
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                char c = ch[k];
                if ((c & 65280) == 0 || (c & 65280) == 61440) {
                    ptr2 = ptr + 1;
                    b[ptr] = (byte) c;
                } else {
                    ptr2 = ptr;
                }
                k++;
                ptr = ptr2;
            }
            if (ptr == len) {
                return b;
            }
            byte[] b2 = new byte[ptr];
            System.arraycopy(b, 0, b2, 0, ptr);
            return b2;
        }

        public String byteToChar(byte[] b, String encoding) {
            return null;
        }
    }

    private static class WingdingsConversion implements ExtraEncoding {
        private static final byte[] table;

        private WingdingsConversion() {
        }

        public byte[] charToByte(char char1, String encoding) {
            if (char1 == ' ') {
                return new byte[]{(byte) char1};
            } else if (char1 < '\u2701' || char1 > '\u27be' || table[char1 - 9984] == null) {
                return new byte[0];
            } else {
                return new byte[]{table[char1 - 9984]};
            }
        }

        public byte[] charToByte(String text, String encoding) {
            char[] cc = text.toCharArray();
            byte[] b = new byte[cc.length];
            int len = cc.length;
            int k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                char c = cc[k];
                if (c == ' ') {
                    ptr2 = ptr + 1;
                    b[ptr] = (byte) c;
                } else {
                    if (c >= '\u2701' && c <= '\u27be') {
                        byte v = table[c - 9984];
                        if (v != null) {
                            ptr2 = ptr + 1;
                            b[ptr] = v;
                        }
                    }
                    ptr2 = ptr;
                }
                k++;
                ptr = ptr2;
            }
            if (ptr == len) {
                return b;
            }
            byte[] b2 = new byte[ptr];
            System.arraycopy(b, 0, b2, 0, ptr);
            return b2;
        }

        public String byteToChar(byte[] b, String encoding) {
            return null;
        }

        static {
            table = new byte[]{(byte) 0, (byte) 35, DocWriter.QUOTE, (byte) 0, (byte) 0, (byte) 0, (byte) 41, DocWriter.GT, (byte) 81, (byte) 42, (byte) 0, (byte) 0, (byte) 65, (byte) 63, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -4, (byte) 0, (byte) 0, (byte) 0, (byte) -5, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 86, (byte) 0, (byte) 88, (byte) 89, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -75, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -74, (byte) 0, (byte) 0, (byte) 0, (byte) -83, (byte) -81, (byte) -84, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 124, (byte) 123, (byte) 0, (byte) 0, (byte) 0, (byte) 84, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -90, (byte) 0, (byte) 0, (byte) 0, (byte) 113, (byte) 114, (byte) 0, (byte) 0, (byte) 0, (byte) 117, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 125, (byte) 126, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -116, (byte) -115, (byte) -114, (byte) -113, (byte) -112, (byte) -111, (byte) -110, (byte) -109, (byte) -108, (byte) -107, (byte) -127, (byte) -126, (byte) -125, (byte) -124, (byte) -123, (byte) -122, (byte) -121, (byte) -120, (byte) -119, (byte) -118, (byte) -116, (byte) -115, (byte) -114, (byte) -113, (byte) -112, (byte) -111, (byte) -110, (byte) -109, (byte) -108, (byte) -107, (byte) -24, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -24, (byte) -40, (byte) 0, (byte) 0, (byte) -60, (byte) -58, (byte) 0, (byte) 0, (byte) -16, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -36, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0};
        }
    }

    static {
        int k;
        winansiByteToChar = new char[]{'\u0000', '\u0001', '\u0002', '\u0003', '\u0004', '\u0005', '\u0006', '\u0007', '\b', '\t', '\n', '\u000b', '\f', '\r', '\u000e', '\u000f', '\u0010', '\u0011', '\u0012', '\u0013', '\u0014', '\u0015', '\u0016', '\u0017', '\u0018', '\u0019', '\u001a', '\u001b', '\u001c', '\u001d', '\u001e', '\u001f', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', PdfWriter.VERSION_1_2, PdfWriter.VERSION_1_3, PdfWriter.VERSION_1_4, PdfWriter.VERSION_1_5, PdfWriter.VERSION_1_6, PdfWriter.VERSION_1_7, '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', Barcode128.CODE_AB_TO_C, Barcode128.CODE_AC_TO_B, Barcode128.CODE_BC_TO_A, Barcode128.FNC1_INDEX, Barcode128.START_A, Barcode128.START_B, Barcode128.START_C, 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '\u007f', '\u20ac', '\ufffd', '\u201a', '\u0192', '\u201e', '\u2026', '\u2020', '\u2021', '\u02c6', '\u2030', '\u0160', '\u2039', '\u0152', '\ufffd', '\u017d', '\ufffd', '\ufffd', '\u2018', '\u2019', '\u201c', '\u201d', '\u2022', '\u2013', '\u2014', '\u02dc', '\u2122', '\u0161', '\u203a', '\u0153', '\ufffd', '\u017e', '\u0178', '\u00a0', '\u00a1', '\u00a2', '\u00a3', '\u00a4', '\u00a5', '\u00a6', '\u00a7', '\u00a8', '\u00a9', '\u00aa', '\u00ab', '\u00ac', '\u00ad', '\u00ae', '\u00af', '\u00b0', '\u00b1', '\u00b2', '\u00b3', '\u00b4', '\u00b5', '\u00b6', '\u00b7', '\u00b8', '\u00b9', '\u00ba', '\u00bb', '\u00bc', '\u00bd', '\u00be', '\u00bf', '\u00c0', '\u00c1', '\u00c2', Barcode128.DEL, Barcode128.FNC3, Barcode128.FNC2, Barcode128.SHIFT, Barcode128.CODE_C, Barcode128.FNC4, '\u00c9', Barcode128.FNC1, Barcode128.STARTA, Barcode128.STARTB, Barcode128.STARTC, '\u00ce', '\u00cf', '\u00d0', '\u00d1', '\u00d2', '\u00d3', '\u00d4', '\u00d5', '\u00d6', '\u00d7', '\u00d8', '\u00d9', '\u00da', '\u00db', '\u00dc', '\u00dd', '\u00de', '\u00df', '\u00e0', '\u00e1', '\u00e2', '\u00e3', '\u00e4', '\u00e5', '\u00e6', '\u00e7', '\u00e8', '\u00e9', '\u00ea', '\u00eb', '\u00ec', '\u00ed', '\u00ee', '\u00ef', '\u00f0', '\u00f1', '\u00f2', '\u00f3', '\u00f4', '\u00f5', '\u00f6', '\u00f7', '\u00f8', '\u00f9', '\u00fa', '\u00fb', '\u00fc', '\u00fd', '\u00fe', '\u00ff'};
        pdfEncodingByteToChar = new char[]{'\u0000', '\u0001', '\u0002', '\u0003', '\u0004', '\u0005', '\u0006', '\u0007', '\b', '\t', '\n', '\u000b', '\f', '\r', '\u000e', '\u000f', '\u0010', '\u0011', '\u0012', '\u0013', '\u0014', '\u0015', '\u0016', '\u0017', '\u0018', '\u0019', '\u001a', '\u001b', '\u001c', '\u001d', '\u001e', '\u001f', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', PdfWriter.VERSION_1_2, PdfWriter.VERSION_1_3, PdfWriter.VERSION_1_4, PdfWriter.VERSION_1_5, PdfWriter.VERSION_1_6, PdfWriter.VERSION_1_7, '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', Barcode128.CODE_AB_TO_C, Barcode128.CODE_AC_TO_B, Barcode128.CODE_BC_TO_A, Barcode128.FNC1_INDEX, Barcode128.START_A, Barcode128.START_B, Barcode128.START_C, 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '\u007f', '\u2022', '\u2020', '\u2021', '\u2026', '\u2014', '\u2013', '\u0192', '\u2044', '\u2039', '\u203a', '\u2212', '\u2030', '\u201e', '\u201c', '\u201d', '\u2018', '\u2019', '\u201a', '\u2122', '\ufb01', '\ufb02', '\u0141', '\u0152', '\u0160', '\u0178', '\u017d', '\u0131', '\u0142', '\u0153', '\u0161', '\u017e', '\ufffd', '\u20ac', '\u00a1', '\u00a2', '\u00a3', '\u00a4', '\u00a5', '\u00a6', '\u00a7', '\u00a8', '\u00a9', '\u00aa', '\u00ab', '\u00ac', '\u00ad', '\u00ae', '\u00af', '\u00b0', '\u00b1', '\u00b2', '\u00b3', '\u00b4', '\u00b5', '\u00b6', '\u00b7', '\u00b8', '\u00b9', '\u00ba', '\u00bb', '\u00bc', '\u00bd', '\u00be', '\u00bf', '\u00c0', '\u00c1', '\u00c2', Barcode128.DEL, Barcode128.FNC3, Barcode128.FNC2, Barcode128.SHIFT, Barcode128.CODE_C, Barcode128.FNC4, '\u00c9', Barcode128.FNC1, Barcode128.STARTA, Barcode128.STARTB, Barcode128.STARTC, '\u00ce', '\u00cf', '\u00d0', '\u00d1', '\u00d2', '\u00d3', '\u00d4', '\u00d5', '\u00d6', '\u00d7', '\u00d8', '\u00d9', '\u00da', '\u00db', '\u00dc', '\u00dd', '\u00de', '\u00df', '\u00e0', '\u00e1', '\u00e2', '\u00e3', '\u00e4', '\u00e5', '\u00e6', '\u00e7', '\u00e8', '\u00e9', '\u00ea', '\u00eb', '\u00ec', '\u00ed', '\u00ee', '\u00ef', '\u00f0', '\u00f1', '\u00f2', '\u00f3', '\u00f4', '\u00f5', '\u00f6', '\u00f7', '\u00f8', '\u00f9', '\u00fa', '\u00fb', '\u00fc', '\u00fd', '\u00fe', '\u00ff'};
        winansi = new IntHashtable();
        pdfEncoding = new IntHashtable();
        extraEncodings = new HashMap();
        for (k = PdfWriter.PageModeUseOutlines; k < 161; k++) {
            char c = winansiByteToChar[k];
            if (c != '\ufffd') {
                winansi.put(c, k);
            }
        }
        for (k = PdfWriter.PageModeUseOutlines; k < 161; k++) {
            c = pdfEncodingByteToChar[k];
            if (c != '\ufffd') {
                pdfEncoding.put(c, k);
            }
        }
        addExtraEncoding("Wingdings", new WingdingsConversion());
        addExtraEncoding(BaseFont.SYMBOL, new SymbolConversion(true));
        addExtraEncoding(BaseFont.ZAPFDINGBATS, new SymbolConversion(false));
        addExtraEncoding("SymbolTT", new SymbolTTConversion());
        addExtraEncoding("Cp437", new Cp437Conversion());
    }

    public static final byte[] convertToBytes(String text, String encoding) {
        if (text == null) {
            return new byte[0];
        }
        int len;
        byte[] b;
        int k;
        if (encoding == null || encoding.length() == 0) {
            len = text.length();
            b = new byte[len];
            for (k = 0; k < len; k++) {
                b[k] = (byte) text.charAt(k);
            }
            return b;
        }
        ExtraEncoding extra = (ExtraEncoding) extraEncodings.get(encoding.toLowerCase());
        if (extra != null) {
            b = extra.charToByte(text, encoding);
            if (b != null) {
                return b;
            }
        }
        IntHashtable hash = null;
        if (encoding.equals(BaseFont.WINANSI)) {
            hash = winansi;
        } else {
            if (encoding.equals(PdfObject.TEXT_PDFDOCENCODING)) {
                hash = pdfEncoding;
            }
        }
        char[] cc;
        int c;
        if (hash != null) {
            cc = text.toCharArray();
            len = cc.length;
            b = new byte[len];
            k = 0;
            int ptr = 0;
            while (k < len) {
                int ptr2;
                char char1 = cc[k];
                if (char1 < '\u0080' || (char1 > '\u00a0' && char1 <= '\u00ff')) {
                    c = char1;
                } else {
                    c = hash.get(char1);
                }
                if (c != 0) {
                    ptr2 = ptr + 1;
                    b[ptr] = (byte) c;
                } else {
                    ptr2 = ptr;
                }
                k++;
                ptr = ptr2;
            }
            if (ptr == len) {
                return b;
            }
            byte[] b2 = new byte[ptr];
            System.arraycopy(b, 0, b2, 0, ptr);
            return b2;
        }
        if (encoding.equals(PdfObject.TEXT_UNICODE)) {
            cc = text.toCharArray();
            b = new byte[((cc.length * 2) + 2)];
            b[0] = (byte) -2;
            b[1] = (byte) -1;
            int bptr = 2;
            for (int c2 : cc) {
                int i = bptr + 1;
                b[bptr] = (byte) (c2 >> 8);
                bptr = i + 1;
                b[i] = (byte) (c2 & TIFFConstants.TIFFTAG_OSUBFILETYPE);
            }
            return b;
        }
        try {
            CharsetEncoder ce = Charset.forName(encoding).newEncoder();
            ce.onUnmappableCharacter(CodingErrorAction.IGNORE);
            ByteBuffer bb = ce.encode(CharBuffer.wrap(text.toCharArray()));
            bb.rewind();
            byte[] br = new byte[bb.limit()];
            bb.get(br);
            return br;
        } catch (IOException e) {
            throw new ExceptionConverter(e);
        }
    }

    public static final byte[] convertToBytes(char char1, String encoding) {
        if (encoding == null || encoding.length() == 0) {
            return new byte[]{(byte) char1};
        }
        ExtraEncoding extra = (ExtraEncoding) extraEncodings.get(encoding.toLowerCase());
        if (extra != null) {
            byte[] b = extra.charToByte(char1, encoding);
            if (b != null) {
                return b;
            }
        }
        IntHashtable hash = null;
        if (encoding.equals(BaseFont.WINANSI)) {
            hash = winansi;
        } else if (encoding.equals(PdfObject.TEXT_PDFDOCENCODING)) {
            hash = pdfEncoding;
        }
        if (hash != null) {
            int c;
            if (char1 < '\u0080' || (char1 > '\u00a0' && char1 <= '\u00ff')) {
                c = char1;
            } else {
                c = hash.get(char1);
            }
            if (c == 0) {
                return new byte[0];
            }
            return new byte[]{(byte) c};
        } else if (encoding.equals(PdfObject.TEXT_UNICODE)) {
            return new byte[]{(byte) -2, (byte) -1, (byte) (char1 >> 8), (byte) (char1 & TIFFConstants.TIFFTAG_OSUBFILETYPE)};
        } else {
            try {
                CharsetEncoder ce = Charset.forName(encoding).newEncoder();
                ce.onUnmappableCharacter(CodingErrorAction.IGNORE);
                ByteBuffer bb = ce.encode(CharBuffer.wrap(new char[]{char1}));
                bb.rewind();
                byte[] br = new byte[bb.limit()];
                bb.get(br);
                return br;
            } catch (IOException e) {
                throw new ExceptionConverter(e);
            }
        }
    }

    public static final String convertToString(byte[] bytes, String encoding) {
        if (bytes == null) {
            return PdfObject.NOTHING;
        }
        char[] c;
        int k;
        if (encoding == null || encoding.length() == 0) {
            c = new char[bytes.length];
            for (k = 0; k < bytes.length; k++) {
                c[k] = (char) (bytes[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
            }
            return new String(c);
        }
        ExtraEncoding extra = (ExtraEncoding) extraEncodings.get(encoding.toLowerCase());
        if (extra != null) {
            String text = extra.byteToChar(bytes, encoding);
            if (text != null) {
                return text;
            }
        }
        char[] ch = null;
        if (encoding.equals(BaseFont.WINANSI)) {
            ch = winansiByteToChar;
        } else if (encoding.equals(PdfObject.TEXT_PDFDOCENCODING)) {
            ch = pdfEncodingByteToChar;
        }
        if (ch != null) {
            int len = bytes.length;
            c = new char[len];
            for (k = 0; k < len; k++) {
                c[k] = ch[bytes[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
            return new String(c);
        }
        try {
            return new String(bytes, encoding);
        } catch (UnsupportedEncodingException e) {
            throw new ExceptionConverter(e);
        }
    }

    public static boolean isPdfDocEncoding(String text) {
        if (text == null) {
            return true;
        }
        int len = text.length();
        for (int k = 0; k < len; k++) {
            char char1 = text.charAt(k);
            if (char1 >= '\u0080' && ((char1 <= '\u00a0' || char1 > '\u00ff') && !pdfEncoding.containsKey(char1))) {
                return false;
            }
        }
        return true;
    }

    public static void addExtraEncoding(String name, ExtraEncoding enc) {
        synchronized (extraEncodings) {
            HashMap<String, ExtraEncoding> newEncodings = (HashMap) extraEncodings.clone();
            newEncodings.put(name.toLowerCase(), enc);
            extraEncodings = newEncodings;
        }
    }
}

package com.itextpdf.text.pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.pdf.codec.TIFFConstants;

class PdfColor extends PdfArray {
    PdfColor(int red, int green, int blue) {
        super(new PdfNumber(((double) (red & TIFFConstants.TIFFTAG_OSUBFILETYPE)) / 255.0d));
        add(new PdfNumber(((double) (green & TIFFConstants.TIFFTAG_OSUBFILETYPE)) / 255.0d));
        add(new PdfNumber(((double) (blue & TIFFConstants.TIFFTAG_OSUBFILETYPE)) / 255.0d));
    }

    PdfColor(BaseColor color) {
        this(color.getRed(), color.getGreen(), color.getBlue());
    }
}

package com.itextpdf.text.pdf;

import com.itextpdf.text.DocWriter;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.crypto.AESCipherCBCnoPad;
import com.itextpdf.text.pdf.crypto.ARCFOUREncryption;
import com.itextpdf.text.pdf.crypto.IVGenerator;
import com.itextpdf.text.pdf.security.DigestAlgorithms;
import com.itextpdf.text.pdf.security.TSAClientBouncyCastle;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.cert.Certificate;

public class PdfEncryption {
    public static final int AES_128 = 4;
    public static final int AES_256 = 5;
    private static final int KEY_SALT_OFFSET = 40;
    private static final int OU_LENGHT = 48;
    private static final int SALT_LENGHT = 8;
    public static final int STANDARD_ENCRYPTION_128 = 3;
    public static final int STANDARD_ENCRYPTION_40 = 2;
    private static final int VALIDATION_SALT_OFFSET = 32;
    private static final byte[] metadataPad;
    private static final byte[] pad;
    private static final byte[] salt;
    static long seq;
    private ARCFOUREncryption arcfour;
    private int cryptoMode;
    byte[] documentID;
    private boolean embeddedFilesOnly;
    private boolean encryptMetadata;
    byte[] extra;
    byte[] key;
    private int keyLength;
    int keySize;
    MessageDigest md5;
    byte[] mkey;
    byte[] oeKey;
    byte[] ownerKey;
    long permissions;
    byte[] perms;
    protected PdfPublicKeySecurityHandler publicKeyHandler;
    private int revision;
    byte[] ueKey;
    byte[] userKey;

    static {
        pad = new byte[]{(byte) 40, (byte) -65, (byte) 78, (byte) 94, (byte) 78, (byte) 117, (byte) -118, (byte) 65, (byte) 100, (byte) 0, (byte) 78, (byte) 86, (byte) -1, (byte) -6, (byte) 1, (byte) 8, (byte) 46, (byte) 46, (byte) 0, (byte) -74, (byte) -48, (byte) 104, DocWriter.GT, Byte.MIN_VALUE, DocWriter.FORWARD, BidiOrder.CS, (byte) -87, (byte) -2, (byte) 100, (byte) 83, (byte) 105, (byte) 122};
        salt = new byte[]{(byte) 115, (byte) 65, (byte) 108, (byte) 84};
        metadataPad = new byte[]{(byte) -1, (byte) -1, (byte) -1, (byte) -1};
        seq = System.currentTimeMillis();
    }

    public PdfEncryption() {
        this.mkey = new byte[0];
        this.extra = new byte[AES_256];
        this.ownerKey = new byte[VALIDATION_SALT_OFFSET];
        this.userKey = new byte[VALIDATION_SALT_OFFSET];
        this.publicKeyHandler = null;
        this.arcfour = new ARCFOUREncryption();
        try {
            this.md5 = MessageDigest.getInstance("MD5");
            this.publicKeyHandler = new PdfPublicKeySecurityHandler();
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public PdfEncryption(PdfEncryption enc) {
        this();
        if (enc.key != null) {
            this.key = (byte[]) enc.key.clone();
        }
        this.keySize = enc.keySize;
        this.mkey = (byte[]) enc.mkey.clone();
        this.ownerKey = (byte[]) enc.ownerKey.clone();
        this.userKey = (byte[]) enc.userKey.clone();
        this.permissions = enc.permissions;
        if (enc.documentID != null) {
            this.documentID = (byte[]) enc.documentID.clone();
        }
        this.revision = enc.revision;
        this.keyLength = enc.keyLength;
        this.encryptMetadata = enc.encryptMetadata;
        this.embeddedFilesOnly = enc.embeddedFilesOnly;
        this.publicKeyHandler = enc.publicKeyHandler;
    }

    public void setCryptoMode(int mode, int kl) {
        boolean z;
        this.cryptoMode = mode;
        this.encryptMetadata = (mode & SALT_LENGHT) != SALT_LENGHT;
        if ((mode & 24) == 24) {
            z = true;
        } else {
            z = false;
        }
        this.embeddedFilesOnly = z;
        switch (mode & 7) {
            case PdfWriter.markAll /*0*/:
                this.encryptMetadata = true;
                this.embeddedFilesOnly = false;
                this.keyLength = KEY_SALT_OFFSET;
                this.revision = STANDARD_ENCRYPTION_40;
            case PdfWriter.markInlineElementsOnly /*1*/:
                this.embeddedFilesOnly = false;
                if (kl > 0) {
                    this.keyLength = kl;
                } else {
                    this.keyLength = PdfWriter.PageModeUseOutlines;
                }
                this.revision = STANDARD_ENCRYPTION_128;
            case STANDARD_ENCRYPTION_40 /*2*/:
                this.keyLength = PdfWriter.PageModeUseOutlines;
                this.revision = AES_128;
            case STANDARD_ENCRYPTION_128 /*3*/:
                this.keyLength = PdfWriter.PageModeUseThumbs;
                this.keySize = VALIDATION_SALT_OFFSET;
                this.revision = AES_256;
            default:
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("no.valid.encryption.mode", new Object[0]));
        }
    }

    public int getCryptoMode() {
        return this.cryptoMode;
    }

    public boolean isMetadataEncrypted() {
        return this.encryptMetadata;
    }

    public long getPermissions() {
        return this.permissions;
    }

    public boolean isEmbeddedFilesOnly() {
        return this.embeddedFilesOnly;
    }

    private byte[] padPassword(byte[] userPassword) {
        byte[] userPad = new byte[VALIDATION_SALT_OFFSET];
        if (userPassword == null) {
            System.arraycopy(pad, 0, userPad, 0, VALIDATION_SALT_OFFSET);
        } else {
            System.arraycopy(userPassword, 0, userPad, 0, Math.min(userPassword.length, VALIDATION_SALT_OFFSET));
            if (userPassword.length < VALIDATION_SALT_OFFSET) {
                System.arraycopy(pad, 0, userPad, userPassword.length, 32 - userPassword.length);
            }
        }
        return userPad;
    }

    private byte[] computeOwnerKey(byte[] userPad, byte[] ownerPad) {
        byte[] ownerKey = new byte[VALIDATION_SALT_OFFSET];
        byte[] digest = this.md5.digest(ownerPad);
        if (this.revision == STANDARD_ENCRYPTION_128 || this.revision == AES_128) {
            byte[] mkey = new byte[(this.keyLength / SALT_LENGHT)];
            for (int k = 0; k < 50; k++) {
                this.md5.update(digest, 0, mkey.length);
                System.arraycopy(this.md5.digest(), 0, digest, 0, mkey.length);
            }
            System.arraycopy(userPad, 0, ownerKey, 0, VALIDATION_SALT_OFFSET);
            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < mkey.length; j++) {
                    mkey[j] = (byte) (digest[j] ^ i);
                }
                this.arcfour.prepareARCFOURKey(mkey);
                this.arcfour.encryptARCFOUR(ownerKey);
            }
        } else {
            this.arcfour.prepareARCFOURKey(digest, 0, AES_256);
            this.arcfour.encryptARCFOUR(userPad, ownerKey);
        }
        return ownerKey;
    }

    private void setupGlobalEncryptionKey(byte[] documentID, byte[] userPad, byte[] ownerKey, long permissions) {
        this.documentID = documentID;
        this.ownerKey = ownerKey;
        this.permissions = permissions;
        this.mkey = new byte[(this.keyLength / SALT_LENGHT)];
        this.md5.reset();
        this.md5.update(userPad);
        this.md5.update(ownerKey);
        byte[] ext = new byte[AES_128];
        ext[0] = (byte) ((int) permissions);
        ext[1] = (byte) ((int) (permissions >> SALT_LENGHT));
        ext[STANDARD_ENCRYPTION_40] = (byte) ((int) (permissions >> 16));
        ext[STANDARD_ENCRYPTION_128] = (byte) ((int) (permissions >> 24));
        this.md5.update(ext, 0, AES_128);
        if (documentID != null) {
            this.md5.update(documentID);
        }
        if (!this.encryptMetadata) {
            this.md5.update(metadataPad);
        }
        byte[] digest = new byte[this.mkey.length];
        System.arraycopy(this.md5.digest(), 0, digest, 0, this.mkey.length);
        if (this.revision == STANDARD_ENCRYPTION_128 || this.revision == AES_128) {
            for (int k = 0; k < 50; k++) {
                System.arraycopy(this.md5.digest(digest), 0, digest, 0, this.mkey.length);
            }
        }
        System.arraycopy(digest, 0, this.mkey, 0, this.mkey.length);
    }

    private void setupUserKey() {
        if (this.revision == STANDARD_ENCRYPTION_128 || this.revision == AES_128) {
            this.md5.update(pad);
            byte[] digest = this.md5.digest(this.documentID);
            System.arraycopy(digest, 0, this.userKey, 0, 16);
            for (int k = 16; k < VALIDATION_SALT_OFFSET; k++) {
                this.userKey[k] = (byte) 0;
            }
            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < this.mkey.length; j++) {
                    digest[j] = (byte) (this.mkey[j] ^ i);
                }
                this.arcfour.prepareARCFOURKey(digest, 0, this.mkey.length);
                this.arcfour.encryptARCFOUR(this.userKey, 0, 16);
            }
            return;
        }
        this.arcfour.prepareARCFOURKey(this.mkey);
        this.arcfour.encryptARCFOUR(pad, this.userKey);
    }

    public void setupAllKeys(byte[] userPassword, byte[] ownerPassword, int permissions) {
        if (ownerPassword == null || ownerPassword.length == 0) {
            ownerPassword = this.md5.digest(createDocumentId());
        }
        int i = (this.revision == STANDARD_ENCRYPTION_128 || this.revision == AES_128 || this.revision == AES_256) ? -3904 : -64;
        permissions = (permissions | i) & -4;
        this.permissions = (long) permissions;
        if (this.revision == AES_256) {
            if (userPassword == null) {
                try {
                    userPassword = new byte[0];
                } catch (Exception ex) {
                    throw new ExceptionConverter(ex);
                }
            }
            this.documentID = createDocumentId();
            Object uvs = IVGenerator.getIV(SALT_LENGHT);
            byte[] uks = IVGenerator.getIV(SALT_LENGHT);
            this.key = IVGenerator.getIV(VALIDATION_SALT_OFFSET);
            MessageDigest md = MessageDigest.getInstance(TSAClientBouncyCastle.DEFAULTHASHALGORITHM);
            md.update(userPassword, 0, Math.min(userPassword.length, 127));
            md.update(uvs);
            this.userKey = new byte[OU_LENGHT];
            md.digest(this.userKey, 0, VALIDATION_SALT_OFFSET);
            System.arraycopy(uvs, 0, this.userKey, VALIDATION_SALT_OFFSET, SALT_LENGHT);
            System.arraycopy(uks, 0, this.userKey, KEY_SALT_OFFSET, SALT_LENGHT);
            md.update(userPassword, 0, Math.min(userPassword.length, 127));
            md.update(uks);
            this.ueKey = new AESCipherCBCnoPad(true, md.digest()).processBlock(this.key, 0, this.key.length);
            byte[] ovs = IVGenerator.getIV(SALT_LENGHT);
            byte[] oks = IVGenerator.getIV(SALT_LENGHT);
            md.update(ownerPassword, 0, Math.min(ownerPassword.length, 127));
            md.update(ovs);
            md.update(this.userKey);
            this.ownerKey = new byte[OU_LENGHT];
            md.digest(this.ownerKey, 0, VALIDATION_SALT_OFFSET);
            System.arraycopy(ovs, 0, this.ownerKey, VALIDATION_SALT_OFFSET, SALT_LENGHT);
            System.arraycopy(oks, 0, this.ownerKey, KEY_SALT_OFFSET, SALT_LENGHT);
            md.update(ownerPassword, 0, Math.min(ownerPassword.length, 127));
            md.update(oks);
            md.update(this.userKey);
            this.oeKey = new AESCipherCBCnoPad(true, md.digest()).processBlock(this.key, 0, this.key.length);
            byte[] permsp = IVGenerator.getIV(16);
            permsp[0] = (byte) permissions;
            permsp[1] = (byte) (permissions >> SALT_LENGHT);
            permsp[STANDARD_ENCRYPTION_40] = (byte) (permissions >> 16);
            permsp[STANDARD_ENCRYPTION_128] = (byte) (permissions >> 24);
            permsp[AES_128] = (byte) -1;
            permsp[AES_256] = (byte) -1;
            permsp[6] = (byte) -1;
            permsp[7] = (byte) -1;
            permsp[SALT_LENGHT] = this.encryptMetadata ? (byte) 84 : (byte) 70;
            permsp[9] = (byte) 97;
            permsp[10] = (byte) 100;
            permsp[11] = (byte) 98;
            this.perms = new AESCipherCBCnoPad(true, this.key).processBlock(permsp, 0, permsp.length);
            return;
        }
        byte[] userPad = padPassword(userPassword);
        this.ownerKey = computeOwnerKey(userPad, padPassword(ownerPassword));
        this.documentID = createDocumentId();
        setupByUserPad(this.documentID, userPad, this.ownerKey, (long) permissions);
    }

    public boolean readKey(PdfDictionary enc, byte[] password) throws BadPasswordException {
        if (password == null) {
            try {
                password = new byte[0];
            } catch (BadPasswordException ex) {
                throw ex;
            } catch (Exception ex2) {
                throw new ExceptionConverter(ex2);
            }
        }
        byte[] oValue = DocWriter.getISOBytes(enc.get(PdfName.f74O).toString());
        byte[] uValue = DocWriter.getISOBytes(enc.get(PdfName.f80U).toString());
        byte[] oeValue = DocWriter.getISOBytes(enc.get(PdfName.OE).toString());
        byte[] ueValue = DocWriter.getISOBytes(enc.get(PdfName.UE).toString());
        byte[] perms = DocWriter.getISOBytes(enc.get(PdfName.PERMS).toString());
        MessageDigest md = MessageDigest.getInstance(TSAClientBouncyCastle.DEFAULTHASHALGORITHM);
        md.update(password, 0, Math.min(password.length, 127));
        md.update(oValue, VALIDATION_SALT_OFFSET, SALT_LENGHT);
        md.update(uValue, 0, OU_LENGHT);
        boolean isOwnerPass = compareArray(md.digest(), oValue, VALIDATION_SALT_OFFSET);
        if (isOwnerPass) {
            md.update(password, 0, Math.min(password.length, 127));
            md.update(oValue, KEY_SALT_OFFSET, SALT_LENGHT);
            md.update(uValue, 0, OU_LENGHT);
            this.key = new AESCipherCBCnoPad(false, md.digest()).processBlock(oeValue, 0, oeValue.length);
        } else {
            md.update(password, 0, Math.min(password.length, 127));
            md.update(uValue, VALIDATION_SALT_OFFSET, SALT_LENGHT);
            if (compareArray(md.digest(), uValue, VALIDATION_SALT_OFFSET)) {
                md.update(password, 0, Math.min(password.length, 127));
                md.update(uValue, KEY_SALT_OFFSET, SALT_LENGHT);
                this.key = new AESCipherCBCnoPad(false, md.digest()).processBlock(ueValue, 0, ueValue.length);
            } else {
                throw new BadPasswordException(MessageLocalization.getComposedMessage("bad.user.password", new Object[0]));
            }
        }
        byte[] decPerms = new AESCipherCBCnoPad(false, this.key).processBlock(perms, 0, perms.length);
        if (decPerms[9] == 97 && decPerms[10] == 100 && decPerms[11] == 98) {
            this.permissions = (long) ((((decPerms[0] & TIFFConstants.TIFFTAG_OSUBFILETYPE) | ((decPerms[1] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << SALT_LENGHT)) | ((decPerms[STANDARD_ENCRYPTION_40] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 16)) | ((decPerms[STANDARD_ENCRYPTION_40] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 24));
            this.encryptMetadata = decPerms[SALT_LENGHT] == 84;
            return isOwnerPass;
        }
        throw new BadPasswordException(MessageLocalization.getComposedMessage("bad.user.password", new Object[0]));
    }

    private static boolean compareArray(byte[] a, byte[] b, int len) {
        for (int k = 0; k < len; k++) {
            if (a[k] != b[k]) {
                return false;
            }
        }
        return true;
    }

    public static byte[] createDocumentId() {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            long time = System.currentTimeMillis();
            StringBuilder append = new StringBuilder().append(time).append("+").append(Runtime.getRuntime().freeMemory()).append("+");
            long j = seq;
            seq = 1 + j;
            return md5.digest(append.append(j).toString().getBytes());
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public void setupByUserPassword(byte[] documentID, byte[] userPassword, byte[] ownerKey, long permissions) {
        setupByUserPad(documentID, padPassword(userPassword), ownerKey, permissions);
    }

    private void setupByUserPad(byte[] documentID, byte[] userPad, byte[] ownerKey, long permissions) {
        setupGlobalEncryptionKey(documentID, userPad, ownerKey, permissions);
        setupUserKey();
    }

    public void setupByOwnerPassword(byte[] documentID, byte[] ownerPassword, byte[] userKey, byte[] ownerKey, long permissions) {
        setupByOwnerPad(documentID, padPassword(ownerPassword), userKey, ownerKey, permissions);
    }

    private void setupByOwnerPad(byte[] documentID, byte[] ownerPad, byte[] userKey, byte[] ownerKey, long permissions) {
        setupGlobalEncryptionKey(documentID, computeOwnerKey(ownerKey, ownerPad), ownerKey, permissions);
        setupUserKey();
    }

    public void setKey(byte[] key) {
        this.key = key;
    }

    public void setupByEncryptionKey(byte[] key, int keylength) {
        this.mkey = new byte[(keylength / SALT_LENGHT)];
        System.arraycopy(key, 0, this.mkey, 0, this.mkey.length);
    }

    public void setHashKey(int number, int generation) {
        if (this.revision != AES_256) {
            this.md5.reset();
            this.extra[0] = (byte) number;
            this.extra[1] = (byte) (number >> SALT_LENGHT);
            this.extra[STANDARD_ENCRYPTION_40] = (byte) (number >> 16);
            this.extra[STANDARD_ENCRYPTION_128] = (byte) generation;
            this.extra[AES_128] = (byte) (generation >> SALT_LENGHT);
            this.md5.update(this.mkey);
            this.md5.update(this.extra);
            if (this.revision == AES_128) {
                this.md5.update(salt);
            }
            this.key = this.md5.digest();
            this.keySize = this.mkey.length + AES_256;
            if (this.keySize > 16) {
                this.keySize = 16;
            }
        }
    }

    public static PdfObject createInfoId(byte[] id, boolean modified) throws IOException {
        int k;
        ByteBuffer buf = new ByteBuffer(90);
        buf.append('[').append('<');
        if (id.length != 16) {
            id = createDocumentId();
        }
        for (k = 0; k < 16; k++) {
            buf.appendHex(id[k]);
        }
        buf.append('>').append('<');
        if (modified) {
            id = createDocumentId();
        }
        for (k = 0; k < 16; k++) {
            buf.appendHex(id[k]);
        }
        buf.append('>').append(']');
        buf.close();
        return new PdfLiteral(buf.toByteArray());
    }

    public PdfDictionary getEncryptionDictionary() {
        PdfDictionary dic = new PdfDictionary();
        PdfDictionary stdcf;
        if (this.publicKeyHandler.getRecipientsSize() > 0) {
            dic.put(PdfName.FILTER, PdfName.PUBSEC);
            dic.put(PdfName.f77R, new PdfNumber(this.revision));
            try {
                PdfArray recipients = this.publicKeyHandler.getEncodedRecipients();
                if (this.revision == STANDARD_ENCRYPTION_40) {
                    dic.put(PdfName.f81V, new PdfNumber(1));
                    dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S4);
                    dic.put(PdfName.RECIPIENTS, recipients);
                } else if (this.revision == STANDARD_ENCRYPTION_128 && this.encryptMetadata) {
                    dic.put(PdfName.f81V, new PdfNumber((int) STANDARD_ENCRYPTION_40));
                    dic.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseOutlines));
                    dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S4);
                    dic.put(PdfName.RECIPIENTS, recipients);
                } else {
                    if (this.revision == AES_256) {
                        dic.put(PdfName.f77R, new PdfNumber((int) AES_256));
                        dic.put(PdfName.f81V, new PdfNumber((int) AES_256));
                    } else {
                        dic.put(PdfName.f77R, new PdfNumber((int) AES_128));
                        dic.put(PdfName.f81V, new PdfNumber((int) AES_128));
                    }
                    dic.put(PdfName.SUBFILTER, PdfName.ADBE_PKCS7_S5);
                    stdcf = new PdfDictionary();
                    stdcf.put(PdfName.RECIPIENTS, recipients);
                    if (!this.encryptMetadata) {
                        stdcf.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
                    }
                    if (this.revision == AES_128) {
                        stdcf.put(PdfName.CFM, PdfName.AESV2);
                        stdcf.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseOutlines));
                    } else if (this.revision == AES_256) {
                        stdcf.put(PdfName.CFM, PdfName.AESV3);
                        stdcf.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseThumbs));
                    } else {
                        stdcf.put(PdfName.CFM, PdfName.V2);
                    }
                    PdfDictionary cf = new PdfDictionary();
                    cf.put(PdfName.DEFAULTCRYPTFILTER, stdcf);
                    dic.put(PdfName.CF, cf);
                    if (this.embeddedFilesOnly) {
                        dic.put(PdfName.EFF, PdfName.DEFAULTCRYPTFILTER);
                        dic.put(PdfName.STRF, PdfName.IDENTITY);
                        dic.put(PdfName.STMF, PdfName.IDENTITY);
                    } else {
                        dic.put(PdfName.STRF, PdfName.DEFAULTCRYPTFILTER);
                        dic.put(PdfName.STMF, PdfName.DEFAULTCRYPTFILTER);
                    }
                }
                try {
                    MessageDigest md;
                    if (this.revision == AES_256) {
                        md = MessageDigest.getInstance(TSAClientBouncyCastle.DEFAULTHASHALGORITHM);
                    } else {
                        md = MessageDigest.getInstance(DigestAlgorithms.SHA1);
                    }
                    md.update(this.publicKeyHandler.getSeed());
                    for (int i = 0; i < this.publicKeyHandler.getRecipientsSize(); i++) {
                        md.update(this.publicKeyHandler.getEncodedRecipient(i));
                    }
                    if (!this.encryptMetadata) {
                        md.update(new byte[]{(byte) -1, (byte) -1, (byte) -1, (byte) -1});
                    }
                    byte[] mdResult = md.digest();
                    if (this.revision == AES_256) {
                        this.key = mdResult;
                    } else {
                        setupByEncryptionKey(mdResult, this.keyLength);
                    }
                } catch (Exception f) {
                    throw new ExceptionConverter(f);
                }
            } catch (Exception f2) {
                throw new ExceptionConverter(f2);
            }
        }
        dic.put(PdfName.FILTER, PdfName.STANDARD);
        dic.put(PdfName.f74O, new PdfLiteral(StringUtils.escapeString(this.ownerKey)));
        dic.put(PdfName.f80U, new PdfLiteral(StringUtils.escapeString(this.userKey)));
        dic.put(PdfName.f75P, new PdfNumber(this.permissions));
        dic.put(PdfName.f77R, new PdfNumber(this.revision));
        if (this.revision == STANDARD_ENCRYPTION_40) {
            dic.put(PdfName.f81V, new PdfNumber(1));
        } else if (this.revision == STANDARD_ENCRYPTION_128 && this.encryptMetadata) {
            dic.put(PdfName.f81V, new PdfNumber((int) STANDARD_ENCRYPTION_40));
            dic.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseOutlines));
        } else if (this.revision == AES_256) {
            if (!this.encryptMetadata) {
                dic.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
            }
            dic.put(PdfName.OE, new PdfLiteral(StringUtils.escapeString(this.oeKey)));
            dic.put(PdfName.UE, new PdfLiteral(StringUtils.escapeString(this.ueKey)));
            dic.put(PdfName.PERMS, new PdfLiteral(StringUtils.escapeString(this.perms)));
            dic.put(PdfName.f81V, new PdfNumber(this.revision));
            dic.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseThumbs));
            stdcf = new PdfDictionary();
            stdcf.put(PdfName.LENGTH, new PdfNumber((int) VALIDATION_SALT_OFFSET));
            if (this.embeddedFilesOnly) {
                stdcf.put(PdfName.AUTHEVENT, PdfName.EFOPEN);
                dic.put(PdfName.EFF, PdfName.STDCF);
                dic.put(PdfName.STRF, PdfName.IDENTITY);
                dic.put(PdfName.STMF, PdfName.IDENTITY);
            } else {
                stdcf.put(PdfName.AUTHEVENT, PdfName.DOCOPEN);
                dic.put(PdfName.STRF, PdfName.STDCF);
                dic.put(PdfName.STMF, PdfName.STDCF);
            }
            stdcf.put(PdfName.CFM, PdfName.AESV3);
            cf = new PdfDictionary();
            cf.put(PdfName.STDCF, stdcf);
            dic.put(PdfName.CF, cf);
        } else {
            if (!this.encryptMetadata) {
                dic.put(PdfName.ENCRYPTMETADATA, PdfBoolean.PDFFALSE);
            }
            dic.put(PdfName.f77R, new PdfNumber((int) AES_128));
            dic.put(PdfName.f81V, new PdfNumber((int) AES_128));
            dic.put(PdfName.LENGTH, new PdfNumber((int) PdfWriter.PageModeUseOutlines));
            stdcf = new PdfDictionary();
            stdcf.put(PdfName.LENGTH, new PdfNumber(16));
            if (this.embeddedFilesOnly) {
                stdcf.put(PdfName.AUTHEVENT, PdfName.EFOPEN);
                dic.put(PdfName.EFF, PdfName.STDCF);
                dic.put(PdfName.STRF, PdfName.IDENTITY);
                dic.put(PdfName.STMF, PdfName.IDENTITY);
            } else {
                stdcf.put(PdfName.AUTHEVENT, PdfName.DOCOPEN);
                dic.put(PdfName.STRF, PdfName.STDCF);
                dic.put(PdfName.STMF, PdfName.STDCF);
            }
            if (this.revision == AES_128) {
                stdcf.put(PdfName.CFM, PdfName.AESV2);
            } else {
                stdcf.put(PdfName.CFM, PdfName.V2);
            }
            cf = new PdfDictionary();
            cf.put(PdfName.STDCF, stdcf);
            dic.put(PdfName.CF, cf);
        }
        return dic;
    }

    public PdfObject getFileID(boolean modified) throws IOException {
        return createInfoId(this.documentID, modified);
    }

    public OutputStreamEncryption getEncryptionStream(OutputStream os) {
        return new OutputStreamEncryption(os, this.key, 0, this.keySize, this.revision);
    }

    public int calculateStreamSize(int n) {
        if (this.revision == AES_128 || this.revision == AES_256) {
            return (2147483632 & n) + VALIDATION_SALT_OFFSET;
        }
        return n;
    }

    public byte[] encryptByteArray(byte[] b) {
        try {
            ByteArrayOutputStream ba = new ByteArrayOutputStream();
            OutputStreamEncryption os2 = getEncryptionStream(ba);
            os2.write(b);
            os2.finish();
            return ba.toByteArray();
        } catch (IOException ex) {
            throw new ExceptionConverter(ex);
        }
    }

    public StandardDecryption getDecryptor() {
        return new StandardDecryption(this.key, 0, this.keySize, this.revision);
    }

    public byte[] decryptByteArray(byte[] b) {
        try {
            ByteArrayOutputStream ba = new ByteArrayOutputStream();
            StandardDecryption dec = getDecryptor();
            byte[] b2 = dec.update(b, 0, b.length);
            if (b2 != null) {
                ba.write(b2);
            }
            b2 = dec.finish();
            if (b2 != null) {
                ba.write(b2);
            }
            return ba.toByteArray();
        } catch (IOException ex) {
            throw new ExceptionConverter(ex);
        }
    }

    public void addRecipient(Certificate cert, int permission) {
        this.documentID = createDocumentId();
        this.publicKeyHandler.addRecipient(new PdfPublicKeyRecipient(cert, permission));
    }

    public byte[] computeUserPassword(byte[] ownerPassword) {
        byte[] userPad = computeOwnerKey(this.ownerKey, padPassword(ownerPassword));
        for (int i = 0; i < userPad.length; i++) {
            boolean match = true;
            for (int j = 0; j < userPad.length - i; j++) {
                if (userPad[i + j] != pad[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                byte[] userPassword = new byte[i];
                System.arraycopy(userPad, 0, userPassword, 0, i);
                return userPassword;
            }
        }
        return userPad;
    }
}

package com.itextpdf.text.pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocListener;
import com.itextpdf.text.DocWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.ImgJBIG2;
import com.itextpdf.text.ImgWMF;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Version;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.text.log.Counter;
import com.itextpdf.text.log.CounterFactory;
import com.itextpdf.text.pdf.PdfDocument.Destination;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.collection.PdfCollection;
import com.itextpdf.text.pdf.events.PdfPageEventForwarder;
import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
import com.itextpdf.text.pdf.interfaces.PdfAnnotations;
import com.itextpdf.text.pdf.interfaces.PdfDocumentActions;
import com.itextpdf.text.pdf.interfaces.PdfEncryptionSettings;
import com.itextpdf.text.pdf.interfaces.PdfIsoConformance;
import com.itextpdf.text.pdf.interfaces.PdfPageActions;
import com.itextpdf.text.pdf.interfaces.PdfRunDirection;
import com.itextpdf.text.pdf.interfaces.PdfVersion;
import com.itextpdf.text.pdf.interfaces.PdfViewerPreferences;
import com.itextpdf.text.pdf.interfaces.PdfXConformance;
import com.itextpdf.text.pdf.internal.PdfVersionImp;
import com.itextpdf.text.pdf.internal.PdfXConformanceImp;
import com.itextpdf.text.xml.xmp.PdfProperties;
import com.itextpdf.text.xml.xmp.XmpWriter;
import com.itextpdf.xmp.XMPConst;
import com.itextpdf.xmp.XMPException;
import com.itextpdf.xmp.options.PropertyOptions;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;

public class PdfWriter extends DocWriter implements PdfViewerPreferences, PdfEncryptionSettings, PdfVersion, PdfDocumentActions, PdfPageActions, PdfRunDirection, PdfAnnotations {
    public static final int ALLOW_ASSEMBLY = 1024;
    public static final int ALLOW_COPY = 16;
    public static final int ALLOW_DEGRADED_PRINTING = 4;
    public static final int ALLOW_FILL_IN = 256;
    public static final int ALLOW_MODIFY_ANNOTATIONS = 32;
    public static final int ALLOW_MODIFY_CONTENTS = 8;
    public static final int ALLOW_PRINTING = 2052;
    public static final int ALLOW_SCREENREADERS = 512;
    @Deprecated
    public static final int AllowAssembly = 1024;
    @Deprecated
    public static final int AllowCopy = 16;
    @Deprecated
    public static final int AllowDegradedPrinting = 4;
    @Deprecated
    public static final int AllowFillIn = 256;
    @Deprecated
    public static final int AllowModifyAnnotations = 32;
    @Deprecated
    public static final int AllowModifyContents = 8;
    @Deprecated
    public static final int AllowPrinting = 2052;
    @Deprecated
    public static final int AllowScreenReaders = 512;
    protected static Counter COUNTER = null;
    public static final int CenterWindow = 65536;
    public static final PdfName DID_PRINT;
    public static final PdfName DID_SAVE;
    public static final PdfName DOCUMENT_CLOSE;
    public static final int DO_NOT_ENCRYPT_METADATA = 8;
    public static final int DirectionL2R = 4194304;
    public static final int DirectionR2L = 8388608;
    public static final int DisplayDocTitle = 131072;
    public static final int EMBEDDED_FILES_ONLY = 24;
    public static final int ENCRYPTION_AES_128 = 2;
    public static final int ENCRYPTION_AES_256 = 3;
    static final int ENCRYPTION_MASK = 7;
    public static final int FitWindow = 32768;
    public static final int GENERATION_MAX = 65535;
    public static final int HideMenubar = 8192;
    public static final int HideToolbar = 4096;
    public static final int HideWindowUI = 16384;
    public static final float NO_SPACE_CHAR_RATIO = 1.0E7f;
    public static final int NonFullScreenPageModeUseNone = 262144;
    public static final int NonFullScreenPageModeUseOC = 2097152;
    public static final int NonFullScreenPageModeUseOutlines = 524288;
    public static final int NonFullScreenPageModeUseThumbs = 1048576;
    public static final PdfName PAGE_CLOSE;
    public static final PdfName PAGE_OPEN;
    public static final int PDFX1A2001 = 1;
    public static final int PDFX32002 = 2;
    public static final int PDFXNONE = 0;
    public static final PdfName PDF_VERSION_1_2;
    public static final PdfName PDF_VERSION_1_3;
    public static final PdfName PDF_VERSION_1_4;
    public static final PdfName PDF_VERSION_1_5;
    public static final PdfName PDF_VERSION_1_6;
    public static final PdfName PDF_VERSION_1_7;
    public static final int PageLayoutOneColumn = 2;
    public static final int PageLayoutSinglePage = 1;
    public static final int PageLayoutTwoColumnLeft = 4;
    public static final int PageLayoutTwoColumnRight = 8;
    public static final int PageLayoutTwoPageLeft = 16;
    public static final int PageLayoutTwoPageRight = 32;
    public static final int PageModeFullScreen = 512;
    public static final int PageModeUseAttachments = 2048;
    public static final int PageModeUseNone = 64;
    public static final int PageModeUseOC = 1024;
    public static final int PageModeUseOutlines = 128;
    public static final int PageModeUseThumbs = 256;
    public static final int PrintScalingNone = 16777216;
    public static final int RUN_DIRECTION_DEFAULT = 0;
    public static final int RUN_DIRECTION_LTR = 2;
    public static final int RUN_DIRECTION_NO_BIDI = 1;
    public static final int RUN_DIRECTION_RTL = 3;
    public static final int SIGNATURE_APPEND_ONLY = 2;
    public static final int SIGNATURE_EXISTS = 1;
    public static final float SPACE_CHAR_RATIO_DEFAULT = 2.5f;
    public static final int STANDARD_ENCRYPTION_128 = 1;
    public static final int STANDARD_ENCRYPTION_40 = 0;
    @Deprecated
    public static final boolean STRENGTH128BITS = true;
    @Deprecated
    public static final boolean STRENGTH40BITS = false;
    public static final char VERSION_1_2 = '2';
    public static final char VERSION_1_3 = '3';
    public static final char VERSION_1_4 = '4';
    public static final char VERSION_1_5 = '5';
    public static final char VERSION_1_6 = '6';
    public static final char VERSION_1_7 = '7';
    public static final PdfName WILL_PRINT;
    public static final PdfName WILL_SAVE;
    public static final int markAll = 0;
    public static final int markInlineElementsOnly = 1;
    private static final List<PdfName> standardStructElems_1_4;
    private static final List<PdfName> standardStructElems_1_7;
    protected HashMap<PdfStream, PdfIndirectReference> JBIG2Globals;
    protected PdfArray OCGLocked;
    protected PdfArray OCGRadioGroup;
    protected PdfOCProperties OCProperties;
    protected PdfBody body;
    protected int colorNumber;
    protected ICC_Profile colorProfile;
    protected int compressionLevel;
    protected PdfEncryption crypto;
    protected int currentPageNumber;
    protected PdfReaderInstance currentPdfReaderInstance;
    protected PdfDictionary defaultColorspace;
    protected PdfContentByte directContent;
    protected PdfContentByte directContentUnder;
    protected HashMap<ICachedColorSpace, ColorDetails> documentColors;
    protected HashMap<PdfDictionary, PdfObject[]> documentExtGState;
    protected LinkedHashMap<BaseFont, FontDetails> documentFonts;
    protected HashSet<PdfOCG> documentOCG;
    protected ArrayList<PdfOCG> documentOCGorder;
    protected HashMap<PdfPatternPainter, PdfName> documentPatterns;
    protected HashMap<Object, PdfObject[]> documentProperties;
    protected HashSet<PdfShadingPattern> documentShadingPatterns;
    protected HashSet<PdfShading> documentShadings;
    protected HashMap<ColorDetails, ColorDetails> documentSpotPatterns;
    protected PdfDictionary extraCatalog;
    protected int fontNumber;
    protected HashMap<PdfIndirectReference, Object[]> formXObjects;
    protected int formXObjectsCounter;
    protected boolean fullCompression;
    protected PdfDictionary group;
    protected PdfDictionary imageDictionary;
    private final HashMap<Long, PdfName> images;
    protected List<HashMap<String, Object>> newBookmarks;
    protected byte[] originalFileID;
    protected PdfDictionary pageDictEntries;
    private PdfPageEvent pageEvent;
    protected ArrayList<PdfIndirectReference> pageReferences;
    protected ColorDetails patternColorspaceCMYK;
    protected ColorDetails patternColorspaceGRAY;
    protected ColorDetails patternColorspaceRGB;
    protected int patternNumber;
    protected PdfDocument pdf;
    protected PdfIsoConformance pdfIsoConformance;
    protected PdfVersionImp pdf_version;
    protected long prevxref;
    protected HashMap<PdfReader, PdfReaderInstance> readerInstances;
    private boolean rgbTransparencyBlending;
    protected PdfPages root;
    protected int runDirection;
    private float spaceCharRatio;
    protected PdfStructureTreeRoot structureTreeRoot;
    protected PdfName tabs;
    protected boolean tagged;
    protected int taggingMode;
    protected TtfUnicodeWriter ttfUnicodeWriter;
    private boolean userProperties;
    protected byte[] xmpMetadata;
    protected XmpWriter xmpWriter;

    public static class PdfBody {
        private static final int OBJSINSTREAM = 200;
        protected int currentObjNum;
        protected ByteBuffer index;
        protected int numObj;
        protected long position;
        protected int refnum;
        protected ByteBuffer streamObjects;
        protected final PdfWriter writer;
        protected final TreeSet<PdfCrossReference> xrefs;

        public static class PdfCrossReference implements Comparable<PdfCrossReference> {
            private final int generation;
            private final long offset;
            private final int refnum;
            private final int type;

            public PdfCrossReference(int refnum, long offset, int generation) {
                this.type = PdfWriter.markAll;
                this.offset = offset;
                this.refnum = refnum;
                this.generation = generation;
            }

            public PdfCrossReference(int refnum, long offset) {
                this.type = PdfWriter.markInlineElementsOnly;
                this.offset = offset;
                this.refnum = refnum;
                this.generation = PdfWriter.markAll;
            }

            public PdfCrossReference(int type, int refnum, long offset, int generation) {
                this.type = type;
                this.offset = offset;
                this.refnum = refnum;
                this.generation = generation;
            }

            public int getRefnum() {
                return this.refnum;
            }

            public void toPdf(OutputStream os) throws IOException {
                StringBuffer off = new StringBuffer("0000000000").append(this.offset);
                off.delete(PdfWriter.markAll, off.length() - 10);
                StringBuffer gen = new StringBuffer("00000").append(this.generation);
                gen.delete(PdfWriter.markAll, gen.length() - 5);
                off.append(' ').append(gen).append(this.generation == PdfWriter.GENERATION_MAX ? " f \n" : " n \n");
                os.write(DocWriter.getISOBytes(off.toString()));
            }

            public void toPdf(int midSize, OutputStream os) throws IOException {
                os.write((byte) this.type);
                while (true) {
                    midSize--;
                    if (midSize >= 0) {
                        os.write((byte) ((int) ((this.offset >>> (midSize * PdfWriter.PageLayoutTwoColumnRight)) & 255)));
                    } else {
                        os.write((byte) ((this.generation >>> PdfWriter.PageLayoutTwoColumnRight) & TIFFConstants.TIFFTAG_OSUBFILETYPE));
                        os.write((byte) (this.generation & TIFFConstants.TIFFTAG_OSUBFILETYPE));
                        return;
                    }
                }
            }

            public int compareTo(PdfCrossReference other) {
                if (this.refnum < other.refnum) {
                    return -1;
                }
                return this.refnum == other.refnum ? PdfWriter.markAll : PdfWriter.markInlineElementsOnly;
            }

            public boolean equals(Object obj) {
                if (!(obj instanceof PdfCrossReference)) {
                    return PdfWriter.STRENGTH40BITS;
                }
                if (this.refnum == ((PdfCrossReference) obj).refnum) {
                    return PdfWriter.STRENGTH128BITS;
                }
                return PdfWriter.STRENGTH40BITS;
            }

            public int hashCode() {
                return this.refnum;
            }
        }

        protected PdfBody(PdfWriter writer) {
            this.numObj = PdfWriter.markAll;
            this.xrefs = new TreeSet();
            this.xrefs.add(new PdfCrossReference(PdfWriter.markAll, 0, PdfWriter.GENERATION_MAX));
            this.position = writer.getOs().getCounter();
            this.refnum = PdfWriter.markInlineElementsOnly;
            this.writer = writer;
        }

        void setRefnum(int refnum) {
            this.refnum = refnum;
        }

        protected PdfCrossReference addToObjStm(PdfObject obj, int nObj) throws IOException {
            if (this.numObj >= OBJSINSTREAM) {
                flushObjStm();
            }
            if (this.index == null) {
                this.index = new ByteBuffer();
                this.streamObjects = new ByteBuffer();
                this.currentObjNum = getIndirectReferenceNumber();
                this.numObj = PdfWriter.markAll;
            }
            int p = this.streamObjects.size();
            int idx = this.numObj;
            this.numObj = idx + PdfWriter.markInlineElementsOnly;
            PdfEncryption enc = this.writer.crypto;
            this.writer.crypto = null;
            obj.toPdf(this.writer, this.streamObjects);
            this.writer.crypto = enc;
            this.streamObjects.append(' ');
            this.index.append(nObj).append(' ').append(p).append(' ');
            return new PdfCrossReference(PdfWriter.SIGNATURE_APPEND_ONLY, nObj, (long) this.currentObjNum, idx);
        }

        public void flushObjStm() throws IOException {
            if (this.numObj != 0) {
                int first = this.index.size();
                this.index.append(this.streamObjects);
                PdfObject stream = new PdfStream(this.index.toByteArray());
                stream.flateCompress(this.writer.getCompressionLevel());
                stream.put(PdfName.TYPE, PdfName.OBJSTM);
                stream.put(PdfName.f73N, new PdfNumber(this.numObj));
                stream.put(PdfName.FIRST, new PdfNumber(first));
                add(stream, this.currentObjNum);
                this.index = null;
                this.streamObjects = null;
                this.numObj = PdfWriter.markAll;
            }
        }

        PdfIndirectObject add(PdfObject object) throws IOException {
            return add(object, getIndirectReferenceNumber());
        }

        PdfIndirectObject add(PdfObject object, boolean inObjStm) throws IOException {
            return add(object, getIndirectReferenceNumber(), PdfWriter.markAll, inObjStm);
        }

        public PdfIndirectReference getPdfIndirectReference() {
            return new PdfIndirectReference(PdfWriter.markAll, getIndirectReferenceNumber());
        }

        protected int getIndirectReferenceNumber() {
            int n = this.refnum;
            this.refnum = n + PdfWriter.markInlineElementsOnly;
            this.xrefs.add(new PdfCrossReference(n, 0, PdfWriter.GENERATION_MAX));
            return n;
        }

        PdfIndirectObject add(PdfObject object, PdfIndirectReference ref) throws IOException {
            return add(object, ref, PdfWriter.STRENGTH128BITS);
        }

        PdfIndirectObject add(PdfObject object, PdfIndirectReference ref, boolean inObjStm) throws IOException {
            return add(object, ref.getNumber(), ref.getGeneration(), inObjStm);
        }

        PdfIndirectObject add(PdfObject object, int refNumber) throws IOException {
            return add(object, refNumber, PdfWriter.markAll, PdfWriter.STRENGTH128BITS);
        }

        protected PdfIndirectObject add(PdfObject object, int refNumber, int generation, boolean inObjStm) throws IOException {
            PdfIndirectObject indirect;
            if (inObjStm && object.canBeInObjStm() && this.writer.isFullCompression()) {
                PdfCrossReference pxref = addToObjStm(object, refNumber);
                indirect = new PdfIndirectObject(refNumber, object, this.writer);
                if (this.xrefs.add(pxref)) {
                    return indirect;
                }
                this.xrefs.remove(pxref);
                this.xrefs.add(pxref);
                return indirect;
            } else if (this.writer.isFullCompression()) {
                indirect = new PdfIndirectObject(refNumber, object, this.writer);
                write(indirect, refNumber);
                return indirect;
            } else {
                indirect = new PdfIndirectObject(refNumber, generation, object, this.writer);
                write(indirect, refNumber, generation);
                return indirect;
            }
        }

        protected void write(PdfIndirectObject indirect, int refNumber) throws IOException {
            PdfCrossReference pxref = new PdfCrossReference(refNumber, this.position);
            if (!this.xrefs.add(pxref)) {
                this.xrefs.remove(pxref);
                this.xrefs.add(pxref);
            }
            indirect.writeTo(this.writer.getOs());
            this.position = this.writer.getOs().getCounter();
        }

        protected void write(PdfIndirectObject indirect, int refNumber, int generation) throws IOException {
            PdfCrossReference pxref = new PdfCrossReference(refNumber, this.position, generation);
            if (!this.xrefs.add(pxref)) {
                this.xrefs.remove(pxref);
                this.xrefs.add(pxref);
            }
            indirect.writeTo(this.writer.getOs());
            this.position = this.writer.getOs().getCounter();
        }

        public long offset() {
            return this.position;
        }

        public int size() {
            return Math.max(((PdfCrossReference) this.xrefs.last()).getRefnum() + PdfWriter.markInlineElementsOnly, this.refnum);
        }

        public void writeCrossReferenceTable(OutputStream os, PdfIndirectReference root, PdfIndirectReference info, PdfIndirectReference encryption, PdfObject fileID, long prevxref) throws IOException {
            int refNumber = PdfWriter.markAll;
            if (this.writer.isFullCompression()) {
                flushObjStm();
                refNumber = getIndirectReferenceNumber();
                this.xrefs.add(new PdfCrossReference(refNumber, this.position));
            }
            int first = ((PdfCrossReference) this.xrefs.first()).getRefnum();
            int len = PdfWriter.markAll;
            ArrayList<Integer> sections = new ArrayList();
            Iterator i$ = this.xrefs.iterator();
            while (i$.hasNext()) {
                PdfCrossReference entry = (PdfCrossReference) i$.next();
                if (first + len == entry.getRefnum()) {
                    len += PdfWriter.markInlineElementsOnly;
                } else {
                    sections.add(Integer.valueOf(first));
                    sections.add(Integer.valueOf(len));
                    first = entry.getRefnum();
                    len = PdfWriter.markInlineElementsOnly;
                }
            }
            sections.add(Integer.valueOf(first));
            sections.add(Integer.valueOf(len));
            int k;
            if (this.writer.isFullCompression()) {
                int mid = 5;
                long mask = 1095216660480L;
                while (mid > PdfWriter.markInlineElementsOnly) {
                    if ((this.position & mask) != 0) {
                        break;
                    }
                    mask >>>= PdfWriter.PageLayoutTwoColumnRight;
                    mid--;
                }
                ByteBuffer buf = new ByteBuffer();
                i$ = this.xrefs.iterator();
                while (i$.hasNext()) {
                    ((PdfCrossReference) i$.next()).toPdf(mid, buf);
                }
                PdfObject xr = new PdfStream(buf.toByteArray());
                xr.flateCompress(this.writer.getCompressionLevel());
                xr.put(PdfName.SIZE, new PdfNumber(size()));
                xr.put(PdfName.ROOT, root);
                if (info != null) {
                    xr.put(PdfName.INFO, info);
                }
                if (encryption != null) {
                    xr.put(PdfName.ENCRYPT, encryption);
                }
                if (fileID != null) {
                    xr.put(PdfName.ID, fileID);
                }
                PdfName pdfName = PdfName.f82W;
                int[] iArr = new int[PdfWriter.RUN_DIRECTION_RTL];
                iArr[PdfWriter.markAll] = PdfWriter.markInlineElementsOnly;
                iArr[PdfWriter.markInlineElementsOnly] = mid;
                iArr[PdfWriter.SIGNATURE_APPEND_ONLY] = PdfWriter.SIGNATURE_APPEND_ONLY;
                xr.put(pdfName, new PdfArray(iArr));
                xr.put(PdfName.TYPE, PdfName.XREF);
                PdfArray idx = new PdfArray();
                for (k = PdfWriter.markAll; k < sections.size(); k += PdfWriter.markInlineElementsOnly) {
                    idx.add(new PdfNumber(((Integer) sections.get(k)).intValue()));
                }
                xr.put(PdfName.INDEX, idx);
                if (prevxref > 0) {
                    xr.put(PdfName.PREV, new PdfNumber(prevxref));
                }
                PdfEncryption enc = this.writer.crypto;
                this.writer.crypto = null;
                PdfWriter pdfWriter = this.writer;
                new PdfIndirectObject(refNumber, xr, pdfWriter).writeTo(this.writer.getOs());
                this.writer.crypto = enc;
                return;
            }
            os.write(DocWriter.getISOBytes("xref\n"));
            Iterator<PdfCrossReference> i = this.xrefs.iterator();
            for (k = PdfWriter.markAll; k < sections.size(); k += PdfWriter.SIGNATURE_APPEND_ONLY) {
                first = ((Integer) sections.get(k)).intValue();
                len = ((Integer) sections.get(k + PdfWriter.markInlineElementsOnly)).intValue();
                os.write(DocWriter.getISOBytes(String.valueOf(first)));
                os.write(DocWriter.getISOBytes(" "));
                os.write(DocWriter.getISOBytes(String.valueOf(len)));
                os.write(10);
                int len2 = len;
                while (true) {
                    len = len2 - 1;
                    if (len2 <= 0) {
                        break;
                    }
                    ((PdfCrossReference) i.next()).toPdf(os);
                    len2 = len;
                }
            }
        }
    }

    public static class PdfTrailer extends PdfDictionary {
        long offset;

        public PdfTrailer(int size, long offset, PdfIndirectReference root, PdfIndirectReference info, PdfIndirectReference encryption, PdfObject fileID, long prevxref) {
            this.offset = offset;
            put(PdfName.SIZE, new PdfNumber(size));
            put(PdfName.ROOT, root);
            if (info != null) {
                put(PdfName.INFO, info);
            }
            if (encryption != null) {
                put(PdfName.ENCRYPT, encryption);
            }
            if (fileID != null) {
                put(PdfName.ID, fileID);
            }
            if (prevxref > 0) {
                put(PdfName.PREV, new PdfNumber(prevxref));
            }
        }

        public void toPdf(PdfWriter writer, OutputStream os) throws IOException {
            PdfWriter.checkPdfIsoConformance(writer, PdfWriter.PageLayoutTwoColumnRight, this);
            os.write(DocWriter.getISOBytes("trailer\n"));
            super.toPdf(null, os);
            os.write(10);
            PdfWriter.writeKeyInfo(os);
            os.write(DocWriter.getISOBytes("startxref\n"));
            os.write(DocWriter.getISOBytes(String.valueOf(this.offset)));
            os.write(DocWriter.getISOBytes("\n%%EOF\n"));
        }
    }

    static {
        COUNTER = CounterFactory.getCounter(PdfWriter.class);
        PDF_VERSION_1_2 = new PdfName("1.2");
        PDF_VERSION_1_3 = new PdfName("1.3");
        PDF_VERSION_1_4 = new PdfName("1.4");
        PDF_VERSION_1_5 = new PdfName("1.5");
        PDF_VERSION_1_6 = new PdfName("1.6");
        PDF_VERSION_1_7 = new PdfName("1.7");
        DOCUMENT_CLOSE = PdfName.WC;
        WILL_SAVE = PdfName.WS;
        DID_SAVE = PdfName.DS;
        WILL_PRINT = PdfName.WP;
        DID_PRINT = PdfName.DP;
        PAGE_OPEN = PdfName.f74O;
        PAGE_CLOSE = PdfName.f64C;
        standardStructElems_1_4 = Arrays.asList(new PdfName[]{PdfName.DOCUMENT, PdfName.PART, PdfName.ART, PdfName.SECT, PdfName.DIV, PdfName.BLOCKQUOTE, PdfName.CAPTION, PdfName.TOC, PdfName.TOCI, PdfName.INDEX, PdfName.NONSTRUCT, PdfName.PRIVATE, PdfName.f75P, PdfName.f68H, PdfName.H1, PdfName.H2, PdfName.H3, PdfName.H4, PdfName.H5, PdfName.H6, PdfName.f71L, PdfName.LBL, PdfName.LI, PdfName.LBODY, PdfName.TABLE, PdfName.TR, PdfName.TH, PdfName.TD, PdfName.SPAN, PdfName.QUOTE, PdfName.NOTE, PdfName.REFERENCE, PdfName.BIBENTRY, PdfName.CODE, PdfName.LINK, PdfName.FIGURE, PdfName.FORMULA, PdfName.FORM});
        standardStructElems_1_7 = Arrays.asList(new PdfName[]{PdfName.DOCUMENT, PdfName.PART, PdfName.ART, PdfName.SECT, PdfName.DIV, PdfName.BLOCKQUOTE, PdfName.CAPTION, PdfName.TOC, PdfName.TOCI, PdfName.INDEX, PdfName.NONSTRUCT, PdfName.PRIVATE, PdfName.f75P, PdfName.f68H, PdfName.H1, PdfName.H2, PdfName.H3, PdfName.H4, PdfName.H5, PdfName.H6, PdfName.f71L, PdfName.LBL, PdfName.LI, PdfName.LBODY, PdfName.TABLE, PdfName.TR, PdfName.TH, PdfName.TD, PdfName.THEAD, PdfName.TBODY, PdfName.TFOOT, PdfName.SPAN, PdfName.QUOTE, PdfName.NOTE, PdfName.REFERENCE, PdfName.BIBENTRY, PdfName.CODE, PdfName.LINK, PdfName.ANNOT, PdfName.RUBY, PdfName.RB, PdfName.RT, PdfName.RP, PdfName.WARICHU, PdfName.WT, PdfName.WP, PdfName.FIGURE, PdfName.FORMULA, PdfName.FORM});
    }

    protected Counter getCounter() {
        return COUNTER;
    }

    protected PdfWriter() {
        this.root = new PdfPages(this);
        this.pageReferences = new ArrayList();
        this.currentPageNumber = markInlineElementsOnly;
        this.tabs = null;
        this.pageDictEntries = new PdfDictionary();
        this.prevxref = 0;
        this.originalFileID = null;
        this.pdf_version = new PdfVersionImp();
        this.xmpMetadata = null;
        this.xmpWriter = null;
        this.pdfIsoConformance = initPdfIsoConformance();
        this.fullCompression = STRENGTH40BITS;
        this.compressionLevel = -1;
        this.documentFonts = new LinkedHashMap();
        this.fontNumber = markInlineElementsOnly;
        this.formXObjects = new HashMap();
        this.formXObjectsCounter = markInlineElementsOnly;
        this.readerInstances = new HashMap();
        this.documentColors = new HashMap();
        this.colorNumber = markInlineElementsOnly;
        this.documentPatterns = new HashMap();
        this.patternNumber = markInlineElementsOnly;
        this.documentShadingPatterns = new HashSet();
        this.documentShadings = new HashSet();
        this.documentExtGState = new HashMap();
        this.documentProperties = new HashMap();
        this.tagged = STRENGTH40BITS;
        this.taggingMode = markInlineElementsOnly;
        this.documentOCG = new HashSet();
        this.documentOCGorder = new ArrayList();
        this.OCGRadioGroup = new PdfArray();
        this.OCGLocked = new PdfArray();
        this.spaceCharRatio = SPACE_CHAR_RATIO_DEFAULT;
        this.runDirection = markInlineElementsOnly;
        this.defaultColorspace = new PdfDictionary();
        this.documentSpotPatterns = new HashMap();
        this.imageDictionary = new PdfDictionary();
        this.images = new HashMap();
        this.JBIG2Globals = new HashMap();
        this.ttfUnicodeWriter = null;
    }

    protected PdfWriter(PdfDocument document, OutputStream os) {
        super(document, os);
        this.root = new PdfPages(this);
        this.pageReferences = new ArrayList();
        this.currentPageNumber = markInlineElementsOnly;
        this.tabs = null;
        this.pageDictEntries = new PdfDictionary();
        this.prevxref = 0;
        this.originalFileID = null;
        this.pdf_version = new PdfVersionImp();
        this.xmpMetadata = null;
        this.xmpWriter = null;
        this.pdfIsoConformance = initPdfIsoConformance();
        this.fullCompression = STRENGTH40BITS;
        this.compressionLevel = -1;
        this.documentFonts = new LinkedHashMap();
        this.fontNumber = markInlineElementsOnly;
        this.formXObjects = new HashMap();
        this.formXObjectsCounter = markInlineElementsOnly;
        this.readerInstances = new HashMap();
        this.documentColors = new HashMap();
        this.colorNumber = markInlineElementsOnly;
        this.documentPatterns = new HashMap();
        this.patternNumber = markInlineElementsOnly;
        this.documentShadingPatterns = new HashSet();
        this.documentShadings = new HashSet();
        this.documentExtGState = new HashMap();
        this.documentProperties = new HashMap();
        this.tagged = STRENGTH40BITS;
        this.taggingMode = markInlineElementsOnly;
        this.documentOCG = new HashSet();
        this.documentOCGorder = new ArrayList();
        this.OCGRadioGroup = new PdfArray();
        this.OCGLocked = new PdfArray();
        this.spaceCharRatio = SPACE_CHAR_RATIO_DEFAULT;
        this.runDirection = markInlineElementsOnly;
        this.defaultColorspace = new PdfDictionary();
        this.documentSpotPatterns = new HashMap();
        this.imageDictionary = new PdfDictionary();
        this.images = new HashMap();
        this.JBIG2Globals = new HashMap();
        this.ttfUnicodeWriter = null;
        this.pdf = document;
        this.directContentUnder = new PdfContentByte(this);
        this.directContent = this.directContentUnder.getDuplicate();
    }

    public static PdfWriter getInstance(Document document, OutputStream os) throws DocumentException {
        PdfDocument pdf = new PdfDocument();
        document.addDocListener(pdf);
        PdfWriter writer = new PdfWriter(pdf, os);
        pdf.addWriter(writer);
        return writer;
    }

    public static PdfWriter getInstance(Document document, OutputStream os, DocListener listener) throws DocumentException {
        PdfDocument pdf = new PdfDocument();
        pdf.addDocListener(listener);
        document.addDocListener(pdf);
        PdfWriter writer = new PdfWriter(pdf, os);
        pdf.addWriter(writer);
        return writer;
    }

    PdfDocument getPdfDocument() {
        return this.pdf;
    }

    public PdfDictionary getInfo() {
        return this.pdf.getInfo();
    }

    public float getVerticalPosition(boolean ensureNewLine) {
        return this.pdf.getVerticalPosition(ensureNewLine);
    }

    public void setInitialLeading(float leading) throws DocumentException {
        if (this.open) {
            throw new DocumentException(MessageLocalization.getComposedMessage("you.can.t.set.the.initial.leading.if.the.document.is.already.open", new Object[markAll]));
        }
        this.pdf.setLeading(leading);
    }

    public PdfContentByte getDirectContent() {
        if (this.open) {
            return this.directContent;
        }
        throw new RuntimeException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[markAll]));
    }

    public PdfContentByte getDirectContentUnder() {
        if (this.open) {
            return this.directContentUnder;
        }
        throw new RuntimeException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[markAll]));
    }

    void resetContent() {
        this.directContent.reset();
        this.directContentUnder.reset();
    }

    public ICC_Profile getColorProfile() {
        return this.colorProfile;
    }

    void addLocalDestinations(TreeMap<String, Destination> desto) throws IOException {
        for (Entry<String, Destination> entry : desto.entrySet()) {
            String name = (String) entry.getKey();
            Destination dest = (Destination) entry.getValue();
            PdfObject destination = dest.destination;
            if (dest.reference == null) {
                dest.reference = getPdfIndirectReference();
            }
            if (destination == null) {
                addToBody(new PdfString("invalid_" + name), dest.reference);
            } else {
                addToBody(destination, dest.reference);
            }
        }
    }

    public PdfIndirectObject addToBody(PdfObject object) throws IOException {
        PdfIndirectObject iobj = this.body.add(object);
        cacheObject(iobj);
        return iobj;
    }

    public PdfIndirectObject addToBody(PdfObject object, boolean inObjStm) throws IOException {
        PdfIndirectObject iobj = this.body.add(object, inObjStm);
        cacheObject(iobj);
        return iobj;
    }

    public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref) throws IOException {
        PdfIndirectObject iobj = this.body.add(object, ref);
        cacheObject(iobj);
        return iobj;
    }

    public PdfIndirectObject addToBody(PdfObject object, PdfIndirectReference ref, boolean inObjStm) throws IOException {
        PdfIndirectObject iobj = this.body.add(object, ref, inObjStm);
        cacheObject(iobj);
        return iobj;
    }

    public PdfIndirectObject addToBody(PdfObject object, int refNumber) throws IOException {
        PdfIndirectObject iobj = this.body.add(object, refNumber);
        cacheObject(iobj);
        return iobj;
    }

    public PdfIndirectObject addToBody(PdfObject object, int refNumber, boolean inObjStm) throws IOException {
        PdfIndirectObject iobj = this.body.add(object, refNumber, markAll, inObjStm);
        cacheObject(iobj);
        return iobj;
    }

    protected void cacheObject(PdfIndirectObject iobj) {
    }

    public PdfIndirectReference getPdfIndirectReference() {
        return this.body.getPdfIndirectReference();
    }

    protected int getIndirectReferenceNumber() {
        return this.body.getIndirectReferenceNumber();
    }

    public OutputStreamCounter getOs() {
        return this.os;
    }

    protected PdfDictionary getCatalog(PdfIndirectReference rootObj) {
        PdfDictionary catalog = this.pdf.getCatalog(rootObj);
        buildStructTreeRootForTagged(catalog);
        if (!this.documentOCG.isEmpty()) {
            fillOCProperties(STRENGTH40BITS);
            catalog.put(PdfName.OCPROPERTIES, this.OCProperties);
        }
        return catalog;
    }

    protected void buildStructTreeRootForTagged(PdfDictionary catalog) {
        if (this.tagged) {
            try {
                getStructureTreeRoot().buildTree();
                catalog.put(PdfName.STRUCTTREEROOT, this.structureTreeRoot.getReference());
                PdfDictionary mi = new PdfDictionary();
                mi.put(PdfName.MARKED, PdfBoolean.PDFTRUE);
                if (this.userProperties) {
                    mi.put(PdfName.USERPROPERTIES, PdfBoolean.PDFTRUE);
                }
                catalog.put(PdfName.MARKINFO, mi);
            } catch (Exception e) {
                throw new ExceptionConverter(e);
            }
        }
    }

    public PdfDictionary getExtraCatalog() {
        if (this.extraCatalog == null) {
            this.extraCatalog = new PdfDictionary();
        }
        return this.extraCatalog;
    }

    public void addPageDictEntry(PdfName key, PdfObject object) {
        this.pageDictEntries.put(key, object);
    }

    public PdfDictionary getPageDictEntries() {
        return this.pageDictEntries;
    }

    public void resetPageDictEntries() {
        this.pageDictEntries = new PdfDictionary();
    }

    public void setLinearPageMode() {
        this.root.setLinearMode(null);
    }

    public int reorderPages(int[] order) throws DocumentException {
        return this.root.reorderPages(order);
    }

    public PdfIndirectReference getPageReference(int page) {
        page--;
        if (page < 0) {
            throw new IndexOutOfBoundsException(MessageLocalization.getComposedMessage("the.page.number.must.be.gt.eq.1", new Object[markAll]));
        } else if (page < this.pageReferences.size()) {
            ref = (PdfIndirectReference) this.pageReferences.get(page);
            if (ref != null) {
                return ref;
            }
            ref = this.body.getPdfIndirectReference();
            this.pageReferences.set(page, ref);
            return ref;
        } else {
            int empty = page - this.pageReferences.size();
            for (int k = markAll; k < empty; k += markInlineElementsOnly) {
                this.pageReferences.add(null);
            }
            ref = this.body.getPdfIndirectReference();
            this.pageReferences.add(ref);
            return ref;
        }
    }

    public int getPageNumber() {
        return this.pdf.getPageNumber();
    }

    PdfIndirectReference getCurrentPage() {
        return getPageReference(this.currentPageNumber);
    }

    public int getCurrentPageNumber() {
        return this.currentPageNumber;
    }

    public void setPageViewport(PdfArray vp) {
        addPageDictEntry(PdfName.VP, vp);
    }

    public void setTabs(PdfName tabs) {
        this.tabs = tabs;
    }

    public PdfName getTabs() {
        return this.tabs;
    }

    PdfIndirectReference add(PdfPage page, PdfContents contents) throws PdfException {
        if (this.open) {
            try {
                page.add(addToBody(contents).getIndirectReference());
                if (this.group != null) {
                    page.put(PdfName.GROUP, this.group);
                    this.group = null;
                } else if (this.rgbTransparencyBlending) {
                    PdfDictionary pp = new PdfDictionary();
                    pp.put(PdfName.TYPE, PdfName.GROUP);
                    pp.put(PdfName.f78S, PdfName.TRANSPARENCY);
                    pp.put(PdfName.CS, PdfName.DEVICERGB);
                    page.put(PdfName.GROUP, pp);
                }
                this.root.addPage((PdfDictionary) page);
                this.currentPageNumber += markInlineElementsOnly;
                return null;
            } catch (IOException ioe) {
                throw new ExceptionConverter(ioe);
            }
        }
        throw new PdfException(MessageLocalization.getComposedMessage("the.document.is.not.open", new Object[markAll]));
    }

    public void setPageEvent(PdfPageEvent event) {
        if (event == null) {
            this.pageEvent = null;
        } else if (this.pageEvent == null) {
            this.pageEvent = event;
        } else if (this.pageEvent instanceof PdfPageEventForwarder) {
            ((PdfPageEventForwarder) this.pageEvent).addPageEvent(event);
        } else {
            PdfPageEventForwarder forward = new PdfPageEventForwarder();
            forward.addPageEvent(this.pageEvent);
            forward.addPageEvent(event);
            this.pageEvent = forward;
        }
    }

    public PdfPageEvent getPageEvent() {
        return this.pageEvent;
    }

    public void open() {
        super.open();
        try {
            this.pdf_version.writeHeader(this.os);
            this.body = new PdfBody(this);
            if (isPdfX() && ((PdfXConformanceImp) this.pdfIsoConformance).isPdfX32002()) {
                PdfObject sec = new PdfDictionary();
                sec.put(PdfName.GAMMA, new PdfArray(new float[]{2.2f, 2.2f, 2.2f}));
                sec.put(PdfName.MATRIX, new PdfArray(new float[]{0.4124f, 0.2126f, 0.0193f, 0.3576f, 0.7152f, 0.1192f, 0.1805f, 0.0722f, 0.9505f}));
                sec.put(PdfName.WHITEPOINT, new PdfArray(new float[]{0.9505f, BaseField.BORDER_WIDTH_THIN, 1.089f}));
                PdfArray arr = new PdfArray(PdfName.CALRGB);
                arr.add(sec);
                setDefaultColorspace(PdfName.DEFAULTRGB, addToBody(arr).getIndirectReference());
            }
        } catch (IOException ioe) {
            throw new ExceptionConverter(ioe);
        }
    }

    public void close() {
        if (this.open) {
            if (this.currentPageNumber - 1 != this.pageReferences.size()) {
                throw new RuntimeException("The page " + this.pageReferences.size() + " was requested but the document has only " + (this.currentPageNumber - 1) + " pages.");
            }
            this.pdf.close();
            try {
                PdfObject fileID;
                addSharedObjectsToBody();
                Iterator i$ = this.documentOCG.iterator();
                while (i$.hasNext()) {
                    PdfOCG layer = (PdfOCG) i$.next();
                    addToBody(layer.getPdfObject(), layer.getRef());
                }
                PdfObject catalog = getCatalog(this.root.writePageTree());
                if (!this.documentOCG.isEmpty()) {
                    checkPdfIsoConformance(this, ENCRYPTION_MASK, this.OCProperties);
                }
                if (this.xmpMetadata == null && this.xmpWriter != null) {
                    try {
                        OutputStream baos = new ByteArrayOutputStream();
                        this.xmpWriter.serialize(baos);
                        this.xmpWriter.close();
                        this.xmpMetadata = baos.toByteArray();
                    } catch (IOException e) {
                        this.xmpWriter = null;
                    } catch (XMPException e2) {
                        this.xmpWriter = null;
                    }
                }
                if (this.xmpMetadata != null) {
                    PdfObject pdfStream = new PdfStream(this.xmpMetadata);
                    pdfStream.put(PdfName.TYPE, PdfName.METADATA);
                    pdfStream.put(PdfName.SUBTYPE, PdfName.XML);
                    if (!(this.crypto == null || this.crypto.isMetadataEncrypted())) {
                        PdfObject ar = new PdfArray();
                        ar.add(PdfName.CRYPT);
                        pdfStream.put(PdfName.FILTER, ar);
                    }
                    catalog.put(PdfName.METADATA, this.body.add(pdfStream).getIndirectReference());
                }
                if (isPdfX()) {
                    completeInfoDictionary(getInfo());
                    completeExtraCatalog(getExtraCatalog());
                }
                if (this.extraCatalog != null) {
                    catalog.mergeDifferent(this.extraCatalog);
                }
                writeOutlines(catalog, STRENGTH40BITS);
                PdfIndirectObject indirectCatalog = addToBody(catalog, (boolean) STRENGTH40BITS);
                PdfIndirectObject infoObj = addToBody(getInfo(), (boolean) STRENGTH40BITS);
                PdfIndirectReference encryption = null;
                this.body.flushObjStm();
                boolean isModified = this.originalFileID != null ? STRENGTH128BITS : STRENGTH40BITS;
                if (this.crypto != null) {
                    encryption = addToBody(this.crypto.getEncryptionDictionary(), (boolean) STRENGTH40BITS).getIndirectReference();
                    fileID = this.crypto.getFileID(isModified);
                } else {
                    fileID = PdfEncryption.createInfoId(isModified ? this.originalFileID : PdfEncryption.createDocumentId(), isModified);
                }
                this.body.writeCrossReferenceTable(this.os, indirectCatalog.getIndirectReference(), infoObj.getIndirectReference(), encryption, fileID, this.prevxref);
                if (this.fullCompression) {
                    writeKeyInfo(this.os);
                    this.os.write(DocWriter.getISOBytes("startxref\n"));
                    this.os.write(DocWriter.getISOBytes(String.valueOf(this.body.offset())));
                    this.os.write(DocWriter.getISOBytes("\n%%EOF\n"));
                } else {
                    new PdfTrailer(this.body.size(), this.body.offset(), indirectCatalog.getIndirectReference(), infoObj.getIndirectReference(), encryption, fileID, this.prevxref).toPdf(this, this.os);
                }
                super.close();
            } catch (Exception ioe) {
                throw new ExceptionConverter(ioe);
            } catch (Throwable th) {
                super.close();
            }
        }
        getCounter().written(this.os.getCounter());
    }

    protected void addXFormsToBody() throws IOException {
        for (Object[] objs : this.formXObjects.values()) {
            PdfTemplate template = objs[markInlineElementsOnly];
            if ((template == null || !(template.getIndirectReference() instanceof PRIndirectReference)) && template != null && template.getType() == markInlineElementsOnly) {
                addToBody(template.getFormXObject(this.compressionLevel), template.getIndirectReference());
            }
        }
    }

    protected void addSharedObjectsToBody() throws IOException {
        for (FontDetails details : this.documentFonts.values()) {
            details.writeFont(this);
        }
        addXFormsToBody();
        for (PdfReaderInstance element : this.readerInstances.values()) {
            this.currentPdfReaderInstance = element;
            this.currentPdfReaderInstance.writeAllPages();
        }
        this.currentPdfReaderInstance = null;
        for (ColorDetails color : this.documentColors.values()) {
            addToBody(color.getPdfObject(this), color.getIndirectReference());
        }
        for (PdfPatternPainter pat : this.documentPatterns.keySet()) {
            addToBody(pat.getPattern(this.compressionLevel), pat.getIndirectReference());
        }
        Iterator i$ = this.documentShadingPatterns.iterator();
        while (i$.hasNext()) {
            ((PdfShadingPattern) i$.next()).addToBody();
        }
        i$ = this.documentShadings.iterator();
        while (i$.hasNext()) {
            ((PdfShading) i$.next()).addToBody();
        }
        for (Entry<PdfDictionary, PdfObject[]> entry : this.documentExtGState.entrySet()) {
            addToBody((PdfDictionary) entry.getKey(), (PdfIndirectReference) ((PdfObject[]) entry.getValue())[markInlineElementsOnly]);
        }
        for (Entry<Object, PdfObject[]> entry2 : this.documentProperties.entrySet()) {
            PdfLayerMembership prop = entry2.getKey();
            PdfObject[] obj = (PdfObject[]) entry2.getValue();
            if (prop instanceof PdfLayerMembership) {
                PdfLayerMembership layer = prop;
                addToBody(layer.getPdfObject(), layer.getRef());
            } else if ((prop instanceof PdfDictionary) && !(prop instanceof PdfLayer)) {
                addToBody((PdfObject) prop, (PdfIndirectReference) obj[markInlineElementsOnly]);
            }
        }
    }

    public PdfOutline getRootOutline() {
        return this.directContent.getRootOutline();
    }

    public void setOutlines(List<HashMap<String, Object>> outlines) {
        this.newBookmarks = outlines;
    }

    protected void writeOutlines(PdfDictionary catalog, boolean namedAsNames) throws IOException {
        if (this.newBookmarks != null && !this.newBookmarks.isEmpty()) {
            PdfObject top = new PdfDictionary();
            PdfIndirectReference topRef = getPdfIndirectReference();
            Object[] kids = SimpleBookmark.iterateOutlines(this, topRef, this.newBookmarks, namedAsNames);
            top.put(PdfName.FIRST, (PdfIndirectReference) kids[markAll]);
            top.put(PdfName.LAST, (PdfIndirectReference) kids[markInlineElementsOnly]);
            top.put(PdfName.COUNT, new PdfNumber(((Integer) kids[SIGNATURE_APPEND_ONLY]).intValue()));
            addToBody(top, topRef);
            catalog.put(PdfName.OUTLINES, topRef);
        }
    }

    public void setPdfVersion(char version) {
        this.pdf_version.setPdfVersion(version);
    }

    public void setAtLeastPdfVersion(char version) {
        this.pdf_version.setAtLeastPdfVersion(version);
    }

    public void setPdfVersion(PdfName version) {
        this.pdf_version.setPdfVersion(version);
    }

    public void addDeveloperExtension(PdfDeveloperExtension de) {
        this.pdf_version.addDeveloperExtension(de);
    }

    PdfVersionImp getPdfVersion() {
        return this.pdf_version;
    }

    public void setViewerPreferences(int preferences) {
        this.pdf.setViewerPreferences(preferences);
    }

    public void addViewerPreference(PdfName key, PdfObject value) {
        this.pdf.addViewerPreference(key, value);
    }

    public void setPageLabels(PdfPageLabels pageLabels) {
        this.pdf.setPageLabels(pageLabels);
    }

    public void addNamedDestinations(Map<String, String> map, int page_offset) {
        for (Entry<String, String> entry : map.entrySet()) {
            String dest = (String) entry.getValue();
            int page = Integer.parseInt(dest.substring(markAll, dest.indexOf(" ")));
            addNamedDestination((String) entry.getKey(), page + page_offset, new PdfDestination(dest.substring(dest.indexOf(" ") + markInlineElementsOnly)));
        }
    }

    public void addNamedDestination(String name, int page, PdfDestination dest) {
        dest.addPage(getPageReference(page));
        this.pdf.localDestination(name, dest);
    }

    public void addJavaScript(PdfAction js) {
        this.pdf.addJavaScript(js);
    }

    public void addJavaScript(String code, boolean unicode) {
        addJavaScript(PdfAction.javaScript(code, this, unicode));
    }

    public void addJavaScript(String code) {
        addJavaScript(code, (boolean) STRENGTH40BITS);
    }

    public void addJavaScript(String name, PdfAction js) {
        this.pdf.addJavaScript(name, js);
    }

    public void addJavaScript(String name, String code, boolean unicode) {
        addJavaScript(name, PdfAction.javaScript(code, this, unicode));
    }

    public void addJavaScript(String name, String code) {
        addJavaScript(name, code, STRENGTH40BITS);
    }

    public void addFileAttachment(String description, byte[] fileStore, String file, String fileDisplay) throws IOException {
        addFileAttachment(description, PdfFileSpecification.fileEmbedded(this, file, fileDisplay, fileStore));
    }

    public void addFileAttachment(String description, PdfFileSpecification fs) throws IOException {
        this.pdf.addFileAttachment(description, fs);
    }

    public void addFileAttachment(PdfFileSpecification fs) throws IOException {
        addFileAttachment(null, fs);
    }

    public void setOpenAction(String name) {
        this.pdf.setOpenAction(name);
    }

    public void setOpenAction(PdfAction action) {
        this.pdf.setOpenAction(action);
    }

    public void setAdditionalAction(PdfName actionType, PdfAction action) throws DocumentException {
        if (actionType.equals(DOCUMENT_CLOSE) || actionType.equals(WILL_SAVE) || actionType.equals(DID_SAVE) || actionType.equals(WILL_PRINT) || actionType.equals(DID_PRINT)) {
            this.pdf.addAdditionalAction(actionType, action);
            return;
        }
        Object[] objArr = new Object[markInlineElementsOnly];
        objArr[markAll] = actionType.toString();
        throw new DocumentException(MessageLocalization.getComposedMessage("invalid.additional.action.type.1", objArr));
    }

    public void setCollection(PdfCollection collection) {
        setAtLeastPdfVersion(VERSION_1_7);
        this.pdf.setCollection(collection);
    }

    public PdfAcroForm getAcroForm() {
        return this.pdf.getAcroForm();
    }

    public void addAnnotation(PdfAnnotation annot) {
        this.pdf.addAnnotation(annot);
    }

    void addAnnotation(PdfAnnotation annot, int page) {
        addAnnotation(annot);
    }

    public void addCalculationOrder(PdfFormField annot) {
        this.pdf.addCalculationOrder(annot);
    }

    public void setSigFlags(int f) {
        this.pdf.setSigFlags(f);
    }

    public void setLanguage(String language) {
        this.pdf.setLanguage(language);
    }

    public void setXmpMetadata(byte[] xmpMetadata) {
        this.xmpMetadata = xmpMetadata;
    }

    public void setPageXmpMetadata(byte[] xmpMetadata) throws IOException {
        this.pdf.setXmpMetadata(xmpMetadata);
    }

    public XmpWriter getXmpWriter() {
        return this.xmpWriter;
    }

    public void createXmpMetadata() {
        try {
            this.xmpWriter = createXmpWriter(null, this.pdf.getInfo());
            if (isTagged()) {
                this.xmpWriter.getXmpMeta().setPropertyInteger(XMPConst.NS_PDFUA_ID, PdfProperties.PART, markInlineElementsOnly, new PropertyOptions(PropertyOptions.SEPARATE_NODE));
            }
            this.xmpMetadata = null;
        } catch (XMPException e) {
            throw new ExceptionConverter(e);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    protected PdfIsoConformance initPdfIsoConformance() {
        return new PdfXConformanceImp(this);
    }

    public void setPDFXConformance(int pdfx) {
        if (!(this.pdfIsoConformance instanceof PdfXConformanceImp) || ((PdfXConformance) this.pdfIsoConformance).getPDFXConformance() == pdfx) {
            return;
        }
        if (this.pdf.isOpen()) {
            throw new PdfXConformanceException(MessageLocalization.getComposedMessage("pdfx.conformance.can.only.be.set.before.opening.the.document", new Object[markAll]));
        } else if (this.crypto != null) {
            throw new PdfXConformanceException(MessageLocalization.getComposedMessage("a.pdfx.conforming.document.cannot.be.encrypted", new Object[markAll]));
        } else {
            if (pdfx != 0) {
                setPdfVersion((char) VERSION_1_3);
            }
            ((PdfXConformance) this.pdfIsoConformance).setPDFXConformance(pdfx);
        }
    }

    public int getPDFXConformance() {
        if (this.pdfIsoConformance instanceof PdfXConformanceImp) {
            return ((PdfXConformance) this.pdfIsoConformance).getPDFXConformance();
        }
        return markAll;
    }

    public boolean isPdfX() {
        if (this.pdfIsoConformance instanceof PdfXConformanceImp) {
            return ((PdfXConformance) this.pdfIsoConformance).isPdfX();
        }
        return STRENGTH40BITS;
    }

    public boolean isPdfIso() {
        return this.pdfIsoConformance.isPdfIso();
    }

    public void setOutputIntents(String outputConditionIdentifier, String outputCondition, String registryName, String info, ICC_Profile colorProfile) throws IOException {
        checkPdfIsoConformance(this, 19, colorProfile);
        getExtraCatalog();
        PdfObject out = new PdfDictionary(PdfName.OUTPUTINTENT);
        if (outputCondition != null) {
            out.put(PdfName.OUTPUTCONDITION, new PdfString(outputCondition, PdfObject.TEXT_UNICODE));
        }
        if (outputConditionIdentifier != null) {
            out.put(PdfName.OUTPUTCONDITIONIDENTIFIER, new PdfString(outputConditionIdentifier, PdfObject.TEXT_UNICODE));
        }
        if (registryName != null) {
            out.put(PdfName.REGISTRYNAME, new PdfString(registryName, PdfObject.TEXT_UNICODE));
        }
        if (info != null) {
            out.put(PdfName.INFO, new PdfString(info, PdfObject.TEXT_UNICODE));
        }
        if (colorProfile != null) {
            out.put(PdfName.DESTOUTPUTPROFILE, addToBody(new PdfICCBased(colorProfile, this.compressionLevel)).getIndirectReference());
        }
        out.put(PdfName.f78S, PdfName.GTS_PDFX);
        this.extraCatalog.put(PdfName.OUTPUTINTENTS, new PdfArray(out));
        this.colorProfile = colorProfile;
    }

    public void setOutputIntents(String outputConditionIdentifier, String outputCondition, String registryName, String info, byte[] destOutputProfile) throws IOException {
        setOutputIntents(outputConditionIdentifier, outputCondition, registryName, info, destOutputProfile == null ? null : ICC_Profile.getInstance(destOutputProfile));
    }

    public boolean setOutputIntents(PdfReader reader, boolean checkExistence) throws IOException {
        PdfArray outs = reader.getCatalog().getAsArray(PdfName.OUTPUTINTENTS);
        if (outs == null || outs.isEmpty()) {
            return STRENGTH40BITS;
        }
        PdfDictionary out = outs.getAsDict(markAll);
        PdfObject obj = PdfReader.getPdfObject(out.get(PdfName.f78S));
        if (obj == null || !PdfName.GTS_PDFX.equals(obj)) {
            return STRENGTH40BITS;
        }
        if (checkExistence) {
            return STRENGTH128BITS;
        }
        PRStream stream = (PRStream) PdfReader.getPdfObject(out.get(PdfName.DESTOUTPUTPROFILE));
        byte[] destProfile = null;
        if (stream != null) {
            destProfile = PdfReader.getStreamBytes(stream);
        }
        setOutputIntents(getNameString(out, PdfName.OUTPUTCONDITIONIDENTIFIER), getNameString(out, PdfName.OUTPUTCONDITION), getNameString(out, PdfName.REGISTRYNAME), getNameString(out, PdfName.INFO), destProfile);
        return STRENGTH128BITS;
    }

    private static String getNameString(PdfDictionary dic, PdfName key) {
        PdfObject obj = PdfReader.getPdfObject(dic.get(key));
        if (obj == null || !obj.isString()) {
            return null;
        }
        return ((PdfString) obj).toUnicodeString();
    }

    PdfEncryption getEncryption() {
        return this.crypto;
    }

    public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, int encryptionType) throws DocumentException {
        if (this.pdf.isOpen()) {
            throw new DocumentException(MessageLocalization.getComposedMessage("encryption.can.only.be.added.before.opening.the.document", new Object[markAll]));
        }
        this.crypto = new PdfEncryption();
        this.crypto.setCryptoMode(encryptionType, markAll);
        this.crypto.setupAllKeys(userPassword, ownerPassword, permissions);
    }

    public void setEncryption(Certificate[] certs, int[] permissions, int encryptionType) throws DocumentException {
        if (this.pdf.isOpen()) {
            throw new DocumentException(MessageLocalization.getComposedMessage("encryption.can.only.be.added.before.opening.the.document", new Object[markAll]));
        }
        this.crypto = new PdfEncryption();
        if (certs != null) {
            for (int i = markAll; i < certs.length; i += markInlineElementsOnly) {
                this.crypto.addRecipient(certs[i], permissions[i]);
            }
        }
        this.crypto.setCryptoMode(encryptionType, markAll);
        this.crypto.getEncryptionDictionary();
    }

    @Deprecated
    public void setEncryption(byte[] userPassword, byte[] ownerPassword, int permissions, boolean strength128Bits) throws DocumentException {
        setEncryption(userPassword, ownerPassword, permissions, strength128Bits ? markInlineElementsOnly : markAll);
    }

    @Deprecated
    public void setEncryption(boolean strength, String userPassword, String ownerPassword, int permissions) throws DocumentException {
        setEncryption(DocWriter.getISOBytes(userPassword), DocWriter.getISOBytes(ownerPassword), permissions, strength ? markInlineElementsOnly : markAll);
    }

    @Deprecated
    public void setEncryption(int encryptionType, String userPassword, String ownerPassword, int permissions) throws DocumentException {
        setEncryption(DocWriter.getISOBytes(userPassword), DocWriter.getISOBytes(ownerPassword), permissions, encryptionType);
    }

    public boolean isFullCompression() {
        return this.fullCompression;
    }

    public void setFullCompression() throws DocumentException {
        if (this.open) {
            throw new DocumentException(MessageLocalization.getComposedMessage("you.can.t.set.the.full.compression.if.the.document.is.already.open", new Object[markAll]));
        }
        this.fullCompression = STRENGTH128BITS;
        setAtLeastPdfVersion(VERSION_1_5);
    }

    public int getCompressionLevel() {
        return this.compressionLevel;
    }

    public void setCompressionLevel(int compressionLevel) {
        if (compressionLevel < 0 || compressionLevel > 9) {
            this.compressionLevel = -1;
        } else {
            this.compressionLevel = compressionLevel;
        }
    }

    FontDetails addSimple(BaseFont bf) {
        FontDetails ret = (FontDetails) this.documentFonts.get(bf);
        if (ret == null) {
            checkPdfIsoConformance(this, PageLayoutTwoColumnLeft, bf);
            int i;
            if (bf.getFontType() == PageLayoutTwoColumnLeft) {
                StringBuilder append = new StringBuilder().append("F");
                i = this.fontNumber;
                this.fontNumber = i + markInlineElementsOnly;
                ret = new FontDetails(new PdfName(append.append(i).toString()), ((DocumentFont) bf).getIndirectReference(), bf);
            } else {
                StringBuilder append2 = new StringBuilder().append("F");
                i = this.fontNumber;
                this.fontNumber = i + markInlineElementsOnly;
                ret = new FontDetails(new PdfName(append2.append(i).toString()), this.body.getPdfIndirectReference(), bf);
            }
            this.documentFonts.put(bf, ret);
        }
        return ret;
    }

    void eliminateFontSubset(PdfDictionary fonts) {
        for (FontDetails ft : this.documentFonts.values()) {
            if (fonts.get(ft.getFontName()) != null) {
                ft.setSubset(STRENGTH40BITS);
            }
        }
    }

    PdfName addDirectTemplateSimple(PdfTemplate template, PdfName forcedName) {
        PdfName name;
        PdfIndirectReference ref = template.getIndirectReference();
        Object[] obj = (Object[]) this.formXObjects.get(ref);
        if (obj == null) {
            if (forcedName == null) {
                PdfName name2;
                try {
                    name2 = new PdfName("Xf" + this.formXObjectsCounter);
                } catch (Exception e) {
                    e = e;
                    throw new ExceptionConverter(e);
                }
                try {
                    this.formXObjectsCounter += markInlineElementsOnly;
                    name = name2;
                } catch (Exception e2) {
                    Exception e3;
                    e3 = e2;
                    name = name2;
                    throw new ExceptionConverter(e3);
                }
            }
            name = forcedName;
            if (template.getType() == SIGNATURE_APPEND_ONLY) {
                PdfImportedPage ip = (PdfImportedPage) template;
                PdfReader r = ip.getPdfReaderInstance().getReader();
                if (!this.readerInstances.containsKey(r)) {
                    this.readerInstances.put(r, ip.getPdfReaderInstance());
                }
                template = null;
            }
            HashMap hashMap = this.formXObjects;
            Object obj2 = new Object[SIGNATURE_APPEND_ONLY];
            obj2[markAll] = name;
            obj2[markInlineElementsOnly] = template;
            hashMap.put(ref, obj2);
        } else {
            name = (PdfName) obj[markAll];
        }
        return name;
    }

    public void releaseTemplate(PdfTemplate tp) throws IOException {
        Object[] objs = (Object[]) this.formXObjects.get(tp.getIndirectReference());
        if (objs != null && objs[markInlineElementsOnly] != null) {
            PdfTemplate template = objs[markInlineElementsOnly];
            if (!(template.getIndirectReference() instanceof PRIndirectReference) && template.getType() == markInlineElementsOnly) {
                addToBody(template.getFormXObject(this.compressionLevel), template.getIndirectReference());
                objs[markInlineElementsOnly] = null;
            }
        }
    }

    public PdfImportedPage getImportedPage(PdfReader reader, int pageNumber) {
        return getPdfReaderInstance(reader).getImportedPage(pageNumber);
    }

    protected PdfReaderInstance getPdfReaderInstance(PdfReader reader) {
        PdfReaderInstance inst = (PdfReaderInstance) this.readerInstances.get(reader);
        if (inst != null) {
            return inst;
        }
        inst = reader.getPdfReaderInstance(this);
        this.readerInstances.put(reader, inst);
        return inst;
    }

    public void freeReader(PdfReader reader) throws IOException {
        this.currentPdfReaderInstance = (PdfReaderInstance) this.readerInstances.get(reader);
        if (this.currentPdfReaderInstance != null) {
            this.currentPdfReaderInstance.writeAllPages();
            this.currentPdfReaderInstance = null;
            this.readerInstances.remove(reader);
        }
    }

    public long getCurrentDocumentSize() {
        return (this.body.offset() + ((long) (this.body.size() * 20))) + 72;
    }

    protected int getNewObjectNumber(PdfReader reader, int number, int generation) {
        if (this.currentPdfReaderInstance == null || this.currentPdfReaderInstance.getReader() != reader) {
            this.currentPdfReaderInstance = getPdfReaderInstance(reader);
        }
        return this.currentPdfReaderInstance.getNewObjectNumber(number, generation);
    }

    RandomAccessFileOrArray getReaderFile(PdfReader reader) {
        return this.currentPdfReaderInstance.getReaderFile();
    }

    PdfName getColorspaceName() {
        StringBuilder append = new StringBuilder().append("CS");
        int i = this.colorNumber;
        this.colorNumber = i + markInlineElementsOnly;
        return new PdfName(append.append(i).toString());
    }

    ColorDetails addSimple(ICachedColorSpace spc) {
        ColorDetails ret = (ColorDetails) this.documentColors.get(spc);
        if (ret == null) {
            ret = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), spc);
            if (spc instanceof IPdfSpecialColorSpace) {
                ((IPdfSpecialColorSpace) spc).getColorantDetails(this);
            }
            this.documentColors.put(spc, ret);
        }
        return ret;
    }

    PdfName addSimplePattern(PdfPatternPainter painter) {
        Exception e;
        PdfName name = (PdfName) this.documentPatterns.get(painter);
        if (name != null) {
            return name;
        }
        try {
            PdfName name2 = new PdfName("P" + this.patternNumber);
            try {
                this.patternNumber += markInlineElementsOnly;
                this.documentPatterns.put(painter, name2);
                return name2;
            } catch (Exception e2) {
                e = e2;
                name = name2;
                throw new ExceptionConverter(e);
            }
        } catch (Exception e3) {
            e = e3;
            throw new ExceptionConverter(e);
        }
    }

    void addSimpleShadingPattern(PdfShadingPattern shading) {
        if (!this.documentShadingPatterns.contains(shading)) {
            shading.setName(this.patternNumber);
            this.patternNumber += markInlineElementsOnly;
            this.documentShadingPatterns.add(shading);
            addSimpleShading(shading.getShading());
        }
    }

    void addSimpleShading(PdfShading shading) {
        if (!this.documentShadings.contains(shading)) {
            this.documentShadings.add(shading);
            shading.setName(this.documentShadings.size());
        }
    }

    PdfObject[] addSimpleExtGState(PdfDictionary gstate) {
        if (!this.documentExtGState.containsKey(gstate)) {
            HashMap hashMap = this.documentExtGState;
            Object obj = new PdfObject[SIGNATURE_APPEND_ONLY];
            obj[markAll] = new PdfName("GS" + (this.documentExtGState.size() + markInlineElementsOnly));
            obj[markInlineElementsOnly] = getPdfIndirectReference();
            hashMap.put(gstate, obj);
        }
        return (PdfObject[]) this.documentExtGState.get(gstate);
    }

    PdfObject[] addSimpleProperty(Object prop, PdfIndirectReference refi) {
        if (!this.documentProperties.containsKey(prop)) {
            if (prop instanceof PdfOCG) {
                checkPdfIsoConformance(this, ENCRYPTION_MASK, prop);
            }
            HashMap hashMap = this.documentProperties;
            Object obj = new PdfObject[SIGNATURE_APPEND_ONLY];
            obj[markAll] = new PdfName("Pr" + (this.documentProperties.size() + markInlineElementsOnly));
            obj[markInlineElementsOnly] = refi;
            hashMap.put(prop, obj);
        }
        return (PdfObject[]) this.documentProperties.get(prop);
    }

    boolean propertyExists(Object prop) {
        return this.documentProperties.containsKey(prop);
    }

    public void setTagged() {
        setTagged(markInlineElementsOnly);
    }

    public void setTagged(int taggingMode) {
        if (this.open) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("tagging.must.be.set.before.opening.the.document", new Object[markAll]));
        }
        this.tagged = STRENGTH128BITS;
        this.taggingMode = taggingMode;
    }

    public boolean needToBeMarkedInContent(IAccessibleElement element) {
        if ((this.taggingMode & markInlineElementsOnly) == 0 || element.isInline() || PdfName.ARTIFACT.equals(element.getRole())) {
            return STRENGTH128BITS;
        }
        return STRENGTH40BITS;
    }

    public void checkElementRole(IAccessibleElement element, IAccessibleElement parent) {
        if (parent != null && (parent.getRole() == null || PdfName.ARTIFACT.equals(parent.getRole()))) {
            element.setRole(null);
        } else if ((this.taggingMode & markInlineElementsOnly) == 0 || !element.isInline() || element.getRole() != null) {
        } else {
            if (parent == null || !parent.isInline()) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("inline.elements.with.role.null.are.not.allowed", new Object[markAll]));
            }
        }
    }

    public boolean isTagged() {
        return this.tagged;
    }

    protected void flushTaggedObjects() throws IOException {
    }

    protected void flushAcroFields() throws IOException, BadPdfFormatException {
    }

    public PdfStructureTreeRoot getStructureTreeRoot() {
        if (this.tagged && this.structureTreeRoot == null) {
            this.structureTreeRoot = new PdfStructureTreeRoot(this);
        }
        return this.structureTreeRoot;
    }

    public PdfOCProperties getOCProperties() {
        fillOCProperties(STRENGTH128BITS);
        return this.OCProperties;
    }

    public void addOCGRadioGroup(ArrayList<PdfLayer> group) {
        PdfObject ar = new PdfArray();
        for (int k = markAll; k < group.size(); k += markInlineElementsOnly) {
            PdfLayer layer = (PdfLayer) group.get(k);
            if (layer.getTitle() == null) {
                ar.add(layer.getRef());
            }
        }
        if (ar.size() != 0) {
            this.OCGRadioGroup.add(ar);
        }
    }

    public void lockLayer(PdfLayer layer) {
        this.OCGLocked.add(layer.getRef());
    }

    private static void getOCGOrder(PdfArray order, PdfLayer layer) {
        if (layer.isOnPanel()) {
            if (layer.getTitle() == null) {
                order.add(layer.getRef());
            }
            ArrayList<PdfLayer> children = layer.getChildren();
            if (children != null) {
                PdfObject kids = new PdfArray();
                if (layer.getTitle() != null) {
                    kids.add(new PdfString(layer.getTitle(), PdfObject.TEXT_UNICODE));
                }
                for (int k = markAll; k < children.size(); k += markInlineElementsOnly) {
                    getOCGOrder(kids, (PdfLayer) children.get(k));
                }
                if (kids.size() > 0) {
                    order.add(kids);
                }
            }
        }
    }

    private void addASEvent(PdfName event, PdfName category) {
        PdfArray arr = new PdfArray();
        Iterator i$ = this.documentOCG.iterator();
        while (i$.hasNext()) {
            PdfLayer layer = (PdfLayer) i$.next();
            PdfDictionary usage = layer.getAsDict(PdfName.USAGE);
            if (!(usage == null || usage.get(category) == null)) {
                arr.add(layer.getRef());
            }
        }
        if (arr.size() != 0) {
            PdfDictionary d = this.OCProperties.getAsDict(PdfName.f65D);
            PdfArray arras = d.getAsArray(PdfName.AS);
            if (arras == null) {
                arras = new PdfArray();
                d.put(PdfName.AS, arras);
            }
            PdfObject as = new PdfDictionary();
            as.put(PdfName.EVENT, event);
            as.put(PdfName.CATEGORY, new PdfArray((PdfObject) category));
            as.put(PdfName.OCGS, arr);
            arras.add(as);
        }
    }

    protected void fillOCProperties(boolean erase) {
        PdfArray gr;
        Iterator i$;
        if (this.OCProperties == null) {
            this.OCProperties = new PdfOCProperties();
        }
        if (erase) {
            this.OCProperties.remove(PdfName.OCGS);
            this.OCProperties.remove(PdfName.f65D);
        }
        if (this.OCProperties.get(PdfName.OCGS) == null) {
            gr = new PdfArray();
            i$ = this.documentOCG.iterator();
            while (i$.hasNext()) {
                gr.add(((PdfLayer) i$.next()).getRef());
            }
            this.OCProperties.put(PdfName.OCGS, gr);
        }
        if (this.OCProperties.get(PdfName.f65D) == null) {
            ArrayList<PdfOCG> docOrder = new ArrayList(this.documentOCGorder);
            Iterator<PdfOCG> it = docOrder.iterator();
            while (it.hasNext()) {
                if (((PdfLayer) it.next()).getParent() != null) {
                    it.remove();
                }
            }
            PdfArray order = new PdfArray();
            i$ = docOrder.iterator();
            while (i$.hasNext()) {
                getOCGOrder(order, (PdfLayer) i$.next());
            }
            PdfDictionary d = new PdfDictionary();
            this.OCProperties.put(PdfName.f65D, d);
            d.put(PdfName.ORDER, order);
            if (docOrder.size() > 0 && (docOrder.get(markAll) instanceof PdfLayer)) {
                PdfString name = ((PdfLayer) docOrder.get(markAll)).getAsString(PdfName.NAME);
                if (name != null) {
                    d.put(PdfName.NAME, name);
                }
            }
            gr = new PdfArray();
            i$ = this.documentOCG.iterator();
            while (i$.hasNext()) {
                PdfLayer layer = (PdfLayer) i$.next();
                if (!layer.isOn()) {
                    gr.add(layer.getRef());
                }
            }
            if (gr.size() > 0) {
                d.put(PdfName.OFF, gr);
            }
            if (this.OCGRadioGroup.size() > 0) {
                d.put(PdfName.RBGROUPS, this.OCGRadioGroup);
            }
            if (this.OCGLocked.size() > 0) {
                d.put(PdfName.LOCKED, this.OCGLocked);
            }
            addASEvent(PdfName.VIEW, PdfName.ZOOM);
            addASEvent(PdfName.VIEW, PdfName.VIEW);
            addASEvent(PdfName.PRINT, PdfName.PRINT);
            addASEvent(PdfName.EXPORT, PdfName.EXPORT);
            d.put(PdfName.LISTMODE, PdfName.VISIBLEPAGES);
        }
    }

    void registerLayer(PdfOCG layer) {
        checkPdfIsoConformance(this, ENCRYPTION_MASK, layer);
        if (!(layer instanceof PdfLayer)) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("only.pdflayer.is.accepted", new Object[markAll]));
        } else if (((PdfLayer) layer).getTitle() != null) {
            this.documentOCGorder.add(layer);
        } else if (!this.documentOCG.contains(layer)) {
            this.documentOCG.add(layer);
            this.documentOCGorder.add(layer);
        }
    }

    public Rectangle getPageSize() {
        return this.pdf.getPageSize();
    }

    public void setCropBoxSize(Rectangle crop) {
        this.pdf.setCropBoxSize(crop);
    }

    public void setBoxSize(String boxName, Rectangle size) {
        this.pdf.setBoxSize(boxName, size);
    }

    public Rectangle getBoxSize(String boxName) {
        return this.pdf.getBoxSize(boxName);
    }

    public Rectangle getBoxSize(String boxName, Rectangle intersectingRectangle) {
        Rectangle pdfRectangle = this.pdf.getBoxSize(boxName);
        if (pdfRectangle == null || intersectingRectangle == null) {
            return null;
        }
        com.itextpdf.awt.geom.Rectangle outRect = new com.itextpdf.awt.geom.Rectangle(pdfRectangle).intersection(new com.itextpdf.awt.geom.Rectangle(intersectingRectangle));
        if (outRect.isEmpty()) {
            return null;
        }
        Rectangle output = new Rectangle((float) outRect.getX(), (float) outRect.getY(), (float) (outRect.getX() + outRect.getWidth()), (float) (outRect.getY() + outRect.getHeight()));
        output.normalize();
        return output;
    }

    public void setPageEmpty(boolean pageEmpty) {
        if (!pageEmpty) {
            this.pdf.setPageEmpty(pageEmpty);
        }
    }

    public boolean isPageEmpty() {
        return this.pdf.isPageEmpty();
    }

    public void setPageAction(PdfName actionType, PdfAction action) throws DocumentException {
        if (actionType.equals(PAGE_OPEN) || actionType.equals(PAGE_CLOSE)) {
            this.pdf.setPageAction(actionType, action);
            return;
        }
        Object[] objArr = new Object[markInlineElementsOnly];
        objArr[markAll] = actionType.toString();
        throw new DocumentException(MessageLocalization.getComposedMessage("invalid.page.additional.action.type.1", objArr));
    }

    public void setDuration(int seconds) {
        this.pdf.setDuration(seconds);
    }

    public void setTransition(PdfTransition transition) {
        this.pdf.setTransition(transition);
    }

    public void setThumbnail(Image image) throws PdfException, DocumentException {
        this.pdf.setThumbnail(image);
    }

    public PdfDictionary getGroup() {
        return this.group;
    }

    public void setGroup(PdfDictionary group) {
        this.group = group;
    }

    public float getSpaceCharRatio() {
        return this.spaceCharRatio;
    }

    public void setSpaceCharRatio(float spaceCharRatio) {
        if (spaceCharRatio < 0.001f) {
            this.spaceCharRatio = 0.001f;
        } else {
            this.spaceCharRatio = spaceCharRatio;
        }
    }

    public void setRunDirection(int runDirection) {
        if (runDirection < markInlineElementsOnly || runDirection > RUN_DIRECTION_RTL) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.run.direction.1", runDirection));
        }
        this.runDirection = runDirection;
    }

    public int getRunDirection() {
        return this.runDirection;
    }

    public void setUserunit(float userunit) throws DocumentException {
        if (userunit < BaseField.BORDER_WIDTH_THIN || userunit > 75000.0f) {
            throw new DocumentException(MessageLocalization.getComposedMessage("userunit.should.be.a.value.between.1.and.75000", new Object[markAll]));
        }
        addPageDictEntry(PdfName.USERUNIT, new PdfNumber(userunit));
        setAtLeastPdfVersion(VERSION_1_6);
    }

    public PdfDictionary getDefaultColorspace() {
        return this.defaultColorspace;
    }

    public void setDefaultColorspace(PdfName key, PdfObject cs) {
        if (cs == null || cs.isNull()) {
            this.defaultColorspace.remove(key);
        }
        this.defaultColorspace.put(key, cs);
    }

    ColorDetails addSimplePatternColorspace(BaseColor color) {
        int type = ExtendedColor.getType(color);
        if (type == PageLayoutTwoColumnLeft || type == 5) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("an.uncolored.tile.pattern.can.not.have.another.pattern.or.shading.as.color", new Object[markAll]));
        }
        PdfObject array;
        switch (type) {
            case markAll /*0*/:
                if (this.patternColorspaceRGB == null) {
                    this.patternColorspaceRGB = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
                    array = new PdfArray(PdfName.PATTERN);
                    array.add(PdfName.DEVICERGB);
                    addToBody(array, this.patternColorspaceRGB.getIndirectReference());
                }
                return this.patternColorspaceRGB;
            case markInlineElementsOnly /*1*/:
                if (this.patternColorspaceGRAY == null) {
                    this.patternColorspaceGRAY = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
                    array = new PdfArray(PdfName.PATTERN);
                    array.add(PdfName.DEVICEGRAY);
                    addToBody(array, this.patternColorspaceGRAY.getIndirectReference());
                }
                return this.patternColorspaceGRAY;
            case SIGNATURE_APPEND_ONLY /*2*/:
                if (this.patternColorspaceCMYK == null) {
                    this.patternColorspaceCMYK = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
                    array = new PdfArray(PdfName.PATTERN);
                    array.add(PdfName.DEVICECMYK);
                    addToBody(array, this.patternColorspaceCMYK.getIndirectReference());
                }
                return this.patternColorspaceCMYK;
            case RUN_DIRECTION_RTL /*3*/:
                ColorDetails details = addSimple(((SpotColor) color).getPdfSpotColor());
                ColorDetails patternDetails = (ColorDetails) this.documentSpotPatterns.get(details);
                if (patternDetails != null) {
                    return patternDetails;
                }
                patternDetails = new ColorDetails(getColorspaceName(), this.body.getPdfIndirectReference(), null);
                array = new PdfArray(PdfName.PATTERN);
                array.add(details.getIndirectReference());
                addToBody(array, patternDetails.getIndirectReference());
                this.documentSpotPatterns.put(details, patternDetails);
                return patternDetails;
            default:
                try {
                    throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.color.type", new Object[markAll]));
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage());
                }
        }
        throw new RuntimeException(e.getMessage());
    }

    public boolean isStrictImageSequence() {
        return this.pdf.isStrictImageSequence();
    }

    public void setStrictImageSequence(boolean strictImageSequence) {
        this.pdf.setStrictImageSequence(strictImageSequence);
    }

    public void clearTextWrap() throws DocumentException {
        this.pdf.clearTextWrap();
    }

    public PdfName addDirectImageSimple(Image image) throws PdfException, DocumentException {
        return addDirectImageSimple(image, null);
    }

    public PdfName addDirectImageSimple(Image image, PdfIndirectReference fixedRef) throws PdfException, DocumentException {
        PdfName name;
        if (this.images.containsKey(image.getMySerialId())) {
            name = (PdfName) this.images.get(image.getMySerialId());
        } else {
            if (image.isImgTemplate()) {
                name = new PdfName(HtmlTags.IMG + this.images.size());
                if (image instanceof ImgWMF) {
                    try {
                        ((ImgWMF) image).readWMF(PdfTemplate.createTemplate(this, 0.0f, 0.0f));
                    } catch (Exception e) {
                        throw new DocumentException(e);
                    }
                }
            }
            PdfIndirectReference dref = image.getDirectReference();
            if (dref != null) {
                PdfName pdfName = new PdfName(HtmlTags.IMG + this.images.size());
                this.images.put(image.getMySerialId(), pdfName);
                this.imageDictionary.put(pdfName, dref);
                return pdfName;
            }
            Image maskImage = image.getImageMask();
            PdfIndirectReference maskRef = null;
            if (maskImage != null) {
                maskRef = getImageReference((PdfName) this.images.get(maskImage.getMySerialId()));
            }
            PdfImage i = new PdfImage(image, HtmlTags.IMG + this.images.size(), maskRef);
            if (image instanceof ImgJBIG2) {
                byte[] globals = ((ImgJBIG2) image).getGlobalBytes();
                if (globals != null) {
                    PdfDictionary decodeparms = new PdfDictionary();
                    decodeparms.put(PdfName.JBIG2GLOBALS, getReferenceJBIG2Globals(globals));
                    i.put(PdfName.DECODEPARMS, decodeparms);
                }
            }
            if (image.hasICCProfile()) {
                PdfObject iccRef = add(new PdfICCBased(image.getICCProfile(), image.getCompressionLevel()));
                PdfArray iccArray = new PdfArray();
                iccArray.add(PdfName.ICCBASED);
                iccArray.add(iccRef);
                PdfArray colorspace = i.getAsArray(PdfName.COLORSPACE);
                if (colorspace == null) {
                    i.put(PdfName.COLORSPACE, iccArray);
                } else if (colorspace.size() <= markInlineElementsOnly || !PdfName.INDEXED.equals(colorspace.getPdfObject(markAll))) {
                    i.put(PdfName.COLORSPACE, iccArray);
                } else {
                    colorspace.set(markInlineElementsOnly, iccArray);
                }
            }
            add(i, fixedRef);
            name = i.name();
            this.images.put(image.getMySerialId(), name);
        }
        return name;
    }

    PdfIndirectReference add(PdfImage pdfImage, PdfIndirectReference fixedRef) throws PdfException {
        if (this.imageDictionary.contains(pdfImage.name())) {
            return (PdfIndirectReference) this.imageDictionary.get(pdfImage.name());
        }
        checkPdfIsoConformance(this, 5, pdfImage);
        if (fixedRef instanceof PRIndirectReference) {
            PRIndirectReference r2 = (PRIndirectReference) fixedRef;
            fixedRef = new PdfIndirectReference(markAll, getNewObjectNumber(r2.getReader(), r2.getNumber(), r2.getGeneration()));
        }
        if (fixedRef == null) {
            try {
                fixedRef = addToBody(pdfImage).getIndirectReference();
            } catch (IOException ioe) {
                throw new ExceptionConverter(ioe);
            }
        }
        addToBody((PdfObject) pdfImage, fixedRef);
        this.imageDictionary.put(pdfImage.name(), fixedRef);
        return fixedRef;
    }

    PdfIndirectReference getImageReference(PdfName name) {
        return (PdfIndirectReference) this.imageDictionary.get(name);
    }

    protected PdfIndirectReference add(PdfICCBased icc) {
        try {
            return addToBody(icc).getIndirectReference();
        } catch (IOException ioe) {
            throw new ExceptionConverter(ioe);
        }
    }

    protected PdfIndirectReference getReferenceJBIG2Globals(byte[] content) {
        if (content == null) {
            return null;
        }
        for (PdfStream stream : this.JBIG2Globals.keySet()) {
            if (Arrays.equals(content, stream.getBytes())) {
                return (PdfIndirectReference) this.JBIG2Globals.get(stream);
            }
        }
        PdfStream stream2 = new PdfStream(content);
        try {
            PdfIndirectObject ref = addToBody(stream2);
            this.JBIG2Globals.put(stream2, ref.getIndirectReference());
            return ref.getIndirectReference();
        } catch (IOException e) {
            return null;
        }
    }

    public boolean isUserProperties() {
        return this.userProperties;
    }

    public void setUserProperties(boolean userProperties) {
        this.userProperties = userProperties;
    }

    public boolean isRgbTransparencyBlending() {
        return this.rgbTransparencyBlending;
    }

    public void setRgbTransparencyBlending(boolean rgbTransparencyBlending) {
        this.rgbTransparencyBlending = rgbTransparencyBlending;
    }

    protected static void writeKeyInfo(OutputStream os) throws IOException {
        Version version = Version.getInstance();
        String k = version.getKey();
        if (k == null) {
            k = "iText";
        }
        Object[] objArr = new Object[SIGNATURE_APPEND_ONLY];
        objArr[markAll] = k;
        objArr[markInlineElementsOnly] = version.getRelease();
        os.write(DocWriter.getISOBytes(String.format("%%%s-%s\n", objArr)));
    }

    protected TtfUnicodeWriter getTtfUnicodeWriter() {
        if (this.ttfUnicodeWriter == null) {
            this.ttfUnicodeWriter = new TtfUnicodeWriter(this);
        }
        return this.ttfUnicodeWriter;
    }

    protected XmpWriter createXmpWriter(ByteArrayOutputStream baos, PdfDictionary info) throws IOException {
        return new XmpWriter((OutputStream) baos, info);
    }

    protected XmpWriter createXmpWriter(ByteArrayOutputStream baos, HashMap<String, String> info) throws IOException {
        return new XmpWriter((OutputStream) baos, (Map) info);
    }

    public static void checkPdfIsoConformance(PdfWriter writer, int key, Object obj1) {
        if (writer != null) {
            writer.checkPdfIsoConformance(key, obj1);
        }
    }

    public void checkPdfIsoConformance(int key, Object obj1) {
        this.pdfIsoConformance.checkPdfIsoConformance(key, obj1);
    }

    private void completeInfoDictionary(PdfDictionary info) {
        if (isPdfX()) {
            if (info.get(PdfName.GTS_PDFXVERSION) == null) {
                if (((PdfXConformanceImp) this.pdfIsoConformance).isPdfX1A2001()) {
                    info.put(PdfName.GTS_PDFXVERSION, new PdfString("PDF/X-1:2001"));
                    info.put(new PdfName("GTS_PDFXConformance"), new PdfString("PDF/X-1a:2001"));
                } else if (((PdfXConformanceImp) this.pdfIsoConformance).isPdfX32002()) {
                    info.put(PdfName.GTS_PDFXVERSION, new PdfString("PDF/X-3:2002"));
                }
            }
            if (info.get(PdfName.TITLE) == null) {
                info.put(PdfName.TITLE, new PdfString("Pdf document"));
            }
            if (info.get(PdfName.CREATOR) == null) {
                info.put(PdfName.CREATOR, new PdfString("Unknown"));
            }
            if (info.get(PdfName.TRAPPED) == null) {
                info.put(PdfName.TRAPPED, new PdfName(XMPConst.FALSESTR));
            }
        }
    }

    private void completeExtraCatalog(PdfDictionary extraCatalog) {
        if (isPdfX() && extraCatalog.get(PdfName.OUTPUTINTENTS) == null) {
            PdfObject out = new PdfDictionary(PdfName.OUTPUTINTENT);
            out.put(PdfName.OUTPUTCONDITION, new PdfString("SWOP CGATS TR 001-1995"));
            out.put(PdfName.OUTPUTCONDITIONIDENTIFIER, new PdfString("CGATS TR 001"));
            out.put(PdfName.REGISTRYNAME, new PdfString("http://www.color.org"));
            out.put(PdfName.INFO, new PdfString(PdfObject.NOTHING));
            out.put(PdfName.f78S, PdfName.GTS_PDFX);
            extraCatalog.put(PdfName.OUTPUTINTENTS, new PdfArray(out));
        }
    }

    public List<PdfName> getStandardStructElems() {
        if (this.pdf_version.getVersion() < VERSION_1_7) {
            return standardStructElems_1_4;
        }
        return standardStructElems_1_7;
    }
}

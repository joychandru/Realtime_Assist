package com.itextpdf.text.pdf;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

public abstract class BaseFont {
    public static final int ASCENT = 1;
    public static final int AWT_ASCENT = 9;
    public static final int AWT_DESCENT = 10;
    public static final int AWT_LEADING = 11;
    public static final int AWT_MAXADVANCE = 12;
    public static final int BBOXLLX = 5;
    public static final int BBOXLLY = 6;
    public static final int BBOXURX = 7;
    public static final int BBOXURY = 8;
    protected static final HashMap<String, PdfName> BuiltinFonts14;
    public static final boolean CACHED = true;
    public static final int CAPHEIGHT = 2;
    public static final int[] CHAR_RANGE_ARABIC;
    public static final int[] CHAR_RANGE_CYRILLIC;
    public static final int[] CHAR_RANGE_HEBREW;
    public static final int[] CHAR_RANGE_LATIN;
    public static final char CID_NEWLINE = '\u7fff';
    public static final String COURIER = "Courier";
    public static final String COURIER_BOLD = "Courier-Bold";
    public static final String COURIER_BOLDOBLIQUE = "Courier-BoldOblique";
    public static final String COURIER_OBLIQUE = "Courier-Oblique";
    public static final String CP1250 = "Cp1250";
    public static final String CP1252 = "Cp1252";
    public static final String CP1257 = "Cp1257";
    public static final int DESCENT = 3;
    public static final boolean EMBEDDED = true;
    public static final int FONT_TYPE_CJK = 2;
    public static final int FONT_TYPE_DOCUMENT = 4;
    public static final int FONT_TYPE_T1 = 0;
    public static final int FONT_TYPE_T3 = 5;
    public static final int FONT_TYPE_TT = 1;
    public static final int FONT_TYPE_TTUNI = 3;
    public static final int FONT_WEIGHT = 23;
    public static final String HELVETICA = "Helvetica";
    public static final String HELVETICA_BOLD = "Helvetica-Bold";
    public static final String HELVETICA_BOLDOBLIQUE = "Helvetica-BoldOblique";
    public static final String HELVETICA_OBLIQUE = "Helvetica-Oblique";
    public static final String IDENTITY_H = "Identity-H";
    public static final String IDENTITY_V = "Identity-V";
    public static final int ITALICANGLE = 4;
    public static final String MACROMAN = "MacRoman";
    public static final boolean NOT_CACHED = false;
    public static final boolean NOT_EMBEDDED = false;
    public static final char PARAGRAPH_SEPARATOR = '\u2029';
    public static final String RESOURCE_PATH = "com/itextpdf/text/pdf/fonts/";
    public static final int STRIKETHROUGH_POSITION = 15;
    public static final int STRIKETHROUGH_THICKNESS = 16;
    public static final int SUBSCRIPT_OFFSET = 18;
    public static final int SUBSCRIPT_SIZE = 17;
    public static final int SUPERSCRIPT_OFFSET = 20;
    public static final int SUPERSCRIPT_SIZE = 19;
    public static final String SYMBOL = "Symbol";
    public static final String TIMES_BOLD = "Times-Bold";
    public static final String TIMES_BOLDITALIC = "Times-BoldItalic";
    public static final String TIMES_ITALIC = "Times-Italic";
    public static final String TIMES_ROMAN = "Times-Roman";
    public static final int UNDERLINE_POSITION = 13;
    public static final int UNDERLINE_THICKNESS = 14;
    public static final int WEIGHT_CLASS = 21;
    public static final int WIDTH_CLASS = 22;
    public static final String WINANSI = "Cp1252";
    public static final String ZAPFDINGBATS = "ZapfDingbats";
    protected static HashMap<String, BaseFont> fontCache = null;
    public static final String notdef = ".notdef";
    protected int[][] charBBoxes;
    protected int compressionLevel;
    protected String[] differences;
    protected boolean directTextToByte;
    protected boolean embedded;
    protected String encoding;
    protected boolean fastWinansi;
    protected boolean fontSpecific;
    int fontType;
    protected boolean forceWidthsOutput;
    protected IntHashtable specialMap;
    protected boolean subset;
    protected ArrayList<int[]> subsetRanges;
    protected char[] unicodeDifferences;
    protected boolean vertical;
    protected int[] widths;

    static class StreamFont extends PdfStream {
        public StreamFont(byte[] contents, int[] lengths, int compressionLevel) throws DocumentException {
            try {
                this.bytes = contents;
                put(PdfName.LENGTH, new PdfNumber(this.bytes.length));
                for (int k = BaseFont.FONT_TYPE_T1; k < lengths.length; k += BaseFont.FONT_TYPE_TT) {
                    put(new PdfName("Length" + (k + BaseFont.FONT_TYPE_TT)), new PdfNumber(lengths[k]));
                }
                flateCompress(compressionLevel);
            } catch (Exception e) {
                throw new DocumentException(e);
            }
        }

        public StreamFont(byte[] contents, String subType, int compressionLevel) throws DocumentException {
            try {
                this.bytes = contents;
                put(PdfName.LENGTH, new PdfNumber(this.bytes.length));
                if (subType != null) {
                    put(PdfName.SUBTYPE, new PdfName(subType));
                }
                flateCompress(compressionLevel);
            } catch (Exception e) {
                throw new DocumentException(e);
            }
        }
    }

    public abstract String[][] getAllNameEntries();

    public abstract String[][] getFamilyFontName();

    public abstract float getFontDescriptor(int i, float f);

    public abstract String[][] getFullFontName();

    abstract PdfStream getFullFontStream() throws IOException, DocumentException;

    public abstract int getKerning(int i, int i2);

    public abstract String getPostscriptFontName();

    protected abstract int[] getRawCharBBox(int i, String str);

    abstract int getRawWidth(int i, String str);

    public abstract boolean hasKernPairs();

    public abstract boolean setKerning(int i, int i2, int i3);

    public abstract void setPostscriptFontName(String str);

    abstract void writeFont(PdfWriter pdfWriter, PdfIndirectReference pdfIndirectReference, Object[] objArr) throws DocumentException, IOException;

    static {
        CHAR_RANGE_LATIN = new int[]{FONT_TYPE_T1, 383, PdfWriter.HideMenubar, 8303, 8352, 8399, 64256, 64262};
        CHAR_RANGE_ARABIC = new int[]{FONT_TYPE_T1, 127, 1536, 1663, 8352, 8399, 64336, 64511, 65136, 65279};
        CHAR_RANGE_HEBREW = new int[]{FONT_TYPE_T1, 127, 1424, 1535, 8352, 8399, 64285, 64335};
        CHAR_RANGE_CYRILLIC = new int[]{FONT_TYPE_T1, 127, PdfWriter.PageModeUseOC, 1327, PdfWriter.HideMenubar, 8303, 8352, 8399};
        fontCache = new HashMap();
        BuiltinFonts14 = new HashMap();
        BuiltinFonts14.put(COURIER, PdfName.COURIER);
        BuiltinFonts14.put(COURIER_BOLD, PdfName.COURIER_BOLD);
        BuiltinFonts14.put(COURIER_BOLDOBLIQUE, PdfName.COURIER_BOLDOBLIQUE);
        BuiltinFonts14.put(COURIER_OBLIQUE, PdfName.COURIER_OBLIQUE);
        BuiltinFonts14.put(HELVETICA, PdfName.HELVETICA);
        BuiltinFonts14.put(HELVETICA_BOLD, PdfName.HELVETICA_BOLD);
        BuiltinFonts14.put(HELVETICA_BOLDOBLIQUE, PdfName.HELVETICA_BOLDOBLIQUE);
        BuiltinFonts14.put(HELVETICA_OBLIQUE, PdfName.HELVETICA_OBLIQUE);
        BuiltinFonts14.put(SYMBOL, PdfName.SYMBOL);
        BuiltinFonts14.put(TIMES_ROMAN, PdfName.TIMES_ROMAN);
        BuiltinFonts14.put(TIMES_BOLD, PdfName.TIMES_BOLD);
        BuiltinFonts14.put(TIMES_BOLDITALIC, PdfName.TIMES_BOLDITALIC);
        BuiltinFonts14.put(TIMES_ITALIC, PdfName.TIMES_ITALIC);
        BuiltinFonts14.put(ZAPFDINGBATS, PdfName.ZAPFDINGBATS);
    }

    protected BaseFont() {
        this.widths = new int[PdfWriter.PageModeUseThumbs];
        this.differences = new String[PdfWriter.PageModeUseThumbs];
        this.unicodeDifferences = new char[PdfWriter.PageModeUseThumbs];
        this.charBBoxes = new int[PdfWriter.PageModeUseThumbs][];
        this.compressionLevel = -1;
        this.fontSpecific = EMBEDDED;
        this.forceWidthsOutput = NOT_EMBEDDED;
        this.directTextToByte = NOT_EMBEDDED;
        this.subset = EMBEDDED;
        this.fastWinansi = NOT_EMBEDDED;
        this.vertical = NOT_EMBEDDED;
    }

    public static BaseFont createFont() throws DocumentException, IOException {
        return createFont(HELVETICA, WINANSI, NOT_EMBEDDED);
    }

    public static BaseFont createFont(String name, String encoding, boolean embedded) throws DocumentException, IOException {
        return createFont(name, encoding, embedded, EMBEDDED, null, null, NOT_EMBEDDED);
    }

    public static BaseFont createFont(String name, String encoding, boolean embedded, boolean forceRead) throws DocumentException, IOException {
        return createFont(name, encoding, embedded, EMBEDDED, null, null, forceRead);
    }

    public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb) throws DocumentException, IOException {
        return createFont(name, encoding, embedded, cached, ttfAfm, pfb, NOT_EMBEDDED);
    }

    public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb, boolean noThrow) throws DocumentException, IOException {
        return createFont(name, encoding, embedded, cached, ttfAfm, pfb, noThrow, NOT_EMBEDDED);
    }

    public static BaseFont createFont(String name, String encoding, boolean embedded, boolean cached, byte[] ttfAfm, byte[] pfb, boolean noThrow, boolean forceRead) throws DocumentException, IOException {
        BaseFont fontFound;
        BaseFont fontBuilt;
        String nameBase = getBaseName(name);
        encoding = normalizeEncoding(encoding);
        boolean isBuiltinFonts14 = BuiltinFonts14.containsKey(name);
        boolean isCJKFont = isBuiltinFonts14 ? NOT_EMBEDDED : CJKFont.isCJKFont(nameBase, encoding);
        if (isBuiltinFonts14 || isCJKFont) {
            embedded = NOT_EMBEDDED;
        } else if (encoding.equals(IDENTITY_H) || encoding.equals(IDENTITY_V)) {
            embedded = EMBEDDED;
        }
        String key = name + "\n" + encoding + "\n" + embedded;
        if (cached) {
            synchronized (fontCache) {
                fontFound = (BaseFont) fontCache.get(key);
            }
            if (fontFound != null) {
                return fontFound;
            }
        }
        if (isBuiltinFonts14 || name.toLowerCase().endsWith(".afm") || name.toLowerCase().endsWith(".pfm")) {
            fontBuilt = new Type1Font(name, encoding, embedded, ttfAfm, pfb, forceRead);
            fontBuilt.fastWinansi = encoding.equals(WINANSI);
        } else if (nameBase.toLowerCase().endsWith(".ttf") || nameBase.toLowerCase().endsWith(".otf") || nameBase.toLowerCase().indexOf(".ttc,") > 0) {
            if (encoding.equals(IDENTITY_H) || encoding.equals(IDENTITY_V)) {
                fontBuilt = new TrueTypeFontUnicode(name, encoding, embedded, ttfAfm, forceRead);
            } else {
                fontBuilt = new TrueTypeFont(name, encoding, embedded, ttfAfm, NOT_EMBEDDED, forceRead);
                fontBuilt.fastWinansi = encoding.equals(WINANSI);
            }
        } else if (isCJKFont) {
            fontBuilt = new CJKFont(name, encoding, embedded);
        } else if (noThrow) {
            return null;
        } else {
            Object[] objArr = new Object[FONT_TYPE_CJK];
            objArr[FONT_TYPE_T1] = name;
            objArr[FONT_TYPE_TT] = encoding;
            throw new DocumentException(MessageLocalization.getComposedMessage("font.1.with.2.is.not.recognized", objArr));
        }
        if (cached) {
            synchronized (fontCache) {
                fontFound = (BaseFont) fontCache.get(key);
                if (fontFound != null) {
                    return fontFound;
                }
                fontCache.put(key, fontBuilt);
            }
        }
        return fontBuilt;
    }

    public static BaseFont createFont(PRIndirectReference fontRef) {
        return new DocumentFont(fontRef);
    }

    public boolean isVertical() {
        return this.vertical;
    }

    protected static String getBaseName(String name) {
        if (name.endsWith(",Bold")) {
            return name.substring(FONT_TYPE_T1, name.length() - 5);
        }
        if (name.endsWith(",Italic")) {
            return name.substring(FONT_TYPE_T1, name.length() - 7);
        }
        if (name.endsWith(",BoldItalic")) {
            return name.substring(FONT_TYPE_T1, name.length() - 11);
        }
        return name;
    }

    protected static String normalizeEncoding(String enc) {
        if (enc.equals("winansi") || enc.equals(PdfObject.NOTHING)) {
            return WINANSI;
        }
        if (enc.equals("macroman")) {
            return MACROMAN;
        }
        return enc;
    }

    protected void createEncoding() {
        String name;
        int k;
        if (this.encoding.startsWith("#")) {
            this.specialMap = new IntHashtable();
            StringTokenizer tok = new StringTokenizer(this.encoding.substring(FONT_TYPE_TT), " ,\t\n\r\f");
            if (tok.nextToken().equals("full")) {
                while (tok.hasMoreTokens()) {
                    int orderK;
                    String order = tok.nextToken();
                    name = tok.nextToken();
                    char uni = (char) Integer.parseInt(tok.nextToken(), STRIKETHROUGH_THICKNESS);
                    if (order.startsWith("'")) {
                        orderK = order.charAt(FONT_TYPE_TT);
                    } else {
                        orderK = Integer.parseInt(order);
                    }
                    orderK %= PdfWriter.PageModeUseThumbs;
                    this.specialMap.put(uni, orderK);
                    this.differences[orderK] = name;
                    this.unicodeDifferences[orderK] = uni;
                    this.widths[orderK] = getRawWidth(uni, name);
                    this.charBBoxes[orderK] = getRawCharBBox(uni, name);
                }
            } else {
                k = FONT_TYPE_T1;
                if (tok.hasMoreTokens()) {
                    k = Integer.parseInt(tok.nextToken());
                }
                while (tok.hasMoreTokens() && k < PdfWriter.PageModeUseThumbs) {
                    int uni2 = Integer.parseInt(tok.nextToken(), STRIKETHROUGH_THICKNESS) % PdfWriter.CenterWindow;
                    name = GlyphList.unicodeToName(uni2);
                    if (name != null) {
                        this.specialMap.put(uni2, k);
                        this.differences[k] = name;
                        this.unicodeDifferences[k] = (char) uni2;
                        this.widths[k] = getRawWidth(uni2, name);
                        this.charBBoxes[k] = getRawCharBBox(uni2, name);
                        k += FONT_TYPE_TT;
                    }
                }
            }
            for (k = FONT_TYPE_T1; k < PdfWriter.PageModeUseThumbs; k += FONT_TYPE_TT) {
                if (this.differences[k] == null) {
                    this.differences[k] = notdef;
                }
            }
        } else if (this.fontSpecific) {
            for (k = FONT_TYPE_T1; k < PdfWriter.PageModeUseThumbs; k += FONT_TYPE_TT) {
                this.widths[k] = getRawWidth(k, null);
                this.charBBoxes[k] = getRawCharBBox(k, null);
            }
        } else {
            byte[] b = new byte[FONT_TYPE_TT];
            for (k = FONT_TYPE_T1; k < PdfWriter.PageModeUseThumbs; k += FONT_TYPE_TT) {
                char c;
                b[FONT_TYPE_T1] = (byte) k;
                String s = PdfEncodings.convertToString(b, this.encoding);
                if (s.length() > 0) {
                    c = s.charAt(FONT_TYPE_T1);
                } else {
                    c = '?';
                }
                name = GlyphList.unicodeToName(c);
                if (name == null) {
                    name = notdef;
                }
                this.differences[k] = name;
                this.unicodeDifferences[k] = c;
                this.widths[k] = getRawWidth(c, name);
                this.charBBoxes[k] = getRawCharBBox(c, name);
            }
        }
    }

    public int getWidth(int char1) {
        if (!this.fastWinansi) {
            int total = FONT_TYPE_T1;
            byte[] mbytes = convertToBytes((char) char1);
            for (int k = FONT_TYPE_T1; k < mbytes.length; k += FONT_TYPE_TT) {
                total += this.widths[mbytes[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
            return total;
        } else if (char1 < PdfWriter.PageModeUseOutlines || (char1 >= 160 && char1 <= TIFFConstants.TIFFTAG_OSUBFILETYPE)) {
            return this.widths[char1];
        } else {
            return this.widths[PdfEncodings.winansi.get(char1)];
        }
    }

    public int getWidth(String text) {
        int total = FONT_TYPE_T1;
        int k;
        if (this.fastWinansi) {
            int len = text.length();
            for (k = FONT_TYPE_T1; k < len; k += FONT_TYPE_TT) {
                char char1 = text.charAt(k);
                if (char1 < '\u0080' || (char1 >= '\u00a0' && char1 <= '\u00ff')) {
                    total += this.widths[char1];
                } else {
                    total += this.widths[PdfEncodings.winansi.get(char1)];
                }
            }
            return total;
        }
        byte[] mbytes = convertToBytes(text);
        for (k = FONT_TYPE_T1; k < mbytes.length; k += FONT_TYPE_TT) {
            total += this.widths[mbytes[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
        }
        return total;
    }

    public int getDescent(String text) {
        int min = FONT_TYPE_T1;
        char[] chars = text.toCharArray();
        for (int k = FONT_TYPE_T1; k < chars.length; k += FONT_TYPE_TT) {
            int[] bbox = getCharBBox(chars[k]);
            if (bbox != null && bbox[FONT_TYPE_TT] < min) {
                min = bbox[FONT_TYPE_TT];
            }
        }
        return min;
    }

    public int getAscent(String text) {
        int max = FONT_TYPE_T1;
        char[] chars = text.toCharArray();
        for (int k = FONT_TYPE_T1; k < chars.length; k += FONT_TYPE_TT) {
            int[] bbox = getCharBBox(chars[k]);
            if (bbox != null && bbox[FONT_TYPE_TTUNI] > max) {
                max = bbox[FONT_TYPE_TTUNI];
            }
        }
        return max;
    }

    public float getDescentPoint(String text, float fontSize) {
        return (((float) getDescent(text)) * 0.001f) * fontSize;
    }

    public float getAscentPoint(String text, float fontSize) {
        return (((float) getAscent(text)) * 0.001f) * fontSize;
    }

    public float getWidthPointKerned(String text, float fontSize) {
        float size = (((float) getWidth(text)) * 0.001f) * fontSize;
        if (!hasKernPairs()) {
            return size;
        }
        int len = text.length() - 1;
        int kern = FONT_TYPE_T1;
        char[] c = text.toCharArray();
        for (int k = FONT_TYPE_T1; k < len; k += FONT_TYPE_TT) {
            kern += getKerning(c[k], c[k + FONT_TYPE_TT]);
        }
        return size + ((((float) kern) * 0.001f) * fontSize);
    }

    public float getWidthPoint(String text, float fontSize) {
        return (((float) getWidth(text)) * 0.001f) * fontSize;
    }

    public float getWidthPoint(int char1, float fontSize) {
        return (((float) getWidth(char1)) * 0.001f) * fontSize;
    }

    public byte[] convertToBytes(String text) {
        if (this.directTextToByte) {
            return PdfEncodings.convertToBytes(text, null);
        }
        if (this.specialMap == null) {
            return PdfEncodings.convertToBytes(text, this.encoding);
        }
        byte[] b = new byte[text.length()];
        int length = text.length();
        int k = FONT_TYPE_T1;
        int ptr = FONT_TYPE_T1;
        while (k < length) {
            int ptr2;
            char c = text.charAt(k);
            if (this.specialMap.containsKey(c)) {
                ptr2 = ptr + FONT_TYPE_TT;
                b[ptr] = (byte) this.specialMap.get(c);
            } else {
                ptr2 = ptr;
            }
            k += FONT_TYPE_TT;
            ptr = ptr2;
        }
        if (ptr >= length) {
            return b;
        }
        byte[] b2 = new byte[ptr];
        System.arraycopy(b, FONT_TYPE_T1, b2, FONT_TYPE_T1, ptr);
        return b2;
    }

    byte[] convertToBytes(int char1) {
        if (this.directTextToByte) {
            return PdfEncodings.convertToBytes((char) char1, null);
        }
        if (this.specialMap == null) {
            return PdfEncodings.convertToBytes((char) char1, this.encoding);
        }
        if (!this.specialMap.containsKey(char1)) {
            return new byte[FONT_TYPE_T1];
        }
        byte[] bArr = new byte[FONT_TYPE_TT];
        bArr[FONT_TYPE_T1] = (byte) this.specialMap.get(char1);
        return bArr;
    }

    public String getEncoding() {
        return this.encoding;
    }

    public void setFontDescriptor(int key, float value) {
    }

    public int getFontType() {
        return this.fontType;
    }

    public boolean isEmbedded() {
        return this.embedded;
    }

    public boolean isFontSpecific() {
        return this.fontSpecific;
    }

    public static String createSubsetPrefix() {
        StringBuilder s = new StringBuilder(PdfObject.NOTHING);
        for (int k = FONT_TYPE_T1; k < BBOXLLY; k += FONT_TYPE_TT) {
            s.append((char) ((int) ((Math.random() * 26.0d) + 65.0d)));
        }
        return s + "+";
    }

    char getUnicodeDifferences(int index) {
        return this.unicodeDifferences[index];
    }

    public static String[][] getFullFontName(String name, String encoding, byte[] ttfAfm) throws DocumentException, IOException {
        BaseFont fontBuilt;
        String nameBase = getBaseName(name);
        if (nameBase.toLowerCase().endsWith(".ttf") || nameBase.toLowerCase().endsWith(".otf") || nameBase.toLowerCase().indexOf(".ttc,") > 0) {
            fontBuilt = new TrueTypeFont(name, WINANSI, NOT_EMBEDDED, ttfAfm, EMBEDDED, NOT_EMBEDDED);
        } else {
            fontBuilt = createFont(name, encoding, NOT_EMBEDDED, NOT_EMBEDDED, ttfAfm, null);
        }
        return fontBuilt.getFullFontName();
    }

    public static Object[] getAllFontNames(String name, String encoding, byte[] ttfAfm) throws DocumentException, IOException {
        BaseFont fontBuilt;
        String nameBase = getBaseName(name);
        if (nameBase.toLowerCase().endsWith(".ttf") || nameBase.toLowerCase().endsWith(".otf") || nameBase.toLowerCase().indexOf(".ttc,") > 0) {
            fontBuilt = new TrueTypeFont(name, WINANSI, NOT_EMBEDDED, ttfAfm, EMBEDDED, NOT_EMBEDDED);
        } else {
            fontBuilt = createFont(name, encoding, NOT_EMBEDDED, NOT_EMBEDDED, ttfAfm, null);
        }
        Object[] objArr = new Object[FONT_TYPE_TTUNI];
        objArr[FONT_TYPE_T1] = fontBuilt.getPostscriptFontName();
        objArr[FONT_TYPE_TT] = fontBuilt.getFamilyFontName();
        objArr[FONT_TYPE_CJK] = fontBuilt.getFullFontName();
        return objArr;
    }

    public static String[][] getAllNameEntries(String name, String encoding, byte[] ttfAfm) throws DocumentException, IOException {
        BaseFont fontBuilt;
        String nameBase = getBaseName(name);
        if (nameBase.toLowerCase().endsWith(".ttf") || nameBase.toLowerCase().endsWith(".otf") || nameBase.toLowerCase().indexOf(".ttc,") > 0) {
            fontBuilt = new TrueTypeFont(name, WINANSI, NOT_EMBEDDED, ttfAfm, EMBEDDED, NOT_EMBEDDED);
        } else {
            fontBuilt = createFont(name, encoding, NOT_EMBEDDED, NOT_EMBEDDED, ttfAfm, null);
        }
        return fontBuilt.getAllNameEntries();
    }

    public String[] getCodePagesSupported() {
        return new String[FONT_TYPE_T1];
    }

    public static String[] enumerateTTCNames(String ttcFile) throws DocumentException, IOException {
        return new EnumerateTTC(ttcFile).getNames();
    }

    public static String[] enumerateTTCNames(byte[] ttcArray) throws DocumentException, IOException {
        return new EnumerateTTC(ttcArray).getNames();
    }

    public int[] getWidths() {
        return this.widths;
    }

    public String[] getDifferences() {
        return this.differences;
    }

    public char[] getUnicodeDifferences() {
        return this.unicodeDifferences;
    }

    public boolean isForceWidthsOutput() {
        return this.forceWidthsOutput;
    }

    public void setForceWidthsOutput(boolean forceWidthsOutput) {
        this.forceWidthsOutput = forceWidthsOutput;
    }

    public boolean isDirectTextToByte() {
        return this.directTextToByte;
    }

    public void setDirectTextToByte(boolean directTextToByte) {
        this.directTextToByte = directTextToByte;
    }

    public boolean isSubset() {
        return this.subset;
    }

    public void setSubset(boolean subset) {
        this.subset = subset;
    }

    public int getUnicodeEquivalent(int c) {
        return c;
    }

    public int getCidCode(int c) {
        return c;
    }

    public boolean charExists(int c) {
        return convertToBytes(c).length > 0 ? EMBEDDED : NOT_EMBEDDED;
    }

    public boolean setCharAdvance(int c, int advance) {
        byte[] b = convertToBytes(c);
        if (b.length == 0) {
            return NOT_EMBEDDED;
        }
        this.widths[b[FONT_TYPE_T1] & TIFFConstants.TIFFTAG_OSUBFILETYPE] = advance;
        return EMBEDDED;
    }

    private static void addFont(PRIndirectReference fontRef, IntHashtable hits, ArrayList<Object[]> fonts) {
        PdfObject obj = PdfReader.getPdfObject((PdfObject) fontRef);
        if (obj != null && obj.isDictionary()) {
            PdfDictionary font = (PdfDictionary) obj;
            PdfName subtype = font.getAsName(PdfName.SUBTYPE);
            if (PdfName.TYPE1.equals(subtype) || PdfName.TRUETYPE.equals(subtype) || PdfName.TYPE0.equals(subtype)) {
                Object obj2 = new Object[FONT_TYPE_CJK];
                obj2[FONT_TYPE_T1] = PdfName.decodeName(font.getAsName(PdfName.BASEFONT).toString());
                obj2[FONT_TYPE_TT] = fontRef;
                fonts.add(obj2);
                hits.put(fontRef.getNumber(), FONT_TYPE_TT);
            }
        }
    }

    private static void recourseFonts(PdfDictionary page, IntHashtable hits, ArrayList<Object[]> fonts, int level) {
        level += FONT_TYPE_TT;
        if (level <= 50 && page != null) {
            PdfDictionary resources = page.getAsDict(PdfName.RESOURCES);
            if (resources != null) {
                PdfDictionary font = resources.getAsDict(PdfName.FONT);
                if (font != null) {
                    for (PdfName key : font.getKeys()) {
                        PdfObject ft = font.get(key);
                        if (!(ft == null || !ft.isIndirect() || hits.containsKey(((PRIndirectReference) ft).getNumber()))) {
                            addFont((PRIndirectReference) ft, hits, fonts);
                        }
                    }
                }
                PdfDictionary xobj = resources.getAsDict(PdfName.XOBJECT);
                if (xobj != null) {
                    for (PdfName key2 : xobj.getKeys()) {
                        PdfObject po = xobj.getDirectObject(key2);
                        if (po instanceof PdfDictionary) {
                            recourseFonts((PdfDictionary) po, hits, fonts, level);
                        }
                    }
                }
            }
        }
    }

    public static ArrayList<Object[]> getDocumentFonts(PdfReader reader) {
        IntHashtable hits = new IntHashtable();
        ArrayList<Object[]> fonts = new ArrayList();
        int npages = reader.getNumberOfPages();
        for (int k = FONT_TYPE_TT; k <= npages; k += FONT_TYPE_TT) {
            recourseFonts(reader.getPageN(k), hits, fonts, FONT_TYPE_TT);
        }
        return fonts;
    }

    public static ArrayList<Object[]> getDocumentFonts(PdfReader reader, int page) {
        IntHashtable hits = new IntHashtable();
        ArrayList<Object[]> fonts = new ArrayList();
        recourseFonts(reader.getPageN(page), hits, fonts, FONT_TYPE_TT);
        return fonts;
    }

    public int[] getCharBBox(int c) {
        byte[] b = convertToBytes(c);
        if (b.length == 0) {
            return null;
        }
        return this.charBBoxes[b[FONT_TYPE_T1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
    }

    public void correctArabicAdvance() {
        char c;
        for (c = '\u064b'; c <= '\u0658'; c = (char) (c + FONT_TYPE_TT)) {
            setCharAdvance(c, FONT_TYPE_T1);
        }
        setCharAdvance(1648, FONT_TYPE_T1);
        for (c = '\u06d6'; c <= '\u06dc'; c = (char) (c + FONT_TYPE_TT)) {
            setCharAdvance(c, FONT_TYPE_T1);
        }
        for (c = '\u06df'; c <= '\u06e4'; c = (char) (c + FONT_TYPE_TT)) {
            setCharAdvance(c, FONT_TYPE_T1);
        }
        for (c = '\u06e7'; c <= '\u06e8'; c = (char) (c + FONT_TYPE_TT)) {
            setCharAdvance(c, FONT_TYPE_T1);
        }
        for (c = '\u06ea'; c <= '\u06ed'; c = (char) (c + FONT_TYPE_TT)) {
            setCharAdvance(c, FONT_TYPE_T1);
        }
    }

    public void addSubsetRange(int[] range) {
        if (this.subsetRanges == null) {
            this.subsetRanges = new ArrayList();
        }
        this.subsetRanges.add(range);
    }

    public int getCompressionLevel() {
        return this.compressionLevel;
    }

    public void setCompressionLevel(int compressionLevel) {
        if (compressionLevel < 0 || compressionLevel > AWT_ASCENT) {
            this.compressionLevel = -1;
        } else {
            this.compressionLevel = compressionLevel;
        }
    }
}

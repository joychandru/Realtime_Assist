package com.itextpdf.text.pdf;

import com.itextpdf.awt.geom.AffineTransform;
import com.itextpdf.text.AccessibleElementId;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocWriter;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.interfaces.IAccessibleElement;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;

public class PdfAnnotation extends PdfDictionary implements IAccessibleElement {
    public static final PdfName AA_BLUR;
    public static final PdfName AA_DOWN;
    public static final PdfName AA_ENTER;
    public static final PdfName AA_EXIT;
    public static final PdfName AA_FOCUS;
    public static final PdfName AA_JS_CHANGE;
    public static final PdfName AA_JS_FORMAT;
    public static final PdfName AA_JS_KEY;
    public static final PdfName AA_JS_OTHER_CHANGE;
    public static final PdfName AA_UP;
    public static final PdfName APPEARANCE_DOWN;
    public static final PdfName APPEARANCE_NORMAL;
    public static final PdfName APPEARANCE_ROLLOVER;
    public static final int FLAGS_HIDDEN = 2;
    public static final int FLAGS_INVISIBLE = 1;
    public static final int FLAGS_LOCKED = 128;
    public static final int FLAGS_LOCKEDCONTENTS = 512;
    public static final int FLAGS_NOROTATE = 16;
    public static final int FLAGS_NOVIEW = 32;
    public static final int FLAGS_NOZOOM = 8;
    public static final int FLAGS_PRINT = 4;
    public static final int FLAGS_READONLY = 64;
    public static final int FLAGS_TOGGLENOVIEW = 256;
    public static final PdfName HIGHLIGHT_INVERT;
    public static final PdfName HIGHLIGHT_NONE;
    public static final PdfName HIGHLIGHT_OUTLINE;
    public static final PdfName HIGHLIGHT_PUSH;
    public static final PdfName HIGHLIGHT_TOGGLE;
    public static final int MARKUP_HIGHLIGHT = 0;
    public static final int MARKUP_SQUIGGLY = 3;
    public static final int MARKUP_STRIKEOUT = 2;
    public static final int MARKUP_UNDERLINE = 1;
    protected HashMap<PdfName, PdfObject> accessibleAttributes;
    protected boolean annotation;
    protected boolean form;
    private AccessibleElementId id;
    private int placeInPage;
    protected PdfIndirectReference reference;
    protected PdfName role;
    protected HashSet<PdfTemplate> templates;
    protected boolean used;
    protected PdfWriter writer;

    public static class PdfImportedLink {
        PdfArray destination;
        float llx;
        float lly;
        int newPage;
        HashMap<PdfName, PdfObject> parameters;
        PdfArray rect;
        float urx;
        float ury;

        PdfImportedLink(PdfDictionary annotation) {
            this.parameters = new HashMap();
            this.destination = null;
            this.newPage = PdfAnnotation.MARKUP_HIGHLIGHT;
            this.parameters.putAll(annotation.hashMap);
            try {
                this.destination = (PdfArray) this.parameters.remove(PdfName.DEST);
                if (this.destination != null) {
                    this.destination = new PdfArray(this.destination);
                }
                PdfArray rc = (PdfArray) this.parameters.remove(PdfName.RECT);
                this.llx = rc.getAsNumber(PdfAnnotation.MARKUP_HIGHLIGHT).floatValue();
                this.lly = rc.getAsNumber(PdfAnnotation.MARKUP_UNDERLINE).floatValue();
                this.urx = rc.getAsNumber(PdfAnnotation.MARKUP_STRIKEOUT).floatValue();
                this.ury = rc.getAsNumber(PdfAnnotation.MARKUP_SQUIGGLY).floatValue();
                this.rect = new PdfArray(rc);
            } catch (ClassCastException e) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("you.have.to.consolidate.the.named.destinations.of.your.reader", new Object[PdfAnnotation.MARKUP_HIGHLIGHT]));
            }
        }

        public Map<PdfName, PdfObject> getParameters() {
            return new HashMap(this.parameters);
        }

        public PdfArray getRect() {
            return new PdfArray(this.rect);
        }

        public boolean isInternal() {
            return this.destination != null;
        }

        public int getDestinationPage() {
            if (!isInternal()) {
                return PdfAnnotation.MARKUP_HIGHLIGHT;
            }
            PRIndirectReference pr = (PRIndirectReference) this.destination.getAsIndirectObject(PdfAnnotation.MARKUP_HIGHLIGHT);
            PdfReader r = pr.getReader();
            for (int i = PdfAnnotation.MARKUP_UNDERLINE; i <= r.getNumberOfPages(); i += PdfAnnotation.MARKUP_UNDERLINE) {
                PRIndirectReference pp = r.getPageOrigRef(i);
                if (pp.getGeneration() == pr.getGeneration() && pp.getNumber() == pr.getNumber()) {
                    return i;
                }
            }
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("page.not.found", new Object[PdfAnnotation.MARKUP_HIGHLIGHT]));
        }

        public void setDestinationPage(int newPage) {
            if (isInternal()) {
                this.newPage = newPage;
                return;
            }
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("cannot.change.destination.of.external.link", new Object[PdfAnnotation.MARKUP_HIGHLIGHT]));
        }

        public void transformDestination(float a, float b, float c, float d, float e, float f) {
            if (!isInternal()) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("cannot.change.destination.of.external.link", new Object[PdfAnnotation.MARKUP_HIGHLIGHT]));
            } else if (this.destination.getAsName(PdfAnnotation.MARKUP_UNDERLINE).equals(PdfName.XYZ)) {
                float x = this.destination.getAsNumber(PdfAnnotation.MARKUP_STRIKEOUT).floatValue();
                float y = this.destination.getAsNumber(PdfAnnotation.MARKUP_SQUIGGLY).floatValue();
                float yy = ((x * b) + (y * d)) + f;
                this.destination.set(PdfAnnotation.MARKUP_STRIKEOUT, new PdfNumber(((x * a) + (y * c)) + e));
                this.destination.set(PdfAnnotation.MARKUP_SQUIGGLY, new PdfNumber(yy));
            }
        }

        public void transformRect(float a, float b, float c, float d, float e, float f) {
            float y = ((this.llx * b) + (this.lly * d)) + f;
            this.llx = ((this.llx * a) + (this.lly * c)) + e;
            this.lly = y;
            y = ((this.urx * b) + (this.ury * d)) + f;
            this.urx = ((this.urx * a) + (this.ury * c)) + e;
            this.ury = y;
        }

        public PdfAnnotation createAnnotation(PdfWriter writer) {
            PdfAnnotation annotation = new PdfAnnotation(writer, new Rectangle(this.llx, this.lly, this.urx, this.ury));
            if (this.newPage != 0) {
                this.destination.set(PdfAnnotation.MARKUP_HIGHLIGHT, writer.getPageReference(this.newPage));
            }
            if (this.destination != null) {
                annotation.put(PdfName.DEST, this.destination);
            }
            annotation.hashMap.putAll(this.parameters);
            return annotation;
        }

        public String toString() {
            StringBuffer buf = new StringBuffer("Imported link: location [");
            buf.append(this.llx);
            buf.append(' ');
            buf.append(this.lly);
            buf.append(' ');
            buf.append(this.urx);
            buf.append(' ');
            buf.append(this.ury);
            buf.append("] destination ");
            buf.append(this.destination);
            buf.append(" parameters ");
            buf.append(this.parameters);
            if (this.parameters != null) {
                appendDictionary(buf, this.parameters);
            }
            return buf.toString();
        }

        private void appendDictionary(StringBuffer buf, HashMap<PdfName, PdfObject> dict) {
            buf.append(" <<");
            for (Entry<PdfName, PdfObject> entry : dict.entrySet()) {
                buf.append(entry.getKey());
                buf.append(":");
                if (entry.getValue() instanceof PdfDictionary) {
                    appendDictionary(buf, ((PdfDictionary) entry.getValue()).hashMap);
                } else {
                    buf.append(entry.getValue());
                }
                buf.append(" ");
            }
            buf.append(">> ");
        }
    }

    static {
        HIGHLIGHT_NONE = PdfName.f73N;
        HIGHLIGHT_INVERT = PdfName.f69I;
        HIGHLIGHT_OUTLINE = PdfName.f74O;
        HIGHLIGHT_PUSH = PdfName.f75P;
        HIGHLIGHT_TOGGLE = PdfName.f79T;
        APPEARANCE_NORMAL = PdfName.f73N;
        APPEARANCE_ROLLOVER = PdfName.f77R;
        APPEARANCE_DOWN = PdfName.f65D;
        AA_ENTER = PdfName.f66E;
        AA_EXIT = PdfName.f83X;
        AA_DOWN = PdfName.f65D;
        AA_UP = PdfName.f80U;
        AA_FOCUS = PdfName.FO;
        AA_BLUR = PdfName.BL;
        AA_JS_KEY = PdfName.f70K;
        AA_JS_FORMAT = PdfName.f67F;
        AA_JS_CHANGE = PdfName.f81V;
        AA_JS_OTHER_CHANGE = PdfName.f64C;
    }

    public PdfAnnotation(PdfWriter writer, Rectangle rect) {
        this.form = false;
        this.annotation = true;
        this.used = false;
        this.placeInPage = -1;
        this.role = null;
        this.accessibleAttributes = null;
        this.id = null;
        this.writer = writer;
        if (rect != null) {
            put(PdfName.RECT, new PdfRectangle(rect));
        }
    }

    public PdfAnnotation(PdfWriter writer, float llx, float lly, float urx, float ury, PdfString title, PdfString content) {
        this.form = false;
        this.annotation = true;
        this.used = false;
        this.placeInPage = -1;
        this.role = null;
        this.accessibleAttributes = null;
        this.id = null;
        this.writer = writer;
        put(PdfName.SUBTYPE, PdfName.TEXT);
        put(PdfName.f79T, title);
        put(PdfName.RECT, new PdfRectangle(llx, lly, urx, ury));
        put(PdfName.CONTENTS, content);
    }

    public PdfAnnotation(PdfWriter writer, float llx, float lly, float urx, float ury, PdfAction action) {
        this.form = false;
        this.annotation = true;
        this.used = false;
        this.placeInPage = -1;
        this.role = null;
        this.accessibleAttributes = null;
        this.id = null;
        this.writer = writer;
        put(PdfName.SUBTYPE, PdfName.LINK);
        put(PdfName.RECT, new PdfRectangle(llx, lly, urx, ury));
        put(PdfName.f62A, action);
        put(PdfName.BORDER, new PdfBorderArray(0.0f, 0.0f, 0.0f));
        put(PdfName.f64C, new PdfColor(MARKUP_HIGHLIGHT, MARKUP_HIGHLIGHT, TIFFConstants.TIFFTAG_OSUBFILETYPE));
    }

    public static PdfAnnotation createScreen(PdfWriter writer, Rectangle rect, String clipTitle, PdfFileSpecification fs, String mimeType, boolean playOnDisplay) throws IOException {
        PdfAnnotation ann = new PdfAnnotation(writer, rect);
        ann.put(PdfName.SUBTYPE, PdfName.SCREEN);
        ann.put(PdfName.f67F, new PdfNumber((int) FLAGS_PRINT));
        ann.put(PdfName.TYPE, PdfName.ANNOT);
        ann.setPage();
        PdfIndirectReference actionRef = writer.addToBody(PdfAction.rendition(clipTitle, fs, mimeType, ann.getIndirectReference())).getIndirectReference();
        if (playOnDisplay) {
            PdfDictionary aa = new PdfDictionary();
            aa.put(new PdfName("PV"), actionRef);
            ann.put(PdfName.AA, aa);
        }
        ann.put(PdfName.f62A, actionRef);
        return ann;
    }

    public PdfIndirectReference getIndirectReference() {
        if (this.reference == null) {
            this.reference = this.writer.getPdfIndirectReference();
        }
        return this.reference;
    }

    public static PdfAnnotation createText(PdfWriter writer, Rectangle rect, String title, String contents, boolean open, String icon) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.TEXT);
        if (title != null) {
            annot.put(PdfName.f79T, new PdfString(title, PdfObject.TEXT_UNICODE));
        }
        if (contents != null) {
            annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        }
        if (open) {
            annot.put(PdfName.OPEN, PdfBoolean.PDFTRUE);
        }
        if (icon != null) {
            annot.put(PdfName.NAME, new PdfName(icon));
        }
        return annot;
    }

    protected static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.LINK);
        if (!highlight.equals(HIGHLIGHT_INVERT)) {
            annot.put(PdfName.f68H, highlight);
        }
        return annot;
    }

    public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, PdfAction action) {
        PdfAnnotation annot = createLink(writer, rect, highlight);
        annot.putEx(PdfName.f62A, action);
        return annot;
    }

    public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, String namedDestination) {
        PdfAnnotation annot = createLink(writer, rect, highlight);
        annot.put(PdfName.DEST, new PdfString(namedDestination, PdfObject.TEXT_UNICODE));
        return annot;
    }

    public static PdfAnnotation createLink(PdfWriter writer, Rectangle rect, PdfName highlight, int page, PdfDestination dest) {
        PdfAnnotation annot = createLink(writer, rect, highlight);
        dest.addPage(writer.getPageReference(page));
        annot.put(PdfName.DEST, dest);
        return annot;
    }

    public static PdfAnnotation createFreeText(PdfWriter writer, Rectangle rect, String contents, PdfContentByte defaultAppearance) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.FREETEXT);
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        annot.setDefaultAppearanceString(defaultAppearance);
        return annot;
    }

    public static PdfAnnotation createLine(PdfWriter writer, Rectangle rect, String contents, float x1, float y1, float x2, float y2) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.LINE);
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        PdfArray array = new PdfArray(new PdfNumber(x1));
        array.add(new PdfNumber(y1));
        array.add(new PdfNumber(x2));
        array.add(new PdfNumber(y2));
        annot.put(PdfName.f71L, array);
        return annot;
    }

    public static PdfAnnotation createSquareCircle(PdfWriter writer, Rectangle rect, String contents, boolean square) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        if (square) {
            annot.put(PdfName.SUBTYPE, PdfName.SQUARE);
        } else {
            annot.put(PdfName.SUBTYPE, PdfName.CIRCLE);
        }
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        return annot;
    }

    public static PdfAnnotation createMarkup(PdfWriter writer, Rectangle rect, String contents, int type, float[] quadPoints) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        PdfName name = PdfName.HIGHLIGHT;
        switch (type) {
            case MARKUP_UNDERLINE /*1*/:
                name = PdfName.UNDERLINE;
                break;
            case MARKUP_STRIKEOUT /*2*/:
                name = PdfName.STRIKEOUT;
                break;
            case MARKUP_SQUIGGLY /*3*/:
                name = PdfName.SQUIGGLY;
                break;
        }
        annot.put(PdfName.SUBTYPE, name);
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        PdfArray array = new PdfArray();
        for (int k = MARKUP_HIGHLIGHT; k < quadPoints.length; k += MARKUP_UNDERLINE) {
            array.add(new PdfNumber(quadPoints[k]));
        }
        annot.put(PdfName.QUADPOINTS, array);
        return annot;
    }

    public static PdfAnnotation createStamp(PdfWriter writer, Rectangle rect, String contents, String name) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.STAMP);
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        annot.put(PdfName.NAME, new PdfName(name));
        return annot;
    }

    public static PdfAnnotation createInk(PdfWriter writer, Rectangle rect, String contents, float[][] inkList) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.INK);
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        PdfArray outer = new PdfArray();
        for (int k = MARKUP_HIGHLIGHT; k < inkList.length; k += MARKUP_UNDERLINE) {
            PdfObject inner = new PdfArray();
            float[] deep = inkList[k];
            for (int j = MARKUP_HIGHLIGHT; j < deep.length; j += MARKUP_UNDERLINE) {
                inner.add(new PdfNumber(deep[j]));
            }
            outer.add(inner);
        }
        annot.put(PdfName.INKLIST, outer);
        return annot;
    }

    public static PdfAnnotation createFileAttachment(PdfWriter writer, Rectangle rect, String contents, byte[] fileStore, String file, String fileDisplay) throws IOException {
        return createFileAttachment(writer, rect, contents, PdfFileSpecification.fileEmbedded(writer, file, fileDisplay, fileStore));
    }

    public static PdfAnnotation createFileAttachment(PdfWriter writer, Rectangle rect, String contents, PdfFileSpecification fs) throws IOException {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.FILEATTACHMENT);
        if (contents != null) {
            annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        }
        annot.put(PdfName.FS, fs.getReference());
        return annot;
    }

    public static PdfAnnotation createPopup(PdfWriter writer, Rectangle rect, String contents, boolean open) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        annot.put(PdfName.SUBTYPE, PdfName.POPUP);
        if (contents != null) {
            annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        }
        if (open) {
            annot.put(PdfName.OPEN, PdfBoolean.PDFTRUE);
        }
        return annot;
    }

    public static PdfAnnotation createPolygonPolyline(PdfWriter writer, Rectangle rect, String contents, boolean polygon, PdfArray vertices) {
        PdfAnnotation annot = new PdfAnnotation(writer, rect);
        if (polygon) {
            annot.put(PdfName.SUBTYPE, PdfName.POLYGON);
        } else {
            annot.put(PdfName.SUBTYPE, PdfName.POLYLINE);
        }
        annot.put(PdfName.CONTENTS, new PdfString(contents, PdfObject.TEXT_UNICODE));
        annot.put(PdfName.VERTICES, new PdfArray(vertices));
        return annot;
    }

    public void setDefaultAppearanceString(PdfContentByte cb) {
        byte[] b = cb.getInternalBuffer().toByteArray();
        int len = b.length;
        for (int k = MARKUP_HIGHLIGHT; k < len; k += MARKUP_UNDERLINE) {
            if (b[k] == 10) {
                b[k] = DocWriter.SPACE;
            }
        }
        put(PdfName.DA, new PdfString(b));
    }

    public void setFlags(int flags) {
        if (flags == 0) {
            remove(PdfName.f67F);
        } else {
            put(PdfName.f67F, new PdfNumber(flags));
        }
    }

    public void setBorder(PdfBorderArray border) {
        put(PdfName.BORDER, border);
    }

    public void setBorderStyle(PdfBorderDictionary border) {
        put(PdfName.BS, border);
    }

    public void setHighlighting(PdfName highlight) {
        if (highlight.equals(HIGHLIGHT_INVERT)) {
            remove(PdfName.f68H);
        } else {
            put(PdfName.f68H, highlight);
        }
    }

    public void setAppearance(PdfName ap, PdfTemplate template) {
        PdfDictionary dic = (PdfDictionary) get(PdfName.AP);
        if (dic == null) {
            dic = new PdfDictionary();
        }
        dic.put(ap, template.getIndirectReference());
        put(PdfName.AP, dic);
        if (this.form) {
            if (this.templates == null) {
                this.templates = new HashSet();
            }
            this.templates.add(template);
        }
    }

    public void setAppearance(PdfName ap, String state, PdfTemplate template) {
        PdfDictionary dic;
        PdfDictionary dicAp = (PdfDictionary) get(PdfName.AP);
        if (dicAp == null) {
            dicAp = new PdfDictionary();
        }
        PdfObject obj = dicAp.get(ap);
        if (obj == null || !obj.isDictionary()) {
            dic = new PdfDictionary();
        } else {
            dic = (PdfDictionary) obj;
        }
        dic.put(new PdfName(state), template.getIndirectReference());
        dicAp.put(ap, dic);
        put(PdfName.AP, dicAp);
        if (this.form) {
            if (this.templates == null) {
                this.templates = new HashSet();
            }
            this.templates.add(template);
        }
    }

    public void setAppearanceState(String state) {
        if (state == null) {
            remove(PdfName.AS);
        } else {
            put(PdfName.AS, new PdfName(state));
        }
    }

    public void setColor(BaseColor color) {
        put(PdfName.f64C, new PdfColor(color));
    }

    public void setTitle(String title) {
        if (title == null) {
            remove(PdfName.f79T);
        } else {
            put(PdfName.f79T, new PdfString(title, PdfObject.TEXT_UNICODE));
        }
    }

    public void setPopup(PdfAnnotation popup) {
        put(PdfName.POPUP, popup.getIndirectReference());
        popup.put(PdfName.PARENT, getIndirectReference());
    }

    public void setAction(PdfAction action) {
        put(PdfName.f62A, action);
    }

    public void setAdditionalActions(PdfName key, PdfAction action) {
        PdfDictionary dic;
        PdfObject obj = get(PdfName.AA);
        if (obj == null || !obj.isDictionary()) {
            dic = new PdfDictionary();
        } else {
            dic = (PdfDictionary) obj;
        }
        dic.put(key, action);
        put(PdfName.AA, dic);
    }

    public boolean isUsed() {
        return this.used;
    }

    public void setUsed() {
        this.used = true;
    }

    public HashSet<PdfTemplate> getTemplates() {
        return this.templates;
    }

    public boolean isForm() {
        return this.form;
    }

    public boolean isAnnotation() {
        return this.annotation;
    }

    public void setPage(int page) {
        put(PdfName.f75P, this.writer.getPageReference(page));
    }

    public void setPage() {
        put(PdfName.f75P, this.writer.getCurrentPage());
    }

    public int getPlaceInPage() {
        return this.placeInPage;
    }

    public void setPlaceInPage(int placeInPage) {
        this.placeInPage = placeInPage;
    }

    public void setRotate(int v) {
        put(PdfName.ROTATE, new PdfNumber(v));
    }

    PdfDictionary getMK() {
        PdfDictionary mk = (PdfDictionary) get(PdfName.MK);
        if (mk != null) {
            return mk;
        }
        mk = new PdfDictionary();
        put(PdfName.MK, mk);
        return mk;
    }

    public void setMKRotation(int rotation) {
        getMK().put(PdfName.f77R, new PdfNumber(rotation));
    }

    public static PdfArray getMKColor(BaseColor color) {
        PdfArray array = new PdfArray();
        switch (ExtendedColor.getType(color)) {
            case MARKUP_UNDERLINE /*1*/:
                array.add(new PdfNumber(((GrayColor) color).getGray()));
                break;
            case MARKUP_STRIKEOUT /*2*/:
                CMYKColor cmyk = (CMYKColor) color;
                array.add(new PdfNumber(cmyk.getCyan()));
                array.add(new PdfNumber(cmyk.getMagenta()));
                array.add(new PdfNumber(cmyk.getYellow()));
                array.add(new PdfNumber(cmyk.getBlack()));
                break;
            case MARKUP_SQUIGGLY /*3*/:
            case FLAGS_PRINT /*4*/:
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                throw new RuntimeException(MessageLocalization.getComposedMessage("separations.patterns.and.shadings.are.not.allowed.in.mk.dictionary", new Object[MARKUP_HIGHLIGHT]));
            default:
                array.add(new PdfNumber(((float) color.getRed()) / 255.0f));
                array.add(new PdfNumber(((float) color.getGreen()) / 255.0f));
                array.add(new PdfNumber(((float) color.getBlue()) / 255.0f));
                break;
        }
        return array;
    }

    public void setMKBorderColor(BaseColor color) {
        if (color == null) {
            getMK().remove(PdfName.BC);
        } else {
            getMK().put(PdfName.BC, getMKColor(color));
        }
    }

    public void setMKBackgroundColor(BaseColor color) {
        if (color == null) {
            getMK().remove(PdfName.BG);
        } else {
            getMK().put(PdfName.BG, getMKColor(color));
        }
    }

    public void setMKNormalCaption(String caption) {
        getMK().put(PdfName.CA, new PdfString(caption, PdfObject.TEXT_UNICODE));
    }

    public void setMKRolloverCaption(String caption) {
        getMK().put(PdfName.RC, new PdfString(caption, PdfObject.TEXT_UNICODE));
    }

    public void setMKAlternateCaption(String caption) {
        getMK().put(PdfName.AC, new PdfString(caption, PdfObject.TEXT_UNICODE));
    }

    public void setMKNormalIcon(PdfTemplate template) {
        getMK().put(PdfName.f69I, template.getIndirectReference());
    }

    public void setMKRolloverIcon(PdfTemplate template) {
        getMK().put(PdfName.RI, template.getIndirectReference());
    }

    public void setMKAlternateIcon(PdfTemplate template) {
        getMK().put(PdfName.IX, template.getIndirectReference());
    }

    public void setMKIconFit(PdfName scale, PdfName scalingType, float leftoverLeft, float leftoverBottom, boolean fitInBounds) {
        PdfDictionary dic = new PdfDictionary();
        if (!scale.equals(PdfName.f62A)) {
            dic.put(PdfName.SW, scale);
        }
        if (!scalingType.equals(PdfName.f75P)) {
            dic.put(PdfName.f78S, scalingType);
        }
        if (!(leftoverLeft == 0.5f && leftoverBottom == 0.5f)) {
            PdfArray array = new PdfArray(new PdfNumber(leftoverLeft));
            array.add(new PdfNumber(leftoverBottom));
            dic.put(PdfName.f62A, array);
        }
        if (fitInBounds) {
            dic.put(PdfName.FB, PdfBoolean.PDFTRUE);
        }
        getMK().put(PdfName.IF, dic);
    }

    public void setMKTextPosition(int tp) {
        getMK().put(PdfName.TP, new PdfNumber(tp));
    }

    public void setLayer(PdfOCG layer) {
        put(PdfName.OC, layer.getRef());
    }

    public void setName(String name) {
        put(PdfName.NM, new PdfString(name));
    }

    public void applyCTM(AffineTransform ctm) {
        PdfArray origRect = getAsArray(PdfName.RECT);
        if (origRect != null) {
            PdfRectangle rect;
            if (origRect.size() == FLAGS_PRINT) {
                rect = new PdfRectangle(origRect.getAsNumber(MARKUP_HIGHLIGHT).floatValue(), origRect.getAsNumber(MARKUP_UNDERLINE).floatValue(), origRect.getAsNumber(MARKUP_STRIKEOUT).floatValue(), origRect.getAsNumber(MARKUP_SQUIGGLY).floatValue());
            } else {
                rect = new PdfRectangle(origRect.getAsNumber(MARKUP_HIGHLIGHT).floatValue(), origRect.getAsNumber(MARKUP_UNDERLINE).floatValue());
            }
            put(PdfName.RECT, rect.transform(ctm));
        }
    }

    public void toPdf(PdfWriter writer, OutputStream os) throws IOException {
        PdfWriter.checkPdfIsoConformance(writer, 13, this);
        super.toPdf(writer, os);
    }

    public PdfObject getAccessibleAttribute(PdfName key) {
        if (this.accessibleAttributes != null) {
            return (PdfObject) this.accessibleAttributes.get(key);
        }
        return null;
    }

    public void setAccessibleAttribute(PdfName key, PdfObject value) {
        if (this.accessibleAttributes == null) {
            this.accessibleAttributes = new HashMap();
        }
        this.accessibleAttributes.put(key, value);
    }

    public HashMap<PdfName, PdfObject> getAccessibleAttributes() {
        return this.accessibleAttributes;
    }

    public PdfName getRole() {
        return this.role;
    }

    public void setRole(PdfName role) {
        this.role = role;
    }

    public AccessibleElementId getId() {
        if (this.id == null) {
            this.id = new AccessibleElementId();
        }
        return this.id;
    }

    public void setId(AccessibleElementId id) {
        this.id = id;
    }

    public boolean isInline() {
        return false;
    }
}

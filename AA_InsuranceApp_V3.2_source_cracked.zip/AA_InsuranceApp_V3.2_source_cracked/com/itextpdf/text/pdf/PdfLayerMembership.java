package com.itextpdf.text.pdf;

import java.util.Collection;
import java.util.HashSet;

public class PdfLayerMembership extends PdfDictionary implements PdfOCG {
    public static final PdfName ALLOFF;
    public static final PdfName ALLON;
    public static final PdfName ANYOFF;
    public static final PdfName ANYON;
    HashSet<PdfLayer> layers;
    PdfArray members;
    PdfIndirectReference ref;

    static {
        ALLON = new PdfName("AllOn");
        ANYON = new PdfName("AnyOn");
        ANYOFF = new PdfName("AnyOff");
        ALLOFF = new PdfName("AllOff");
    }

    public PdfLayerMembership(PdfWriter writer) {
        super(PdfName.OCMD);
        this.members = new PdfArray();
        this.layers = new HashSet();
        put(PdfName.OCGS, this.members);
        this.ref = writer.getPdfIndirectReference();
    }

    public PdfIndirectReference getRef() {
        return this.ref;
    }

    public void addMember(PdfLayer layer) {
        if (!this.layers.contains(layer)) {
            this.members.add(layer.getRef());
            this.layers.add(layer);
        }
    }

    public Collection<PdfLayer> getLayers() {
        return this.layers;
    }

    public void setVisibilityPolicy(PdfName type) {
        put(PdfName.f75P, type);
    }

    public void setVisibilityExpression(PdfVisibilityExpression ve) {
        put(PdfName.VE, ve);
    }

    public PdfObject getPdfObject() {
        return this;
    }
}

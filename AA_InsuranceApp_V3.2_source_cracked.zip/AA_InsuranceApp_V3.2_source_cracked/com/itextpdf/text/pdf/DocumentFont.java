package com.itextpdf.text.pdf;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Utilities;
import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.pdf.codec.JBIG2SegmentReader;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.codec.wmf.MetaDo;
import com.itextpdf.text.pdf.collection.PdfCollectionField;
import com.itextpdf.text.pdf.fonts.cmaps.CMapParserEx;
import com.itextpdf.text.pdf.fonts.cmaps.CMapToUnicode;
import com.itextpdf.text.pdf.fonts.cmaps.CidLocationFromByte;
import com.itextpdf.xmp.XMPError;
import com.itextpdf.xmp.impl.ParseRDF;
import java.io.IOException;
import java.util.HashMap;

public class DocumentFont extends BaseFont {
    private static final int[] stdEnc;
    private float ascender;
    private IntHashtable byte2uni;
    private float capHeight;
    protected String cjkEncoding;
    private BaseFont cjkMirror;
    protected int defaultWidth;
    private float descender;
    private IntHashtable diffmap;
    private PdfDictionary font;
    private String fontName;
    private float fontWeight;
    private IntHashtable hMetrics;
    protected boolean isType0;
    private float italicAngle;
    private float llx;
    private float lly;
    private HashMap<Integer, int[]> metrics;
    private PRIndirectReference refFont;
    private IntHashtable uni2byte;
    protected String uniMap;
    private float urx;
    private float ury;

    static {
        stdEnc = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 33, 34, 35, 36, 37, 38, 8217, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 8216, 97, 98, 99, 100, XMPError.BADSCHEMA, XMPError.BADXPATH, XMPError.BADOPTIONS, XMPError.BADINDEX, 105, 106, XMPError.BADSERIALIZE, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 161, 162, 163, 8260, 165, 402, 167, 164, 39, 8220, 171, 8249, 8250, 64257, 64258, 0, 8211, 8224, 8225, 183, 0, 182, 8226, 8218, 8222, 8221, 187, 8230, 8240, 0, 191, 0, 96, 180, 710, 732, 175, 728, 729, 168, 0, 730, 184, 0, 733, 731, 711, 8212, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 198, 0, 170, 0, 0, 0, 0, TIFFConstants.TIFFTAG_HALFTONEHINTS, 216, TIFFConstants.TIFFTAG_EXTRASAMPLES, 186, 0, 0, 0, 0, 0, 230, 0, 0, 0, TIFFConstants.TIFFTAG_SOFTWARE, 0, 0, MetaDo.META_DIBCREATEPATTERNBRUSH, 248, TIFFConstants.TIFFTAG_SAMPLEFORMAT, 223, 0, 0, 0, 0};
    }

    DocumentFont(PdfDictionary font) {
        this.metrics = new HashMap();
        this.uni2byte = new IntHashtable();
        this.byte2uni = new IntHashtable();
        this.ascender = 800.0f;
        this.capHeight = 700.0f;
        this.descender = -200.0f;
        this.italicAngle = 0.0f;
        this.fontWeight = 0.0f;
        this.llx = -50.0f;
        this.lly = -200.0f;
        this.urx = 100.0f;
        this.ury = 900.0f;
        this.isType0 = false;
        this.defaultWidth = 1000;
        this.refFont = null;
        this.font = font;
        init();
    }

    DocumentFont(PRIndirectReference refFont) {
        this.metrics = new HashMap();
        this.uni2byte = new IntHashtable();
        this.byte2uni = new IntHashtable();
        this.ascender = 800.0f;
        this.capHeight = 700.0f;
        this.descender = -200.0f;
        this.italicAngle = 0.0f;
        this.fontWeight = 0.0f;
        this.llx = -50.0f;
        this.lly = -200.0f;
        this.urx = 100.0f;
        this.ury = 900.0f;
        this.isType0 = false;
        this.defaultWidth = 1000;
        this.refFont = refFont;
        this.font = (PdfDictionary) PdfReader.getPdfObject((PdfObject) refFont);
        init();
    }

    public PdfDictionary getFontDictionary() {
        return this.font;
    }

    private void init() {
        this.encoding = PdfObject.NOTHING;
        this.fontSpecific = false;
        this.fontType = 4;
        PdfName baseFont = this.font.getAsName(PdfName.BASEFONT);
        this.fontName = baseFont != null ? PdfName.decodeName(baseFont.toString()) : "Unspecified Font Name";
        PdfName subType = this.font.getAsName(PdfName.SUBTYPE);
        if (PdfName.TYPE1.equals(subType) || PdfName.TRUETYPE.equals(subType)) {
            doType1TT();
        } else if (PdfName.TYPE3.equals(subType)) {
            fillEncoding(null);
        } else {
            PdfName encodingName = this.font.getAsName(PdfName.ENCODING);
            if (encodingName != null) {
                String enc = PdfName.decodeName(encodingName.toString());
                String ffontname = CJKFont.GetCompatibleFont(enc);
                if (ffontname != null) {
                    try {
                        this.cjkMirror = BaseFont.createFont(ffontname, enc, false);
                        this.cjkEncoding = enc;
                        this.uniMap = ((CJKFont) this.cjkMirror).getUniMap();
                    } catch (Exception e) {
                        throw new ExceptionConverter(e);
                    }
                }
                if (PdfName.TYPE0.equals(subType)) {
                    this.isType0 = true;
                    if (enc.equals(BaseFont.IDENTITY_H) || this.cjkMirror == null) {
                        processType0(this.font);
                        return;
                    }
                    PdfDictionary cidft = (PdfDictionary) PdfReader.getPdfObjectRelease(((PdfArray) PdfReader.getPdfObjectRelease(this.font.get(PdfName.DESCENDANTFONTS))).getPdfObject(0));
                    PdfNumber dwo = (PdfNumber) PdfReader.getPdfObjectRelease(cidft.get(PdfName.DW));
                    if (dwo != null) {
                        this.defaultWidth = dwo.intValue();
                    }
                    this.hMetrics = readWidths((PdfArray) PdfReader.getPdfObjectRelease(cidft.get(PdfName.f82W)));
                    fillFontDesc((PdfDictionary) PdfReader.getPdfObjectRelease(cidft.get(PdfName.FONTDESCRIPTOR)));
                }
            }
        }
    }

    private void processType0(PdfDictionary font) {
        try {
            PdfObject toUniObject = PdfReader.getPdfObjectRelease(font.get(PdfName.TOUNICODE));
            PdfDictionary cidft = (PdfDictionary) PdfReader.getPdfObjectRelease(((PdfArray) PdfReader.getPdfObjectRelease(font.get(PdfName.DESCENDANTFONTS))).getPdfObject(0));
            PdfNumber dwo = (PdfNumber) PdfReader.getPdfObjectRelease(cidft.get(PdfName.DW));
            int dw = 1000;
            if (dwo != null) {
                dw = dwo.intValue();
            }
            IntHashtable widths = readWidths((PdfArray) PdfReader.getPdfObjectRelease(cidft.get(PdfName.f82W)));
            fillFontDesc((PdfDictionary) PdfReader.getPdfObjectRelease(cidft.get(PdfName.FONTDESCRIPTOR)));
            if (toUniObject instanceof PRStream) {
                fillMetrics(PdfReader.getStreamBytes((PRStream) toUniObject), widths, dw);
            }
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    private IntHashtable readWidths(PdfArray ws) {
        IntHashtable hh = new IntHashtable();
        if (ws != null) {
            int k = 0;
            while (k < ws.size()) {
                int c1 = ((PdfNumber) PdfReader.getPdfObjectRelease(ws.getPdfObject(k))).intValue();
                k++;
                PdfObject obj = PdfReader.getPdfObjectRelease(ws.getPdfObject(k));
                if (obj.isArray()) {
                    PdfArray a2 = (PdfArray) obj;
                    int j = 0;
                    while (j < a2.size()) {
                        int c12 = c1 + 1;
                        hh.put(c1, ((PdfNumber) PdfReader.getPdfObjectRelease(a2.getPdfObject(j))).intValue());
                        j++;
                        c1 = c12;
                    }
                } else {
                    int c2 = ((PdfNumber) obj).intValue();
                    k++;
                    int w = ((PdfNumber) PdfReader.getPdfObjectRelease(ws.getPdfObject(k))).intValue();
                    while (c1 <= c2) {
                        hh.put(c1, w);
                        c1++;
                    }
                }
                k++;
            }
        }
        return hh;
    }

    private String decodeString(PdfString ps) {
        if (ps.isHexWriting()) {
            return PdfEncodings.convertToString(ps.getBytes(), "UnicodeBigUnmarked");
        }
        return ps.toUnicodeString();
    }

    private void fillMetrics(byte[] touni, IntHashtable widths, int dw) {
        try {
            PdfContentParser pdfContentParser = new PdfContentParser(new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(touni))));
            boolean notFound = true;
            int nestLevel = 0;
            int maxExc = 50;
            while (true) {
                if (notFound || nestLevel > 0) {
                    try {
                        PdfObject ob = pdfContentParser.readPRObject();
                        if (ob != null) {
                            if (ob.type() != 200) {
                                continue;
                            } else if (ob.toString().equals("begin")) {
                                notFound = false;
                                nestLevel++;
                            } else if (ob.toString().equals("end")) {
                                nestLevel--;
                            } else if (ob.toString().equals("beginbfchar")) {
                                while (true) {
                                    nx = pdfContentParser.readPRObject();
                                    if (nx.toString().equals("endbfchar")) {
                                        break;
                                    }
                                    String cid = decodeString((PdfString) nx);
                                    uni = decodeString((PdfString) pdfContentParser.readPRObject());
                                    if (uni.length() == 1) {
                                        int cidc = cid.charAt(0);
                                        unic = uni.charAt(uni.length() - 1);
                                        w = dw;
                                        if (widths.containsKey(cidc)) {
                                            w = widths.get(cidc);
                                        }
                                        this.metrics.put(Integer.valueOf(unic), new int[]{cidc, w});
                                    }
                                }
                            } else if (ob.toString().equals("beginbfrange")) {
                                while (true) {
                                    nx = pdfContentParser.readPRObject();
                                    if (nx.toString().equals("endbfrange")) {
                                        break;
                                    }
                                    String cid1 = decodeString((PdfString) nx);
                                    String cid2 = decodeString((PdfString) pdfContentParser.readPRObject());
                                    int cid1c = cid1.charAt(0);
                                    int cid2c = cid2.charAt(0);
                                    PdfObject ob2 = pdfContentParser.readPRObject();
                                    if (ob2.isString()) {
                                        uni = decodeString((PdfString) ob2);
                                        if (uni.length() == 1) {
                                            unic = uni.charAt(uni.length() - 1);
                                            while (cid1c <= cid2c) {
                                                w = dw;
                                                if (widths.containsKey(cid1c)) {
                                                    w = widths.get(cid1c);
                                                }
                                                this.metrics.put(Integer.valueOf(unic), new int[]{cid1c, w});
                                                cid1c++;
                                                unic++;
                                            }
                                        }
                                    } else {
                                        PdfArray a = (PdfArray) ob2;
                                        int j = 0;
                                        while (j < a.size()) {
                                            uni = decodeString(a.getAsString(j));
                                            if (uni.length() == 1) {
                                                unic = uni.charAt(uni.length() - 1);
                                                w = dw;
                                                if (widths.containsKey(cid1c)) {
                                                    w = widths.get(cid1c);
                                                }
                                                this.metrics.put(Integer.valueOf(unic), new int[]{cid1c, w});
                                            }
                                            j++;
                                            cid1c++;
                                        }
                                    }
                                }
                            }
                        } else {
                            return;
                        }
                    } catch (Exception e) {
                        maxExc--;
                        if (maxExc < 0) {
                            return;
                        }
                    }
                } else {
                    return;
                }
            }
        } catch (Exception e2) {
            throw new ExceptionConverter(e2);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void doType1TT() {
        /*
        r30 = this;
        r25 = 0;
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.ENCODING;
        r27 = r27.get(r28);
        r10 = com.itextpdf.text.pdf.PdfReader.getPdfObject(r27);
        if (r10 != 0) goto L_0x00bf;
    L_0x0014:
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.BASEFONT;
        r4 = r27.getAsName(r28);
        r27 = BuiltinFonts14;
        r0 = r30;
        r0 = r0.fontName;
        r28 = r0;
        r27 = r27.containsKey(r28);
        if (r27 == 0) goto L_0x00b5;
    L_0x002e:
        r27 = com.itextpdf.text.pdf.PdfName.SYMBOL;
        r0 = r27;
        r27 = r0.equals(r4);
        if (r27 != 0) goto L_0x0042;
    L_0x0038:
        r27 = com.itextpdf.text.pdf.PdfName.ZAPFDINGBATS;
        r0 = r27;
        r27 = r0.equals(r4);
        if (r27 == 0) goto L_0x00b5;
    L_0x0042:
        r0 = r30;
        r0.fillEncoding(r4);
    L_0x0047:
        r25 = r30.processToUnicode();	 Catch:{ Exception -> 0x00ac }
        if (r25 == 0) goto L_0x00d0;
    L_0x004d:
        r23 = r25.createReverseMapping();	 Catch:{ Exception -> 0x00ac }
        r27 = r23.entrySet();	 Catch:{ Exception -> 0x00ac }
        r15 = r27.iterator();	 Catch:{ Exception -> 0x00ac }
    L_0x0059:
        r27 = r15.hasNext();	 Catch:{ Exception -> 0x00ac }
        if (r27 == 0) goto L_0x00d0;
    L_0x005f:
        r17 = r15.next();	 Catch:{ Exception -> 0x00ac }
        r17 = (java.util.Map.Entry) r17;	 Catch:{ Exception -> 0x00ac }
        r0 = r30;
        r0 = r0.uni2byte;	 Catch:{ Exception -> 0x00ac }
        r28 = r0;
        r27 = r17.getKey();	 Catch:{ Exception -> 0x00ac }
        r27 = (java.lang.Integer) r27;	 Catch:{ Exception -> 0x00ac }
        r29 = r27.intValue();	 Catch:{ Exception -> 0x00ac }
        r27 = r17.getValue();	 Catch:{ Exception -> 0x00ac }
        r27 = (java.lang.Integer) r27;	 Catch:{ Exception -> 0x00ac }
        r27 = r27.intValue();	 Catch:{ Exception -> 0x00ac }
        r0 = r28;
        r1 = r29;
        r2 = r27;
        r0.put(r1, r2);	 Catch:{ Exception -> 0x00ac }
        r0 = r30;
        r0 = r0.byte2uni;	 Catch:{ Exception -> 0x00ac }
        r28 = r0;
        r27 = r17.getValue();	 Catch:{ Exception -> 0x00ac }
        r27 = (java.lang.Integer) r27;	 Catch:{ Exception -> 0x00ac }
        r29 = r27.intValue();	 Catch:{ Exception -> 0x00ac }
        r27 = r17.getKey();	 Catch:{ Exception -> 0x00ac }
        r27 = (java.lang.Integer) r27;	 Catch:{ Exception -> 0x00ac }
        r27 = r27.intValue();	 Catch:{ Exception -> 0x00ac }
        r0 = r28;
        r1 = r29;
        r2 = r27;
        r0.put(r1, r2);	 Catch:{ Exception -> 0x00ac }
        goto L_0x0059;
    L_0x00ac:
        r12 = move-exception;
        r27 = new com.itextpdf.text.ExceptionConverter;
        r0 = r27;
        r0.<init>(r12);
        throw r27;
    L_0x00b5:
        r27 = 0;
        r0 = r30;
        r1 = r27;
        r0.fillEncoding(r1);
        goto L_0x0047;
    L_0x00bf:
        r27 = r10.isName();
        if (r27 == 0) goto L_0x014a;
    L_0x00c5:
        r27 = r10;
        r27 = (com.itextpdf.text.pdf.PdfName) r27;
        r0 = r30;
        r1 = r27;
        r0.fillEncoding(r1);
    L_0x00d0:
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.WIDTHS;
        r21 = r27.getAsArray(r28);
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.FIRSTCHAR;
        r14 = r27.getAsNumber(r28);
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.LASTCHAR;
        r18 = r27.getAsNumber(r28);
        r27 = BuiltinFonts14;
        r0 = r30;
        r0 = r0.fontName;
        r28 = r0;
        r27 = r27.containsKey(r28);
        if (r27 == 0) goto L_0x036e;
    L_0x0102:
        r0 = r30;
        r0 = r0.fontName;	 Catch:{ Exception -> 0x0279 }
        r27 = r0;
        r28 = "Cp1252";
        r29 = 0;
        r5 = com.itextpdf.text.pdf.BaseFont.createFont(r27, r28, r29);	 Catch:{ Exception -> 0x0279 }
        r0 = r30;
        r0 = r0.uni2byte;
        r27 = r0;
        r9 = r27.toOrderedKeys();
        r16 = 0;
    L_0x011c:
        r0 = r9.length;
        r27 = r0;
        r0 = r16;
        r1 = r27;
        if (r0 >= r1) goto L_0x0282;
    L_0x0125:
        r0 = r30;
        r0 = r0.uni2byte;
        r27 = r0;
        r28 = r9[r16];
        r19 = r27.get(r28);
        r0 = r30;
        r0 = r0.widths;
        r27 = r0;
        r28 = r9[r16];
        r28 = com.itextpdf.text.pdf.GlyphList.unicodeToName(r28);
        r0 = r19;
        r1 = r28;
        r28 = r5.getRawWidth(r0, r1);
        r27[r19] = r28;
        r16 = r16 + 1;
        goto L_0x011c;
    L_0x014a:
        r27 = r10.isDictionary();
        if (r27 == 0) goto L_0x00d0;
    L_0x0150:
        r11 = r10;
        r11 = (com.itextpdf.text.pdf.PdfDictionary) r11;
        r27 = com.itextpdf.text.pdf.PdfName.BASEENCODING;
        r0 = r27;
        r27 = r11.get(r0);
        r10 = com.itextpdf.text.pdf.PdfReader.getPdfObject(r27);
        if (r10 != 0) goto L_0x01a1;
    L_0x0161:
        r27 = 0;
        r0 = r30;
        r1 = r27;
        r0.fillEncoding(r1);
    L_0x016a:
        r27 = com.itextpdf.text.pdf.PdfName.DIFFERENCES;
        r0 = r27;
        r8 = r11.getAsArray(r0);
        if (r8 == 0) goto L_0x00d0;
    L_0x0174:
        r27 = new com.itextpdf.text.pdf.IntHashtable;
        r27.<init>();
        r0 = r27;
        r1 = r30;
        r1.diffmap = r0;
        r7 = 0;
        r16 = 0;
    L_0x0182:
        r27 = r8.size();
        r0 = r16;
        r1 = r27;
        if (r0 >= r1) goto L_0x00d0;
    L_0x018c:
        r0 = r16;
        r22 = r8.getPdfObject(r0);
        r27 = r22.isNumber();
        if (r27 == 0) goto L_0x01ad;
    L_0x0198:
        r22 = (com.itextpdf.text.pdf.PdfNumber) r22;
        r7 = r22.intValue();
    L_0x019e:
        r16 = r16 + 1;
        goto L_0x0182;
    L_0x01a1:
        r27 = r10;
        r27 = (com.itextpdf.text.pdf.PdfName) r27;
        r0 = r30;
        r1 = r27;
        r0.fillEncoding(r1);
        goto L_0x016a;
    L_0x01ad:
        r22 = (com.itextpdf.text.pdf.PdfName) r22;
        r27 = r22.toString();
        r27 = com.itextpdf.text.pdf.PdfName.decodeName(r27);
        r6 = com.itextpdf.text.pdf.GlyphList.nameToUnicode(r27);
        if (r6 == 0) goto L_0x01f8;
    L_0x01bd:
        r0 = r6.length;
        r27 = r0;
        if (r27 <= 0) goto L_0x01f8;
    L_0x01c2:
        r0 = r30;
        r0 = r0.uni2byte;
        r27 = r0;
        r28 = 0;
        r28 = r6[r28];
        r0 = r27;
        r1 = r28;
        r0.put(r1, r7);
        r0 = r30;
        r0 = r0.byte2uni;
        r27 = r0;
        r28 = 0;
        r28 = r6[r28];
        r0 = r27;
        r1 = r28;
        r0.put(r7, r1);
        r0 = r30;
        r0 = r0.diffmap;
        r27 = r0;
        r28 = 0;
        r28 = r6[r28];
        r0 = r27;
        r1 = r28;
        r0.put(r1, r7);
    L_0x01f5:
        r7 = r7 + 1;
        goto L_0x019e;
    L_0x01f8:
        if (r25 != 0) goto L_0x0205;
    L_0x01fa:
        r25 = r30.processToUnicode();
        if (r25 != 0) goto L_0x0205;
    L_0x0200:
        r25 = new com.itextpdf.text.pdf.fonts.cmaps.CMapToUnicode;
        r25.<init>();
    L_0x0205:
        r27 = 1;
        r0 = r27;
        r0 = new byte[r0];
        r27 = r0;
        r28 = 0;
        r0 = (byte) r7;
        r29 = r0;
        r27[r28] = r29;
        r28 = 0;
        r29 = 1;
        r0 = r25;
        r1 = r27;
        r2 = r28;
        r3 = r29;
        r26 = r0.lookup(r1, r2, r3);
        if (r26 == 0) goto L_0x01f5;
    L_0x0226:
        r27 = r26.length();
        r28 = 1;
        r0 = r27;
        r1 = r28;
        if (r0 != r1) goto L_0x01f5;
    L_0x0232:
        r0 = r30;
        r0 = r0.uni2byte;
        r27 = r0;
        r28 = 0;
        r0 = r26;
        r1 = r28;
        r28 = r0.charAt(r1);
        r0 = r27;
        r1 = r28;
        r0.put(r1, r7);
        r0 = r30;
        r0 = r0.byte2uni;
        r27 = r0;
        r28 = 0;
        r0 = r26;
        r1 = r28;
        r28 = r0.charAt(r1);
        r0 = r27;
        r1 = r28;
        r0.put(r7, r1);
        r0 = r30;
        r0 = r0.diffmap;
        r27 = r0;
        r28 = 0;
        r0 = r26;
        r1 = r28;
        r28 = r0.charAt(r1);
        r0 = r27;
        r1 = r28;
        r0.put(r1, r7);
        goto L_0x01f5;
    L_0x0279:
        r9 = move-exception;
        r27 = new com.itextpdf.text.ExceptionConverter;
        r0 = r27;
        r0.<init>(r9);
        throw r27;
    L_0x0282:
        r0 = r30;
        r0 = r0.diffmap;
        r27 = r0;
        if (r27 == 0) goto L_0x02cc;
    L_0x028a:
        r0 = r30;
        r0 = r0.diffmap;
        r27 = r0;
        r9 = r27.toOrderedKeys();
        r16 = 0;
    L_0x0296:
        r0 = r9.length;
        r27 = r0;
        r0 = r16;
        r1 = r27;
        if (r0 >= r1) goto L_0x02c4;
    L_0x029f:
        r0 = r30;
        r0 = r0.diffmap;
        r27 = r0;
        r28 = r9[r16];
        r19 = r27.get(r28);
        r0 = r30;
        r0 = r0.widths;
        r27 = r0;
        r28 = r9[r16];
        r28 = com.itextpdf.text.pdf.GlyphList.unicodeToName(r28);
        r0 = r19;
        r1 = r28;
        r28 = r5.getRawWidth(r0, r1);
        r27[r19] = r28;
        r16 = r16 + 1;
        goto L_0x0296;
    L_0x02c4:
        r27 = 0;
        r0 = r27;
        r1 = r30;
        r1.diffmap = r0;
    L_0x02cc:
        r27 = 1;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.ascender = r0;
        r27 = 2;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.capHeight = r0;
        r27 = 3;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.descender = r0;
        r27 = 4;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.italicAngle = r0;
        r27 = 23;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.fontWeight = r0;
        r27 = 5;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.llx = r0;
        r27 = 6;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.lly = r0;
        r27 = 7;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.urx = r0;
        r27 = 8;
        r28 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r0 = r27;
        r1 = r28;
        r27 = r5.getFontDescriptor(r0, r1);
        r0 = r27;
        r1 = r30;
        r1.ury = r0;
    L_0x036e:
        if (r14 == 0) goto L_0x03d5;
    L_0x0370:
        if (r18 == 0) goto L_0x03d5;
    L_0x0372:
        if (r21 == 0) goto L_0x03d5;
    L_0x0374:
        r13 = r14.intValue();
        r27 = r21.size();
        r20 = r13 + r27;
        r0 = r30;
        r0 = r0.widths;
        r27 = r0;
        r0 = r27;
        r0 = r0.length;
        r27 = r0;
        r0 = r27;
        r1 = r20;
        if (r0 >= r1) goto L_0x03b0;
    L_0x038f:
        r0 = r20;
        r0 = new int[r0];
        r24 = r0;
        r0 = r30;
        r0 = r0.widths;
        r27 = r0;
        r28 = 0;
        r29 = 0;
        r0 = r27;
        r1 = r28;
        r2 = r24;
        r3 = r29;
        java.lang.System.arraycopy(r0, r1, r2, r3, r13);
        r0 = r24;
        r1 = r30;
        r1.widths = r0;
    L_0x03b0:
        r16 = 0;
    L_0x03b2:
        r27 = r21.size();
        r0 = r16;
        r1 = r27;
        if (r0 >= r1) goto L_0x03d5;
    L_0x03bc:
        r0 = r30;
        r0 = r0.widths;
        r27 = r0;
        r28 = r13 + r16;
        r0 = r21;
        r1 = r16;
        r29 = r0.getAsNumber(r1);
        r29 = r29.intValue();
        r27[r28] = r29;
        r16 = r16 + 1;
        goto L_0x03b2;
    L_0x03d5:
        r0 = r30;
        r0 = r0.font;
        r27 = r0;
        r28 = com.itextpdf.text.pdf.PdfName.FONTDESCRIPTOR;
        r27 = r27.getAsDict(r28);
        r0 = r30;
        r1 = r27;
        r0.fillFontDesc(r1);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.DocumentFont.doType1TT():void");
    }

    private CMapToUnicode processToUnicode() {
        PdfObject toUni = PdfReader.getPdfObjectRelease(this.font.get(PdfName.TOUNICODE));
        if (!(toUni instanceof PRStream)) {
            return null;
        }
        try {
            CidLocationFromByte lb = new CidLocationFromByte(PdfReader.getStreamBytes((PRStream) toUni));
            CMapToUnicode cmapRet = new CMapToUnicode();
            try {
                CMapParserEx.parseCid(PdfObject.NOTHING, cmapRet, lb);
                return cmapRet;
            } catch (Exception e) {
                CMapToUnicode cMapToUnicode = cmapRet;
                return null;
            }
        } catch (Exception e2) {
            return null;
        }
    }

    private void fillFontDesc(PdfDictionary fontDesc) {
        if (fontDesc != null) {
            PdfNumber v = fontDesc.getAsNumber(PdfName.ASCENT);
            if (v != null) {
                this.ascender = v.floatValue();
            }
            v = fontDesc.getAsNumber(PdfName.CAPHEIGHT);
            if (v != null) {
                this.capHeight = v.floatValue();
            }
            v = fontDesc.getAsNumber(PdfName.DESCENT);
            if (v != null) {
                this.descender = v.floatValue();
            }
            v = fontDesc.getAsNumber(PdfName.ITALICANGLE);
            if (v != null) {
                this.italicAngle = v.floatValue();
            }
            v = fontDesc.getAsNumber(PdfName.FONTWEIGHT);
            if (v != null) {
                this.fontWeight = v.floatValue();
            }
            PdfArray bbox = fontDesc.getAsArray(PdfName.FONTBBOX);
            if (bbox != null) {
                float t;
                this.llx = bbox.getAsNumber(0).floatValue();
                this.lly = bbox.getAsNumber(1).floatValue();
                this.urx = bbox.getAsNumber(2).floatValue();
                this.ury = bbox.getAsNumber(3).floatValue();
                if (this.llx > this.urx) {
                    t = this.llx;
                    this.llx = this.urx;
                    this.urx = t;
                }
                if (this.lly > this.ury) {
                    t = this.lly;
                    this.lly = this.ury;
                    this.ury = t;
                }
            }
            float maxAscent = Math.max(this.ury, this.ascender);
            float minDescent = Math.min(this.lly, this.descender);
            this.ascender = (maxAscent * 1000.0f) / (maxAscent - minDescent);
            this.descender = (minDescent * 1000.0f) / (maxAscent - minDescent);
        }
    }

    private void fillEncoding(PdfName encoding) {
        int k;
        if (encoding == null && isSymbolic()) {
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                this.uni2byte.put(k, k);
                this.byte2uni.put(k, k);
            }
        } else if (PdfName.MAC_ROMAN_ENCODING.equals(encoding) || PdfName.WIN_ANSI_ENCODING.equals(encoding) || PdfName.SYMBOL.equals(encoding) || PdfName.ZAPFDINGBATS.equals(encoding)) {
            byte[] b = new byte[PdfWriter.PageModeUseThumbs];
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                b[k] = (byte) k;
            }
            String enc = BaseFont.WINANSI;
            if (PdfName.MAC_ROMAN_ENCODING.equals(encoding)) {
                enc = BaseFont.MACROMAN;
            } else if (PdfName.SYMBOL.equals(encoding)) {
                enc = BaseFont.SYMBOL;
            } else if (PdfName.ZAPFDINGBATS.equals(encoding)) {
                enc = BaseFont.ZAPFDINGBATS;
            }
            char[] arr = PdfEncodings.convertToString(b, enc).toCharArray();
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                this.uni2byte.put(arr[k], k);
                this.byte2uni.put(k, arr[k]);
            }
            this.encoding = enc;
        } else {
            for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
                this.uni2byte.put(stdEnc[k], k);
                this.byte2uni.put(k, stdEnc[k]);
            }
        }
    }

    public String[][] getFamilyFontName() {
        return getFullFontName();
    }

    public float getFontDescriptor(int key, float fontSize) {
        if (this.cjkMirror != null) {
            return this.cjkMirror.getFontDescriptor(key, fontSize);
        }
        switch (key) {
            case PdfWriter.markInlineElementsOnly /*1*/:
            case PdfStream.BEST_COMPRESSION /*9*/:
                return (this.ascender * fontSize) / 1000.0f;
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
                return (this.capHeight * fontSize) / 1000.0f;
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
            case ParseRDF.RDFTERM_FIRST_OLD /*10*/:
                return (this.descender * fontSize) / 1000.0f;
            case PdfWriter.PageLayoutTwoColumnLeft /*4*/:
                return this.italicAngle;
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                return (this.llx * fontSize) / 1000.0f;
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                return (this.lly * fontSize) / 1000.0f;
            case PdfCollectionField.SIZE /*7*/:
                return (this.urx * fontSize) / 1000.0f;
            case PdfWriter.PageLayoutTwoColumnRight /*8*/:
                return (this.ury * fontSize) / 1000.0f;
            case ParseRDF.RDFTERM_ABOUT_EACH_PREFIX /*11*/:
                return 0.0f;
            case ParseRDF.RDFTERM_LAST_OLD /*12*/:
                return ((this.urx - this.llx) * fontSize) / 1000.0f;
            case JBIG2SegmentReader.IMMEDIATE_LOSSLESS_HALFTONE_REGION /*23*/:
                return (this.fontWeight * fontSize) / 1000.0f;
            default:
                return 0.0f;
        }
    }

    public String[][] getFullFontName() {
        String[][] strArr = new String[1][];
        strArr[0] = new String[]{PdfObject.NOTHING, PdfObject.NOTHING, PdfObject.NOTHING, this.fontName};
        return strArr;
    }

    public String[][] getAllNameEntries() {
        String[][] strArr = new String[1][];
        strArr[0] = new String[]{"4", PdfObject.NOTHING, PdfObject.NOTHING, PdfObject.NOTHING, this.fontName};
        return strArr;
    }

    public int getKerning(int char1, int char2) {
        return 0;
    }

    public String getPostscriptFontName() {
        return this.fontName;
    }

    int getRawWidth(int c, String name) {
        return 0;
    }

    public boolean hasKernPairs() {
        return false;
    }

    void writeFont(PdfWriter writer, PdfIndirectReference ref, Object[] params) throws DocumentException, IOException {
    }

    public PdfStream getFullFontStream() {
        return null;
    }

    public int getWidth(int char1) {
        if (this.isType0) {
            if (this.hMetrics == null || this.cjkMirror == null || this.cjkMirror.isVertical()) {
                int[] ws = (int[]) this.metrics.get(Integer.valueOf(char1));
                if (ws != null) {
                    return ws[1];
                }
                return 0;
            }
            int v = this.hMetrics.get(this.cjkMirror.getCidCode(char1));
            if (v > 0) {
                return v;
            }
            return this.defaultWidth;
        } else if (this.cjkMirror != null) {
            return this.cjkMirror.getWidth(char1);
        } else {
            return super.getWidth(char1);
        }
    }

    public int getWidth(String text) {
        if (this.isType0) {
            int total = 0;
            int k;
            if (this.hMetrics == null || this.cjkMirror == null || this.cjkMirror.isVertical()) {
                for (char valueOf : text.toCharArray()) {
                    int[] ws = (int[]) this.metrics.get(Integer.valueOf(valueOf));
                    if (ws != null) {
                        total += ws[1];
                    }
                }
                return total;
            } else if (((CJKFont) this.cjkMirror).isIdentity()) {
                for (k = 0; k < text.length(); k++) {
                    total += getWidth(text.charAt(k));
                }
                return total;
            } else {
                k = 0;
                while (k < text.length()) {
                    int val;
                    if (Utilities.isSurrogatePair(text, k)) {
                        val = Utilities.convertToUtf32(text, k);
                        k++;
                    } else {
                        val = text.charAt(k);
                    }
                    total += getWidth(val);
                    k++;
                }
                return total;
            }
        } else if (this.cjkMirror != null) {
            return this.cjkMirror.getWidth(text);
        } else {
            return super.getWidth(text);
        }
    }

    public byte[] convertToBytes(String text) {
        if (this.cjkMirror != null) {
            return this.cjkMirror.convertToBytes(text);
        }
        byte[] b;
        int k;
        if (this.isType0) {
            char[] chars = text.toCharArray();
            int len = chars.length;
            b = new byte[(len * 2)];
            k = 0;
            int bptr = 0;
            while (k < len) {
                int[] ws = (int[]) this.metrics.get(Integer.valueOf(chars[k]));
                if (ws != null) {
                    int g = ws[0];
                    int i = bptr + 1;
                    b[bptr] = (byte) (g / PdfWriter.PageModeUseThumbs);
                    bptr = i + 1;
                    b[i] = (byte) g;
                }
                k++;
                bptr = bptr;
            }
            if (bptr == b.length) {
                return b;
            }
            byte[] nb = new byte[bptr];
            System.arraycopy(b, 0, nb, 0, bptr);
            return nb;
        }
        char[] cc = text.toCharArray();
        b = new byte[cc.length];
        int ptr = 0;
        for (k = 0; k < cc.length; k++) {
            if (this.uni2byte.containsKey(cc[k])) {
                int ptr2 = ptr + 1;
                b[ptr] = (byte) this.uni2byte.get(cc[k]);
                ptr = ptr2;
            }
        }
        if (ptr == b.length) {
            return b;
        }
        byte[] b2 = new byte[ptr];
        System.arraycopy(b, 0, b2, 0, ptr);
        return b2;
    }

    byte[] convertToBytes(int char1) {
        if (this.cjkMirror != null) {
            return this.cjkMirror.convertToBytes(char1);
        }
        if (this.isType0) {
            int[] ws = (int[]) this.metrics.get(Integer.valueOf(char1));
            if (ws == null) {
                return new byte[0];
            }
            int g = ws[0];
            return new byte[]{(byte) (g / PdfWriter.PageModeUseThumbs), (byte) g};
        } else if (!this.uni2byte.containsKey(char1)) {
            return new byte[0];
        } else {
            return new byte[]{(byte) this.uni2byte.get(char1)};
        }
    }

    PdfIndirectReference getIndirectReference() {
        if (this.refFont != null) {
            return this.refFont;
        }
        throw new IllegalArgumentException("Font reuse not allowed with direct font objects.");
    }

    public boolean charExists(int c) {
        if (this.cjkMirror != null) {
            return this.cjkMirror.charExists(c);
        }
        if (this.isType0) {
            return this.metrics.containsKey(Integer.valueOf(c));
        }
        return super.charExists(c);
    }

    public void setPostscriptFontName(String name) {
    }

    public boolean setKerning(int char1, int char2, int kern) {
        return false;
    }

    public int[] getCharBBox(int c) {
        return null;
    }

    protected int[] getRawCharBBox(int c, String name) {
        return null;
    }

    public boolean isVertical() {
        if (this.cjkMirror != null) {
            return this.cjkMirror.isVertical();
        }
        return super.isVertical();
    }

    IntHashtable getUni2Byte() {
        return this.uni2byte;
    }

    IntHashtable getByte2Uni() {
        return this.byte2uni;
    }

    IntHashtable getDiffmap() {
        return this.diffmap;
    }

    boolean isSymbolic() {
        PdfDictionary fontDescriptor = this.font.getAsDict(PdfName.FONTDESCRIPTOR);
        if (fontDescriptor == null) {
            return false;
        }
        PdfNumber flags = fontDescriptor.getAsNumber(PdfName.FLAGS);
        if (flags == null || (flags.intValue() & 4) == 0) {
            return false;
        }
        return true;
    }
}

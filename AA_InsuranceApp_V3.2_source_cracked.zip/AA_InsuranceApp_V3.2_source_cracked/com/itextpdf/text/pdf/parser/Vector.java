package com.itextpdf.text.pdf.parser;

import java.util.Arrays;

public class Vector {
    public static final int I1 = 0;
    public static final int I2 = 1;
    public static final int I3 = 2;
    private final float[] vals;

    public Vector(float x, float y, float z) {
        this.vals = new float[]{0.0f, 0.0f, 0.0f};
        this.vals[I1] = x;
        this.vals[I2] = y;
        this.vals[I3] = z;
    }

    public float get(int index) {
        return this.vals[index];
    }

    public Vector cross(Matrix by) {
        return new Vector(((this.vals[I1] * by.get(I1)) + (this.vals[I2] * by.get(3))) + (this.vals[I3] * by.get(6)), ((this.vals[I1] * by.get(I2)) + (this.vals[I2] * by.get(4))) + (this.vals[I3] * by.get(7)), ((this.vals[I1] * by.get(I3)) + (this.vals[I2] * by.get(5))) + (this.vals[I3] * by.get(8)));
    }

    public Vector subtract(Vector v) {
        return new Vector(this.vals[I1] - v.vals[I1], this.vals[I2] - v.vals[I2], this.vals[I3] - v.vals[I3]);
    }

    public Vector cross(Vector with) {
        return new Vector((this.vals[I2] * with.vals[I3]) - (this.vals[I3] * with.vals[I2]), (this.vals[I3] * with.vals[I1]) - (this.vals[I1] * with.vals[I3]), (this.vals[I1] * with.vals[I2]) - (this.vals[I2] * with.vals[I1]));
    }

    public Vector normalize() {
        float l = length();
        return new Vector(this.vals[I1] / l, this.vals[I2] / l, this.vals[I3] / l);
    }

    public Vector multiply(float by) {
        return new Vector(this.vals[I1] * by, this.vals[I2] * by, this.vals[I3] * by);
    }

    public float dot(Vector with) {
        return ((this.vals[I1] * with.vals[I1]) + (this.vals[I2] * with.vals[I2])) + (this.vals[I3] * with.vals[I3]);
    }

    public float length() {
        return (float) Math.sqrt((double) lengthSquared());
    }

    public float lengthSquared() {
        return ((this.vals[I1] * this.vals[I1]) + (this.vals[I2] * this.vals[I2])) + (this.vals[I3] * this.vals[I3]);
    }

    public String toString() {
        return this.vals[I1] + "," + this.vals[I2] + "," + this.vals[I3];
    }

    public int hashCode() {
        return Arrays.hashCode(this.vals) + 31;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        if (Arrays.equals(this.vals, ((Vector) obj).vals)) {
            return true;
        }
        return false;
    }
}

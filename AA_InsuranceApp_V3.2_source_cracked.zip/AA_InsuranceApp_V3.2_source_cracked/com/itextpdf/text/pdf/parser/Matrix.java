package com.itextpdf.text.pdf.parser;

import com.itextpdf.text.pdf.BaseField;
import java.util.Arrays;

public class Matrix {
    public static final int I11 = 0;
    public static final int I12 = 1;
    public static final int I13 = 2;
    public static final int I21 = 3;
    public static final int I22 = 4;
    public static final int I23 = 5;
    public static final int I31 = 6;
    public static final int I32 = 7;
    public static final int I33 = 8;
    private final float[] vals;

    public Matrix() {
        this.vals = new float[]{BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN};
    }

    public Matrix(float tx, float ty) {
        this.vals = new float[]{BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN};
        this.vals[I31] = tx;
        this.vals[I32] = ty;
    }

    public Matrix(float a, float b, float c, float d, float e, float f) {
        this.vals = new float[]{BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN, 0.0f, 0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN};
        this.vals[I11] = a;
        this.vals[I12] = b;
        this.vals[I13] = 0.0f;
        this.vals[I21] = c;
        this.vals[I22] = d;
        this.vals[I23] = 0.0f;
        this.vals[I31] = e;
        this.vals[I32] = f;
        this.vals[I33] = BaseField.BORDER_WIDTH_THIN;
    }

    public float get(int index) {
        return this.vals[index];
    }

    public Matrix multiply(Matrix by) {
        Matrix rslt = new Matrix();
        float[] a = this.vals;
        float[] b = by.vals;
        float[] c = rslt.vals;
        c[I11] = ((a[I11] * b[I11]) + (a[I12] * b[I21])) + (a[I13] * b[I31]);
        c[I12] = ((a[I11] * b[I12]) + (a[I12] * b[I22])) + (a[I13] * b[I32]);
        c[I13] = ((a[I11] * b[I13]) + (a[I12] * b[I23])) + (a[I13] * b[I33]);
        c[I21] = ((a[I21] * b[I11]) + (a[I22] * b[I21])) + (a[I23] * b[I31]);
        c[I22] = ((a[I21] * b[I12]) + (a[I22] * b[I22])) + (a[I23] * b[I32]);
        c[I23] = ((a[I21] * b[I13]) + (a[I22] * b[I23])) + (a[I23] * b[I33]);
        c[I31] = ((a[I31] * b[I11]) + (a[I32] * b[I21])) + (a[I33] * b[I31]);
        c[I32] = ((a[I31] * b[I12]) + (a[I32] * b[I22])) + (a[I33] * b[I32]);
        c[I33] = ((a[I31] * b[I13]) + (a[I32] * b[I23])) + (a[I33] * b[I33]);
        return rslt;
    }

    public Matrix subtract(Matrix arg) {
        Matrix rslt = new Matrix();
        float[] a = this.vals;
        float[] b = arg.vals;
        float[] c = rslt.vals;
        c[I11] = a[I11] - b[I11];
        c[I12] = a[I12] - b[I12];
        c[I13] = a[I13] - b[I13];
        c[I21] = a[I21] - b[I21];
        c[I22] = a[I22] - b[I22];
        c[I23] = a[I23] - b[I23];
        c[I31] = a[I31] - b[I31];
        c[I32] = a[I32] - b[I32];
        c[I33] = a[I33] - b[I33];
        return rslt;
    }

    public float getDeterminant() {
        return ((((((this.vals[I11] * this.vals[I22]) * this.vals[I33]) + ((this.vals[I12] * this.vals[I23]) * this.vals[I31])) + ((this.vals[I13] * this.vals[I21]) * this.vals[I32])) - ((this.vals[I11] * this.vals[I23]) * this.vals[I32])) - ((this.vals[I12] * this.vals[I21]) * this.vals[I33])) - ((this.vals[I13] * this.vals[I22]) * this.vals[I31]);
    }

    public boolean equals(Object obj) {
        if (obj instanceof Matrix) {
            return Arrays.equals(this.vals, ((Matrix) obj).vals);
        }
        return false;
    }

    public int hashCode() {
        int result = I12;
        for (int i = I11; i < this.vals.length; i += I12) {
            result = (result * 31) + Float.floatToIntBits(this.vals[i]);
        }
        return result;
    }

    public String toString() {
        return this.vals[I11] + "\t" + this.vals[I12] + "\t" + this.vals[I13] + "\n" + this.vals[I21] + "\t" + this.vals[I22] + "\t" + this.vals[I13] + "\n" + this.vals[I31] + "\t" + this.vals[I32] + "\t" + this.vals[I33];
    }
}

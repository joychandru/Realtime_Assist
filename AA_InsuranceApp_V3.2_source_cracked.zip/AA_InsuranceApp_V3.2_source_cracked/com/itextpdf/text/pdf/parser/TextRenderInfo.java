package com.itextpdf.text.pdf.parser;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.pdf.BaseField;
import com.itextpdf.text.pdf.DocumentFont;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TextRenderInfo {
    private final GraphicsState gs;
    private final Collection<MarkedContentInfo> markedContentInfos;
    private final String text;
    private final Matrix textToUserSpaceTransformMatrix;

    TextRenderInfo(String text, GraphicsState gs, Matrix textMatrix, Collection<MarkedContentInfo> markedContentInfo) {
        this.text = text;
        this.textToUserSpaceTransformMatrix = textMatrix.multiply(gs.ctm);
        this.gs = gs;
        this.markedContentInfos = new ArrayList(markedContentInfo);
    }

    private TextRenderInfo(TextRenderInfo parent, int charIndex, float horizontalOffset) {
        this.text = parent.text.substring(charIndex, charIndex + 1);
        this.textToUserSpaceTransformMatrix = new Matrix(horizontalOffset, 0.0f).multiply(parent.textToUserSpaceTransformMatrix);
        this.gs = parent.gs;
        this.markedContentInfos = parent.markedContentInfos;
    }

    public String getText() {
        return this.text;
    }

    public boolean hasMcid(int mcid) {
        return hasMcid(mcid, false);
    }

    public boolean hasMcid(int mcid, boolean checkTheTopmostLevelOnly) {
        if (!checkTheTopmostLevelOnly) {
            for (MarkedContentInfo info : this.markedContentInfos) {
                if (info.hasMcid() && info.getMcid() == mcid) {
                    return true;
                }
            }
        } else if (this.markedContentInfos instanceof ArrayList) {
            Integer infoMcid = getMcid();
            if (infoMcid == null) {
                return false;
            }
            if (infoMcid.intValue() == mcid) {
                return true;
            }
            return false;
        }
        return false;
    }

    public Integer getMcid() {
        if (!(this.markedContentInfos instanceof ArrayList)) {
            return null;
        }
        MarkedContentInfo info;
        ArrayList<MarkedContentInfo> mci = this.markedContentInfos;
        if (mci.size() > 0) {
            info = (MarkedContentInfo) mci.get(mci.size() - 1);
        } else {
            info = null;
        }
        if (info == null || !info.hasMcid()) {
            return null;
        }
        return Integer.valueOf(info.getMcid());
    }

    float getUnscaledWidth() {
        return getStringWidth(this.text);
    }

    public LineSegment getBaseline() {
        return getUnscaledBaselineWithOffset(0.0f + this.gs.rise).transformBy(this.textToUserSpaceTransformMatrix);
    }

    public LineSegment getAscentLine() {
        return getUnscaledBaselineWithOffset(this.gs.rise + this.gs.getFont().getFontDescriptor(1, this.gs.getFontSize())).transformBy(this.textToUserSpaceTransformMatrix);
    }

    public LineSegment getDescentLine() {
        return getUnscaledBaselineWithOffset(this.gs.rise + this.gs.getFont().getFontDescriptor(3, this.gs.getFontSize())).transformBy(this.textToUserSpaceTransformMatrix);
    }

    private LineSegment getUnscaledBaselineWithOffset(float yOffset) {
        return new LineSegment(new Vector(0.0f, yOffset, BaseField.BORDER_WIDTH_THIN), new Vector(getUnscaledWidth() - (this.gs.characterSpacing * this.gs.horizontalScaling), yOffset, BaseField.BORDER_WIDTH_THIN));
    }

    public DocumentFont getFont() {
        return this.gs.getFont();
    }

    public float getRise() {
        if (this.gs.rise == 0.0f) {
            return 0.0f;
        }
        return convertHeightFromTextSpaceToUserSpace(this.gs.rise);
    }

    private float convertWidthFromTextSpaceToUserSpace(float width) {
        return new LineSegment(new Vector(0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN), new Vector(width, 0.0f, BaseField.BORDER_WIDTH_THIN)).transformBy(this.textToUserSpaceTransformMatrix).getLength();
    }

    private float convertHeightFromTextSpaceToUserSpace(float height) {
        return new LineSegment(new Vector(0.0f, 0.0f, BaseField.BORDER_WIDTH_THIN), new Vector(0.0f, height, BaseField.BORDER_WIDTH_THIN)).transformBy(this.textToUserSpaceTransformMatrix).getLength();
    }

    public float getSingleSpaceWidth() {
        return convertWidthFromTextSpaceToUserSpace(getUnscaledFontSpaceWidth());
    }

    public int getTextRenderMode() {
        return this.gs.renderMode;
    }

    public BaseColor getFillColor() {
        return this.gs.fillColor;
    }

    public BaseColor getStrokeColor() {
        return this.gs.strokeColor;
    }

    private float getUnscaledFontSpaceWidth() {
        char charToUse = ' ';
        if (this.gs.font.getWidth(32) == 0) {
            charToUse = '\u00a0';
        }
        return getStringWidth(String.valueOf(charToUse));
    }

    private float getStringWidth(String string) {
        DocumentFont font = this.gs.font;
        char[] chars = string.toCharArray();
        float totalWidth = 0.0f;
        for (int i = 0; i < chars.length; i++) {
            totalWidth += (((this.gs.fontSize * (((float) font.getWidth(chars[i])) / 1000.0f)) + this.gs.characterSpacing) + (chars[i] == ' ' ? this.gs.wordSpacing : 0.0f)) * this.gs.horizontalScaling;
        }
        return totalWidth;
    }

    public List<TextRenderInfo> getCharacterRenderInfos() {
        List<TextRenderInfo> rslt = new ArrayList(this.text.length());
        DocumentFont font = this.gs.font;
        char[] chars = this.text.toCharArray();
        float totalWidth = 0.0f;
        for (int i = 0; i < chars.length; i++) {
            float w = ((float) font.getWidth(chars[i])) / 1000.0f;
            float wordSpacing = chars[i] == ' ' ? this.gs.wordSpacing : 0.0f;
            rslt.add(new TextRenderInfo(this, i, totalWidth));
            totalWidth += (((this.gs.fontSize * w) + this.gs.characterSpacing) + wordSpacing) * this.gs.horizontalScaling;
        }
        return rslt;
    }
}

package com.itextpdf.text.pdf.fonts;

public class FontsResourceAnchor {
}

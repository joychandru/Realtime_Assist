package com.itextpdf.text.pdf.fonts.cmaps;

import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfString;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import java.util.ArrayList;

public class CMapByteCid extends AbstractCMap {
    private ArrayList<char[]> planes;

    public CMapByteCid() {
        this.planes = new ArrayList();
        this.planes.add(new char[PdfWriter.PageModeUseThumbs]);
    }

    void addChar(PdfString mark, PdfObject code) {
        if (code instanceof PdfNumber) {
            encodeSequence(AbstractCMap.decodeStringToByte(mark), (char) ((PdfNumber) code).intValue());
        }
    }

    private void encodeSequence(byte[] seqs, char cid) {
        char[] plane;
        int one;
        int size = seqs.length - 1;
        int nextPlane = 0;
        int idx = 0;
        while (idx < size) {
            plane = (char[]) this.planes.get(nextPlane);
            one = seqs[idx] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            char c = plane[one];
            if (c == '\u0000' || (c & PdfWriter.FitWindow) != 0) {
                if (c == '\u0000') {
                    this.planes.add(new char[PdfWriter.PageModeUseThumbs]);
                    c = (char) ((this.planes.size() - 1) | PdfWriter.FitWindow);
                    plane[one] = c;
                }
                nextPlane = c & 32767;
                idx++;
            } else {
                throw new RuntimeException(MessageLocalization.getComposedMessage("inconsistent.mapping", new Object[0]));
            }
        }
        plane = (char[]) this.planes.get(nextPlane);
        one = seqs[size] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
        if ((plane[one] & PdfWriter.FitWindow) != 0) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("inconsistent.mapping", new Object[0]));
        }
        plane[one] = cid;
    }

    public int decodeSingle(CMapSequence seq) {
        int end = seq.off + seq.len;
        int currentPlane = 0;
        while (seq.off < end) {
            byte[] bArr = seq.seq;
            int i = seq.off;
            seq.off = i + 1;
            int one = bArr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            seq.len--;
            int cid = ((char[]) this.planes.get(currentPlane))[one];
            if ((PdfWriter.FitWindow & cid) == 0) {
                return cid;
            }
            currentPlane = cid & 32767;
        }
        return -1;
    }

    public String decodeSequence(CMapSequence seq) {
        StringBuilder sb = new StringBuilder();
        while (true) {
            int cid = decodeSingle(seq);
            if (cid < 0) {
                return sb.toString();
            }
            sb.append((char) cid);
        }
    }
}

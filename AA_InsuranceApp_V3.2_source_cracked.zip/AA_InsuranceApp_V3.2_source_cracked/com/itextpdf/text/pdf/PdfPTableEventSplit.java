package com.itextpdf.text.pdf;

public interface PdfPTableEventSplit extends PdfPTableEvent {
    void splitTable(PdfPTable pdfPTable);
}

package com.itextpdf.text.pdf;

public interface PdfOCG {
    PdfObject getPdfObject();

    PdfIndirectReference getRef();
}

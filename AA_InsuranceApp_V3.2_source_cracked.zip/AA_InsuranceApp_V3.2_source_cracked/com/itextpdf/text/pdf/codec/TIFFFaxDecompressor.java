package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.DocWriter;
import com.itextpdf.text.Jpeg;
import com.itextpdf.text.pdf.BidiOrder;
import com.itextpdf.text.pdf.ByteBuffer;
import com.itextpdf.text.pdf.PdfContentParser;
import com.itextpdf.text.pdf.PdfWriter;

public class TIFFFaxDecompressor {
    static short[] additionalMakeup;
    static short[] black;
    static byte[] flipTable;
    static short[] initBlack;
    static int[] table1;
    static int[] table2;
    static short[] twoBitBlack;
    static byte[] twoDCodes;
    static short[] white;
    private int bitPointer;
    private int bitsPerScanline;
    private byte[] buffer;
    private int bytePointer;
    private int changingElemSize;
    protected int compression;
    private int[] currChangingElems;
    private byte[] data;
    public int fails;
    protected int fillBits;
    protected int fillOrder;
    private int f24h;
    private int lastChangingElement;
    private int lineBitNum;
    protected int oneD;
    private int[] prevChangingElems;
    private int t4Options;
    private int t6Options;
    protected int uncompressedMode;
    private int f25w;

    static {
        table1 = new int[]{0, 1, 3, 7, 15, 31, 63, 127, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        table2 = new int[]{0, PdfWriter.PageModeUseOutlines, 192, Jpeg.M_APP0, 240, 248, 252, TIFFConstants.TIFFTAG_SUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        flipTable = new byte[]{(byte) 0, Byte.MIN_VALUE, (byte) 64, (byte) -64, DocWriter.SPACE, (byte) -96, (byte) 96, (byte) -32, BidiOrder.f13S, (byte) -112, (byte) 80, (byte) -48, ByteBuffer.ZERO, (byte) -80, (byte) 112, (byte) -16, (byte) 8, (byte) -120, (byte) 72, (byte) -56, (byte) 40, (byte) -88, (byte) 104, (byte) -24, (byte) 24, (byte) -104, (byte) 88, (byte) -40, (byte) 56, (byte) -72, (byte) 120, (byte) -8, (byte) 4, (byte) -124, (byte) 68, (byte) -60, (byte) 36, (byte) -92, (byte) 100, (byte) -28, (byte) 20, (byte) -108, (byte) 84, (byte) -44, (byte) 52, (byte) -76, (byte) 116, (byte) -12, BidiOrder.CS, (byte) -116, (byte) 76, (byte) -52, (byte) 44, (byte) -84, (byte) 108, (byte) -20, (byte) 28, (byte) -100, (byte) 92, (byte) -36, DocWriter.LT, (byte) -68, (byte) 124, (byte) -4, (byte) 2, (byte) -126, (byte) 66, (byte) -62, DocWriter.QUOTE, (byte) -94, (byte) 98, (byte) -30, BidiOrder.TYPE_MAX, (byte) -110, (byte) 82, (byte) -46, (byte) 50, (byte) -78, (byte) 114, (byte) -14, (byte) 10, (byte) -118, (byte) 74, (byte) -54, (byte) 42, (byte) -86, (byte) 106, (byte) -22, (byte) 26, (byte) -102, (byte) 90, (byte) -38, (byte) 58, (byte) -70, (byte) 122, (byte) -6, (byte) 6, (byte) -122, (byte) 70, (byte) -58, (byte) 38, (byte) -90, (byte) 102, (byte) -26, (byte) 22, (byte) -106, (byte) 86, (byte) -42, (byte) 54, (byte) -74, (byte) 118, (byte) -10, BidiOrder.BN, (byte) -114, (byte) 78, (byte) -50, (byte) 46, (byte) -82, (byte) 110, (byte) -18, (byte) 30, (byte) -98, (byte) 94, (byte) -34, DocWriter.GT, (byte) -66, (byte) 126, (byte) -2, (byte) 1, (byte) -127, (byte) 65, (byte) -63, (byte) 33, (byte) -95, (byte) 97, (byte) -31, BidiOrder.WS, (byte) -111, (byte) 81, (byte) -47, (byte) 49, (byte) -79, (byte) 113, (byte) -15, (byte) 9, (byte) -119, (byte) 73, (byte) -55, (byte) 41, (byte) -87, (byte) 105, (byte) -23, (byte) 25, (byte) -103, (byte) 89, (byte) -39, (byte) 57, (byte) -71, (byte) 121, (byte) -7, (byte) 5, (byte) -123, (byte) 69, (byte) -59, (byte) 37, (byte) -91, (byte) 101, (byte) -27, (byte) 21, (byte) -107, (byte) 85, (byte) -43, (byte) 53, (byte) -75, (byte) 117, (byte) -11, BidiOrder.NSM, (byte) -115, (byte) 77, (byte) -51, (byte) 45, (byte) -83, (byte) 109, (byte) -19, (byte) 29, (byte) -99, (byte) 93, (byte) -35, DocWriter.EQUALS, (byte) -67, (byte) 125, (byte) -3, (byte) 3, (byte) -125, (byte) 67, (byte) -61, (byte) 35, (byte) -93, (byte) 99, (byte) -29, (byte) 19, (byte) -109, (byte) 83, (byte) -45, (byte) 51, (byte) -77, (byte) 115, (byte) -13, BidiOrder.AN, (byte) -117, (byte) 75, (byte) -53, (byte) 43, (byte) -85, (byte) 107, (byte) -21, (byte) 27, (byte) -101, (byte) 91, (byte) -37, (byte) 59, (byte) -69, (byte) 123, (byte) -5, (byte) 7, (byte) -121, (byte) 71, (byte) -57, (byte) 39, (byte) -89, (byte) 103, (byte) -25, (byte) 23, (byte) -105, (byte) 87, (byte) -41, (byte) 55, (byte) -73, (byte) 119, (byte) -9, BidiOrder.f10B, (byte) -113, (byte) 79, (byte) -49, DocWriter.FORWARD, (byte) -81, (byte) 111, (byte) -17, (byte) 31, (byte) -97, (byte) 95, (byte) -33, (byte) 63, (byte) -65, Byte.MAX_VALUE, (byte) -1};
        white = new short[]{(short) 6430, (short) 6400, (short) 6400, (short) 6400, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 944, (short) 944, (short) 944, (short) 944, (short) 976, (short) 976, (short) 976, (short) 976, (short) 1456, (short) 1456, (short) 1456, (short) 1456, (short) 1488, (short) 1488, (short) 1488, (short) 1488, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 1520, (short) 1520, (short) 1520, (short) 1520, (short) 1552, (short) 1552, (short) 1552, (short) 1552, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 1072, (short) 1072, (short) 1072, (short) 1072, (short) 1104, (short) 1104, (short) 1104, (short) 1104, (short) 1136, (short) 1136, (short) 1136, (short) 1136, (short) 1168, (short) 1168, (short) 1168, (short) 1168, (short) 1200, (short) 1200, (short) 1200, (short) 1200, (short) 1232, (short) 1232, (short) 1232, (short) 1232, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 1008, (short) 1008, (short) 1008, (short) 1008, (short) 1040, (short) 1040, (short) 1040, (short) 1040, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 1712, (short) 1712, (short) 1712, (short) 1712, (short) 1744, (short) 1744, (short) 1744, (short) 1744, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 1264, (short) 1264, (short) 1264, (short) 1264, (short) 1296, (short) 1296, (short) 1296, (short) 1296, (short) 1328, (short) 1328, (short) 1328, (short) 1328, (short) 1360, (short) 1360, (short) 1360, (short) 1360, (short) 1392, (short) 1392, (short) 1392, (short) 1392, (short) 1424, (short) 1424, (short) 1424, (short) 1424, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 1968, (short) 1968, (short) 1968, (short) 1968, (short) 2000, (short) 2000, (short) 2000, (short) 2000, (short) 2032, (short) 2032, (short) 2032, (short) 2032, (short) 16, (short) 16, (short) 16, (short) 16, (short) 10257, (short) 10257, (short) 10257, (short) 10257, (short) 12305, (short) 12305, (short) 12305, (short) 12305, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 1904, (short) 1904, (short) 1904, (short) 1904, (short) 1936, (short) 1936, (short) 1936, (short) 1936, (short) -18413, (short) -18413, (short) -16365, (short) -16365, (short) -14317, (short) -14317, (short) -10221, (short) -10221, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 1584, (short) 1584, (short) 1584, (short) 1584, (short) 1616, (short) 1616, (short) 1616, (short) 1616, (short) 1648, (short) 1648, (short) 1648, (short) 1648, (short) 1680, (short) 1680, (short) 1680, (short) 1680, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 1776, (short) 1776, (short) 1776, (short) 1776, (short) 1808, (short) 1808, (short) 1808, (short) 1808, (short) 1840, (short) 1840, (short) 1840, (short) 1840, (short) 1872, (short) 1872, (short) 1872, (short) 1872, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) 14353, (short) 14353, (short) 14353, (short) 14353, (short) 16401, (short) 16401, (short) 16401, (short) 16401, (short) 22547, (short) 22547, (short) 24595, (short) 24595, (short) 20497, (short) 20497, (short) 20497, (short) 20497, (short) 18449, (short) 18449, (short) 18449, (short) 18449, (short) 26643, (short) 26643, (short) 28691, (short) 28691, (short) 30739, (short) 30739, (short) -32749, (short) -32749, (short) -30701, (short) -30701, (short) -28653, (short) -28653, (short) -26605, (short) -26605, (short) -24557, (short) -24557, (short) -22509, (short) -22509, (short) -20461, (short) -20461, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232};
        additionalMakeup = new short[]{(short) 28679, (short) 28679, (short) 31752, (short) -32759, (short) -31735, (short) -30711, (short) -29687, (short) -28663, (short) 29703, (short) 29703, (short) 30727, (short) 30727, (short) -27639, (short) -26615, (short) -25591, (short) -24567};
        initBlack = new short[]{(short) 3226, (short) 6412, (short) 200, (short) 168, (short) 38, (short) 38, (short) 134, (short) 134, (short) 100, (short) 100, (short) 100, (short) 100, (short) 68, (short) 68, (short) 68, (short) 68};
        twoBitBlack = new short[]{(short) 292, (short) 260, (short) 226, (short) 226};
        black = new short[]{(short) 62, (short) 62, (short) 30, (short) 30, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 1680, (short) 1680, (short) 20499, (short) 22547, (short) 24595, (short) 26643, (short) 1776, (short) 1776, (short) 1808, (short) 1808, (short) -24557, (short) -22509, (short) -20461, (short) -18413, (short) 1904, (short) 1904, (short) 1936, (short) 1936, (short) -16365, (short) -14317, (short) 782, (short) 782, (short) 782, (short) 782, (short) 814, (short) 814, (short) 814, (short) 814, (short) -12269, (short) -10221, (short) 10257, (short) 10257, (short) 12305, (short) 12305, (short) 14353, (short) 14353, (short) 16403, (short) 18451, (short) 1712, (short) 1712, (short) 1744, (short) 1744, (short) 28691, (short) 30739, (short) -32749, (short) -30701, (short) -28653, (short) -26605, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 750, (short) 750, (short) 750, (short) 750, (short) 1616, (short) 1616, (short) 1648, (short) 1648, (short) 1424, (short) 1424, (short) 1456, (short) 1456, (short) 1488, (short) 1488, (short) 1520, (short) 1520, (short) 1840, (short) 1840, (short) 1872, (short) 1872, (short) 1968, (short) 1968, (short) 8209, (short) 8209, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 1552, (short) 1552, (short) 1584, (short) 1584, (short) 2000, (short) 2000, (short) 2032, (short) 2032, (short) 976, (short) 976, (short) 1008, (short) 1008, (short) 1040, (short) 1040, (short) 1072, (short) 1072, (short) 1296, (short) 1296, (short) 1328, (short) 1328, (short) 718, (short) 718, (short) 718, (short) 718, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 4113, (short) 4113, (short) 6161, (short) 6161, (short) 848, (short) 848, (short) 880, (short) 880, (short) 912, (short) 912, (short) 944, (short) 944, (short) 622, (short) 622, (short) 622, (short) 622, (short) 654, (short) 654, (short) 654, (short) 654, (short) 1104, (short) 1104, (short) 1136, (short) 1136, (short) 1168, (short) 1168, (short) 1200, (short) 1200, (short) 1232, (short) 1232, (short) 1264, (short) 1264, (short) 686, (short) 686, (short) 686, (short) 686, (short) 1360, (short) 1360, (short) 1392, (short) 1392, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390};
        twoDCodes = new byte[]{(byte) 80, (byte) 88, (byte) 23, (byte) 71, (byte) 30, (byte) 30, DocWriter.GT, DocWriter.GT, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41};
    }

    public TIFFFaxDecompressor() {
        this.uncompressedMode = 0;
        this.fillBits = 0;
        this.changingElemSize = 0;
        this.lastChangingElement = 0;
    }

    public void SetOptions(int fillOrder, int compression, int t4Options, int t6Options) {
        this.fillOrder = fillOrder;
        this.compression = compression;
        this.t4Options = t4Options;
        this.t6Options = t6Options;
        this.oneD = t4Options & 1;
        this.uncompressedMode = (t4Options & 2) >> 1;
        this.fillBits = (t4Options & 4) >> 2;
    }

    public void decodeRaw(byte[] buffer, byte[] compData, int w, int h) {
        this.buffer = buffer;
        this.data = compData;
        this.f25w = w;
        this.f24h = h;
        this.bitsPerScanline = w;
        this.lineBitNum = 0;
        this.bitPointer = 0;
        this.bytePointer = 0;
        this.prevChangingElems = new int[(w + 1)];
        this.currChangingElems = new int[(w + 1)];
        this.fails = 0;
        try {
            if (this.compression == 2) {
                decodeRLE();
            } else if (this.compression == 3) {
                decodeT4();
            } else if (this.compression == 4) {
                this.uncompressedMode = (this.t6Options & 2) >> 1;
                decodeT6();
            } else {
                throw new RuntimeException("Unknown compression type " + this.compression);
            }
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    public void decodeRLE() {
        for (int i = 0; i < this.f24h; i++) {
            decodeNextScanline();
            if (this.bitPointer != 0) {
                this.bytePointer++;
                this.bitPointer = 0;
            }
            this.lineBitNum += this.bitsPerScanline;
        }
    }

    public void decodeNextScanline() {
        int[] iArr;
        int i;
        boolean isWhite = true;
        int bitOffset = 0;
        this.changingElemSize = 0;
        while (bitOffset < this.f25w) {
            int runOffset = bitOffset;
            while (isWhite && bitOffset < this.f25w) {
                int current = nextNBits(10);
                int entry = white[current];
                int isT = entry & 1;
                int bits = (entry >>> 1) & 15;
                if (bits == 12) {
                    entry = additionalMakeup[((current << 2) & 12) | nextLesserThan8Bits(2)];
                    bitOffset += (entry >>> 4) & 4095;
                    updatePointer(4 - ((entry >>> 1) & 7));
                } else if (bits == 0) {
                    this.fails++;
                } else if (bits == 15) {
                    this.fails++;
                    return;
                } else {
                    bitOffset += (entry >>> 5) & 2047;
                    updatePointer(10 - bits);
                    if (isT == 0) {
                        isWhite = false;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    }
                }
            }
            int runLength;
            if (bitOffset == this.f25w) {
                runLength = bitOffset - runOffset;
                if (isWhite && runLength != 0 && runLength % 64 == 0 && nextNBits(8) != 53) {
                    this.fails++;
                    updatePointer(8);
                }
            } else {
                runOffset = bitOffset;
                while (!isWhite && bitOffset < this.f25w) {
                    entry = initBlack[nextLesserThan8Bits(4)];
                    isT = entry & 1;
                    bits = (entry >>> 1) & 15;
                    int code = (entry >>> 5) & 2047;
                    if (code == 100) {
                        entry = black[nextNBits(9)];
                        isT = entry & 1;
                        bits = (entry >>> 1) & 15;
                        code = (entry >>> 5) & 2047;
                        if (bits == 12) {
                            updatePointer(5);
                            entry = additionalMakeup[nextLesserThan8Bits(4)];
                            bits = (entry >>> 1) & 7;
                            code = (entry >>> 4) & 4095;
                            setToBlack(bitOffset, code);
                            bitOffset += code;
                            updatePointer(4 - bits);
                        } else if (bits == 15) {
                            this.fails++;
                            return;
                        } else {
                            setToBlack(bitOffset, code);
                            bitOffset += code;
                            updatePointer(9 - bits);
                            if (isT == 0) {
                                isWhite = true;
                                iArr = this.currChangingElems;
                                i = this.changingElemSize;
                                this.changingElemSize = i + 1;
                                iArr[i] = bitOffset;
                            }
                        }
                    } else if (code == PdfContentParser.COMMAND_TYPE) {
                        entry = twoBitBlack[nextLesserThan8Bits(2)];
                        code = (entry >>> 5) & 2047;
                        bits = (entry >>> 1) & 15;
                        setToBlack(bitOffset, code);
                        bitOffset += code;
                        updatePointer(2 - bits);
                        isWhite = true;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    } else {
                        setToBlack(bitOffset, code);
                        bitOffset += code;
                        updatePointer(4 - bits);
                        isWhite = true;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    }
                }
                if (bitOffset == this.f25w) {
                    runLength = bitOffset - runOffset;
                    if (!(isWhite || runLength == 0 || runLength % 64 != 0 || nextNBits(10) == 55)) {
                        this.fails++;
                        updatePointer(10);
                    }
                }
            }
            iArr = this.currChangingElems;
            i = this.changingElemSize;
            this.changingElemSize = i + 1;
            iArr[i] = bitOffset;
        }
        iArr = this.currChangingElems;
        i = this.changingElemSize;
        this.changingElemSize = i + 1;
        iArr[i] = bitOffset;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void decodeT4() {
        /*
        r24 = this;
        r0 = r24;
        r14 = r0.f24h;
        r22 = 2;
        r0 = r22;
        r4 = new int[r0];
        r10 = 0;
        r0 = r24;
        r0 = r0.data;
        r22 = r0;
        r0 = r22;
        r0 = r0.length;
        r22 = r0;
        r23 = 2;
        r0 = r22;
        r1 = r23;
        if (r0 >= r1) goto L_0x0026;
    L_0x001e:
        r22 = new java.lang.RuntimeException;
        r23 = "Insufficient data to read initial EOL.";
        r22.<init>(r23);
        throw r22;
    L_0x0026:
        r22 = 12;
        r0 = r24;
        r1 = r22;
        r18 = r0.nextNBits(r1);
        r22 = 1;
        r0 = r18;
        r1 = r22;
        if (r0 == r1) goto L_0x0046;
    L_0x0038:
        r0 = r24;
        r0 = r0.fails;
        r22 = r0;
        r22 = r22 + 1;
        r0 = r22;
        r1 = r24;
        r1.fails = r0;
    L_0x0046:
        r22 = 12;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);
        r17 = 0;
        r16 = -1;
    L_0x0053:
        r22 = 1;
        r0 = r17;
        r1 = r22;
        if (r0 == r1) goto L_0x006b;
    L_0x005b:
        r17 = r24.findNextLine();	 Catch:{ Exception -> 0x0062 }
        r16 = r16 + 1;
        goto L_0x0053;
    L_0x0062:
        r13 = move-exception;
        r22 = new java.lang.RuntimeException;
        r23 = "No reference line present.";
        r22.<init>(r23);
        throw r22;
    L_0x006b:
        r24.decodeNextScanline();
        r16 = r16 + 1;
        r0 = r24;
        r0 = r0.lineBitNum;
        r22 = r0;
        r0 = r24;
        r0 = r0.bitsPerScanline;
        r23 = r0;
        r22 = r22 + r23;
        r0 = r22;
        r1 = r24;
        r1.lineBitNum = r0;
    L_0x0084:
        r0 = r16;
        if (r0 >= r14) goto L_0x0109;
    L_0x0088:
        r17 = r24.findNextLine();	 Catch:{ Exception -> 0x00fa }
        if (r17 != 0) goto L_0x01f5;
    L_0x008e:
        r0 = r24;
        r0 = r0.prevChangingElems;
        r21 = r0;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r0 = r22;
        r1 = r24;
        r1.prevChangingElems = r0;
        r0 = r21;
        r1 = r24;
        r1.currChangingElems = r0;
        r10 = 0;
        r2 = -1;
        r15 = 1;
        r7 = 0;
        r22 = 0;
        r0 = r22;
        r1 = r24;
        r1.lastChangingElement = r0;
    L_0x00b2:
        r0 = r24;
        r0 = r0.f25w;
        r22 = r0;
        r0 = r22;
        if (r7 >= r0) goto L_0x01ce;
    L_0x00bc:
        r0 = r24;
        r0.getNextChangingElement(r2, r15, r4);
        r22 = 0;
        r5 = r4[r22];
        r22 = 1;
        r6 = r4[r22];
        r22 = 7;
        r0 = r24;
        r1 = r22;
        r12 = r0.nextLesserThan8Bits(r1);
        r22 = twoDCodes;
        r22 = r22[r12];
        r0 = r22;
        r12 = r0 & 255;
        r22 = r12 & 120;
        r9 = r22 >>> 3;
        r8 = r12 & 7;
        if (r9 != 0) goto L_0x010a;
    L_0x00e3:
        if (r15 != 0) goto L_0x00ee;
    L_0x00e5:
        r22 = r6 - r7;
        r0 = r24;
        r1 = r22;
        r0.setToBlack(r7, r1);
    L_0x00ee:
        r2 = r6;
        r7 = r6;
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);
        goto L_0x00b2;
    L_0x00fa:
        r13 = move-exception;
        r0 = r24;
        r0 = r0.fails;
        r22 = r0;
        r22 = r22 + 1;
        r0 = r22;
        r1 = r24;
        r1.fails = r0;
    L_0x0109:
        return;
    L_0x010a:
        r22 = 1;
        r0 = r22;
        if (r9 != r0) goto L_0x016d;
    L_0x0110:
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);
        if (r15 == 0) goto L_0x0145;
    L_0x011b:
        r20 = r24.decodeWhiteCodeWord();
        r7 = r7 + r20;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r11 = r10 + 1;
        r22[r10] = r7;
        r20 = r24.decodeBlackCodeWord();
        r0 = r24;
        r1 = r20;
        r0.setToBlack(r7, r1);
        r7 = r7 + r20;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r10 = r11 + 1;
        r22[r11] = r7;
    L_0x0142:
        r2 = r7;
        goto L_0x00b2;
    L_0x0145:
        r20 = r24.decodeBlackCodeWord();
        r0 = r24;
        r1 = r20;
        r0.setToBlack(r7, r1);
        r7 = r7 + r20;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r11 = r10 + 1;
        r22[r10] = r7;
        r20 = r24.decodeWhiteCodeWord();
        r7 = r7 + r20;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r10 = r11 + 1;
        r22[r11] = r7;
        goto L_0x0142;
    L_0x016d:
        r22 = 8;
        r0 = r22;
        if (r9 > r0) goto L_0x019f;
    L_0x0173:
        r22 = r9 + -5;
        r3 = r5 + r22;
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r11 = r10 + 1;
        r22[r10] = r3;
        if (r15 != 0) goto L_0x018c;
    L_0x0183:
        r22 = r3 - r7;
        r0 = r24;
        r1 = r22;
        r0.setToBlack(r7, r1);
    L_0x018c:
        r2 = r3;
        r7 = r3;
        if (r15 != 0) goto L_0x019d;
    L_0x0190:
        r15 = 1;
    L_0x0191:
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);
        r10 = r11;
        goto L_0x00b2;
    L_0x019d:
        r15 = 0;
        goto L_0x0191;
    L_0x019f:
        r0 = r24;
        r0 = r0.fails;
        r22 = r0;
        r22 = r22 + 1;
        r0 = r22;
        r1 = r24;
        r1.fails = r0;
        r19 = 0;
    L_0x01af:
        r22 = 1;
        r0 = r17;
        r1 = r22;
        if (r0 == r1) goto L_0x01c1;
    L_0x01b7:
        r17 = r24.findNextLine();	 Catch:{ Exception -> 0x01be }
        r19 = r19 + 1;
        goto L_0x01af;
    L_0x01be:
        r13 = move-exception;
        goto L_0x0109;
    L_0x01c1:
        r22 = r19 + -1;
        r16 = r16 + r22;
        r22 = 13;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);
    L_0x01ce:
        r0 = r24;
        r0 = r0.currChangingElems;
        r22 = r0;
        r11 = r10 + 1;
        r22[r10] = r7;
        r0 = r24;
        r0.changingElemSize = r11;
        r10 = r11;
    L_0x01dd:
        r0 = r24;
        r0 = r0.lineBitNum;
        r22 = r0;
        r0 = r24;
        r0 = r0.bitsPerScanline;
        r23 = r0;
        r22 = r22 + r23;
        r0 = r22;
        r1 = r24;
        r1.lineBitNum = r0;
        r16 = r16 + 1;
        goto L_0x0084;
    L_0x01f5:
        r24.decodeNextScanline();
        goto L_0x01dd;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.TIFFFaxDecompressor.decodeT4():void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void decodeT6() {
        /*
        r24 = this;
        monitor-enter(r24);
        r0 = r24;
        r0 = r0.f24h;	 Catch:{ all -> 0x00cd }
        r16 = r0;
        r22 = 2;
        r0 = r22;
        r4 = new int[r0];	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r9 = r0.currChangingElems;	 Catch:{ all -> 0x00cd }
        r22 = 0;
        r0 = r22;
        r1 = r24;
        r1.changingElemSize = r0;	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.changingElemSize;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r23 = r22 + 1;
        r0 = r23;
        r1 = r24;
        r1.changingElemSize = r0;	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r23 = r0;
        r9[r22] = r23;	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.changingElemSize;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r23 = r22 + 1;
        r0 = r23;
        r1 = r24;
        r1.changingElemSize = r0;	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r23 = r0;
        r9[r22] = r23;	 Catch:{ all -> 0x00cd }
        r18 = 0;
    L_0x0047:
        r0 = r18;
        r1 = r16;
        if (r0 >= r1) goto L_0x023b;
    L_0x004d:
        r2 = -1;
        r17 = 1;
        r0 = r24;
        r0 = r0.prevChangingElems;	 Catch:{ all -> 0x00cd }
        r20 = r0;
        r0 = r24;
        r0 = r0.currChangingElems;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r22;
        r1 = r24;
        r1.prevChangingElems = r0;	 Catch:{ all -> 0x00cd }
        r0 = r20;
        r1 = r24;
        r1.currChangingElems = r0;	 Catch:{ all -> 0x00cd }
        r9 = r20;
        r11 = 0;
        r7 = 0;
        r22 = 0;
        r0 = r22;
        r1 = r24;
        r1.lastChangingElement = r0;	 Catch:{ all -> 0x00cd }
        r12 = r11;
    L_0x0075:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r22;
        if (r7 >= r0) goto L_0x0211;
    L_0x007f:
        r0 = r24;
        r1 = r17;
        r0.getNextChangingElement(r2, r1, r4);	 Catch:{ all -> 0x00cd }
        r22 = 0;
        r5 = r4[r22];	 Catch:{ all -> 0x00cd }
        r22 = 1;
        r6 = r4[r22];	 Catch:{ all -> 0x00cd }
        r22 = 7;
        r0 = r24;
        r1 = r22;
        r14 = r0.nextLesserThan8Bits(r1);	 Catch:{ all -> 0x00cd }
        r22 = twoDCodes;	 Catch:{ all -> 0x00cd }
        r22 = r22[r14];	 Catch:{ all -> 0x00cd }
        r0 = r22;
        r14 = r0 & 255;
        r22 = r14 & 120;
        r10 = r22 >>> 3;
        r8 = r14 & 7;
        if (r10 != 0) goto L_0x00d0;
    L_0x00a8:
        if (r17 != 0) goto L_0x00c1;
    L_0x00aa:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r22;
        if (r6 <= r0) goto L_0x00b8;
    L_0x00b4:
        r0 = r24;
        r6 = r0.f25w;	 Catch:{ all -> 0x00cd }
    L_0x00b8:
        r22 = r6 - r7;
        r0 = r24;
        r1 = r22;
        r0.setToBlack(r7, r1);	 Catch:{ all -> 0x00cd }
    L_0x00c1:
        r2 = r6;
        r7 = r6;
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);	 Catch:{ all -> 0x00cd }
        goto L_0x0075;
    L_0x00cd:
        r22 = move-exception;
        monitor-exit(r24);
        throw r22;
    L_0x00d0:
        r22 = 1;
        r0 = r22;
        if (r10 != r0) goto L_0x014a;
    L_0x00d6:
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);	 Catch:{ all -> 0x00cd }
        if (r17 == 0) goto L_0x0117;
    L_0x00e1:
        r19 = r24.decodeWhiteCodeWord();	 Catch:{ all -> 0x00cd }
        r7 = r7 + r19;
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
        r19 = r24.decodeBlackCodeWord();	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r22 = r22 - r7;
        r0 = r19;
        r1 = r22;
        if (r0 <= r1) goto L_0x0105;
    L_0x00fd:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r19 = r22 - r7;
    L_0x0105:
        r0 = r24;
        r1 = r19;
        r0.setToBlack(r7, r1);	 Catch:{ all -> 0x00cd }
        r7 = r7 + r19;
        r12 = r11 + 1;
        r9[r11] = r7;	 Catch:{ all -> 0x00cd }
        r11 = r12;
    L_0x0113:
        r2 = r7;
        r12 = r11;
        goto L_0x0075;
    L_0x0117:
        r19 = r24.decodeBlackCodeWord();	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r22 = r22 - r7;
        r0 = r19;
        r1 = r22;
        if (r0 <= r1) goto L_0x0131;
    L_0x0129:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r19 = r22 - r7;
    L_0x0131:
        r0 = r24;
        r1 = r19;
        r0.setToBlack(r7, r1);	 Catch:{ all -> 0x00cd }
        r7 = r7 + r19;
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
        r19 = r24.decodeWhiteCodeWord();	 Catch:{ all -> 0x00cd }
        r7 = r7 + r19;
        r12 = r11 + 1;
        r9[r11] = r7;	 Catch:{ all -> 0x00cd }
        r11 = r12;
        goto L_0x0113;
    L_0x014a:
        r22 = 8;
        r0 = r22;
        if (r10 > r0) goto L_0x0186;
    L_0x0150:
        r22 = r10 + -5;
        r3 = r5 + r22;
        r11 = r12 + 1;
        r9[r12] = r3;	 Catch:{ all -> 0x00cd }
        if (r17 != 0) goto L_0x0171;
    L_0x015a:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r22;
        if (r3 <= r0) goto L_0x0168;
    L_0x0164:
        r0 = r24;
        r3 = r0.f25w;	 Catch:{ all -> 0x00cd }
    L_0x0168:
        r22 = r3 - r7;
        r0 = r24;
        r1 = r22;
        r0.setToBlack(r7, r1);	 Catch:{ all -> 0x00cd }
    L_0x0171:
        r2 = r3;
        r7 = r3;
        if (r17 != 0) goto L_0x0183;
    L_0x0175:
        r17 = 1;
    L_0x0177:
        r22 = 7 - r8;
        r0 = r24;
        r1 = r22;
        r0.updatePointer(r1);	 Catch:{ all -> 0x00cd }
        r12 = r11;
        goto L_0x0075;
    L_0x0183:
        r17 = 0;
        goto L_0x0177;
    L_0x0186:
        r22 = 11;
        r0 = r22;
        if (r10 != r0) goto L_0x0075;
    L_0x018c:
        r22 = 3;
        r0 = r24;
        r1 = r22;
        r13 = r0.nextLesserThan8Bits(r1);	 Catch:{ all -> 0x00cd }
        r21 = 0;
        r15 = 0;
    L_0x0199:
        if (r15 != 0) goto L_0x0075;
    L_0x019b:
        r22 = 1;
        r0 = r24;
        r1 = r22;
        r22 = r0.nextLesserThan8Bits(r1);	 Catch:{ all -> 0x00cd }
        r23 = 1;
        r0 = r22;
        r1 = r23;
        if (r0 == r1) goto L_0x01b0;
    L_0x01ad:
        r21 = r21 + 1;
        goto L_0x019b;
    L_0x01b0:
        r22 = 5;
        r0 = r21;
        r1 = r22;
        if (r0 <= r1) goto L_0x01df;
    L_0x01b8:
        r21 = r21 + -6;
        if (r17 != 0) goto L_0x01c3;
    L_0x01bc:
        if (r21 <= 0) goto L_0x01c3;
    L_0x01be:
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
        r12 = r11;
    L_0x01c3:
        r7 = r7 + r21;
        if (r21 <= 0) goto L_0x01c9;
    L_0x01c7:
        r17 = 1;
    L_0x01c9:
        r22 = 1;
        r0 = r24;
        r1 = r22;
        r22 = r0.nextLesserThan8Bits(r1);	 Catch:{ all -> 0x00cd }
        if (r22 != 0) goto L_0x01f3;
    L_0x01d5:
        if (r17 != 0) goto L_0x0243;
    L_0x01d7:
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
    L_0x01db:
        r17 = 1;
    L_0x01dd:
        r15 = 1;
        r12 = r11;
    L_0x01df:
        r22 = 5;
        r0 = r21;
        r1 = r22;
        if (r0 != r1) goto L_0x01fc;
    L_0x01e7:
        if (r17 != 0) goto L_0x023f;
    L_0x01e9:
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
    L_0x01ed:
        r7 = r7 + r21;
        r17 = 1;
        r12 = r11;
        goto L_0x0199;
    L_0x01f3:
        if (r17 == 0) goto L_0x0241;
    L_0x01f5:
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
    L_0x01f9:
        r17 = 0;
        goto L_0x01dd;
    L_0x01fc:
        r7 = r7 + r21;
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
        r22 = 1;
        r0 = r24;
        r1 = r22;
        r0.setToBlack(r7, r1);	 Catch:{ all -> 0x00cd }
        r7 = r7 + 1;
        r17 = 0;
        r12 = r11;
        goto L_0x0199;
    L_0x0211:
        r0 = r24;
        r0 = r0.f25w;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r22;
        if (r12 > r0) goto L_0x023d;
    L_0x021b:
        r11 = r12 + 1;
        r9[r12] = r7;	 Catch:{ all -> 0x00cd }
    L_0x021f:
        r0 = r24;
        r0.changingElemSize = r11;	 Catch:{ all -> 0x00cd }
        r0 = r24;
        r0 = r0.lineBitNum;	 Catch:{ all -> 0x00cd }
        r22 = r0;
        r0 = r24;
        r0 = r0.bitsPerScanline;	 Catch:{ all -> 0x00cd }
        r23 = r0;
        r22 = r22 + r23;
        r0 = r22;
        r1 = r24;
        r1.lineBitNum = r0;	 Catch:{ all -> 0x00cd }
        r18 = r18 + 1;
        goto L_0x0047;
    L_0x023b:
        monitor-exit(r24);
        return;
    L_0x023d:
        r11 = r12;
        goto L_0x021f;
    L_0x023f:
        r11 = r12;
        goto L_0x01ed;
    L_0x0241:
        r11 = r12;
        goto L_0x01f9;
    L_0x0243:
        r11 = r12;
        goto L_0x01db;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.TIFFFaxDecompressor.decodeT6():void");
    }

    private void setToBlack(int bitNum, int numBits) {
        bitNum += this.lineBitNum;
        int lastBit = bitNum + numBits;
        int byteNum = bitNum >> 3;
        int shift = bitNum & 7;
        if (shift > 0) {
            int maskVal = 1 << (7 - shift);
            byte val = this.buffer[byteNum];
            while (maskVal > 0 && bitNum < lastBit) {
                val = (byte) (val | maskVal);
                maskVal >>= 1;
                bitNum++;
            }
            this.buffer[byteNum] = val;
        }
        int byteNum2 = bitNum >> 3;
        while (bitNum < lastBit - 7) {
            byteNum = byteNum2 + 1;
            this.buffer[byteNum2] = (byte) -1;
            bitNum += 8;
            byteNum2 = byteNum;
        }
        while (bitNum < lastBit) {
            byteNum = bitNum >> 3;
            byte[] bArr = this.buffer;
            bArr[byteNum] = (byte) (bArr[byteNum] | (1 << (7 - (bitNum & 7))));
            bitNum++;
        }
    }

    private int decodeWhiteCodeWord() {
        int runLength = 0;
        boolean isWhite = true;
        while (isWhite) {
            int current = nextNBits(10);
            int entry = white[current];
            int isT = entry & 1;
            int bits = (entry >>> 1) & 15;
            if (bits == 12) {
                entry = additionalMakeup[((current << 2) & 12) | nextLesserThan8Bits(2)];
                runLength += (entry >>> 4) & 4095;
                updatePointer(4 - ((entry >>> 1) & 7));
            } else if (bits == 0) {
                throw new RuntimeException("Error 0");
            } else if (bits == 15) {
                throw new RuntimeException("Error 1");
            } else {
                runLength += (entry >>> 5) & 2047;
                updatePointer(10 - bits);
                if (isT == 0) {
                    isWhite = false;
                }
            }
        }
        return runLength;
    }

    private int decodeBlackCodeWord() {
        int runLength = 0;
        boolean isWhite = false;
        while (!isWhite) {
            int entry = initBlack[nextLesserThan8Bits(4)];
            int isT = entry & 1;
            int bits = (entry >>> 1) & 15;
            int code = (entry >>> 5) & 2047;
            if (code == 100) {
                entry = black[nextNBits(9)];
                isT = entry & 1;
                bits = (entry >>> 1) & 15;
                code = (entry >>> 5) & 2047;
                if (bits == 12) {
                    updatePointer(5);
                    entry = additionalMakeup[nextLesserThan8Bits(4)];
                    runLength += (entry >>> 4) & 4095;
                    updatePointer(4 - ((entry >>> 1) & 7));
                } else if (bits == 15) {
                    throw new RuntimeException("Error 2");
                } else {
                    runLength += code;
                    updatePointer(9 - bits);
                    if (isT == 0) {
                        isWhite = true;
                    }
                }
            } else if (code == PdfContentParser.COMMAND_TYPE) {
                entry = twoBitBlack[nextLesserThan8Bits(2)];
                runLength += (entry >>> 5) & 2047;
                updatePointer(2 - ((entry >>> 1) & 15));
                isWhite = true;
            } else {
                runLength += code;
                updatePointer(4 - bits);
                isWhite = true;
            }
        }
        return runLength;
    }

    private int findNextLine() {
        int bitIndexMax = (this.data.length * 8) - 1;
        int bitIndexMax12 = bitIndexMax - 12;
        int bitIndex = (this.bytePointer * 8) + this.bitPointer;
        while (bitIndex <= bitIndexMax12) {
            int next12Bits = nextNBits(12);
            bitIndex += 12;
            while (next12Bits != 1 && bitIndex < bitIndexMax) {
                next12Bits = ((next12Bits & 2047) << 1) | (nextLesserThan8Bits(1) & 1);
                bitIndex++;
            }
            if (next12Bits == 1) {
                if (this.oneD != 1) {
                    return 1;
                }
                if (bitIndex < bitIndexMax) {
                    return nextLesserThan8Bits(1);
                }
            }
        }
        throw new RuntimeException();
    }

    private void getNextChangingElement(int a0, boolean isWhite, int[] ret) {
        int start;
        int[] pce = this.prevChangingElems;
        int ces = this.changingElemSize;
        if (this.lastChangingElement > 0) {
            start = this.lastChangingElement - 1;
        } else {
            start = 0;
        }
        if (isWhite) {
            start &= -2;
        } else {
            start |= 1;
        }
        int i = start;
        while (i < ces) {
            int temp = pce[i];
            if (temp > a0) {
                this.lastChangingElement = i;
                ret[0] = temp;
                break;
            }
            i += 2;
        }
        if (i + 1 < ces) {
            ret[1] = pce[i + 1];
        }
    }

    private int nextNBits(int bitsToGet) {
        byte b;
        byte next;
        byte next2next;
        int l = this.data.length - 1;
        int bp = this.bytePointer;
        if (this.fillOrder == 1) {
            b = this.data[bp];
            if (bp == l) {
                next = (byte) 0;
                next2next = (byte) 0;
            } else if (bp + 1 == l) {
                next = this.data[bp + 1];
                next2next = (byte) 0;
            } else {
                next = this.data[bp + 1];
                next2next = this.data[bp + 2];
            }
        } else if (this.fillOrder == 2) {
            b = flipTable[this.data[bp] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (bp == l) {
                next = (byte) 0;
                next2next = (byte) 0;
            } else if (bp + 1 == l) {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                next2next = (byte) 0;
            } else {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                next2next = flipTable[this.data[bp + 2] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
        } else {
            throw new RuntimeException("Invalid FillOrder");
        }
        int bitsLeft = 8 - this.bitPointer;
        int bitsFromNextByte = bitsToGet - bitsLeft;
        int bitsFromNext2NextByte = 0;
        if (bitsFromNextByte > 8) {
            bitsFromNext2NextByte = bitsFromNextByte - 8;
            bitsFromNextByte = 8;
        }
        this.bytePointer++;
        int i1 = (table1[bitsLeft] & b) << (bitsToGet - bitsLeft);
        int i2 = (table2[bitsFromNextByte] & next) >>> (8 - bitsFromNextByte);
        if (bitsFromNext2NextByte != 0) {
            i2 = (i2 << bitsFromNext2NextByte) | ((table2[bitsFromNext2NextByte] & next2next) >>> (8 - bitsFromNext2NextByte));
            this.bytePointer++;
            this.bitPointer = bitsFromNext2NextByte;
        } else if (bitsFromNextByte == 8) {
            this.bitPointer = 0;
            this.bytePointer++;
        } else {
            this.bitPointer = bitsFromNextByte;
        }
        return i1 | i2;
    }

    private int nextLesserThan8Bits(int bitsToGet) {
        byte b;
        byte next;
        int l = this.data.length - 1;
        int bp = this.bytePointer;
        if (this.fillOrder == 1) {
            b = this.data[bp];
            if (bp == l) {
                next = (byte) 0;
            } else {
                next = this.data[bp + 1];
            }
        } else if (this.fillOrder == 2) {
            b = flipTable[this.data[bp] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (bp == l) {
                next = (byte) 0;
            } else {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
        } else {
            throw new RuntimeException("Invalid FillOrder");
        }
        int bitsLeft = 8 - this.bitPointer;
        int bitsFromNextByte = bitsToGet - bitsLeft;
        int shift = bitsLeft - bitsToGet;
        int i1;
        if (shift >= 0) {
            i1 = (table1[bitsLeft] & b) >>> shift;
            this.bitPointer += bitsToGet;
            if (this.bitPointer != 8) {
                return i1;
            }
            this.bitPointer = 0;
            this.bytePointer++;
            return i1;
        }
        i1 = ((table1[bitsLeft] & b) << (-shift)) | ((table2[bitsFromNextByte] & next) >>> (8 - bitsFromNextByte));
        this.bytePointer++;
        this.bitPointer = bitsFromNextByte;
        return i1;
    }

    private void updatePointer(int bitsToMoveBack) {
        if (bitsToMoveBack > 8) {
            this.bytePointer -= bitsToMoveBack / 8;
            bitsToMoveBack %= 8;
        }
        int i = this.bitPointer - bitsToMoveBack;
        if (i < 0) {
            this.bytePointer--;
            this.bitPointer = i + 8;
            return;
        }
        this.bitPointer = i;
    }
}

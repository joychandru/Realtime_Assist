package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.wmf.MetaDo;

public class TIFFLZWDecoder {
    int[] andTable;
    int bitPointer;
    int bitsToGet;
    int bytePointer;
    byte[] data;
    int dstIndex;
    int f26h;
    int nextBits;
    int nextData;
    int predictor;
    int samplesPerPixel;
    byte[][] stringTable;
    int tableIndex;
    byte[] uncompData;
    int f27w;

    public TIFFLZWDecoder(int w, int predictor, int samplesPerPixel) {
        this.data = null;
        this.bitsToGet = 9;
        this.nextData = 0;
        this.nextBits = 0;
        this.andTable = new int[]{511, 1023, 2047, 4095};
        this.f27w = w;
        this.predictor = predictor;
        this.samplesPerPixel = samplesPerPixel;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public byte[] decode(byte[] r11, byte[] r12, int r13) {
        /*
        r10 = this;
        r9 = 257; // 0x101 float:3.6E-43 double:1.27E-321;
        r7 = 1;
        r8 = 0;
        r6 = r11[r8];
        if (r6 != 0) goto L_0x001a;
    L_0x0008:
        r6 = r11[r7];
        if (r6 != r7) goto L_0x001a;
    L_0x000c:
        r6 = new java.lang.UnsupportedOperationException;
        r7 = "tiff.5.0.style.lzw.codes.are.not.supported";
        r8 = new java.lang.Object[r8];
        r7 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r7, r8);
        r6.<init>(r7);
        throw r6;
    L_0x001a:
        r10.initializeStringTable();
        r10.data = r11;
        r10.f26h = r13;
        r10.uncompData = r12;
        r10.bytePointer = r8;
        r10.bitPointer = r8;
        r10.dstIndex = r8;
        r10.nextData = r8;
        r10.nextBits = r8;
        r4 = 0;
    L_0x002e:
        r0 = r10.getNextCode();
        if (r0 == r9) goto L_0x0046;
    L_0x0034:
        r6 = r10.dstIndex;
        r7 = r12.length;
        if (r6 >= r7) goto L_0x0046;
    L_0x0039:
        r6 = 256; // 0x100 float:3.59E-43 double:1.265E-321;
        if (r0 != r6) goto L_0x007a;
    L_0x003d:
        r10.initializeStringTable();
        r0 = r10.getNextCode();
        if (r0 != r9) goto L_0x0071;
    L_0x0046:
        r6 = r10.predictor;
        r7 = 2;
        if (r6 != r7) goto L_0x00a5;
    L_0x004b:
        r3 = 0;
    L_0x004c:
        if (r3 >= r13) goto L_0x00a5;
    L_0x004e:
        r6 = r10.samplesPerPixel;
        r7 = r10.f27w;
        r7 = r7 * r3;
        r7 = r7 + 1;
        r1 = r6 * r7;
        r2 = r10.samplesPerPixel;
    L_0x0059:
        r6 = r10.f27w;
        r7 = r10.samplesPerPixel;
        r6 = r6 * r7;
        if (r2 >= r6) goto L_0x00a2;
    L_0x0060:
        r6 = r12[r1];
        r7 = r10.samplesPerPixel;
        r7 = r1 - r7;
        r7 = r12[r7];
        r6 = r6 + r7;
        r6 = (byte) r6;
        r12[r1] = r6;
        r1 = r1 + 1;
        r2 = r2 + 1;
        goto L_0x0059;
    L_0x0071:
        r6 = r10.stringTable;
        r6 = r6[r0];
        r10.writeString(r6);
        r4 = r0;
        goto L_0x002e;
    L_0x007a:
        r6 = r10.tableIndex;
        if (r0 >= r6) goto L_0x0090;
    L_0x007e:
        r6 = r10.stringTable;
        r5 = r6[r0];
        r10.writeString(r5);
        r6 = r10.stringTable;
        r6 = r6[r4];
        r7 = r5[r8];
        r10.addStringToTable(r6, r7);
        r4 = r0;
        goto L_0x002e;
    L_0x0090:
        r6 = r10.stringTable;
        r5 = r6[r4];
        r6 = r5[r8];
        r5 = r10.composeString(r5, r6);
        r10.writeString(r5);
        r10.addStringToTable(r5);
        r4 = r0;
        goto L_0x002e;
    L_0x00a2:
        r3 = r3 + 1;
        goto L_0x004c;
    L_0x00a5:
        return r12;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.TIFFLZWDecoder.decode(byte[], byte[], int):byte[]");
    }

    public void initializeStringTable() {
        this.stringTable = new byte[PdfWriter.HideToolbar][];
        for (int i = 0; i < PdfWriter.PageModeUseThumbs; i++) {
            this.stringTable[i] = new byte[1];
            this.stringTable[i][0] = (byte) i;
        }
        this.tableIndex = MetaDo.META_SETBKMODE;
        this.bitsToGet = 9;
    }

    public void writeString(byte[] string) {
        int max = this.uncompData.length - this.dstIndex;
        if (string.length < max) {
            max = string.length;
        }
        System.arraycopy(string, 0, this.uncompData, this.dstIndex, max);
        this.dstIndex += max;
    }

    public void addStringToTable(byte[] oldString, byte newString) {
        int length = oldString.length;
        byte[] string = new byte[(length + 1)];
        System.arraycopy(oldString, 0, string, 0, length);
        string[length] = newString;
        byte[][] bArr = this.stringTable;
        int i = this.tableIndex;
        this.tableIndex = i + 1;
        bArr[i] = string;
        if (this.tableIndex == 511) {
            this.bitsToGet = 10;
        } else if (this.tableIndex == 1023) {
            this.bitsToGet = 11;
        } else if (this.tableIndex == 2047) {
            this.bitsToGet = 12;
        }
    }

    public void addStringToTable(byte[] string) {
        byte[][] bArr = this.stringTable;
        int i = this.tableIndex;
        this.tableIndex = i + 1;
        bArr[i] = string;
        if (this.tableIndex == 511) {
            this.bitsToGet = 10;
        } else if (this.tableIndex == 1023) {
            this.bitsToGet = 11;
        } else if (this.tableIndex == 2047) {
            this.bitsToGet = 12;
        }
    }

    public byte[] composeString(byte[] oldString, byte newString) {
        int length = oldString.length;
        byte[] string = new byte[(length + 1)];
        System.arraycopy(oldString, 0, string, 0, length);
        string[length] = newString;
        return string;
    }

    public int getNextCode() {
        try {
            int i = this.nextData << 8;
            byte[] bArr = this.data;
            int i2 = this.bytePointer;
            this.bytePointer = i2 + 1;
            this.nextData = i | (bArr[i2] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
            this.nextBits += 8;
            if (this.nextBits < this.bitsToGet) {
                i = this.nextData << 8;
                bArr = this.data;
                i2 = this.bytePointer;
                this.bytePointer = i2 + 1;
                this.nextData = i | (bArr[i2] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
                this.nextBits += 8;
            }
            int code = (this.nextData >> (this.nextBits - this.bitsToGet)) & this.andTable[this.bitsToGet - 9];
            this.nextBits -= this.bitsToGet;
            return code;
        } catch (ArrayIndexOutOfBoundsException e) {
            return TIFFConstants.TIFFTAG_IMAGELENGTH;
        }
    }
}

package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.ImgRaw;
import com.itextpdf.text.Utilities;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.BaseField;
import com.itextpdf.text.pdf.ICC_Profile;
import com.itextpdf.text.pdf.PdfArray;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfLiteral;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

public class PngImage {
    public static final String IDAT = "IDAT";
    public static final String IEND = "IEND";
    public static final String IHDR = "IHDR";
    public static final String PLTE = "PLTE";
    public static final int[] PNGID;
    private static final int PNG_FILTER_AVERAGE = 3;
    private static final int PNG_FILTER_NONE = 0;
    private static final int PNG_FILTER_PAETH = 4;
    private static final int PNG_FILTER_SUB = 1;
    private static final int PNG_FILTER_UP = 2;
    private static final int TRANSFERSIZE = 4096;
    public static final String cHRM = "cHRM";
    public static final String gAMA = "gAMA";
    public static final String iCCP = "iCCP";
    private static final PdfName[] intents;
    public static final String pHYs = "pHYs";
    public static final String sRGB = "sRGB";
    public static final String tRNS = "tRNS";
    float XYRatio;
    PdfDictionary additional;
    int bitDepth;
    int bytesPerPixel;
    byte[] colorTable;
    int colorType;
    int compressionMethod;
    DataInputStream dataStream;
    int dpiX;
    int dpiY;
    int filterMethod;
    float gamma;
    boolean genBWMask;
    boolean hasCHRM;
    int height;
    ICC_Profile icc_profile;
    NewByteArrayOutputStream idat;
    byte[] image;
    int inputBands;
    PdfName intent;
    int interlaceMethod;
    InputStream is;
    boolean palShades;
    byte[] smask;
    byte[] trans;
    int transBlue;
    int transGreen;
    int transRedGray;
    int width;
    float xB;
    float xG;
    float xR;
    float xW;
    float yB;
    float yG;
    float yR;
    float yW;

    static class NewByteArrayOutputStream extends ByteArrayOutputStream {
        NewByteArrayOutputStream() {
        }

        public byte[] getBuf() {
            return this.buf;
        }
    }

    static {
        PNGID = new int[]{137, 80, 78, 71, 13, 10, 26, 10};
        PdfName[] pdfNameArr = new PdfName[PNG_FILTER_PAETH];
        pdfNameArr[PNG_FILTER_NONE] = PdfName.PERCEPTUAL;
        pdfNameArr[PNG_FILTER_SUB] = PdfName.RELATIVECOLORIMETRIC;
        pdfNameArr[PNG_FILTER_UP] = PdfName.SATURATION;
        pdfNameArr[PNG_FILTER_AVERAGE] = PdfName.ABSOLUTECOLORIMETRIC;
        intents = pdfNameArr;
    }

    PngImage(InputStream is) {
        this.additional = new PdfDictionary();
        this.idat = new NewByteArrayOutputStream();
        this.transRedGray = -1;
        this.transGreen = -1;
        this.transBlue = -1;
        this.gamma = BaseField.BORDER_WIDTH_THIN;
        this.hasCHRM = false;
        this.is = is;
    }

    public static Image getImage(URL url) throws IOException {
        InputStream inputStream = null;
        try {
            inputStream = url.openStream();
            Image img = getImage(inputStream);
            img.setUrl(url);
            return img;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    public static Image getImage(InputStream is) throws IOException {
        return new PngImage(is).getImage();
    }

    public static Image getImage(String file) throws IOException {
        return getImage(Utilities.toURL(file));
    }

    public static Image getImage(byte[] data) throws IOException {
        Image img = getImage(new ByteArrayInputStream(data));
        img.setOriginalData(data);
        return img;
    }

    boolean checkMarker(String s) {
        if (s.length() != PNG_FILTER_PAETH) {
            return false;
        }
        for (int k = PNG_FILTER_NONE; k < PNG_FILTER_PAETH; k += PNG_FILTER_SUB) {
            char c = s.charAt(k);
            if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void readPng() throws java.io.IOException {
        /*
        r31 = this;
        r13 = 0;
    L_0x0001:
        r26 = PNGID;
        r0 = r26;
        r0 = r0.length;
        r26 = r0;
        r0 = r26;
        if (r13 >= r0) goto L_0x0037;
    L_0x000c:
        r26 = PNGID;
        r26 = r26[r13];
        r0 = r31;
        r0 = r0.is;
        r27 = r0;
        r27 = r27.read();
        r0 = r26;
        r1 = r27;
        if (r0 == r1) goto L_0x0034;
    L_0x0020:
        r26 = new java.io.IOException;
        r27 = "file.is.not.a.valid.png";
        r28 = 0;
        r0 = r28;
        r0 = new java.lang.Object[r0];
        r28 = r0;
        r27 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r27, r28);
        r26.<init>(r27);
        throw r26;
    L_0x0034:
        r13 = r13 + 1;
        goto L_0x0001;
    L_0x0037:
        r26 = 4096; // 0x1000 float:5.74E-42 double:2.0237E-320;
        r0 = r26;
        r4 = new byte[r0];
    L_0x003d:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r17 = getInt(r26);
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r19 = getString(r26);
        if (r17 < 0) goto L_0x005d;
    L_0x0053:
        r0 = r31;
        r1 = r19;
        r26 = r0.checkMarker(r1);
        if (r26 != 0) goto L_0x0071;
    L_0x005d:
        r26 = new java.io.IOException;
        r27 = "corrupted.png.file";
        r28 = 0;
        r0 = r28;
        r0 = new java.lang.Object[r0];
        r28 = r0;
        r27 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r27, r28);
        r26.<init>(r27);
        throw r26;
    L_0x0071:
        r26 = "IDAT";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x00b2;
    L_0x007d:
        if (r17 == 0) goto L_0x00d4;
    L_0x007f:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r27 = 0;
        r28 = 4096; // 0x1000 float:5.74E-42 double:2.0237E-320;
        r0 = r17;
        r1 = r28;
        r28 = java.lang.Math.min(r0, r1);
        r0 = r26;
        r1 = r27;
        r2 = r28;
        r24 = r0.read(r4, r1, r2);
        if (r24 >= 0) goto L_0x009e;
    L_0x009d:
        return;
    L_0x009e:
        r0 = r31;
        r0 = r0.idat;
        r26 = r0;
        r27 = 0;
        r0 = r26;
        r1 = r27;
        r2 = r24;
        r0.write(r4, r1, r2);
        r17 = r17 - r24;
        goto L_0x007d;
    L_0x00b2:
        r26 = "tRNS";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x0227;
    L_0x00be:
        r0 = r31;
        r0 = r0.colorType;
        r26 = r0;
        switch(r26) {
            case 0: goto L_0x00e1;
            case 1: goto L_0x00c7;
            case 2: goto L_0x0140;
            case 3: goto L_0x01f3;
            default: goto L_0x00c7;
        };
    L_0x00c7:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r0 = r26;
        r1 = r17;
        com.itextpdf.text.Utilities.skip(r0, r1);
    L_0x00d4:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r27 = 4;
        com.itextpdf.text.Utilities.skip(r26, r27);
        goto L_0x003d;
    L_0x00e1:
        r26 = 2;
        r0 = r17;
        r1 = r26;
        if (r0 < r1) goto L_0x00c7;
    L_0x00e9:
        r17 = r17 + -2;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r11 = getWord(r26);
        r0 = r31;
        r0 = r0.bitDepth;
        r26 = r0;
        r27 = 16;
        r0 = r26;
        r1 = r27;
        if (r0 != r1) goto L_0x0108;
    L_0x0103:
        r0 = r31;
        r0.transRedGray = r11;
        goto L_0x00c7;
    L_0x0108:
        r0 = r31;
        r0 = r0.additional;
        r26 = r0;
        r27 = com.itextpdf.text.pdf.PdfName.MASK;
        r28 = new com.itextpdf.text.pdf.PdfLiteral;
        r29 = new java.lang.StringBuilder;
        r29.<init>();
        r30 = "[";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r11);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r11);
        r30 = "]";
        r29 = r29.append(r30);
        r29 = r29.toString();
        r28.<init>(r29);
        r26.put(r27, r28);
        goto L_0x00c7;
    L_0x0140:
        r26 = 6;
        r0 = r17;
        r1 = r26;
        if (r0 < r1) goto L_0x00c7;
    L_0x0148:
        r17 = r17 + -6;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r22 = getWord(r26);
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r12 = getWord(r26);
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r3 = getWord(r26);
        r0 = r31;
        r0 = r0.bitDepth;
        r26 = r0;
        r27 = 16;
        r0 = r26;
        r1 = r27;
        if (r0 != r1) goto L_0x0186;
    L_0x0176:
        r0 = r22;
        r1 = r31;
        r1.transRedGray = r0;
        r0 = r31;
        r0.transGreen = r12;
        r0 = r31;
        r0.transBlue = r3;
        goto L_0x00c7;
    L_0x0186:
        r0 = r31;
        r0 = r0.additional;
        r26 = r0;
        r27 = com.itextpdf.text.pdf.PdfName.MASK;
        r28 = new com.itextpdf.text.pdf.PdfLiteral;
        r29 = new java.lang.StringBuilder;
        r29.<init>();
        r30 = "[";
        r29 = r29.append(r30);
        r0 = r29;
        r1 = r22;
        r29 = r0.append(r1);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r1 = r22;
        r29 = r0.append(r1);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r12);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r12);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r3);
        r30 = " ";
        r29 = r29.append(r30);
        r0 = r29;
        r29 = r0.append(r3);
        r30 = "]";
        r29 = r29.append(r30);
        r29 = r29.toString();
        r28.<init>(r29);
        r26.put(r27, r28);
        goto L_0x00c7;
    L_0x01f3:
        if (r17 <= 0) goto L_0x00c7;
    L_0x01f5:
        r0 = r17;
        r0 = new byte[r0];
        r26 = r0;
        r0 = r26;
        r1 = r31;
        r1.trans = r0;
        r16 = 0;
    L_0x0203:
        r0 = r16;
        r1 = r17;
        if (r0 >= r1) goto L_0x0223;
    L_0x0209:
        r0 = r31;
        r0 = r0.trans;
        r26 = r0;
        r0 = r31;
        r0 = r0.is;
        r27 = r0;
        r27 = r27.read();
        r0 = r27;
        r0 = (byte) r0;
        r27 = r0;
        r26[r16] = r27;
        r16 = r16 + 1;
        goto L_0x0203;
    L_0x0223:
        r17 = 0;
        goto L_0x00c7;
    L_0x0227:
        r26 = "IHDR";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x02a5;
    L_0x0233:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r1 = r31;
        r1.width = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r1 = r31;
        r1.height = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r1 = r31;
        r1.bitDepth = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r1 = r31;
        r1.colorType = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r1 = r31;
        r1.compressionMethod = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r1 = r31;
        r1.filterMethod = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r1 = r31;
        r1.interlaceMethod = r0;
        goto L_0x00d4;
    L_0x02a5:
        r26 = "PLTE";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x0333;
    L_0x02b1:
        r0 = r31;
        r0 = r0.colorType;
        r26 = r0;
        r27 = 3;
        r0 = r26;
        r1 = r27;
        if (r0 != r1) goto L_0x0324;
    L_0x02bf:
        r5 = new com.itextpdf.text.pdf.PdfArray;
        r5.<init>();
        r26 = com.itextpdf.text.pdf.PdfName.INDEXED;
        r0 = r26;
        r5.add(r0);
        r26 = r31.getColorspace();
        r0 = r26;
        r5.add(r0);
        r26 = new com.itextpdf.text.pdf.PdfNumber;
        r27 = r17 / 3;
        r27 = r27 + -1;
        r26.<init>(r27);
        r0 = r26;
        r5.add(r0);
        r6 = new com.itextpdf.text.pdf.ByteBuffer;
        r6.<init>();
        r18 = r17;
    L_0x02e9:
        r17 = r18 + -1;
        if (r18 <= 0) goto L_0x02ff;
    L_0x02ed:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        r0 = r26;
        r6.append_i(r0);
        r18 = r17;
        goto L_0x02e9;
    L_0x02ff:
        r26 = new com.itextpdf.text.pdf.PdfString;
        r27 = r6.toByteArray();
        r0 = r27;
        r1 = r31;
        r1.colorTable = r0;
        r26.<init>(r27);
        r0 = r26;
        r5.add(r0);
        r0 = r31;
        r0 = r0.additional;
        r26 = r0;
        r27 = com.itextpdf.text.pdf.PdfName.COLORSPACE;
        r0 = r26;
        r1 = r27;
        r0.put(r1, r5);
        goto L_0x00d4;
    L_0x0324:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r0 = r26;
        r1 = r17;
        com.itextpdf.text.Utilities.skip(r0, r1);
        goto L_0x00d4;
    L_0x0333:
        r26 = "pHYs";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x03a7;
    L_0x033f:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r7 = getInt(r26);
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r8 = getInt(r26);
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r25 = r26.read();
        r26 = 1;
        r0 = r25;
        r1 = r26;
        if (r0 != r1) goto L_0x0395;
    L_0x0365:
        r0 = (float) r7;
        r26 = r0;
        r27 = 1020269481; // 0x3cd013a9 float:0.0254 double:5.040801E-315;
        r26 = r26 * r27;
        r27 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r26 = r26 + r27;
        r0 = r26;
        r0 = (int) r0;
        r26 = r0;
        r0 = r26;
        r1 = r31;
        r1.dpiX = r0;
        r0 = (float) r8;
        r26 = r0;
        r27 = 1020269481; // 0x3cd013a9 float:0.0254 double:5.040801E-315;
        r26 = r26 * r27;
        r27 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r26 = r26 + r27;
        r0 = r26;
        r0 = (int) r0;
        r26 = r0;
        r0 = r26;
        r1 = r31;
        r1.dpiY = r0;
        goto L_0x00d4;
    L_0x0395:
        if (r8 == 0) goto L_0x00d4;
    L_0x0397:
        r0 = (float) r7;
        r26 = r0;
        r0 = (float) r8;
        r27 = r0;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.XYRatio = r0;
        goto L_0x00d4;
    L_0x03a7:
        r26 = "cHRM";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x0518;
    L_0x03b3:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.xW = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.yW = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.xR = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.yR = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.xG = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.yG = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.xB = r0;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = getInt(r26);
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.yB = r0;
        r0 = r31;
        r0 = r0.xW;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x0494:
        r0 = r31;
        r0 = r0.yW;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04a5:
        r0 = r31;
        r0 = r0.xR;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04b6:
        r0 = r31;
        r0 = r0.yR;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04c7:
        r0 = r31;
        r0 = r0.xG;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04d8:
        r0 = r31;
        r0 = r0.yG;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04e9:
        r0 = r31;
        r0 = r0.xB;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x04fa:
        r0 = r31;
        r0 = r0.yB;
        r26 = r0;
        r26 = java.lang.Math.abs(r26);
        r27 = 953267991; // 0x38d1b717 float:1.0E-4 double:4.709769656E-315;
        r26 = (r26 > r27 ? 1 : (r26 == r27 ? 0 : -1));
        if (r26 < 0) goto L_0x0515;
    L_0x050b:
        r26 = 1;
    L_0x050d:
        r0 = r26;
        r1 = r31;
        r1.hasCHRM = r0;
        goto L_0x00d4;
    L_0x0515:
        r26 = 0;
        goto L_0x050d;
    L_0x0518:
        r26 = "sRGB";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x0593;
    L_0x0524:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r23 = r26.read();
        r26 = intents;
        r26 = r26[r23];
        r0 = r26;
        r1 = r31;
        r1.intent = r0;
        r26 = 1074580685; // 0x400ccccd float:2.2 double:5.309134E-315;
        r0 = r26;
        r1 = r31;
        r1.gamma = r0;
        r26 = 1050679863; // 0x3ea01a37 float:0.3127 double:5.19104825E-315;
        r0 = r26;
        r1 = r31;
        r1.xW = r0;
        r26 = 1051226800; // 0x3ea872b0 float:0.329 double:5.19375048E-315;
        r0 = r26;
        r1 = r31;
        r1.yW = r0;
        r26 = 1059313418; // 0x3f23d70a float:0.64 double:5.23370368E-315;
        r0 = r26;
        r1 = r31;
        r1.xR = r0;
        r26 = 1051260355; // 0x3ea8f5c3 float:0.33 double:5.19391626E-315;
        r0 = r26;
        r1 = r31;
        r1.yR = r0;
        r26 = 1050253722; // 0x3e99999a float:0.3 double:5.188942835E-315;
        r0 = r26;
        r1 = r31;
        r1.xG = r0;
        r26 = 1058642330; // 0x3f19999a float:0.6 double:5.230388065E-315;
        r0 = r26;
        r1 = r31;
        r1.yG = r0;
        r26 = 1041865114; // 0x3e19999a float:0.15 double:5.147497604E-315;
        r0 = r26;
        r1 = r31;
        r1.xB = r0;
        r26 = 1031127695; // 0x3d75c28f float:0.06 double:5.094447706E-315;
        r0 = r26;
        r1 = r31;
        r1.yB = r0;
        r26 = 1;
        r0 = r26;
        r1 = r31;
        r1.hasCHRM = r0;
        goto L_0x00d4;
    L_0x0593:
        r26 = "gAMA";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x0613;
    L_0x059f:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r10 = getInt(r26);
        if (r10 == 0) goto L_0x00d4;
    L_0x05ab:
        r26 = 1203982336; // 0x47c35000 float:100000.0 double:5.948463104E-315;
        r0 = (float) r10;
        r27 = r0;
        r26 = r26 / r27;
        r0 = r26;
        r1 = r31;
        r1.gamma = r0;
        r0 = r31;
        r0 = r0.hasCHRM;
        r26 = r0;
        if (r26 != 0) goto L_0x00d4;
    L_0x05c1:
        r26 = 1050679863; // 0x3ea01a37 float:0.3127 double:5.19104825E-315;
        r0 = r26;
        r1 = r31;
        r1.xW = r0;
        r26 = 1051226800; // 0x3ea872b0 float:0.329 double:5.19375048E-315;
        r0 = r26;
        r1 = r31;
        r1.yW = r0;
        r26 = 1059313418; // 0x3f23d70a float:0.64 double:5.23370368E-315;
        r0 = r26;
        r1 = r31;
        r1.xR = r0;
        r26 = 1051260355; // 0x3ea8f5c3 float:0.33 double:5.19391626E-315;
        r0 = r26;
        r1 = r31;
        r1.yR = r0;
        r26 = 1050253722; // 0x3e99999a float:0.3 double:5.188942835E-315;
        r0 = r26;
        r1 = r31;
        r1.xG = r0;
        r26 = 1058642330; // 0x3f19999a float:0.6 double:5.230388065E-315;
        r0 = r26;
        r1 = r31;
        r1.yG = r0;
        r26 = 1041865114; // 0x3e19999a float:0.15 double:5.147497604E-315;
        r0 = r26;
        r1 = r31;
        r1.xB = r0;
        r26 = 1031127695; // 0x3d75c28f float:0.06 double:5.094447706E-315;
        r0 = r26;
        r1 = r31;
        r1.yB = r0;
        r26 = 1;
        r0 = r26;
        r1 = r31;
        r1.hasCHRM = r0;
        goto L_0x00d4;
    L_0x0613:
        r26 = "iCCP";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 == 0) goto L_0x068b;
    L_0x061f:
        r17 = r17 + -1;
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26 = r26.read();
        if (r26 != 0) goto L_0x061f;
    L_0x062d:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r26.read();
        r17 = r17 + -1;
        r0 = r17;
        r14 = new byte[r0];
        r20 = 0;
    L_0x063e:
        if (r17 <= 0) goto L_0x066b;
    L_0x0640:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r0 = r26;
        r1 = r20;
        r2 = r17;
        r21 = r0.read(r14, r1, r2);
        if (r21 >= 0) goto L_0x0666;
    L_0x0652:
        r26 = new java.io.IOException;
        r27 = "premature.end.of.file";
        r28 = 0;
        r0 = r28;
        r0 = new java.lang.Object[r0];
        r28 = r0;
        r27 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r27, r28);
        r26.<init>(r27);
        throw r26;
    L_0x0666:
        r20 = r20 + r21;
        r17 = r17 - r21;
        goto L_0x063e;
    L_0x066b:
        r26 = 1;
        r0 = r26;
        r15 = com.itextpdf.text.pdf.PdfReader.FlateDecode(r14, r0);
        r14 = 0;
        r26 = com.itextpdf.text.pdf.ICC_Profile.getInstance(r15);	 Catch:{ RuntimeException -> 0x0680 }
        r0 = r26;
        r1 = r31;
        r1.icc_profile = r0;	 Catch:{ RuntimeException -> 0x0680 }
        goto L_0x00d4;
    L_0x0680:
        r9 = move-exception;
        r26 = 0;
        r0 = r26;
        r1 = r31;
        r1.icc_profile = r0;
        goto L_0x00d4;
    L_0x068b:
        r26 = "IEND";
        r0 = r26;
        r1 = r19;
        r26 = r0.equals(r1);
        if (r26 != 0) goto L_0x009d;
    L_0x0697:
        r0 = r31;
        r0 = r0.is;
        r26 = r0;
        r0 = r26;
        r1 = r17;
        com.itextpdf.text.Utilities.skip(r0, r1);
        goto L_0x00d4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.PngImage.readPng():void");
    }

    PdfObject getColorspace() {
        if (this.icc_profile != null) {
            if ((this.colorType & PNG_FILTER_UP) == 0) {
                return PdfName.DEVICEGRAY;
            }
            return PdfName.DEVICERGB;
        }
        if (this.gamma != BaseField.BORDER_WIDTH_THIN || this.hasCHRM) {
            PdfObject array = new PdfArray();
            PdfObject dic = new PdfDictionary();
            if ((this.colorType & PNG_FILTER_UP) == 0) {
                if (this.gamma == BaseField.BORDER_WIDTH_THIN) {
                    return PdfName.DEVICEGRAY;
                }
                array.add(PdfName.CALGRAY);
                dic.put(PdfName.GAMMA, new PdfNumber(this.gamma));
                dic.put(PdfName.WHITEPOINT, new PdfLiteral("[1 1 1]"));
                array.add(dic);
                return array;
            }
            PdfObject wp;
            PdfObject pdfLiteral = new PdfLiteral("[1 1 1]");
            array.add(PdfName.CALRGB);
            if (this.gamma != BaseField.BORDER_WIDTH_THIN) {
                PdfObject gm = new PdfArray();
                pdfLiteral = new PdfNumber(this.gamma);
                gm.add(pdfLiteral);
                gm.add(pdfLiteral);
                gm.add(pdfLiteral);
                dic.put(PdfName.GAMMA, gm);
            }
            if (this.hasCHRM) {
                float f = this.yW;
                float f2 = this.xG;
                float f3 = this.xB;
                f3 = this.yR;
                f3 = this.xR;
                float f4 = this.xB;
                f4 = this.yG;
                f3 = this.xR;
                f4 = this.xG;
                float z = r0 * ((((r0 - r0) * r0) - ((r0 - r0) * r0)) + ((r0 - r0) * this.yB));
                f = this.yR;
                f2 = this.xG;
                f3 = this.xB;
                f3 = this.yW;
                f3 = this.xW;
                f4 = this.xB;
                f4 = this.yG;
                f3 = this.xW;
                f4 = this.xG;
                float YA = (r0 * ((((r0 - r0) * r0) - ((r0 - r0) * r0)) + ((r0 - r0) * this.yB))) / z;
                f = this.xR;
                float XA = (r0 * YA) / this.yR;
                f2 = this.xR;
                float ZA = YA * (((BaseField.BORDER_WIDTH_THIN - r0) / this.yR) - BaseField.BORDER_WIDTH_THIN);
                f = -this.yG;
                f2 = this.xR;
                f3 = this.xB;
                f3 = this.yW;
                f3 = this.xW;
                f4 = this.xB;
                f4 = this.yR;
                f3 = this.xW;
                f4 = this.xR;
                float YB = (r0 * ((((r0 - r0) * r0) - ((r0 - r0) * r0)) + ((r0 - r0) * this.yB))) / z;
                f = this.xG;
                float XB = (r0 * YB) / this.yG;
                f2 = this.xG;
                float ZB = YB * (((BaseField.BORDER_WIDTH_THIN - r0) / this.yG) - BaseField.BORDER_WIDTH_THIN);
                f = this.yB;
                f2 = this.xR;
                f3 = this.xG;
                f3 = this.yW;
                f3 = this.xW;
                f4 = this.xG;
                f4 = this.yW;
                f3 = this.xW;
                f4 = this.xR;
                float YC = (r0 * ((((r0 - r0) * r0) - ((r0 - r0) * r0)) + ((r0 - r0) * this.yG))) / z;
                f = this.xB;
                float XC = (r0 * YC) / this.yB;
                f2 = this.xB;
                float ZC = YC * (((BaseField.BORDER_WIDTH_THIN - r0) / this.yB) - BaseField.BORDER_WIDTH_THIN);
                float XW = (XA + XB) + XC;
                float ZW = (ZA + ZB) + ZC;
                PdfObject wpa = new PdfArray();
                wpa.add(new PdfNumber(XW));
                wpa.add(new PdfNumber((float) BaseField.BORDER_WIDTH_THIN));
                wpa.add(new PdfNumber(ZW));
                wp = wpa;
                PdfObject matrix = new PdfArray();
                matrix.add(new PdfNumber(XA));
                matrix.add(new PdfNumber(YA));
                matrix.add(new PdfNumber(ZA));
                matrix.add(new PdfNumber(XB));
                matrix.add(new PdfNumber(YB));
                matrix.add(new PdfNumber(ZB));
                matrix.add(new PdfNumber(XC));
                matrix.add(new PdfNumber(YC));
                matrix.add(new PdfNumber(ZC));
                dic.put(PdfName.MATRIX, matrix);
            }
            dic.put(PdfName.WHITEPOINT, wp);
            array.add(dic);
            return array;
        }
        if ((this.colorType & PNG_FILTER_UP) == 0) {
            return PdfName.DEVICEGRAY;
        }
        return PdfName.DEVICERGB;
    }

    Image getImage() throws IOException {
        readPng();
        int pal0 = PNG_FILTER_NONE;
        int palIdx = PNG_FILTER_NONE;
        try {
            Image img;
            Image im2;
            this.palShades = false;
            if (this.trans != null) {
                for (int k = PNG_FILTER_NONE; k < this.trans.length; k += PNG_FILTER_SUB) {
                    int n = this.trans[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                    if (n == 0) {
                        pal0 += PNG_FILTER_SUB;
                        palIdx = k;
                    }
                    if (n != 0 && n != TIFFConstants.TIFFTAG_OSUBFILETYPE) {
                        this.palShades = true;
                        break;
                    }
                }
            }
            if ((this.colorType & PNG_FILTER_PAETH) != 0) {
                this.palShades = true;
            }
            boolean z = !this.palShades && (pal0 > PNG_FILTER_SUB || this.transRedGray >= 0);
            this.genBWMask = z;
            if (!(this.palShades || this.genBWMask || pal0 != PNG_FILTER_SUB)) {
                this.additional.put(PdfName.MASK, new PdfLiteral("[" + palIdx + " " + palIdx + "]"));
            }
            boolean needDecode = this.interlaceMethod == PNG_FILTER_SUB || this.bitDepth == 16 || (this.colorType & PNG_FILTER_PAETH) != 0 || this.palShades || this.genBWMask;
            switch (this.colorType) {
                case PNG_FILTER_NONE /*0*/:
                    this.inputBands = PNG_FILTER_SUB;
                    break;
                case PNG_FILTER_UP /*2*/:
                    this.inputBands = PNG_FILTER_AVERAGE;
                    break;
                case PNG_FILTER_AVERAGE /*3*/:
                    this.inputBands = PNG_FILTER_SUB;
                    break;
                case PNG_FILTER_PAETH /*4*/:
                    this.inputBands = PNG_FILTER_UP;
                    break;
                case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                    this.inputBands = PNG_FILTER_PAETH;
                    break;
            }
            if (needDecode) {
                decodeIdat();
            }
            int components = this.inputBands;
            if ((this.colorType & PNG_FILTER_PAETH) != 0) {
                components--;
            }
            int bpc = this.bitDepth;
            if (bpc == 16) {
                bpc = 8;
            }
            if (this.image == null) {
                img = new ImgRaw(this.width, this.height, components, bpc, this.idat.toByteArray());
                img.setDeflated(true);
                PdfDictionary decodeparms = new PdfDictionary();
                decodeparms.put(PdfName.BITSPERCOMPONENT, new PdfNumber(this.bitDepth));
                decodeparms.put(PdfName.PREDICTOR, new PdfNumber(15));
                decodeparms.put(PdfName.COLUMNS, new PdfNumber(this.width));
                PdfName pdfName = PdfName.COLORS;
                int i = (this.colorType == PNG_FILTER_AVERAGE || (this.colorType & PNG_FILTER_UP) == 0) ? PNG_FILTER_SUB : PNG_FILTER_AVERAGE;
                decodeparms.put(pdfName, new PdfNumber(i));
                this.additional.put(PdfName.DECODEPARMS, decodeparms);
            } else if (this.colorType == PNG_FILTER_AVERAGE) {
                img = new ImgRaw(this.width, this.height, components, bpc, this.image);
            } else {
                img = Image.getInstance(this.width, this.height, components, bpc, this.image);
            }
            if (this.additional.get(PdfName.COLORSPACE) == null) {
                this.additional.put(PdfName.COLORSPACE, getColorspace());
            }
            if (this.intent != null) {
                this.additional.put(PdfName.INTENT, this.intent);
            }
            if (this.additional.size() > 0) {
                img.setAdditional(this.additional);
            }
            if (this.icc_profile != null) {
                img.tagICC(this.icc_profile);
            }
            if (this.palShades) {
                im2 = Image.getInstance(this.width, this.height, PNG_FILTER_SUB, 8, this.smask);
                im2.makeMask();
                img.setImageMask(im2);
            }
            if (this.genBWMask) {
                im2 = Image.getInstance(this.width, this.height, PNG_FILTER_SUB, PNG_FILTER_SUB, this.smask);
                im2.makeMask();
                img.setImageMask(im2);
            }
            img.setDpi(this.dpiX, this.dpiY);
            img.setXYRatio(this.XYRatio);
            img.setOriginalType(PNG_FILTER_UP);
            return img;
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    void decodeIdat() {
        int nbitDepth = this.bitDepth;
        if (nbitDepth == 16) {
            nbitDepth = 8;
        }
        int size = -1;
        this.bytesPerPixel = this.bitDepth == 16 ? PNG_FILTER_UP : PNG_FILTER_SUB;
        switch (this.colorType) {
            case PNG_FILTER_NONE /*0*/:
                size = (((this.width * nbitDepth) + 7) / 8) * this.height;
                break;
            case PNG_FILTER_UP /*2*/:
                size = (this.width * PNG_FILTER_AVERAGE) * this.height;
                this.bytesPerPixel *= PNG_FILTER_AVERAGE;
                break;
            case PNG_FILTER_AVERAGE /*3*/:
                if (this.interlaceMethod == PNG_FILTER_SUB) {
                    size = (((this.width * nbitDepth) + 7) / 8) * this.height;
                }
                this.bytesPerPixel = PNG_FILTER_SUB;
                break;
            case PNG_FILTER_PAETH /*4*/:
                size = this.width * this.height;
                this.bytesPerPixel *= PNG_FILTER_UP;
                break;
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                size = (this.width * PNG_FILTER_AVERAGE) * this.height;
                this.bytesPerPixel *= PNG_FILTER_PAETH;
                break;
        }
        if (size >= 0) {
            this.image = new byte[size];
        }
        if (this.palShades) {
            this.smask = new byte[(this.width * this.height)];
        } else if (this.genBWMask) {
            this.smask = new byte[(((this.width + 7) / 8) * this.height)];
        }
        this.dataStream = new DataInputStream(new InflaterInputStream(new ByteArrayInputStream(this.idat.getBuf(), PNG_FILTER_NONE, this.idat.size()), new Inflater()));
        if (this.interlaceMethod != PNG_FILTER_SUB) {
            decodePass(PNG_FILTER_NONE, PNG_FILTER_NONE, PNG_FILTER_SUB, PNG_FILTER_SUB, this.width, this.height);
            return;
        }
        decodePass(PNG_FILTER_NONE, PNG_FILTER_NONE, 8, 8, (this.width + 7) / 8, (this.height + 7) / 8);
        decodePass(PNG_FILTER_PAETH, PNG_FILTER_NONE, 8, 8, (this.width + PNG_FILTER_AVERAGE) / 8, (this.height + 7) / 8);
        decodePass(PNG_FILTER_NONE, PNG_FILTER_PAETH, PNG_FILTER_PAETH, 8, (this.width + PNG_FILTER_AVERAGE) / PNG_FILTER_PAETH, (this.height + PNG_FILTER_AVERAGE) / 8);
        decodePass(PNG_FILTER_UP, PNG_FILTER_NONE, PNG_FILTER_PAETH, PNG_FILTER_PAETH, (this.width + PNG_FILTER_SUB) / PNG_FILTER_PAETH, (this.height + PNG_FILTER_AVERAGE) / PNG_FILTER_PAETH);
        decodePass(PNG_FILTER_NONE, PNG_FILTER_UP, PNG_FILTER_UP, PNG_FILTER_PAETH, (this.width + PNG_FILTER_SUB) / PNG_FILTER_UP, (this.height + PNG_FILTER_SUB) / PNG_FILTER_PAETH);
        decodePass(PNG_FILTER_SUB, PNG_FILTER_NONE, PNG_FILTER_UP, PNG_FILTER_UP, this.width / PNG_FILTER_UP, (this.height + PNG_FILTER_SUB) / PNG_FILTER_UP);
        decodePass(PNG_FILTER_NONE, PNG_FILTER_SUB, PNG_FILTER_SUB, PNG_FILTER_UP, this.width, this.height / PNG_FILTER_UP);
    }

    void decodePass(int xOffset, int yOffset, int xStep, int yStep, int passWidth, int passHeight) {
        if (passWidth != 0 && passHeight != 0) {
            int bytesPerRow = (((this.inputBands * passWidth) * this.bitDepth) + 7) / 8;
            byte[] curr = new byte[bytesPerRow];
            byte[] prior = new byte[bytesPerRow];
            int srcY = PNG_FILTER_NONE;
            int dstY = yOffset;
            while (srcY < passHeight) {
                int filter = PNG_FILTER_NONE;
                try {
                    filter = this.dataStream.read();
                    this.dataStream.readFully(curr, PNG_FILTER_NONE, bytesPerRow);
                } catch (Exception e) {
                }
                switch (filter) {
                    case PNG_FILTER_NONE /*0*/:
                        break;
                    case PNG_FILTER_SUB /*1*/:
                        decodeSubFilter(curr, bytesPerRow, this.bytesPerPixel);
                        break;
                    case PNG_FILTER_UP /*2*/:
                        decodeUpFilter(curr, prior, bytesPerRow);
                        break;
                    case PNG_FILTER_AVERAGE /*3*/:
                        decodeAverageFilter(curr, prior, bytesPerRow, this.bytesPerPixel);
                        break;
                    case PNG_FILTER_PAETH /*4*/:
                        decodePaethFilter(curr, prior, bytesPerRow, this.bytesPerPixel);
                        break;
                    default:
                        throw new RuntimeException(MessageLocalization.getComposedMessage("png.filter.unknown", new Object[PNG_FILTER_NONE]));
                }
                processPixels(curr, xOffset, xStep, dstY, passWidth);
                byte[] tmp = prior;
                prior = curr;
                curr = tmp;
                srcY += PNG_FILTER_SUB;
                dstY += yStep;
            }
        }
    }

    void processPixels(byte[] curr, int xOffset, int step, int y, int width) {
        int dstX;
        int yStride;
        int srcX;
        int[] out = getPixel(curr);
        int sizes = PNG_FILTER_NONE;
        switch (this.colorType) {
            case PNG_FILTER_NONE /*0*/:
            case PNG_FILTER_AVERAGE /*3*/:
            case PNG_FILTER_PAETH /*4*/:
                sizes = PNG_FILTER_SUB;
                break;
            case PNG_FILTER_UP /*2*/:
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                sizes = PNG_FILTER_AVERAGE;
                break;
        }
        if (this.image != null) {
            dstX = xOffset;
            yStride = (((this.bitDepth == 16 ? 8 : this.bitDepth) * (sizes * this.width)) + 7) / 8;
            for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                setPixel(this.image, out, this.inputBands * srcX, sizes, dstX, y, this.bitDepth, yStride);
                dstX += step;
            }
        }
        int i;
        int[] v;
        int idx;
        if (this.palShades) {
            if ((this.colorType & PNG_FILTER_PAETH) != 0) {
                if (this.bitDepth == 16) {
                    for (int k = PNG_FILTER_NONE; k < width; k += PNG_FILTER_SUB) {
                        i = (this.inputBands * k) + sizes;
                        out[i] = out[i] >>> 8;
                    }
                }
                yStride = this.width;
                dstX = xOffset;
                for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                    setPixel(this.smask, out, (this.inputBands * srcX) + sizes, PNG_FILTER_SUB, dstX, y, 8, yStride);
                    dstX += step;
                }
                return;
            }
            yStride = this.width;
            v = new int[PNG_FILTER_SUB];
            dstX = xOffset;
            for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                idx = out[srcX];
                if (idx < this.trans.length) {
                    v[PNG_FILTER_NONE] = this.trans[idx];
                } else {
                    v[PNG_FILTER_NONE] = TIFFConstants.TIFFTAG_OSUBFILETYPE;
                }
                setPixel(this.smask, v, PNG_FILTER_NONE, PNG_FILTER_SUB, dstX, y, 8, yStride);
                dstX += step;
            }
        } else if (this.genBWMask) {
            switch (this.colorType) {
                case PNG_FILTER_NONE /*0*/:
                    yStride = (this.width + 7) / 8;
                    v = new int[PNG_FILTER_SUB];
                    dstX = xOffset;
                    for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                        v[PNG_FILTER_NONE] = out[srcX] == this.transRedGray ? PNG_FILTER_SUB : PNG_FILTER_NONE;
                        setPixel(this.smask, v, PNG_FILTER_NONE, PNG_FILTER_SUB, dstX, y, PNG_FILTER_SUB, yStride);
                        dstX += step;
                    }
                case PNG_FILTER_UP /*2*/:
                    yStride = (this.width + 7) / 8;
                    v = new int[PNG_FILTER_SUB];
                    dstX = xOffset;
                    for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                        int markRed = this.inputBands * srcX;
                        i = (out[markRed] == this.transRedGray && out[markRed + PNG_FILTER_SUB] == this.transGreen && out[markRed + PNG_FILTER_UP] == this.transBlue) ? PNG_FILTER_SUB : PNG_FILTER_NONE;
                        v[PNG_FILTER_NONE] = i;
                        setPixel(this.smask, v, PNG_FILTER_NONE, PNG_FILTER_SUB, dstX, y, PNG_FILTER_SUB, yStride);
                        dstX += step;
                    }
                case PNG_FILTER_AVERAGE /*3*/:
                    yStride = (this.width + 7) / 8;
                    v = new int[PNG_FILTER_SUB];
                    dstX = xOffset;
                    for (srcX = PNG_FILTER_NONE; srcX < width; srcX += PNG_FILTER_SUB) {
                        idx = out[srcX];
                        i = (idx >= this.trans.length || this.trans[idx] != null) ? PNG_FILTER_NONE : PNG_FILTER_SUB;
                        v[PNG_FILTER_NONE] = i;
                        setPixel(this.smask, v, PNG_FILTER_NONE, PNG_FILTER_SUB, dstX, y, PNG_FILTER_SUB, yStride);
                        dstX += step;
                    }
                default:
            }
        }
    }

    static int getPixel(byte[] image, int x, int y, int bitDepth, int bytesPerRow) {
        if (bitDepth == 8) {
            return image[(bytesPerRow * y) + x] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
        }
        return ((PNG_FILTER_SUB << bitDepth) - 1) & (image[(bytesPerRow * y) + (x / (8 / bitDepth))] >> ((8 - ((x % (8 / bitDepth)) * bitDepth)) - bitDepth));
    }

    static void setPixel(byte[] image, int[] data, int offset, int size, int x, int y, int bitDepth, int bytesPerRow) {
        int pos;
        int k;
        if (bitDepth == 8) {
            pos = (bytesPerRow * y) + (size * x);
            for (k = PNG_FILTER_NONE; k < size; k += PNG_FILTER_SUB) {
                image[pos + k] = (byte) data[k + offset];
            }
        } else if (bitDepth == 16) {
            pos = (bytesPerRow * y) + (size * x);
            for (k = PNG_FILTER_NONE; k < size; k += PNG_FILTER_SUB) {
                image[pos + k] = (byte) (data[k + offset] >>> 8);
            }
        } else {
            pos = (bytesPerRow * y) + (x / (8 / bitDepth));
            image[pos] = (byte) (image[pos] | (data[offset] << ((8 - ((x % (8 / bitDepth)) * bitDepth)) - bitDepth)));
        }
    }

    int[] getPixel(byte[] curr) {
        int[] out;
        int k;
        switch (this.bitDepth) {
            case PdfWriter.PageLayoutTwoColumnRight /*8*/:
                out = new int[curr.length];
                for (k = PNG_FILTER_NONE; k < out.length; k += PNG_FILTER_SUB) {
                    out[k] = curr[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                }
                return out;
            case PdfWriter.PageLayoutTwoPageLeft /*16*/:
                out = new int[(curr.length / PNG_FILTER_UP)];
                for (k = PNG_FILTER_NONE; k < out.length; k += PNG_FILTER_SUB) {
                    out[k] = ((curr[k * PNG_FILTER_UP] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 8) + (curr[(k * PNG_FILTER_UP) + PNG_FILTER_SUB] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
                }
                return out;
            default:
                out = new int[((curr.length * 8) / this.bitDepth)];
                int idx = PNG_FILTER_NONE;
                int passes = 8 / this.bitDepth;
                int mask = (PNG_FILTER_SUB << this.bitDepth) - 1;
                k = PNG_FILTER_NONE;
                while (k < curr.length) {
                    int j = passes - 1;
                    int idx2 = idx;
                    while (j >= 0) {
                        idx = idx2 + PNG_FILTER_SUB;
                        out[idx2] = (curr[k] >>> (this.bitDepth * j)) & mask;
                        j--;
                        idx2 = idx;
                    }
                    k += PNG_FILTER_SUB;
                    idx = idx2;
                }
                return out;
        }
    }

    private static void decodeSubFilter(byte[] curr, int count, int bpp) {
        for (int i = bpp; i < count; i += PNG_FILTER_SUB) {
            curr[i] = (byte) ((curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + (curr[i - bpp] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
    }

    private static void decodeUpFilter(byte[] curr, byte[] prev, int count) {
        for (int i = PNG_FILTER_NONE; i < count; i += PNG_FILTER_SUB) {
            curr[i] = (byte) ((curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + (prev[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
    }

    private static void decodeAverageFilter(byte[] curr, byte[] prev, int count, int bpp) {
        int i;
        for (i = PNG_FILTER_NONE; i < bpp; i += PNG_FILTER_SUB) {
            curr[i] = (byte) (((prev[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE) / PNG_FILTER_UP) + (curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
        for (i = bpp; i < count; i += PNG_FILTER_SUB) {
            curr[i] = (byte) ((((curr[i - bpp] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + (prev[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE)) / PNG_FILTER_UP) + (curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
    }

    private static int paethPredictor(int a, int b, int c) {
        int p = (a + b) - c;
        int pa = Math.abs(p - a);
        int pb = Math.abs(p - b);
        int pc = Math.abs(p - c);
        if (pa <= pb && pa <= pc) {
            return a;
        }
        if (pb <= pc) {
            return b;
        }
        return c;
    }

    private static void decodePaethFilter(byte[] curr, byte[] prev, int count, int bpp) {
        int i;
        for (i = PNG_FILTER_NONE; i < bpp; i += PNG_FILTER_SUB) {
            curr[i] = (byte) ((curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + (prev[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
        for (i = bpp; i < count; i += PNG_FILTER_SUB) {
            curr[i] = (byte) (paethPredictor(curr[i - bpp] & TIFFConstants.TIFFTAG_OSUBFILETYPE, prev[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE, prev[i - bpp] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + (curr[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE));
        }
    }

    public static final int getInt(InputStream is) throws IOException {
        return (((is.read() << 24) + (is.read() << 16)) + (is.read() << 8)) + is.read();
    }

    public static final int getWord(InputStream is) throws IOException {
        return (is.read() << 8) + is.read();
    }

    public static final String getString(InputStream is) throws IOException {
        StringBuffer buf = new StringBuffer();
        for (int i = PNG_FILTER_NONE; i < PNG_FILTER_PAETH; i += PNG_FILTER_SUB) {
            buf.append((char) is.read());
        }
        return buf.toString();
    }
}

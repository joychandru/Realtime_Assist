package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.pdf.ByteBuffer;
import com.itextpdf.text.pdf.PdfContentParser;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.wmf.MetaDo;
import com.itextpdf.xmp.XMPError;

public class CCITTG4Encoder {
    private static final int CODE = 1;
    private static final int EOL = 1;
    private static final int G3CODE_EOF = -3;
    private static final int G3CODE_EOL = -1;
    private static final int G3CODE_INCOMP = -4;
    private static final int G3CODE_INVALID = -2;
    private static final int LENGTH = 0;
    private static final int RUNLEN = 2;
    private static byte[] oneruns;
    private static byte[] zeroruns;
    private int[][] TIFFFaxBlackCodes;
    private int[][] TIFFFaxWhiteCodes;
    private int bit;
    private int data;
    private byte[] dataBp;
    private int[] horizcode;
    private int[] msbmask;
    private int offsetData;
    private ByteBuffer outBuf;
    private int[] passcode;
    private byte[] refline;
    private int rowbytes;
    private int rowpixels;
    private int sizeData;
    private int[][] vcodes;

    public CCITTG4Encoder(int width) {
        this.bit = 8;
        this.outBuf = new ByteBuffer(PdfWriter.PageModeUseOC);
        this.TIFFFaxWhiteCodes = new int[][]{new int[]{8, 53, LENGTH}, new int[]{6, 7, EOL}, new int[]{4, 7, RUNLEN}, new int[]{4, 8, 3}, new int[]{4, 11, 4}, new int[]{4, 12, 5}, new int[]{4, 14, 6}, new int[]{4, 15, 7}, new int[]{5, 19, 8}, new int[]{5, 20, 9}, new int[]{5, 7, 10}, new int[]{5, 8, 11}, new int[]{6, 8, 12}, new int[]{6, 3, 13}, new int[]{6, 52, 14}, new int[]{6, 53, 15}, new int[]{6, 42, 16}, new int[]{6, 43, 17}, new int[]{7, 39, 18}, new int[]{7, 12, 19}, new int[]{7, 8, 20}, new int[]{7, 23, 21}, new int[]{7, 3, 22}, new int[]{7, 4, 23}, new int[]{7, 40, 24}, new int[]{7, 43, 25}, new int[]{7, 19, 26}, new int[]{7, 36, 27}, new int[]{7, 24, 28}, new int[]{8, RUNLEN, 29}, new int[]{8, 3, 30}, new int[]{8, 26, 31}, new int[]{8, 27, 32}, new int[]{8, 18, 33}, new int[]{8, 19, 34}, new int[]{8, 20, 35}, new int[]{8, 21, 36}, new int[]{8, 22, 37}, new int[]{8, 23, 38}, new int[]{8, 40, 39}, new int[]{8, 41, 40}, new int[]{8, 42, 41}, new int[]{8, 43, 42}, new int[]{8, 44, 43}, new int[]{8, 45, 44}, new int[]{8, 4, 45}, new int[]{8, 5, 46}, new int[]{8, 10, 47}, new int[]{8, 11, 48}, new int[]{8, 82, 49}, new int[]{8, 83, 50}, new int[]{8, 84, 51}, new int[]{8, 85, 52}, new int[]{8, 36, 53}, new int[]{8, 37, 54}, new int[]{8, 88, 55}, new int[]{8, 89, 56}, new int[]{8, 90, 57}, new int[]{8, 91, 58}, new int[]{8, 74, 59}, new int[]{8, 75, 60}, new int[]{8, 50, 61}, new int[]{8, 51, 62}, new int[]{8, 52, 63}, new int[]{5, 27, 64}, new int[]{5, 18, PdfWriter.PageModeUseOutlines}, new int[]{6, 23, 192}, new int[]{7, 55, PdfWriter.PageModeUseThumbs}, new int[]{8, 54, TIFFConstants.TIFFTAG_COLORMAP}, new int[]{8, 55, 384}, new int[]{8, 100, 448}, new int[]{8, XMPError.BADSCHEMA, PdfWriter.PageModeFullScreen}, new int[]{8, XMPError.BADINDEX, 576}, new int[]{8, XMPError.BADOPTIONS, 640}, new int[]{9, XMPError.BADSTREAM, 704}, new int[]{9, 205, 768}, new int[]{9, 210, 832}, new int[]{9, 211, 896}, new int[]{9, 212, 960}, new int[]{9, 213, PdfWriter.PageModeUseOC}, new int[]{9, 214, 1088}, new int[]{9, 215, 1152}, new int[]{9, 216, 1216}, new int[]{9, 217, 1280}, new int[]{9, 218, 1344}, new int[]{9, 219, 1408}, new int[]{9, 152, 1472}, new int[]{9, 153, 1536}, new int[]{9, 154, 1600}, new int[]{6, 24, 1664}, new int[]{9, 155, 1728}, new int[]{11, 8, 1792}, new int[]{11, 12, 1856}, new int[]{11, 13, 1920}, new int[]{12, 18, 1984}, new int[]{12, 19, PdfWriter.PageModeUseAttachments}, new int[]{12, 20, 2112}, new int[]{12, 21, 2176}, new int[]{12, 22, 2240}, new int[]{12, 23, 2304}, new int[]{12, 28, MetaDo.META_DIBBITBLT}, new int[]{12, 29, 2432}, new int[]{12, 30, 2496}, new int[]{12, 31, 2560}, new int[]{12, EOL, G3CODE_EOL}, new int[]{9, EOL, G3CODE_INVALID}, new int[]{10, EOL, G3CODE_INVALID}, new int[]{11, EOL, G3CODE_INVALID}, new int[]{12, LENGTH, G3CODE_INVALID}};
        this.TIFFFaxBlackCodes = new int[][]{new int[]{10, 55, LENGTH}, new int[]{3, RUNLEN, EOL}, new int[]{RUNLEN, 3, RUNLEN}, new int[]{RUNLEN, RUNLEN, 3}, new int[]{3, 3, 4}, new int[]{4, 3, 5}, new int[]{4, RUNLEN, 6}, new int[]{5, 3, 7}, new int[]{6, 5, 8}, new int[]{6, 4, 9}, new int[]{7, 4, 10}, new int[]{7, 5, 11}, new int[]{7, 7, 12}, new int[]{8, 4, 13}, new int[]{8, 7, 14}, new int[]{9, 24, 15}, new int[]{10, 23, 16}, new int[]{10, 24, 17}, new int[]{10, 8, 18}, new int[]{11, XMPError.BADOPTIONS, 19}, new int[]{11, XMPError.BADINDEX, 20}, new int[]{11, 108, 21}, new int[]{11, 55, 22}, new int[]{11, 40, 23}, new int[]{11, 23, 24}, new int[]{11, 24, 25}, new int[]{12, XMPError.BADRDF, 26}, new int[]{12, XMPError.BADXMP, 27}, new int[]{12, XMPError.BADSTREAM, 28}, new int[]{12, 205, 29}, new int[]{12, XMPError.BADINDEX, 30}, new int[]{12, 105, 31}, new int[]{12, 106, 32}, new int[]{12, XMPError.BADSERIALIZE, 33}, new int[]{12, 210, 34}, new int[]{12, 211, 35}, new int[]{12, 212, 36}, new int[]{12, 213, 37}, new int[]{12, 214, 38}, new int[]{12, 215, 39}, new int[]{12, 108, 40}, new int[]{12, 109, 41}, new int[]{12, 218, 42}, new int[]{12, 219, 43}, new int[]{12, 84, 44}, new int[]{12, 85, 45}, new int[]{12, 86, 46}, new int[]{12, 87, 47}, new int[]{12, 100, 48}, new int[]{12, XMPError.BADSCHEMA, 49}, new int[]{12, 82, 50}, new int[]{12, 83, 51}, new int[]{12, 36, 52}, new int[]{12, 55, 53}, new int[]{12, 56, 54}, new int[]{12, 39, 55}, new int[]{12, 40, 56}, new int[]{12, 88, 57}, new int[]{12, 89, 58}, new int[]{12, 43, 59}, new int[]{12, 44, 60}, new int[]{12, 90, 61}, new int[]{12, XMPError.BADXPATH, 62}, new int[]{12, XMPError.BADOPTIONS, 63}, new int[]{10, 15, 64}, new int[]{12, PdfContentParser.COMMAND_TYPE, PdfWriter.PageModeUseOutlines}, new int[]{12, XMPError.BADXML, 192}, new int[]{12, 91, PdfWriter.PageModeUseThumbs}, new int[]{12, 51, TIFFConstants.TIFFTAG_COLORMAP}, new int[]{12, 52, 384}, new int[]{12, 53, 448}, new int[]{13, 108, PdfWriter.PageModeFullScreen}, new int[]{13, 109, 576}, new int[]{13, 74, 640}, new int[]{13, 75, 704}, new int[]{13, 76, 768}, new int[]{13, 77, 832}, new int[]{13, 114, 896}, new int[]{13, 115, 960}, new int[]{13, 116, PdfWriter.PageModeUseOC}, new int[]{13, 117, 1088}, new int[]{13, 118, 1152}, new int[]{13, 119, 1216}, new int[]{13, 82, 1280}, new int[]{13, 83, 1344}, new int[]{13, 84, 1408}, new int[]{13, 85, 1472}, new int[]{13, 90, 1536}, new int[]{13, 91, 1600}, new int[]{13, 100, 1664}, new int[]{13, XMPError.BADSCHEMA, 1728}, new int[]{11, 8, 1792}, new int[]{11, 12, 1856}, new int[]{11, 13, 1920}, new int[]{12, 18, 1984}, new int[]{12, 19, PdfWriter.PageModeUseAttachments}, new int[]{12, 20, 2112}, new int[]{12, 21, 2176}, new int[]{12, 22, 2240}, new int[]{12, 23, 2304}, new int[]{12, 28, MetaDo.META_DIBBITBLT}, new int[]{12, 29, 2432}, new int[]{12, 30, 2496}, new int[]{12, 31, 2560}, new int[]{12, EOL, G3CODE_EOL}, new int[]{9, EOL, G3CODE_INVALID}, new int[]{10, EOL, G3CODE_INVALID}, new int[]{11, EOL, G3CODE_INVALID}, new int[]{12, LENGTH, G3CODE_INVALID}};
        this.horizcode = new int[]{3, EOL, LENGTH};
        this.passcode = new int[]{4, EOL, LENGTH};
        this.vcodes = new int[][]{new int[]{7, 3, LENGTH}, new int[]{6, 3, LENGTH}, new int[]{3, 3, LENGTH}, new int[]{EOL, EOL, LENGTH}, new int[]{3, RUNLEN, LENGTH}, new int[]{6, RUNLEN, LENGTH}, new int[]{7, RUNLEN, LENGTH}};
        this.msbmask = new int[]{LENGTH, EOL, 3, 7, 15, 31, 63, 127, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        this.rowpixels = width;
        this.rowbytes = (this.rowpixels + 7) / 8;
        this.refline = new byte[this.rowbytes];
    }

    public void fax4Encode(byte[] data, int offset, int size) {
        this.dataBp = data;
        this.offsetData = offset;
        this.sizeData = size;
        while (this.sizeData > 0) {
            Fax3Encode2DRow();
            System.arraycopy(this.dataBp, this.offsetData, this.refline, LENGTH, this.rowbytes);
            this.offsetData += this.rowbytes;
            this.sizeData -= this.rowbytes;
        }
    }

    public static byte[] compress(byte[] data, int width, int height) {
        CCITTG4Encoder g4 = new CCITTG4Encoder(width);
        g4.fax4Encode(data, LENGTH, g4.rowbytes * height);
        return g4.close();
    }

    public void fax4Encode(byte[] data, int height) {
        fax4Encode(data, LENGTH, this.rowbytes * height);
    }

    private void putcode(int[] table) {
        putBits(table[EOL], table[LENGTH]);
    }

    private void putspan(int span, int[][] tab) {
        while (span >= 2624) {
            int[] te = tab[XMPError.BADOPTIONS];
            putBits(te[EOL], te[LENGTH]);
            span -= te[RUNLEN];
        }
        if (span >= 64) {
            te = tab[(span >> 6) + 63];
            putBits(te[EOL], te[LENGTH]);
            span -= te[RUNLEN];
        }
        putBits(tab[span][EOL], tab[span][LENGTH]);
    }

    private void putBits(int bits, int length) {
        while (length > this.bit) {
            this.data |= bits >> (length - this.bit);
            length -= this.bit;
            this.outBuf.append((byte) this.data);
            this.data = LENGTH;
            this.bit = 8;
        }
        this.data |= (this.msbmask[length] & bits) << (this.bit - length);
        this.bit -= length;
        if (this.bit == 0) {
            this.outBuf.append((byte) this.data);
            this.data = LENGTH;
            this.bit = 8;
        }
    }

    private void Fax3Encode2DRow() {
        int b1;
        int a0 = LENGTH;
        int a1 = pixel(this.dataBp, this.offsetData, LENGTH) != 0 ? LENGTH : finddiff(this.dataBp, this.offsetData, LENGTH, this.rowpixels, LENGTH);
        if (pixel(this.refline, LENGTH, LENGTH) != 0) {
            b1 = LENGTH;
        } else {
            b1 = finddiff(this.refline, LENGTH, LENGTH, this.rowpixels, LENGTH);
        }
        while (true) {
            int b2 = finddiff2(this.refline, LENGTH, b1, this.rowpixels, pixel(this.refline, LENGTH, b1));
            if (b2 >= a1) {
                int d = b1 - a1;
                if (G3CODE_EOF > d || d > 3) {
                    int a2 = finddiff2(this.dataBp, this.offsetData, a1, this.rowpixels, pixel(this.dataBp, this.offsetData, a1));
                    putcode(this.horizcode);
                    if (a0 + a1 == 0 || pixel(this.dataBp, this.offsetData, a0) == 0) {
                        putspan(a1 - a0, this.TIFFFaxWhiteCodes);
                        putspan(a2 - a1, this.TIFFFaxBlackCodes);
                    } else {
                        putspan(a1 - a0, this.TIFFFaxBlackCodes);
                        putspan(a2 - a1, this.TIFFFaxWhiteCodes);
                    }
                    a0 = a2;
                } else {
                    putcode(this.vcodes[d + 3]);
                    a0 = a1;
                }
            } else {
                putcode(this.passcode);
                a0 = b2;
            }
            if (a0 < this.rowpixels) {
                a1 = finddiff(this.dataBp, this.offsetData, a0, this.rowpixels, pixel(this.dataBp, this.offsetData, a0));
                b1 = finddiff(this.refline, LENGTH, finddiff(this.refline, LENGTH, a0, this.rowpixels, pixel(this.dataBp, this.offsetData, a0) ^ EOL), this.rowpixels, pixel(this.dataBp, this.offsetData, a0));
            } else {
                return;
            }
        }
    }

    private void Fax4PostEncode() {
        putBits(EOL, 12);
        putBits(EOL, 12);
        if (this.bit != 8) {
            this.outBuf.append((byte) this.data);
            this.data = LENGTH;
            this.bit = 8;
        }
    }

    public byte[] close() {
        Fax4PostEncode();
        return this.outBuf.toByteArray();
    }

    private int pixel(byte[] data, int offset, int bit) {
        if (bit >= this.rowpixels) {
            return LENGTH;
        }
        return ((data[(bit >> 3) + offset] & TIFFConstants.TIFFTAG_OSUBFILETYPE) >> (7 - (bit & 7))) & EOL;
    }

    private static int find1span(byte[] bp, int offset, int bs, int be) {
        int n;
        int span;
        int bits = be - bs;
        int pos = offset + (bs >> 3);
        if (bits > 0) {
            n = bs & 7;
            if (n != 0) {
                span = oneruns[(bp[pos] << n) & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                if (span > 8 - n) {
                    span = 8 - n;
                }
                if (span > bits) {
                    span = bits;
                }
                if (n + span < 8) {
                    return span;
                }
                bits -= span;
                pos += EOL;
                while (bits >= 8) {
                    if (bp[pos] != G3CODE_EOL) {
                        return oneruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE] + span;
                    }
                    span += 8;
                    bits -= 8;
                    pos += EOL;
                }
                if (bits > 0) {
                    n = oneruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                    if (n > bits) {
                        n = bits;
                    }
                    span += n;
                }
                return span;
            }
        }
        span = LENGTH;
        while (bits >= 8) {
            if (bp[pos] != G3CODE_EOL) {
                return oneruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE] + span;
            }
            span += 8;
            bits -= 8;
            pos += EOL;
        }
        if (bits > 0) {
            n = oneruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (n > bits) {
                n = bits;
            }
            span += n;
        }
        return span;
    }

    private static int find0span(byte[] bp, int offset, int bs, int be) {
        int n;
        int span;
        int bits = be - bs;
        int pos = offset + (bs >> 3);
        if (bits > 0) {
            n = bs & 7;
            if (n != 0) {
                span = zeroruns[(bp[pos] << n) & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                if (span > 8 - n) {
                    span = 8 - n;
                }
                if (span > bits) {
                    span = bits;
                }
                if (n + span < 8) {
                    return span;
                }
                bits -= span;
                pos += EOL;
                while (bits >= 8) {
                    if (bp[pos] != null) {
                        return zeroruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE] + span;
                    }
                    span += 8;
                    bits -= 8;
                    pos += EOL;
                }
                if (bits > 0) {
                    n = zeroruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                    if (n > bits) {
                        n = bits;
                    }
                    span += n;
                }
                return span;
            }
        }
        span = LENGTH;
        while (bits >= 8) {
            if (bp[pos] != null) {
                return zeroruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE] + span;
            }
            span += 8;
            bits -= 8;
            pos += EOL;
        }
        if (bits > 0) {
            n = zeroruns[bp[pos] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (n > bits) {
                n = bits;
            }
            span += n;
        }
        return span;
    }

    private static int finddiff(byte[] bp, int offset, int bs, int be, int color) {
        return (color != 0 ? find1span(bp, offset, bs, be) : find0span(bp, offset, bs, be)) + bs;
    }

    private static int finddiff2(byte[] bp, int offset, int bs, int be, int color) {
        return bs < be ? finddiff(bp, offset, bs, be, color) : be;
    }

    static {
        zeroruns = new byte[]{(byte) 8, (byte) 7, (byte) 6, (byte) 6, (byte) 5, (byte) 5, (byte) 5, (byte) 5, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0};
        oneruns = new byte[]{(byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 2, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 3, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 5, (byte) 5, (byte) 5, (byte) 5, (byte) 6, (byte) 6, (byte) 7, (byte) 8};
    }
}

package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.DocWriter;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.BidiOrder;
import com.itextpdf.text.pdf.ByteBuffer;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class Base64 {
    public static final int DECODE = 0;
    public static final int DONT_BREAK_LINES = 8;
    public static final int ENCODE = 1;
    private static final byte EQUALS_SIGN = (byte) 61;
    private static final byte EQUALS_SIGN_ENC = (byte) -1;
    public static final int GZIP = 2;
    private static final int MAX_LINE_LENGTH = 76;
    private static final byte NEW_LINE = (byte) 10;
    public static final int NO_OPTIONS = 0;
    public static final int ORDERED = 32;
    private static final String PREFERRED_ENCODING = "UTF-8";
    public static final int URL_SAFE = 16;
    private static final byte WHITE_SPACE_ENC = (byte) -5;
    private static final byte[] _ORDERED_ALPHABET;
    private static final byte[] _ORDERED_DECODABET;
    private static final byte[] _STANDARD_ALPHABET;
    private static final byte[] _STANDARD_DECODABET;
    private static final byte[] _URL_SAFE_ALPHABET;
    private static final byte[] _URL_SAFE_DECODABET;

    public static class InputStream extends FilterInputStream {
        private byte[] alphabet;
        private boolean breakLines;
        private byte[] buffer;
        private int bufferLength;
        private byte[] decodabet;
        private boolean encode;
        private int lineLength;
        private int numSigBytes;
        private int options;
        private int position;

        public InputStream(java.io.InputStream in) {
            this(in, Base64.NO_OPTIONS);
        }

        public InputStream(java.io.InputStream in, int options) {
            boolean z = true;
            super(in);
            this.breakLines = (options & Base64.DONT_BREAK_LINES) != Base64.DONT_BREAK_LINES;
            if ((options & Base64.ENCODE) != Base64.ENCODE) {
                z = false;
            }
            this.encode = z;
            this.bufferLength = this.encode ? 4 : 3;
            this.buffer = new byte[this.bufferLength];
            this.position = -1;
            this.lineLength = Base64.NO_OPTIONS;
            this.options = options;
            this.alphabet = Base64.getAlphabet(options);
            this.decodabet = Base64.getDecodabet(options);
        }

        public int read() throws IOException {
            int b;
            if (this.position < 0) {
                int i;
                if (this.encode) {
                    byte[] b3 = new byte[3];
                    int numBinaryBytes = Base64.NO_OPTIONS;
                    for (i = Base64.NO_OPTIONS; i < 3; i += Base64.ENCODE) {
                        try {
                            b = this.in.read();
                            if (b >= 0) {
                                b3[i] = (byte) b;
                                numBinaryBytes += Base64.ENCODE;
                            }
                        } catch (IOException e) {
                            if (i == 0) {
                                throw e;
                            }
                        }
                    }
                    if (numBinaryBytes <= 0) {
                        return -1;
                    }
                    Base64.encode3to4(b3, Base64.NO_OPTIONS, numBinaryBytes, this.buffer, Base64.NO_OPTIONS, this.options);
                    this.position = Base64.NO_OPTIONS;
                    this.numSigBytes = 4;
                } else {
                    byte[] b4 = new byte[4];
                    i = Base64.NO_OPTIONS;
                    while (i < 4) {
                        do {
                            b = this.in.read();
                            if (b < 0) {
                                break;
                            }
                        } while (this.decodabet[b & 127] <= -5);
                        if (b < 0) {
                            break;
                        }
                        b4[i] = (byte) b;
                        i += Base64.ENCODE;
                    }
                    if (i == 4) {
                        this.numSigBytes = Base64.decode4to3(b4, Base64.NO_OPTIONS, this.buffer, Base64.NO_OPTIONS, this.options);
                        this.position = Base64.NO_OPTIONS;
                    } else if (i == 0) {
                        return -1;
                    } else {
                        throw new IOException(MessageLocalization.getComposedMessage("improperly.padded.base64.input", new Object[Base64.NO_OPTIONS]));
                    }
                }
            }
            if (this.position < 0) {
                throw new IOException(MessageLocalization.getComposedMessage("error.in.base64.code.reading.stream", new Object[Base64.NO_OPTIONS]));
            } else if (this.position >= this.numSigBytes) {
                return -1;
            } else {
                if (this.encode && this.breakLines && this.lineLength >= Base64.MAX_LINE_LENGTH) {
                    this.lineLength = Base64.NO_OPTIONS;
                    return 10;
                }
                this.lineLength += Base64.ENCODE;
                byte[] bArr = this.buffer;
                int i2 = this.position;
                this.position = i2 + Base64.ENCODE;
                b = bArr[i2];
                if (this.position >= this.bufferLength) {
                    this.position = -1;
                }
                return b & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            }
        }

        public int read(byte[] dest, int off, int len) throws IOException {
            int i = Base64.NO_OPTIONS;
            while (i < len) {
                int b = read();
                if (b >= 0) {
                    dest[off + i] = (byte) b;
                    i += Base64.ENCODE;
                } else if (i == 0) {
                    return -1;
                } else {
                    return i;
                }
            }
            return i;
        }
    }

    public static class OutputStream extends FilterOutputStream {
        private byte[] alphabet;
        private byte[] b4;
        private boolean breakLines;
        private byte[] buffer;
        private int bufferLength;
        private byte[] decodabet;
        private boolean encode;
        private int lineLength;
        private int options;
        private int position;
        private boolean suspendEncoding;

        public OutputStream(java.io.OutputStream out) {
            this(out, Base64.ENCODE);
        }

        public OutputStream(java.io.OutputStream out, int options) {
            int i;
            boolean z = true;
            super(out);
            this.breakLines = (options & Base64.DONT_BREAK_LINES) != Base64.DONT_BREAK_LINES;
            if ((options & Base64.ENCODE) != Base64.ENCODE) {
                z = false;
            }
            this.encode = z;
            if (this.encode) {
                i = 3;
            } else {
                i = 4;
            }
            this.bufferLength = i;
            this.buffer = new byte[this.bufferLength];
            this.position = Base64.NO_OPTIONS;
            this.lineLength = Base64.NO_OPTIONS;
            this.suspendEncoding = false;
            this.b4 = new byte[4];
            this.options = options;
            this.alphabet = Base64.getAlphabet(options);
            this.decodabet = Base64.getDecodabet(options);
        }

        public void write(int theByte) throws IOException {
            if (this.suspendEncoding) {
                this.out.write(theByte);
            } else if (this.encode) {
                r1 = this.buffer;
                r2 = this.position;
                this.position = r2 + Base64.ENCODE;
                r1[r2] = (byte) theByte;
                if (this.position >= this.bufferLength) {
                    this.out.write(Base64.encode3to4(this.b4, this.buffer, this.bufferLength, this.options));
                    this.lineLength += 4;
                    if (this.breakLines && this.lineLength >= Base64.MAX_LINE_LENGTH) {
                        this.out.write(10);
                        this.lineLength = Base64.NO_OPTIONS;
                    }
                    this.position = Base64.NO_OPTIONS;
                }
            } else if (this.decodabet[theByte & 127] > Base64.WHITE_SPACE_ENC) {
                r1 = this.buffer;
                r2 = this.position;
                this.position = r2 + Base64.ENCODE;
                r1[r2] = (byte) theByte;
                if (this.position >= this.bufferLength) {
                    this.out.write(this.b4, Base64.NO_OPTIONS, Base64.decode4to3(this.buffer, Base64.NO_OPTIONS, this.b4, Base64.NO_OPTIONS, this.options));
                    this.position = Base64.NO_OPTIONS;
                }
            } else if (this.decodabet[theByte & 127] != Base64.WHITE_SPACE_ENC) {
                throw new IOException(MessageLocalization.getComposedMessage("invalid.character.in.base64.data", new Object[Base64.NO_OPTIONS]));
            }
        }

        public void write(byte[] theBytes, int off, int len) throws IOException {
            if (this.suspendEncoding) {
                this.out.write(theBytes, off, len);
                return;
            }
            for (int i = Base64.NO_OPTIONS; i < len; i += Base64.ENCODE) {
                write(theBytes[off + i]);
            }
        }

        public void flushBase64() throws IOException {
            if (this.position <= 0) {
                return;
            }
            if (this.encode) {
                this.out.write(Base64.encode3to4(this.b4, this.buffer, this.position, this.options));
                this.position = Base64.NO_OPTIONS;
                return;
            }
            throw new IOException(MessageLocalization.getComposedMessage("base64.input.not.properly.padded", new Object[Base64.NO_OPTIONS]));
        }

        public void close() throws IOException {
            flushBase64();
            super.close();
            this.buffer = null;
            this.out = null;
        }

        public void suspendEncoding() throws IOException {
            flushBase64();
            this.suspendEncoding = true;
        }

        public void resumeEncoding() {
            this.suspendEncoding = false;
        }
    }

    static {
        _STANDARD_ALPHABET = new byte[]{(byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72, (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80, (byte) 81, (byte) 82, (byte) 83, (byte) 84, (byte) 85, (byte) 86, (byte) 87, (byte) 88, (byte) 89, (byte) 90, (byte) 97, (byte) 98, (byte) 99, (byte) 100, (byte) 101, (byte) 102, (byte) 103, (byte) 104, (byte) 105, (byte) 106, (byte) 107, (byte) 108, (byte) 109, (byte) 110, (byte) 111, (byte) 112, (byte) 113, (byte) 114, (byte) 115, (byte) 116, (byte) 117, (byte) 118, (byte) 119, (byte) 120, (byte) 121, (byte) 122, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 43, DocWriter.FORWARD};
        _STANDARD_DECODABET = new byte[]{(byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, DocWriter.GT, (byte) -9, (byte) -9, (byte) -9, (byte) 63, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 58, (byte) 59, DocWriter.LT, EQUALS_SIGN, (byte) -9, (byte) -9, (byte) -9, EQUALS_SIGN_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) 0, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, NEW_LINE, BidiOrder.AN, BidiOrder.CS, BidiOrder.NSM, BidiOrder.BN, BidiOrder.f10B, BidiOrder.f13S, BidiOrder.WS, BidiOrder.TYPE_MAX, (byte) 19, (byte) 20, (byte) 21, (byte) 22, (byte) 23, (byte) 24, (byte) 25, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) 26, (byte) 27, (byte) 28, (byte) 29, (byte) 30, (byte) 31, DocWriter.SPACE, (byte) 33, DocWriter.QUOTE, (byte) 35, (byte) 36, (byte) 37, (byte) 38, (byte) 39, (byte) 40, (byte) 41, (byte) 42, (byte) 43, (byte) 44, (byte) 45, (byte) 46, DocWriter.FORWARD, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) -9, (byte) -9, (byte) -9, (byte) -9};
        _URL_SAFE_ALPHABET = new byte[]{(byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72, (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80, (byte) 81, (byte) 82, (byte) 83, (byte) 84, (byte) 85, (byte) 86, (byte) 87, (byte) 88, (byte) 89, (byte) 90, (byte) 97, (byte) 98, (byte) 99, (byte) 100, (byte) 101, (byte) 102, (byte) 103, (byte) 104, (byte) 105, (byte) 106, (byte) 107, (byte) 108, (byte) 109, (byte) 110, (byte) 111, (byte) 112, (byte) 113, (byte) 114, (byte) 115, (byte) 116, (byte) 117, (byte) 118, (byte) 119, (byte) 120, (byte) 121, (byte) 122, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 45, (byte) 95};
        _URL_SAFE_DECODABET = new byte[]{(byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, DocWriter.GT, (byte) -9, (byte) -9, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 58, (byte) 59, DocWriter.LT, EQUALS_SIGN, (byte) -9, (byte) -9, (byte) -9, EQUALS_SIGN_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) 0, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, NEW_LINE, BidiOrder.AN, BidiOrder.CS, BidiOrder.NSM, BidiOrder.BN, BidiOrder.f10B, BidiOrder.f13S, BidiOrder.WS, BidiOrder.TYPE_MAX, (byte) 19, (byte) 20, (byte) 21, (byte) 22, (byte) 23, (byte) 24, (byte) 25, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) 63, (byte) -9, (byte) 26, (byte) 27, (byte) 28, (byte) 29, (byte) 30, (byte) 31, DocWriter.SPACE, (byte) 33, DocWriter.QUOTE, (byte) 35, (byte) 36, (byte) 37, (byte) 38, (byte) 39, (byte) 40, (byte) 41, (byte) 42, (byte) 43, (byte) 44, (byte) 45, (byte) 46, DocWriter.FORWARD, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) -9, (byte) -9, (byte) -9, (byte) -9};
        _ORDERED_ALPHABET = new byte[]{(byte) 45, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72, (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80, (byte) 81, (byte) 82, (byte) 83, (byte) 84, (byte) 85, (byte) 86, (byte) 87, (byte) 88, (byte) 89, (byte) 90, (byte) 95, (byte) 97, (byte) 98, (byte) 99, (byte) 100, (byte) 101, (byte) 102, (byte) 103, (byte) 104, (byte) 105, (byte) 106, (byte) 107, (byte) 108, (byte) 109, (byte) 110, (byte) 111, (byte) 112, (byte) 113, (byte) 114, (byte) 115, (byte) 116, (byte) 117, (byte) 118, (byte) 119, (byte) 120, (byte) 121, (byte) 122};
        _ORDERED_DECODABET = new byte[]{(byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, WHITE_SPACE_ENC, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, WHITE_SPACE_ENC, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) 0, (byte) -9, (byte) -9, (byte) 1, (byte) 2, (byte) 3, (byte) 4, (byte) 5, (byte) 6, (byte) 7, (byte) 8, (byte) 9, NEW_LINE, (byte) -9, (byte) -9, (byte) -9, EQUALS_SIGN_ENC, (byte) -9, (byte) -9, (byte) -9, BidiOrder.AN, BidiOrder.CS, BidiOrder.NSM, BidiOrder.BN, BidiOrder.f10B, BidiOrder.f13S, BidiOrder.WS, BidiOrder.TYPE_MAX, (byte) 19, (byte) 20, (byte) 21, (byte) 22, (byte) 23, (byte) 24, (byte) 25, (byte) 26, (byte) 27, (byte) 28, (byte) 29, (byte) 30, (byte) 31, DocWriter.SPACE, (byte) 33, DocWriter.QUOTE, (byte) 35, (byte) 36, (byte) -9, (byte) -9, (byte) -9, (byte) -9, (byte) 37, (byte) -9, (byte) 38, (byte) 39, (byte) 40, (byte) 41, (byte) 42, (byte) 43, (byte) 44, (byte) 45, (byte) 46, DocWriter.FORWARD, ByteBuffer.ZERO, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 58, (byte) 59, DocWriter.LT, EQUALS_SIGN, DocWriter.GT, (byte) 63, (byte) -9, (byte) -9, (byte) -9, (byte) -9};
    }

    private static final byte[] getAlphabet(int options) {
        if ((options & URL_SAFE) == URL_SAFE) {
            return _URL_SAFE_ALPHABET;
        }
        if ((options & ORDERED) == ORDERED) {
            return _ORDERED_ALPHABET;
        }
        return _STANDARD_ALPHABET;
    }

    private static final byte[] getDecodabet(int options) {
        if ((options & URL_SAFE) == URL_SAFE) {
            return _URL_SAFE_DECODABET;
        }
        if ((options & ORDERED) == ORDERED) {
            return _ORDERED_DECODABET;
        }
        return _STANDARD_DECODABET;
    }

    private Base64() {
    }

    private static final void usage(String msg) {
        System.err.println(msg);
        System.err.println("Usage: java Base64 -e|-d inputfile outputfile");
    }

    private static byte[] encode3to4(byte[] b4, byte[] threeBytes, int numSigBytes, int options) {
        encode3to4(threeBytes, NO_OPTIONS, numSigBytes, b4, NO_OPTIONS, options);
        return b4;
    }

    private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, int options) {
        int i;
        int i2 = NO_OPTIONS;
        byte[] ALPHABET = getAlphabet(options);
        if (numSigBytes > 0) {
            i = (source[srcOffset] << 24) >>> DONT_BREAK_LINES;
        } else {
            i = NO_OPTIONS;
        }
        int i3 = (numSigBytes > ENCODE ? (source[srcOffset + ENCODE] << 24) >>> URL_SAFE : NO_OPTIONS) | i;
        if (numSigBytes > GZIP) {
            i2 = (source[srcOffset + GZIP] << 24) >>> 24;
        }
        int inBuff = i3 | i2;
        switch (numSigBytes) {
            case ENCODE /*1*/:
                destination[destOffset] = ALPHABET[inBuff >>> 18];
                destination[destOffset + ENCODE] = ALPHABET[(inBuff >>> 12) & 63];
                destination[destOffset + GZIP] = EQUALS_SIGN;
                destination[destOffset + 3] = EQUALS_SIGN;
                break;
            case GZIP /*2*/:
                destination[destOffset] = ALPHABET[inBuff >>> 18];
                destination[destOffset + ENCODE] = ALPHABET[(inBuff >>> 12) & 63];
                destination[destOffset + GZIP] = ALPHABET[(inBuff >>> 6) & 63];
                destination[destOffset + 3] = EQUALS_SIGN;
                break;
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                destination[destOffset] = ALPHABET[inBuff >>> 18];
                destination[destOffset + ENCODE] = ALPHABET[(inBuff >>> 12) & 63];
                destination[destOffset + GZIP] = ALPHABET[(inBuff >>> 6) & 63];
                destination[destOffset + 3] = ALPHABET[inBuff & 63];
                break;
        }
        return destination;
    }

    public static String encodeObject(Serializable serializableObject) {
        return encodeObject(serializableObject, NO_OPTIONS);
    }

    public static String encodeObject(Serializable serializableObject, int options) {
        IOException e;
        Throwable th;
        ByteArrayOutputStream baos = null;
        java.io.OutputStream b64os = null;
        ObjectOutputStream oos = null;
        GZIPOutputStream gzos = null;
        int gzip = options & GZIP;
        int dontBreakLines = options & DONT_BREAK_LINES;
        try {
            ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
            try {
                java.io.OutputStream b64os2 = new OutputStream(baos2, options | ENCODE);
                if (gzip == GZIP) {
                    try {
                        GZIPOutputStream gzos2 = new GZIPOutputStream(b64os2);
                        try {
                            gzos = gzos2;
                            oos = new ObjectOutputStream(gzos2);
                        } catch (IOException e2) {
                            e = e2;
                            gzos = gzos2;
                            b64os = b64os2;
                            baos = baos2;
                            try {
                                e.printStackTrace();
                                try {
                                    oos.close();
                                } catch (Exception e3) {
                                }
                                try {
                                    gzos.close();
                                } catch (Exception e4) {
                                }
                                try {
                                    b64os.close();
                                } catch (Exception e5) {
                                }
                                try {
                                    baos.close();
                                    return null;
                                } catch (Exception e6) {
                                    return null;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                try {
                                    oos.close();
                                } catch (Exception e7) {
                                }
                                try {
                                    gzos.close();
                                } catch (Exception e8) {
                                }
                                try {
                                    b64os.close();
                                } catch (Exception e9) {
                                }
                                try {
                                    baos.close();
                                } catch (Exception e10) {
                                }
                                throw th;
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            gzos = gzos2;
                            b64os = b64os2;
                            baos = baos2;
                            oos.close();
                            gzos.close();
                            b64os.close();
                            baos.close();
                            throw th;
                        }
                    } catch (IOException e11) {
                        e = e11;
                        b64os = b64os2;
                        baos = baos2;
                        e.printStackTrace();
                        oos.close();
                        gzos.close();
                        b64os.close();
                        baos.close();
                        return null;
                    } catch (Throwable th4) {
                        th = th4;
                        b64os = b64os2;
                        baos = baos2;
                        oos.close();
                        gzos.close();
                        b64os.close();
                        baos.close();
                        throw th;
                    }
                }
                oos = new ObjectOutputStream(b64os2);
                oos.writeObject(serializableObject);
                try {
                    oos.close();
                } catch (Exception e12) {
                }
                try {
                    gzos.close();
                } catch (Exception e13) {
                }
                try {
                    b64os2.close();
                } catch (Exception e14) {
                }
                try {
                    baos2.close();
                } catch (Exception e15) {
                }
                try {
                    b64os = b64os2;
                    baos = baos2;
                    return new String(baos2.toByteArray(), PREFERRED_ENCODING);
                } catch (UnsupportedEncodingException e16) {
                    b64os = b64os2;
                    baos = baos2;
                    return new String(baos2.toByteArray());
                }
            } catch (IOException e17) {
                e = e17;
                baos = baos2;
                e.printStackTrace();
                oos.close();
                gzos.close();
                b64os.close();
                baos.close();
                return null;
            } catch (Throwable th5) {
                th = th5;
                baos = baos2;
                oos.close();
                gzos.close();
                b64os.close();
                baos.close();
                throw th;
            }
        } catch (IOException e18) {
            e = e18;
            e.printStackTrace();
            oos.close();
            gzos.close();
            b64os.close();
            baos.close();
            return null;
        }
    }

    public static String encodeBytes(byte[] source) {
        return encodeBytes(source, NO_OPTIONS, source.length, NO_OPTIONS);
    }

    public static String encodeBytes(byte[] source, int options) {
        return encodeBytes(source, NO_OPTIONS, source.length, options);
    }

    public static String encodeBytes(byte[] source, int off, int len) {
        return encodeBytes(source, off, len, NO_OPTIONS);
    }

    public static String encodeBytes(byte[] source, int off, int len, int options) {
        OutputStream b64os;
        Throwable th;
        int dontBreakLines = options & DONT_BREAK_LINES;
        IOException e;
        if ((options & GZIP) == GZIP) {
            ByteArrayOutputStream baos = null;
            GZIPOutputStream gzos = null;
            OutputStream b64os2 = null;
            try {
                GZIPOutputStream gZIPOutputStream;
                ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
                try {
                    b64os = new OutputStream(baos2, options | ENCODE);
                    try {
                        gZIPOutputStream = new GZIPOutputStream(b64os);
                    } catch (IOException e2) {
                        e = e2;
                        b64os2 = b64os;
                        baos = baos2;
                        try {
                            e.printStackTrace();
                            try {
                                gzos.close();
                            } catch (Exception e3) {
                            }
                            try {
                                b64os2.close();
                            } catch (Exception e4) {
                            }
                            try {
                                baos.close();
                                return null;
                            } catch (Exception e5) {
                                return null;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            try {
                                gzos.close();
                            } catch (Exception e6) {
                            }
                            try {
                                b64os2.close();
                            } catch (Exception e7) {
                            }
                            try {
                                baos.close();
                            } catch (Exception e8) {
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        b64os2 = b64os;
                        baos = baos2;
                        gzos.close();
                        b64os2.close();
                        baos.close();
                        throw th;
                    }
                } catch (IOException e9) {
                    e = e9;
                    baos = baos2;
                    e.printStackTrace();
                    gzos.close();
                    b64os2.close();
                    baos.close();
                    return null;
                } catch (Throwable th4) {
                    th = th4;
                    baos = baos2;
                    gzos.close();
                    b64os2.close();
                    baos.close();
                    throw th;
                }
                try {
                    gZIPOutputStream.write(source, off, len);
                    gZIPOutputStream.close();
                    try {
                        gZIPOutputStream.close();
                    } catch (Exception e10) {
                    }
                    try {
                        b64os.close();
                    } catch (Exception e11) {
                    }
                    try {
                        baos2.close();
                    } catch (Exception e12) {
                    }
                    try {
                        return new String(baos2.toByteArray(), PREFERRED_ENCODING);
                    } catch (UnsupportedEncodingException e13) {
                        return new String(baos2.toByteArray());
                    }
                } catch (IOException e14) {
                    e = e14;
                    b64os2 = b64os;
                    gzos = gZIPOutputStream;
                    baos = baos2;
                    e.printStackTrace();
                    gzos.close();
                    b64os2.close();
                    baos.close();
                    return null;
                } catch (Throwable th5) {
                    th = th5;
                    b64os2 = b64os;
                    gzos = gZIPOutputStream;
                    baos = baos2;
                    gzos.close();
                    b64os2.close();
                    baos.close();
                    throw th;
                }
            } catch (IOException e15) {
                e = e15;
                e.printStackTrace();
                gzos.close();
                b64os2.close();
                baos.close();
                return null;
            }
        }
        int i;
        boolean breakLines = dontBreakLines == 0;
        int len43 = (len * 4) / 3;
        int i2 = len43 + (len % 3 > 0 ? 4 : NO_OPTIONS);
        if (breakLines) {
            i = len43 / MAX_LINE_LENGTH;
        } else {
            i = NO_OPTIONS;
        }
        byte[] outBuff = new byte[(i + i2)];
        int d = NO_OPTIONS;
        e = NO_OPTIONS;
        int len2 = len - 2;
        int lineLength = NO_OPTIONS;
        while (d < len2) {
            int e16;
            encode3to4(source, d + off, 3, outBuff, e, options);
            lineLength += 4;
            if (breakLines && lineLength == MAX_LINE_LENGTH) {
                outBuff[e + 4] = NEW_LINE;
                e16 = e + ENCODE;
                lineLength = NO_OPTIONS;
            }
            d += 3;
            e = e16 + 4;
        }
        if (d < len) {
            encode3to4(source, d + off, len - d, outBuff, e, options);
            e += 4;
        }
        try {
            return new String(outBuff, NO_OPTIONS, e, PREFERRED_ENCODING);
        } catch (UnsupportedEncodingException e17) {
            return new String(outBuff, NO_OPTIONS, e);
        }
    }

    private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, int options) {
        byte[] DECODABET = getDecodabet(options);
        if (source[srcOffset + GZIP] == EQUALS_SIGN) {
            destination[destOffset] = (byte) ((((DECODABET[source[srcOffset]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 18) | ((DECODABET[source[srcOffset + ENCODE]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 12)) >>> URL_SAFE);
            return ENCODE;
        } else if (source[srcOffset + 3] == EQUALS_SIGN) {
            outBuff = (((DECODABET[source[srcOffset]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 18) | ((DECODABET[source[srcOffset + ENCODE]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 12)) | ((DECODABET[source[srcOffset + GZIP]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 6);
            destination[destOffset] = (byte) (outBuff >>> URL_SAFE);
            destination[destOffset + ENCODE] = (byte) (outBuff >>> DONT_BREAK_LINES);
            return GZIP;
        } else {
            try {
                outBuff = ((((DECODABET[source[srcOffset]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 18) | ((DECODABET[source[srcOffset + ENCODE]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 12)) | ((DECODABET[source[srcOffset + GZIP]] & TIFFConstants.TIFFTAG_OSUBFILETYPE) << 6)) | (DECODABET[source[srcOffset + 3]] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
                destination[destOffset] = (byte) (outBuff >> URL_SAFE);
                destination[destOffset + ENCODE] = (byte) (outBuff >> DONT_BREAK_LINES);
                destination[destOffset + GZIP] = (byte) outBuff;
                return 3;
            } catch (Exception e) {
                System.out.println(PdfObject.NOTHING + source[srcOffset] + ": " + DECODABET[source[srcOffset]]);
                System.out.println(PdfObject.NOTHING + source[srcOffset + ENCODE] + ": " + DECODABET[source[srcOffset + ENCODE]]);
                System.out.println(PdfObject.NOTHING + source[srcOffset + GZIP] + ": " + DECODABET[source[srcOffset + GZIP]]);
                System.out.println(PdfObject.NOTHING + source[srcOffset + 3] + ": " + DECODABET[source[srcOffset + 3]]);
                return -1;
            }
        }
    }

    public static byte[] decode(byte[] source, int off, int len, int options) {
        int b4Posn;
        byte[] DECODABET = getDecodabet(options);
        byte[] outBuff = new byte[((len * 3) / 4)];
        int outBuffPosn = NO_OPTIONS;
        byte[] b4 = new byte[4];
        int i = off;
        int b4Posn2 = NO_OPTIONS;
        while (i < off + len) {
            byte sbiCrop = (byte) (source[i] & 127);
            byte sbiDecode = DECODABET[sbiCrop];
            if (sbiDecode >= -5) {
                if (sbiDecode >= -1) {
                    b4Posn = b4Posn2 + ENCODE;
                    b4[b4Posn2] = sbiCrop;
                    if (b4Posn > 3) {
                        outBuffPosn += decode4to3(b4, NO_OPTIONS, outBuff, outBuffPosn, options);
                        b4Posn = NO_OPTIONS;
                        if (sbiCrop == 61) {
                            break;
                        }
                    } else {
                        continue;
                    }
                } else {
                    b4Posn = b4Posn2;
                }
                i += ENCODE;
                b4Posn2 = b4Posn;
            } else {
                System.err.println("Bad Base64 input character at " + i + ": " + source[i] + "(decimal)");
                b4Posn = b4Posn2;
                return null;
            }
        }
        b4Posn = b4Posn2;
        byte[] out = new byte[outBuffPosn];
        System.arraycopy(outBuff, NO_OPTIONS, out, NO_OPTIONS, outBuffPosn);
        return out;
    }

    public static byte[] decode(String s) {
        return decode(s, NO_OPTIONS);
    }

    public static byte[] decode(String s, int options) {
        byte[] bytes;
        Throwable th;
        try {
            bytes = s.getBytes(PREFERRED_ENCODING);
        } catch (UnsupportedEncodingException e) {
            bytes = s.getBytes();
        }
        bytes = decode(bytes, NO_OPTIONS, bytes.length, options);
        if (bytes != null && bytes.length >= 4 && 35615 == ((bytes[NO_OPTIONS] & TIFFConstants.TIFFTAG_OSUBFILETYPE) | ((bytes[ENCODE] << DONT_BREAK_LINES) & 65280))) {
            ByteArrayInputStream bais = null;
            GZIPInputStream gzis = null;
            ByteArrayOutputStream baos = null;
            byte[] buffer = new byte[PdfWriter.PageModeUseAttachments];
            try {
                ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
                try {
                    ByteArrayInputStream bais2 = new ByteArrayInputStream(bytes);
                    try {
                        GZIPInputStream gzis2 = new GZIPInputStream(bais2);
                        while (true) {
                            try {
                                int length = gzis2.read(buffer);
                                if (length < 0) {
                                    break;
                                }
                                baos2.write(buffer, NO_OPTIONS, length);
                            } catch (IOException e2) {
                                baos = baos2;
                                gzis = gzis2;
                                bais = bais2;
                            } catch (Throwable th2) {
                                th = th2;
                                baos = baos2;
                                gzis = gzis2;
                                bais = bais2;
                            }
                        }
                        bytes = baos2.toByteArray();
                        try {
                            baos2.close();
                        } catch (Exception e3) {
                        }
                        try {
                            gzis2.close();
                        } catch (Exception e4) {
                        }
                        try {
                            bais2.close();
                        } catch (Exception e5) {
                        }
                    } catch (IOException e6) {
                        baos = baos2;
                        bais = bais2;
                        try {
                            baos.close();
                        } catch (Exception e7) {
                        }
                        try {
                            gzis.close();
                        } catch (Exception e8) {
                        }
                        try {
                            bais.close();
                        } catch (Exception e9) {
                        }
                        return bytes;
                    } catch (Throwable th3) {
                        th = th3;
                        baos = baos2;
                        bais = bais2;
                        try {
                            baos.close();
                        } catch (Exception e10) {
                        }
                        try {
                            gzis.close();
                        } catch (Exception e11) {
                        }
                        try {
                            bais.close();
                        } catch (Exception e12) {
                        }
                        throw th;
                    }
                } catch (IOException e13) {
                    baos = baos2;
                    baos.close();
                    gzis.close();
                    bais.close();
                    return bytes;
                } catch (Throwable th4) {
                    th = th4;
                    baos = baos2;
                    baos.close();
                    gzis.close();
                    bais.close();
                    throw th;
                }
            } catch (IOException e14) {
                baos.close();
                gzis.close();
                bais.close();
                return bytes;
            } catch (Throwable th5) {
                th = th5;
                baos.close();
                gzis.close();
                bais.close();
                throw th;
            }
        }
        return bytes;
    }

    public static Object decodeToObject(String encodedObject) {
        ObjectInputStream ois;
        IOException e;
        Throwable th;
        ClassNotFoundException e2;
        ByteArrayInputStream bais = null;
        ObjectInputStream ois2 = null;
        Object obj = null;
        try {
            ByteArrayInputStream bais2 = new ByteArrayInputStream(decode(encodedObject));
            try {
                ois = new ObjectInputStream(bais2);
            } catch (IOException e3) {
                e = e3;
                bais = bais2;
                try {
                    e.printStackTrace();
                    try {
                        bais.close();
                    } catch (Exception e4) {
                    }
                    try {
                        ois2.close();
                    } catch (Exception e5) {
                    }
                    return obj;
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        bais.close();
                    } catch (Exception e6) {
                    }
                    try {
                        ois2.close();
                    } catch (Exception e7) {
                    }
                    throw th;
                }
            } catch (ClassNotFoundException e8) {
                e2 = e8;
                bais = bais2;
                e2.printStackTrace();
                try {
                    bais.close();
                } catch (Exception e9) {
                }
                try {
                    ois2.close();
                } catch (Exception e10) {
                }
                return obj;
            } catch (Throwable th3) {
                th = th3;
                bais = bais2;
                bais.close();
                ois2.close();
                throw th;
            }
            try {
                obj = ois.readObject();
                try {
                    bais2.close();
                } catch (Exception e11) {
                }
                try {
                    ois.close();
                    ois2 = ois;
                    bais = bais2;
                } catch (Exception e12) {
                    ois2 = ois;
                    bais = bais2;
                }
            } catch (IOException e13) {
                e = e13;
                ois2 = ois;
                bais = bais2;
                e.printStackTrace();
                bais.close();
                ois2.close();
                return obj;
            } catch (ClassNotFoundException e14) {
                e2 = e14;
                ois2 = ois;
                bais = bais2;
                e2.printStackTrace();
                bais.close();
                ois2.close();
                return obj;
            } catch (Throwable th4) {
                th = th4;
                ois2 = ois;
                bais = bais2;
                bais.close();
                ois2.close();
                throw th;
            }
        } catch (IOException e15) {
            e = e15;
            e.printStackTrace();
            bais.close();
            ois2.close();
            return obj;
        } catch (ClassNotFoundException e16) {
            e2 = e16;
            e2.printStackTrace();
            bais.close();
            ois2.close();
            return obj;
        }
        return obj;
    }

    public static boolean encodeToFile(byte[] dataToEncode, String filename) {
        boolean success;
        Throwable th;
        OutputStream bos = null;
        try {
            OutputStream bos2 = new OutputStream(new FileOutputStream(filename), ENCODE);
            try {
                bos2.write(dataToEncode);
                success = true;
                try {
                    bos2.close();
                    bos = bos2;
                } catch (Exception e) {
                    bos = bos2;
                }
            } catch (IOException e2) {
                bos = bos2;
                success = false;
                try {
                    bos.close();
                } catch (Exception e3) {
                }
                return success;
            } catch (Throwable th2) {
                th = th2;
                bos = bos2;
                try {
                    bos.close();
                } catch (Exception e4) {
                }
                throw th;
            }
        } catch (IOException e5) {
            success = false;
            bos.close();
            return success;
        } catch (Throwable th3) {
            th = th3;
            bos.close();
            throw th;
        }
        return success;
    }

    public static boolean decodeToFile(String dataToDecode, String filename) {
        boolean success;
        Throwable th;
        OutputStream bos = null;
        try {
            OutputStream bos2 = new OutputStream(new FileOutputStream(filename), NO_OPTIONS);
            try {
                bos2.write(dataToDecode.getBytes(PREFERRED_ENCODING));
                success = true;
                try {
                    bos2.close();
                    bos = bos2;
                } catch (Exception e) {
                    bos = bos2;
                }
            } catch (IOException e2) {
                bos = bos2;
                success = false;
                try {
                    bos.close();
                } catch (Exception e3) {
                }
                return success;
            } catch (Throwable th2) {
                th = th2;
                bos = bos2;
                try {
                    bos.close();
                } catch (Exception e4) {
                }
                throw th;
            }
        } catch (IOException e5) {
            success = false;
            bos.close();
            return success;
        } catch (Throwable th3) {
            th = th3;
            bos.close();
            throw th;
        }
        return success;
    }

    public static byte[] decodeFromFile(String filename) {
        Throwable th;
        byte[] decodedData = null;
        InputStream bis = null;
        try {
            File file = new File(filename);
            int length = NO_OPTIONS;
            if (file.length() > 2147483647L) {
                System.err.println("File is too big for this convenience method (" + file.length() + " bytes).");
                if (bis == null) {
                    return null;
                }
                try {
                    bis.close();
                    return null;
                } catch (Exception e) {
                    return null;
                }
            }
            byte[] buffer = new byte[((int) file.length())];
            InputStream bis2 = new InputStream(new BufferedInputStream(new FileInputStream(file)), NO_OPTIONS);
            while (true) {
                try {
                    int numBytes = bis2.read(buffer, length, PdfWriter.HideToolbar);
                    if (numBytes < 0) {
                        break;
                    }
                    length += numBytes;
                } catch (IOException e2) {
                    bis = bis2;
                } catch (Throwable th2) {
                    th = th2;
                    bis = bis2;
                }
            }
            decodedData = new byte[length];
            System.arraycopy(buffer, NO_OPTIONS, decodedData, NO_OPTIONS, length);
            if (bis2 != null) {
                try {
                    bis2.close();
                    bis = bis2;
                } catch (Exception e3) {
                    bis = bis2;
                }
            }
            return decodedData;
        } catch (IOException e4) {
            try {
                System.err.println("Error decoding from file " + filename);
                if (bis != null) {
                    try {
                        bis.close();
                    } catch (Exception e5) {
                    }
                }
                return decodedData;
            } catch (Throwable th3) {
                th = th3;
                if (bis != null) {
                    try {
                        bis.close();
                    } catch (Exception e6) {
                    }
                }
                throw th;
            }
        }
    }

    public static String encodeFromFile(String filename) {
        Throwable th;
        InputStream bis = null;
        try {
            File file = new File(filename);
            byte[] buffer = new byte[Math.max((int) (((double) file.length()) * 1.4d), 40)];
            int length = NO_OPTIONS;
            InputStream bis2 = new InputStream(new BufferedInputStream(new FileInputStream(file)), ENCODE);
            while (true) {
                try {
                    int numBytes = bis2.read(buffer, length, PdfWriter.HideToolbar);
                    if (numBytes >= 0) {
                        length += numBytes;
                    } else {
                        String encodedData = new String(buffer, NO_OPTIONS, length, PREFERRED_ENCODING);
                        try {
                            bis2.close();
                            bis = bis2;
                            return encodedData;
                        } catch (Exception e) {
                            bis = bis2;
                            return encodedData;
                        }
                    }
                } catch (IOException e2) {
                    bis = bis2;
                } catch (Throwable th2) {
                    th = th2;
                    bis = bis2;
                }
            }
        } catch (IOException e3) {
            try {
                System.err.println("Error encoding from file " + filename);
                try {
                    bis.close();
                    return null;
                } catch (Exception e4) {
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                try {
                    bis.close();
                } catch (Exception e5) {
                }
                throw th;
            }
        }
    }

    public static void encodeFileToFile(String infile, String outfile) {
        IOException ex;
        Throwable th;
        String encoded = encodeFromFile(infile);
        java.io.OutputStream out = null;
        try {
            java.io.OutputStream out2 = new BufferedOutputStream(new FileOutputStream(outfile));
            try {
                out2.write(encoded.getBytes("US-ASCII"));
                try {
                    out2.close();
                    out = out2;
                } catch (Exception e) {
                    out = out2;
                }
            } catch (IOException e2) {
                ex = e2;
                out = out2;
                try {
                    ex.printStackTrace();
                    try {
                        out.close();
                    } catch (Exception e3) {
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        out.close();
                    } catch (Exception e4) {
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                out.close();
                throw th;
            }
        } catch (IOException e5) {
            ex = e5;
            ex.printStackTrace();
            out.close();
        }
    }

    public static void decodeFileToFile(String infile, String outfile) {
        IOException ex;
        Throwable th;
        byte[] decoded = decodeFromFile(infile);
        java.io.OutputStream out = null;
        try {
            java.io.OutputStream out2 = new BufferedOutputStream(new FileOutputStream(outfile));
            try {
                out2.write(decoded);
                try {
                    out2.close();
                    out = out2;
                } catch (Exception e) {
                    out = out2;
                }
            } catch (IOException e2) {
                ex = e2;
                out = out2;
                try {
                    ex.printStackTrace();
                    try {
                        out.close();
                    } catch (Exception e3) {
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        out.close();
                    } catch (Exception e4) {
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                out.close();
                throw th;
            }
        } catch (IOException e5) {
            ex = e5;
            ex.printStackTrace();
            out.close();
        }
    }
}

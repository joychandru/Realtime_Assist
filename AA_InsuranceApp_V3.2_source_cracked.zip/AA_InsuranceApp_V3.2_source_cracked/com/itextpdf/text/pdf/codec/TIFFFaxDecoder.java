package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.DocWriter;
import com.itextpdf.text.Jpeg;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.exceptions.InvalidImageException;
import com.itextpdf.text.pdf.BidiOrder;
import com.itextpdf.text.pdf.ByteBuffer;
import com.itextpdf.text.pdf.PdfContentParser;
import com.itextpdf.text.pdf.PdfWriter;

public class TIFFFaxDecoder {
    static short[] additionalMakeup;
    static short[] black;
    static byte[] flipTable;
    static short[] initBlack;
    static int[] table1;
    static int[] table2;
    static short[] twoBitBlack;
    static byte[] twoDCodes;
    static short[] white;
    private int bitPointer;
    private int bytePointer;
    private int changingElemSize;
    private int compression;
    private int[] currChangingElems;
    private byte[] data;
    private int fillBits;
    private int fillOrder;
    private int f22h;
    private int lastChangingElement;
    private int oneD;
    private int[] prevChangingElems;
    private boolean recoverFromImageError;
    private int uncompressedMode;
    private int f23w;

    static {
        table1 = new int[]{0, 1, 3, 7, 15, 31, 63, 127, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        table2 = new int[]{0, PdfWriter.PageModeUseOutlines, 192, Jpeg.M_APP0, 240, 248, 252, TIFFConstants.TIFFTAG_SUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        flipTable = new byte[]{(byte) 0, Byte.MIN_VALUE, (byte) 64, (byte) -64, DocWriter.SPACE, (byte) -96, (byte) 96, (byte) -32, BidiOrder.f13S, (byte) -112, (byte) 80, (byte) -48, ByteBuffer.ZERO, (byte) -80, (byte) 112, (byte) -16, (byte) 8, (byte) -120, (byte) 72, (byte) -56, (byte) 40, (byte) -88, (byte) 104, (byte) -24, (byte) 24, (byte) -104, (byte) 88, (byte) -40, (byte) 56, (byte) -72, (byte) 120, (byte) -8, (byte) 4, (byte) -124, (byte) 68, (byte) -60, (byte) 36, (byte) -92, (byte) 100, (byte) -28, (byte) 20, (byte) -108, (byte) 84, (byte) -44, (byte) 52, (byte) -76, (byte) 116, (byte) -12, BidiOrder.CS, (byte) -116, (byte) 76, (byte) -52, (byte) 44, (byte) -84, (byte) 108, (byte) -20, (byte) 28, (byte) -100, (byte) 92, (byte) -36, DocWriter.LT, (byte) -68, (byte) 124, (byte) -4, (byte) 2, (byte) -126, (byte) 66, (byte) -62, DocWriter.QUOTE, (byte) -94, (byte) 98, (byte) -30, BidiOrder.TYPE_MAX, (byte) -110, (byte) 82, (byte) -46, (byte) 50, (byte) -78, (byte) 114, (byte) -14, (byte) 10, (byte) -118, (byte) 74, (byte) -54, (byte) 42, (byte) -86, (byte) 106, (byte) -22, (byte) 26, (byte) -102, (byte) 90, (byte) -38, (byte) 58, (byte) -70, (byte) 122, (byte) -6, (byte) 6, (byte) -122, (byte) 70, (byte) -58, (byte) 38, (byte) -90, (byte) 102, (byte) -26, (byte) 22, (byte) -106, (byte) 86, (byte) -42, (byte) 54, (byte) -74, (byte) 118, (byte) -10, BidiOrder.BN, (byte) -114, (byte) 78, (byte) -50, (byte) 46, (byte) -82, (byte) 110, (byte) -18, (byte) 30, (byte) -98, (byte) 94, (byte) -34, DocWriter.GT, (byte) -66, (byte) 126, (byte) -2, (byte) 1, (byte) -127, (byte) 65, (byte) -63, (byte) 33, (byte) -95, (byte) 97, (byte) -31, BidiOrder.WS, (byte) -111, (byte) 81, (byte) -47, (byte) 49, (byte) -79, (byte) 113, (byte) -15, (byte) 9, (byte) -119, (byte) 73, (byte) -55, (byte) 41, (byte) -87, (byte) 105, (byte) -23, (byte) 25, (byte) -103, (byte) 89, (byte) -39, (byte) 57, (byte) -71, (byte) 121, (byte) -7, (byte) 5, (byte) -123, (byte) 69, (byte) -59, (byte) 37, (byte) -91, (byte) 101, (byte) -27, (byte) 21, (byte) -107, (byte) 85, (byte) -43, (byte) 53, (byte) -75, (byte) 117, (byte) -11, BidiOrder.NSM, (byte) -115, (byte) 77, (byte) -51, (byte) 45, (byte) -83, (byte) 109, (byte) -19, (byte) 29, (byte) -99, (byte) 93, (byte) -35, DocWriter.EQUALS, (byte) -67, (byte) 125, (byte) -3, (byte) 3, (byte) -125, (byte) 67, (byte) -61, (byte) 35, (byte) -93, (byte) 99, (byte) -29, (byte) 19, (byte) -109, (byte) 83, (byte) -45, (byte) 51, (byte) -77, (byte) 115, (byte) -13, BidiOrder.AN, (byte) -117, (byte) 75, (byte) -53, (byte) 43, (byte) -85, (byte) 107, (byte) -21, (byte) 27, (byte) -101, (byte) 91, (byte) -37, (byte) 59, (byte) -69, (byte) 123, (byte) -5, (byte) 7, (byte) -121, (byte) 71, (byte) -57, (byte) 39, (byte) -89, (byte) 103, (byte) -25, (byte) 23, (byte) -105, (byte) 87, (byte) -41, (byte) 55, (byte) -73, (byte) 119, (byte) -9, BidiOrder.f10B, (byte) -113, (byte) 79, (byte) -49, DocWriter.FORWARD, (byte) -81, (byte) 111, (byte) -17, (byte) 31, (byte) -97, (byte) 95, (byte) -33, (byte) 63, (byte) -65, Byte.MAX_VALUE, (byte) -1};
        white = new short[]{(short) 6430, (short) 6400, (short) 6400, (short) 6400, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 944, (short) 944, (short) 944, (short) 944, (short) 976, (short) 976, (short) 976, (short) 976, (short) 1456, (short) 1456, (short) 1456, (short) 1456, (short) 1488, (short) 1488, (short) 1488, (short) 1488, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 718, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 750, (short) 1520, (short) 1520, (short) 1520, (short) 1520, (short) 1552, (short) 1552, (short) 1552, (short) 1552, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 428, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 654, (short) 1072, (short) 1072, (short) 1072, (short) 1072, (short) 1104, (short) 1104, (short) 1104, (short) 1104, (short) 1136, (short) 1136, (short) 1136, (short) 1136, (short) 1168, (short) 1168, (short) 1168, (short) 1168, (short) 1200, (short) 1200, (short) 1200, (short) 1200, (short) 1232, (short) 1232, (short) 1232, (short) 1232, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 622, (short) 1008, (short) 1008, (short) 1008, (short) 1008, (short) 1040, (short) 1040, (short) 1040, (short) 1040, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 44, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 396, (short) 1712, (short) 1712, (short) 1712, (short) 1712, (short) 1744, (short) 1744, (short) 1744, (short) 1744, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 846, (short) 1264, (short) 1264, (short) 1264, (short) 1264, (short) 1296, (short) 1296, (short) 1296, (short) 1296, (short) 1328, (short) 1328, (short) 1328, (short) 1328, (short) 1360, (short) 1360, (short) 1360, (short) 1360, (short) 1392, (short) 1392, (short) 1392, (short) 1392, (short) 1424, (short) 1424, (short) 1424, (short) 1424, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 686, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 910, (short) 1968, (short) 1968, (short) 1968, (short) 1968, (short) 2000, (short) 2000, (short) 2000, (short) 2000, (short) 2032, (short) 2032, (short) 2032, (short) 2032, (short) 16, (short) 16, (short) 16, (short) 16, (short) 10257, (short) 10257, (short) 10257, (short) 10257, (short) 12305, (short) 12305, (short) 12305, (short) 12305, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 330, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 362, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 878, (short) 1904, (short) 1904, (short) 1904, (short) 1904, (short) 1936, (short) 1936, (short) 1936, (short) 1936, (short) -18413, (short) -18413, (short) -16365, (short) -16365, (short) -14317, (short) -14317, (short) -10221, (short) -10221, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 590, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 782, (short) 1584, (short) 1584, (short) 1584, (short) 1584, (short) 1616, (short) 1616, (short) 1616, (short) 1616, (short) 1648, (short) 1648, (short) 1648, (short) 1648, (short) 1680, (short) 1680, (short) 1680, (short) 1680, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 814, (short) 1776, (short) 1776, (short) 1776, (short) 1776, (short) 1808, (short) 1808, (short) 1808, (short) 1808, (short) 1840, (short) 1840, (short) 1840, (short) 1840, (short) 1872, (short) 1872, (short) 1872, (short) 1872, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) 6157, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) -12275, (short) 14353, (short) 14353, (short) 14353, (short) 14353, (short) 16401, (short) 16401, (short) 16401, (short) 16401, (short) 22547, (short) 22547, (short) 24595, (short) 24595, (short) 20497, (short) 20497, (short) 20497, (short) 20497, (short) 18449, (short) 18449, (short) 18449, (short) 18449, (short) 26643, (short) 26643, (short) 28691, (short) 28691, (short) 30739, (short) 30739, (short) -32749, (short) -32749, (short) -30701, (short) -30701, (short) -28653, (short) -28653, (short) -26605, (short) -26605, (short) -24557, (short) -24557, (short) -22509, (short) -22509, (short) -20461, (short) -20461, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 8207, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 72, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 104, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 4107, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 266, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 298, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 136, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 168, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 460, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 492, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 2059, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 200, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232, (short) 232};
        additionalMakeup = new short[]{(short) 28679, (short) 28679, (short) 31752, (short) -32759, (short) -31735, (short) -30711, (short) -29687, (short) -28663, (short) 29703, (short) 29703, (short) 30727, (short) 30727, (short) -27639, (short) -26615, (short) -25591, (short) -24567};
        initBlack = new short[]{(short) 3226, (short) 6412, (short) 200, (short) 168, (short) 38, (short) 38, (short) 134, (short) 134, (short) 100, (short) 100, (short) 100, (short) 100, (short) 68, (short) 68, (short) 68, (short) 68};
        twoBitBlack = new short[]{(short) 292, (short) 260, (short) 226, (short) 226};
        black = new short[]{(short) 62, (short) 62, (short) 30, (short) 30, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 0, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 3225, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 588, (short) 1680, (short) 1680, (short) 20499, (short) 22547, (short) 24595, (short) 26643, (short) 1776, (short) 1776, (short) 1808, (short) 1808, (short) -24557, (short) -22509, (short) -20461, (short) -18413, (short) 1904, (short) 1904, (short) 1936, (short) 1936, (short) -16365, (short) -14317, (short) 782, (short) 782, (short) 782, (short) 782, (short) 814, (short) 814, (short) 814, (short) 814, (short) -12269, (short) -10221, (short) 10257, (short) 10257, (short) 12305, (short) 12305, (short) 14353, (short) 14353, (short) 16403, (short) 18451, (short) 1712, (short) 1712, (short) 1744, (short) 1744, (short) 28691, (short) 30739, (short) -32749, (short) -30701, (short) -28653, (short) -26605, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 2061, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 424, (short) 750, (short) 750, (short) 750, (short) 750, (short) 1616, (short) 1616, (short) 1648, (short) 1648, (short) 1424, (short) 1424, (short) 1456, (short) 1456, (short) 1488, (short) 1488, (short) 1520, (short) 1520, (short) 1840, (short) 1840, (short) 1872, (short) 1872, (short) 1968, (short) 1968, (short) 8209, (short) 8209, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 524, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 556, (short) 1552, (short) 1552, (short) 1584, (short) 1584, (short) 2000, (short) 2000, (short) 2032, (short) 2032, (short) 976, (short) 976, (short) 1008, (short) 1008, (short) 1040, (short) 1040, (short) 1072, (short) 1072, (short) 1296, (short) 1296, (short) 1328, (short) 1328, (short) 718, (short) 718, (short) 718, (short) 718, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 456, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 326, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 358, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 490, (short) 4113, (short) 4113, (short) 6161, (short) 6161, (short) 848, (short) 848, (short) 880, (short) 880, (short) 912, (short) 912, (short) 944, (short) 944, (short) 622, (short) 622, (short) 622, (short) 622, (short) 654, (short) 654, (short) 654, (short) 654, (short) 1104, (short) 1104, (short) 1136, (short) 1136, (short) 1168, (short) 1168, (short) 1200, (short) 1200, (short) 1232, (short) 1232, (short) 1264, (short) 1264, (short) 686, (short) 686, (short) 686, (short) 686, (short) 1360, (short) 1360, (short) 1392, (short) 1392, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 12, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390, (short) 390};
        twoDCodes = new byte[]{(byte) 80, (byte) 88, (byte) 23, (byte) 71, (byte) 30, (byte) 30, DocWriter.GT, DocWriter.GT, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, (byte) 4, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, BidiOrder.AN, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 35, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 51, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41, (byte) 41};
    }

    public TIFFFaxDecoder(int fillOrder, int w, int h) {
        this.changingElemSize = 0;
        this.lastChangingElement = 0;
        this.compression = 2;
        this.uncompressedMode = 0;
        this.fillBits = 0;
        this.fillOrder = fillOrder;
        this.f23w = w;
        this.f22h = h;
        this.bitPointer = 0;
        this.bytePointer = 0;
        this.prevChangingElems = new int[(w * 2)];
        this.currChangingElems = new int[(w * 2)];
    }

    public static void reverseBits(byte[] b) {
        for (int k = 0; k < b.length; k++) {
            b[k] = flipTable[b[k] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
        }
    }

    public void decode1D(byte[] buffer, byte[] compData, int startX, int height) {
        this.data = compData;
        int lineOffset = 0;
        int scanlineStride = (this.f23w + 7) / 8;
        this.bitPointer = 0;
        this.bytePointer = 0;
        for (int i = 0; i < height; i++) {
            decodeNextScanline(buffer, lineOffset, startX);
            lineOffset += scanlineStride;
        }
    }

    public void decodeNextScanline(byte[] buffer, int lineOffset, int bitOffset) {
        int[] iArr;
        int i;
        boolean isWhite = true;
        this.changingElemSize = 0;
        while (bitOffset < this.f23w) {
            while (isWhite) {
                int current = nextNBits(10);
                int entry = white[current];
                int isT = entry & 1;
                int bits = (entry >>> 1) & 15;
                if (bits == 12) {
                    entry = additionalMakeup[((current << 2) & 12) | nextLesserThan8Bits(2)];
                    bitOffset += (entry >>> 4) & 4095;
                    updatePointer(4 - ((entry >>> 1) & 7));
                } else if (bits == 0) {
                    throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.code.encountered", new Object[0]));
                } else if (bits == 15) {
                    throw new RuntimeException(MessageLocalization.getComposedMessage("eol.code.word.encountered.in.white.run", new Object[0]));
                } else {
                    bitOffset += (entry >>> 5) & 2047;
                    updatePointer(10 - bits);
                    if (isT == 0) {
                        isWhite = false;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    }
                }
            }
            if (bitOffset != this.f23w) {
                while (!isWhite) {
                    entry = initBlack[nextLesserThan8Bits(4)];
                    isT = entry & 1;
                    bits = (entry >>> 1) & 15;
                    int code = (entry >>> 5) & 2047;
                    if (code == 100) {
                        entry = black[nextNBits(9)];
                        isT = entry & 1;
                        bits = (entry >>> 1) & 15;
                        code = (entry >>> 5) & 2047;
                        if (bits == 12) {
                            updatePointer(5);
                            entry = additionalMakeup[nextLesserThan8Bits(4)];
                            bits = (entry >>> 1) & 7;
                            code = (entry >>> 4) & 4095;
                            setToBlack(buffer, lineOffset, bitOffset, code);
                            bitOffset += code;
                            updatePointer(4 - bits);
                        } else if (bits == 15) {
                            throw new RuntimeException(MessageLocalization.getComposedMessage("eol.code.word.encountered.in.black.run", new Object[0]));
                        } else {
                            setToBlack(buffer, lineOffset, bitOffset, code);
                            bitOffset += code;
                            updatePointer(9 - bits);
                            if (isT == 0) {
                                isWhite = true;
                                iArr = this.currChangingElems;
                                i = this.changingElemSize;
                                this.changingElemSize = i + 1;
                                iArr[i] = bitOffset;
                            }
                        }
                    } else if (code == PdfContentParser.COMMAND_TYPE) {
                        entry = twoBitBlack[nextLesserThan8Bits(2)];
                        code = (entry >>> 5) & 2047;
                        bits = (entry >>> 1) & 15;
                        setToBlack(buffer, lineOffset, bitOffset, code);
                        bitOffset += code;
                        updatePointer(2 - bits);
                        isWhite = true;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    } else {
                        setToBlack(buffer, lineOffset, bitOffset, code);
                        bitOffset += code;
                        updatePointer(4 - bits);
                        isWhite = true;
                        iArr = this.currChangingElems;
                        i = this.changingElemSize;
                        this.changingElemSize = i + 1;
                        iArr[i] = bitOffset;
                    }
                }
                if (bitOffset == this.f23w) {
                    if (this.compression == 2) {
                        advancePointer();
                    }
                }
            } else if (this.compression == 2) {
                advancePointer();
            }
            iArr = this.currChangingElems;
            i = this.changingElemSize;
            this.changingElemSize = i + 1;
            iArr[i] = bitOffset;
        }
        iArr = this.currChangingElems;
        i = this.changingElemSize;
        this.changingElemSize = i + 1;
        iArr[i] = bitOffset;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void decode2D(byte[] r24, byte[] r25, int r26, int r27, long r28) {
        /*
        r23 = this;
        r0 = r25;
        r1 = r23;
        r1.data = r0;
        r20 = 3;
        r0 = r20;
        r1 = r23;
        r1.compression = r0;
        r20 = 0;
        r0 = r20;
        r1 = r23;
        r1.bitPointer = r0;
        r20 = 0;
        r0 = r20;
        r1 = r23;
        r1.bytePointer = r0;
        r0 = r23;
        r0 = r0.f23w;
        r20 = r0;
        r20 = r20 + 7;
        r18 = r20 / 8;
        r20 = 2;
        r0 = r20;
        r5 = new int[r0];
        r11 = 0;
        r20 = 1;
        r20 = r20 & r28;
        r0 = r20;
        r0 = (int) r0;
        r20 = r0;
        r0 = r20;
        r1 = r23;
        r1.oneD = r0;
        r20 = 2;
        r20 = r20 & r28;
        r22 = 1;
        r20 = r20 >> r22;
        r0 = r20;
        r0 = (int) r0;
        r20 = r0;
        r0 = r20;
        r1 = r23;
        r1.uncompressedMode = r0;
        r20 = 4;
        r20 = r20 & r28;
        r22 = 2;
        r20 = r20 >> r22;
        r0 = r20;
        r0 = (int) r0;
        r20 = r0;
        r0 = r20;
        r1 = r23;
        r1.fillBits = r0;
        r20 = 1;
        r0 = r23;
        r1 = r20;
        r20 = r0.readEOL(r1);
        r21 = 1;
        r0 = r20;
        r1 = r21;
        if (r0 == r1) goto L_0x008a;
    L_0x0076:
        r20 = new java.lang.RuntimeException;
        r21 = "first.scanline.must.be.1d.encoded";
        r22 = 0;
        r0 = r22;
        r0 = new java.lang.Object[r0];
        r22 = r0;
        r21 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r21, r22);
        r20.<init>(r21);
        throw r20;
    L_0x008a:
        r15 = 0;
        r0 = r23;
        r1 = r24;
        r2 = r26;
        r0.decodeNextScanline(r1, r15, r2);
        r15 = r15 + r18;
        r16 = 1;
    L_0x0098:
        r0 = r16;
        r1 = r27;
        if (r0 >= r1) goto L_0x01e7;
    L_0x009e:
        r20 = 0;
        r0 = r23;
        r1 = r20;
        r20 = r0.readEOL(r1);
        if (r20 != 0) goto L_0x01dd;
    L_0x00aa:
        r0 = r23;
        r0 = r0.prevChangingElems;
        r19 = r0;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r0 = r20;
        r1 = r23;
        r1.prevChangingElems = r0;
        r0 = r19;
        r1 = r23;
        r1.currChangingElems = r0;
        r11 = 0;
        r3 = -1;
        r14 = 1;
        r8 = r26;
        r20 = 0;
        r0 = r20;
        r1 = r23;
        r1.lastChangingElement = r0;
    L_0x00cf:
        r0 = r23;
        r0 = r0.f23w;
        r20 = r0;
        r0 = r20;
        if (r8 >= r0) goto L_0x01c8;
    L_0x00d9:
        r0 = r23;
        r0.getNextChangingElement(r3, r14, r5);
        r20 = 0;
        r6 = r5[r20];
        r20 = 1;
        r7 = r5[r20];
        r20 = 7;
        r0 = r23;
        r1 = r20;
        r13 = r0.nextLesserThan8Bits(r1);
        r20 = twoDCodes;
        r20 = r20[r13];
        r0 = r20;
        r13 = r0 & 255;
        r20 = r13 & 120;
        r10 = r20 >>> 3;
        r9 = r13 & 7;
        if (r10 != 0) goto L_0x0119;
    L_0x0100:
        if (r14 != 0) goto L_0x010d;
    L_0x0102:
        r20 = r7 - r8;
        r0 = r23;
        r1 = r24;
        r2 = r20;
        r0.setToBlack(r1, r15, r8, r2);
    L_0x010d:
        r3 = r7;
        r8 = r7;
        r20 = 7 - r9;
        r0 = r23;
        r1 = r20;
        r0.updatePointer(r1);
        goto L_0x00cf;
    L_0x0119:
        r20 = 1;
        r0 = r20;
        if (r10 != r0) goto L_0x0180;
    L_0x011f:
        r20 = 7 - r9;
        r0 = r23;
        r1 = r20;
        r0.updatePointer(r1);
        if (r14 == 0) goto L_0x0156;
    L_0x012a:
        r17 = r23.decodeWhiteCodeWord();
        r8 = r8 + r17;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r12 = r11 + 1;
        r20[r11] = r8;
        r17 = r23.decodeBlackCodeWord();
        r0 = r23;
        r1 = r24;
        r2 = r17;
        r0.setToBlack(r1, r15, r8, r2);
        r8 = r8 + r17;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r11 = r12 + 1;
        r20[r12] = r8;
    L_0x0153:
        r3 = r8;
        goto L_0x00cf;
    L_0x0156:
        r17 = r23.decodeBlackCodeWord();
        r0 = r23;
        r1 = r24;
        r2 = r17;
        r0.setToBlack(r1, r15, r8, r2);
        r8 = r8 + r17;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r12 = r11 + 1;
        r20[r11] = r8;
        r17 = r23.decodeWhiteCodeWord();
        r8 = r8 + r17;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r11 = r12 + 1;
        r20[r12] = r8;
        goto L_0x0153;
    L_0x0180:
        r20 = 8;
        r0 = r20;
        if (r10 > r0) goto L_0x01b4;
    L_0x0186:
        r20 = r10 + -5;
        r4 = r6 + r20;
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r12 = r11 + 1;
        r20[r11] = r4;
        if (r14 != 0) goto L_0x01a1;
    L_0x0196:
        r20 = r4 - r8;
        r0 = r23;
        r1 = r24;
        r2 = r20;
        r0.setToBlack(r1, r15, r8, r2);
    L_0x01a1:
        r3 = r4;
        r8 = r4;
        if (r14 != 0) goto L_0x01b2;
    L_0x01a5:
        r14 = 1;
    L_0x01a6:
        r20 = 7 - r9;
        r0 = r23;
        r1 = r20;
        r0.updatePointer(r1);
        r11 = r12;
        goto L_0x00cf;
    L_0x01b2:
        r14 = 0;
        goto L_0x01a6;
    L_0x01b4:
        r20 = new java.lang.RuntimeException;
        r21 = "invalid.code.encountered.while.decoding.2d.group.3.compressed.data";
        r22 = 0;
        r0 = r22;
        r0 = new java.lang.Object[r0];
        r22 = r0;
        r21 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r21, r22);
        r20.<init>(r21);
        throw r20;
    L_0x01c8:
        r0 = r23;
        r0 = r0.currChangingElems;
        r20 = r0;
        r12 = r11 + 1;
        r20[r11] = r8;
        r0 = r23;
        r0.changingElemSize = r12;
        r11 = r12;
    L_0x01d7:
        r15 = r15 + r18;
        r16 = r16 + 1;
        goto L_0x0098;
    L_0x01dd:
        r0 = r23;
        r1 = r24;
        r2 = r26;
        r0.decodeNextScanline(r1, r15, r2);
        goto L_0x01d7;
    L_0x01e7:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.TIFFFaxDecoder.decode2D(byte[], byte[], int, int, long):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void decodeT6(byte[] r28, byte[] r29, int r30, int r31, long r32) {
        /*
        r27 = this;
        r0 = r29;
        r1 = r27;
        r1.data = r0;
        r24 = 4;
        r0 = r24;
        r1 = r27;
        r1.compression = r0;
        r24 = 0;
        r0 = r24;
        r1 = r27;
        r1.bitPointer = r0;
        r24 = 0;
        r0 = r24;
        r1 = r27;
        r1.bytePointer = r0;
        r0 = r27;
        r0 = r0.f23w;
        r24 = r0;
        r24 = r24 + 7;
        r21 = r24 / 8;
        r24 = 2;
        r0 = r24;
        r6 = new int[r0];
        r24 = 2;
        r24 = r24 & r32;
        r26 = 1;
        r24 = r24 >> r26;
        r0 = r24;
        r0 = (int) r0;
        r24 = r0;
        r0 = r24;
        r1 = r27;
        r1.uncompressedMode = r0;
        r0 = r27;
        r11 = r0.currChangingElems;
        r24 = 0;
        r0 = r24;
        r1 = r27;
        r1.changingElemSize = r0;
        r0 = r27;
        r0 = r0.changingElemSize;
        r24 = r0;
        r25 = r24 + 1;
        r0 = r25;
        r1 = r27;
        r1.changingElemSize = r0;
        r0 = r27;
        r0 = r0.f23w;
        r25 = r0;
        r11[r24] = r25;
        r0 = r27;
        r0 = r0.changingElemSize;
        r24 = r0;
        r25 = r24 + 1;
        r0 = r25;
        r1 = r27;
        r1.changingElemSize = r0;
        r0 = r27;
        r0 = r0.f23w;
        r25 = r0;
        r11[r24] = r25;
        r18 = 0;
        r19 = 0;
    L_0x007d:
        r0 = r19;
        r1 = r31;
        if (r0 >= r1) goto L_0x026b;
    L_0x0083:
        r4 = -1;
        r17 = 1;
        r0 = r27;
        r0 = r0.prevChangingElems;
        r22 = r0;
        r0 = r27;
        r0 = r0.currChangingElems;
        r24 = r0;
        r0 = r24;
        r1 = r27;
        r1.prevChangingElems = r0;
        r0 = r22;
        r1 = r27;
        r1.currChangingElems = r0;
        r11 = r22;
        r13 = 0;
        r9 = r30;
        r24 = 0;
        r0 = r24;
        r1 = r27;
        r1.lastChangingElement = r0;
    L_0x00ab:
        r0 = r27;
        r0 = r0.f23w;
        r24 = r0;
        r0 = r24;
        if (r9 >= r0) goto L_0x0255;
    L_0x00b5:
        r0 = r27;
        r0 = r0.bytePointer;
        r24 = r0;
        r0 = r27;
        r0 = r0.data;
        r25 = r0;
        r0 = r25;
        r0 = r0.length;
        r25 = r0;
        r0 = r24;
        r1 = r25;
        if (r0 >= r1) goto L_0x0255;
    L_0x00cc:
        r0 = r27;
        r1 = r17;
        r0.getNextChangingElement(r4, r1, r6);
        r24 = 0;
        r7 = r6[r24];
        r24 = 1;
        r8 = r6[r24];
        r24 = 7;
        r0 = r27;
        r1 = r24;
        r15 = r0.nextLesserThan8Bits(r1);
        r24 = twoDCodes;
        r24 = r24[r15];
        r0 = r24;
        r15 = r0 & 255;
        r24 = r15 & 120;
        r12 = r24 >>> 3;
        r10 = r15 & 7;
        if (r12 != 0) goto L_0x0110;
    L_0x00f5:
        if (r17 != 0) goto L_0x0104;
    L_0x00f7:
        r24 = r8 - r9;
        r0 = r27;
        r1 = r28;
        r2 = r18;
        r3 = r24;
        r0.setToBlack(r1, r2, r9, r3);
    L_0x0104:
        r4 = r8;
        r9 = r8;
        r24 = 7 - r10;
        r0 = r27;
        r1 = r24;
        r0.updatePointer(r1);
        goto L_0x00ab;
    L_0x0110:
        r24 = 1;
        r0 = r24;
        if (r12 != r0) goto L_0x0163;
    L_0x0116:
        r24 = 7 - r10;
        r0 = r27;
        r1 = r24;
        r0.updatePointer(r1);
        if (r17 == 0) goto L_0x0143;
    L_0x0121:
        r20 = r27.decodeWhiteCodeWord();
        r9 = r9 + r20;
        r14 = r13 + 1;
        r11[r13] = r9;
        r20 = r27.decodeBlackCodeWord();
        r0 = r27;
        r1 = r28;
        r2 = r18;
        r3 = r20;
        r0.setToBlack(r1, r2, r9, r3);
        r9 = r9 + r20;
        r13 = r14 + 1;
        r11[r14] = r9;
    L_0x0140:
        r4 = r9;
        goto L_0x00ab;
    L_0x0143:
        r20 = r27.decodeBlackCodeWord();
        r0 = r27;
        r1 = r28;
        r2 = r18;
        r3 = r20;
        r0.setToBlack(r1, r2, r9, r3);
        r9 = r9 + r20;
        r14 = r13 + 1;
        r11[r13] = r9;
        r20 = r27.decodeWhiteCodeWord();
        r9 = r9 + r20;
        r13 = r14 + 1;
        r11[r14] = r9;
        goto L_0x0140;
    L_0x0163:
        r24 = 8;
        r0 = r24;
        if (r12 > r0) goto L_0x0195;
    L_0x0169:
        r24 = r12 + -5;
        r5 = r7 + r24;
        r14 = r13 + 1;
        r11[r13] = r5;
        if (r17 != 0) goto L_0x0180;
    L_0x0173:
        r24 = r5 - r9;
        r0 = r27;
        r1 = r28;
        r2 = r18;
        r3 = r24;
        r0.setToBlack(r1, r2, r9, r3);
    L_0x0180:
        r4 = r5;
        r9 = r5;
        if (r17 != 0) goto L_0x0192;
    L_0x0184:
        r17 = 1;
    L_0x0186:
        r24 = 7 - r10;
        r0 = r27;
        r1 = r24;
        r0.updatePointer(r1);
        r13 = r14;
        goto L_0x00ab;
    L_0x0192:
        r17 = 0;
        goto L_0x0186;
    L_0x0195:
        r24 = 11;
        r0 = r24;
        if (r12 != r0) goto L_0x0246;
    L_0x019b:
        r24 = 3;
        r0 = r27;
        r1 = r24;
        r24 = r0.nextLesserThan8Bits(r1);
        r25 = 7;
        r0 = r24;
        r1 = r25;
        if (r0 == r1) goto L_0x01c1;
    L_0x01ad:
        r24 = new com.itextpdf.text.exceptions.InvalidImageException;
        r25 = "invalid.code.encountered.while.decoding.2d.group.4.compressed.data";
        r26 = 0;
        r0 = r26;
        r0 = new java.lang.Object[r0];
        r26 = r0;
        r25 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r25, r26);
        r24.<init>(r25);
        throw r24;
    L_0x01c1:
        r23 = 0;
        r16 = 0;
        r14 = r13;
    L_0x01c6:
        if (r16 != 0) goto L_0x0243;
    L_0x01c8:
        r24 = 1;
        r0 = r27;
        r1 = r24;
        r24 = r0.nextLesserThan8Bits(r1);
        r25 = 1;
        r0 = r24;
        r1 = r25;
        if (r0 == r1) goto L_0x01dd;
    L_0x01da:
        r23 = r23 + 1;
        goto L_0x01c8;
    L_0x01dd:
        r24 = 5;
        r0 = r23;
        r1 = r24;
        if (r0 <= r1) goto L_0x020d;
    L_0x01e5:
        r23 = r23 + -6;
        if (r17 != 0) goto L_0x01f0;
    L_0x01e9:
        if (r23 <= 0) goto L_0x01f0;
    L_0x01eb:
        r13 = r14 + 1;
        r11[r14] = r9;
        r14 = r13;
    L_0x01f0:
        r9 = r9 + r23;
        if (r23 <= 0) goto L_0x01f6;
    L_0x01f4:
        r17 = 1;
    L_0x01f6:
        r24 = 1;
        r0 = r27;
        r1 = r24;
        r24 = r0.nextLesserThan8Bits(r1);
        if (r24 != 0) goto L_0x0221;
    L_0x0202:
        if (r17 != 0) goto L_0x0270;
    L_0x0204:
        r13 = r14 + 1;
        r11[r14] = r9;
    L_0x0208:
        r17 = 1;
    L_0x020a:
        r16 = 1;
        r14 = r13;
    L_0x020d:
        r24 = 5;
        r0 = r23;
        r1 = r24;
        if (r0 != r1) goto L_0x022a;
    L_0x0215:
        if (r17 != 0) goto L_0x026c;
    L_0x0217:
        r13 = r14 + 1;
        r11[r14] = r9;
    L_0x021b:
        r9 = r9 + r23;
        r17 = 1;
        r14 = r13;
        goto L_0x01c6;
    L_0x0221:
        if (r17 == 0) goto L_0x026e;
    L_0x0223:
        r13 = r14 + 1;
        r11[r14] = r9;
    L_0x0227:
        r17 = 0;
        goto L_0x020a;
    L_0x022a:
        r9 = r9 + r23;
        r13 = r14 + 1;
        r11[r14] = r9;
        r24 = 1;
        r0 = r27;
        r1 = r28;
        r2 = r18;
        r3 = r24;
        r0.setToBlack(r1, r2, r9, r3);
        r9 = r9 + 1;
        r17 = 0;
        r14 = r13;
        goto L_0x01c6;
    L_0x0243:
        r13 = r14;
        goto L_0x00ab;
    L_0x0246:
        r0 = r27;
        r9 = r0.f23w;
        r24 = 7 - r10;
        r0 = r27;
        r1 = r24;
        r0.updatePointer(r1);
        goto L_0x00ab;
    L_0x0255:
        r0 = r11.length;
        r24 = r0;
        r0 = r24;
        if (r13 >= r0) goto L_0x0261;
    L_0x025c:
        r14 = r13 + 1;
        r11[r13] = r9;
        r13 = r14;
    L_0x0261:
        r0 = r27;
        r0.changingElemSize = r13;
        r18 = r18 + r21;
        r19 = r19 + 1;
        goto L_0x007d;
    L_0x026b:
        return;
    L_0x026c:
        r13 = r14;
        goto L_0x021b;
    L_0x026e:
        r13 = r14;
        goto L_0x0227;
    L_0x0270:
        r13 = r14;
        goto L_0x0208;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.codec.TIFFFaxDecoder.decodeT6(byte[], byte[], int, int, long):void");
    }

    private void setToBlack(byte[] buffer, int lineOffset, int bitOffset, int numBits) {
        int bitNum = (lineOffset * 8) + bitOffset;
        int lastBit = bitNum + numBits;
        int byteNum = bitNum >> 3;
        int shift = bitNum & 7;
        if (shift > 0) {
            int maskVal = 1 << (7 - shift);
            byte val = buffer[byteNum];
            while (maskVal > 0 && bitNum < lastBit) {
                val = (byte) (val | maskVal);
                maskVal >>= 1;
                bitNum++;
            }
            buffer[byteNum] = val;
        }
        int byteNum2 = bitNum >> 3;
        while (bitNum < lastBit - 7) {
            byteNum = byteNum2 + 1;
            buffer[byteNum2] = (byte) -1;
            bitNum += 8;
            byteNum2 = byteNum;
        }
        while (bitNum < lastBit) {
            byteNum = bitNum >> 3;
            if (!this.recoverFromImageError || byteNum < buffer.length) {
                buffer[byteNum] = (byte) (buffer[byteNum] | (1 << (7 - (bitNum & 7))));
            }
            bitNum++;
        }
    }

    private int decodeWhiteCodeWord() {
        int runLength = 0;
        boolean isWhite = true;
        while (isWhite) {
            int current = nextNBits(10);
            int entry = white[current];
            int isT = entry & 1;
            int bits = (entry >>> 1) & 15;
            if (bits == 12) {
                entry = additionalMakeup[((current << 2) & 12) | nextLesserThan8Bits(2)];
                runLength += (entry >>> 4) & 4095;
                updatePointer(4 - ((entry >>> 1) & 7));
            } else if (bits == 0) {
                throw new InvalidImageException(MessageLocalization.getComposedMessage("invalid.code.encountered", new Object[0]));
            } else if (bits != 15) {
                runLength += (entry >>> 5) & 2047;
                updatePointer(10 - bits);
                if (isT == 0) {
                    isWhite = false;
                }
            } else if (runLength == 0) {
                isWhite = false;
            } else {
                throw new RuntimeException(MessageLocalization.getComposedMessage("eol.code.word.encountered.in.white.run", new Object[0]));
            }
        }
        return runLength;
    }

    private int decodeBlackCodeWord() {
        int runLength = 0;
        boolean isWhite = false;
        while (!isWhite) {
            int entry = initBlack[nextLesserThan8Bits(4)];
            int isT = entry & 1;
            int bits = (entry >>> 1) & 15;
            int code = (entry >>> 5) & 2047;
            if (code == 100) {
                entry = black[nextNBits(9)];
                isT = entry & 1;
                bits = (entry >>> 1) & 15;
                code = (entry >>> 5) & 2047;
                if (bits == 12) {
                    updatePointer(5);
                    entry = additionalMakeup[nextLesserThan8Bits(4)];
                    runLength += (entry >>> 4) & 4095;
                    updatePointer(4 - ((entry >>> 1) & 7));
                } else if (bits == 15) {
                    throw new RuntimeException(MessageLocalization.getComposedMessage("eol.code.word.encountered.in.black.run", new Object[0]));
                } else {
                    runLength += code;
                    updatePointer(9 - bits);
                    if (isT == 0) {
                        isWhite = true;
                    }
                }
            } else if (code == PdfContentParser.COMMAND_TYPE) {
                entry = twoBitBlack[nextLesserThan8Bits(2)];
                runLength += (entry >>> 5) & 2047;
                updatePointer(2 - ((entry >>> 1) & 15));
                isWhite = true;
            } else {
                runLength += code;
                updatePointer(4 - bits);
                isWhite = true;
            }
        }
        return runLength;
    }

    private int readEOL(boolean isFirstEOL) {
        if (this.fillBits == 0) {
            int next12Bits = nextNBits(12);
            if (isFirstEOL && next12Bits == 0 && nextNBits(4) == 1) {
                this.fillBits = 1;
                return 1;
            } else if (next12Bits != 1) {
                throw new RuntimeException(MessageLocalization.getComposedMessage("scanline.must.begin.with.eol.code.word", new Object[0]));
            }
        } else if (this.fillBits == 1) {
            int bitsLeft = 8 - this.bitPointer;
            if (nextNBits(bitsLeft) != 0) {
                throw new RuntimeException(MessageLocalization.getComposedMessage("all.fill.bits.preceding.eol.code.must.be.0", new Object[0]));
            } else if (bitsLeft >= 4 || nextNBits(8) == 0) {
                int n;
                do {
                    n = nextNBits(8);
                    if (n != 1) {
                    }
                } while (n == 0);
                throw new RuntimeException(MessageLocalization.getComposedMessage("all.fill.bits.preceding.eol.code.must.be.0", new Object[0]));
            } else {
                throw new RuntimeException(MessageLocalization.getComposedMessage("all.fill.bits.preceding.eol.code.must.be.0", new Object[0]));
            }
        }
        if (this.oneD != 0) {
            return nextLesserThan8Bits(1);
        }
        return 1;
    }

    private void getNextChangingElement(int a0, boolean isWhite, int[] ret) {
        int start;
        int[] pce = this.prevChangingElems;
        int ces = this.changingElemSize;
        if (this.lastChangingElement > 0) {
            start = this.lastChangingElement - 1;
        } else {
            start = 0;
        }
        if (isWhite) {
            start &= -2;
        } else {
            start |= 1;
        }
        int i = start;
        while (i < ces) {
            int temp = pce[i];
            if (temp > a0) {
                this.lastChangingElement = i;
                ret[0] = temp;
                break;
            }
            i += 2;
        }
        if (i + 1 < ces) {
            ret[1] = pce[i + 1];
        }
    }

    private int nextNBits(int bitsToGet) {
        byte b;
        byte next;
        byte next2next;
        int l = this.data.length - 1;
        int bp = this.bytePointer;
        if (this.fillOrder == 1) {
            b = this.data[bp];
            if (bp == l) {
                next = (byte) 0;
                next2next = (byte) 0;
            } else if (bp + 1 == l) {
                next = this.data[bp + 1];
                next2next = (byte) 0;
            } else {
                next = this.data[bp + 1];
                next2next = this.data[bp + 2];
            }
        } else if (this.fillOrder == 2) {
            b = flipTable[this.data[bp] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (bp == l) {
                next = (byte) 0;
                next2next = (byte) 0;
            } else if (bp + 1 == l) {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                next2next = (byte) 0;
            } else {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
                next2next = flipTable[this.data[bp + 2] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
        } else {
            throw new RuntimeException(MessageLocalization.getComposedMessage("tiff.fill.order.tag.must.be.either.1.or.2", new Object[0]));
        }
        int bitsLeft = 8 - this.bitPointer;
        int bitsFromNextByte = bitsToGet - bitsLeft;
        int bitsFromNext2NextByte = 0;
        if (bitsFromNextByte > 8) {
            bitsFromNext2NextByte = bitsFromNextByte - 8;
            bitsFromNextByte = 8;
        }
        this.bytePointer++;
        int i1 = (table1[bitsLeft] & b) << (bitsToGet - bitsLeft);
        int i2 = (table2[bitsFromNextByte] & next) >>> (8 - bitsFromNextByte);
        if (bitsFromNext2NextByte != 0) {
            i2 = (i2 << bitsFromNext2NextByte) | ((table2[bitsFromNext2NextByte] & next2next) >>> (8 - bitsFromNext2NextByte));
            this.bytePointer++;
            this.bitPointer = bitsFromNext2NextByte;
        } else if (bitsFromNextByte == 8) {
            this.bitPointer = 0;
            this.bytePointer++;
        } else {
            this.bitPointer = bitsFromNextByte;
        }
        return i1 | i2;
    }

    private int nextLesserThan8Bits(int bitsToGet) {
        byte b = (byte) 0;
        byte next = (byte) 0;
        int l = this.data.length - 1;
        int bp = this.bytePointer;
        if (this.fillOrder == 1) {
            b = this.data[bp];
            if (bp == l) {
                next = (byte) 0;
            } else {
                next = this.data[bp + 1];
            }
        } else if (this.fillOrder != 2) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("tiff.fill.order.tag.must.be.either.1.or.2", new Object[0]));
        } else if (!this.recoverFromImageError || bp < this.data.length) {
            b = flipTable[this.data[bp] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            if (bp == l) {
                next = (byte) 0;
            } else {
                next = flipTable[this.data[bp + 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE];
            }
        }
        int bitsLeft = 8 - this.bitPointer;
        int bitsFromNextByte = bitsToGet - bitsLeft;
        int shift = bitsLeft - bitsToGet;
        int i1;
        if (shift >= 0) {
            i1 = (table1[bitsLeft] & b) >>> shift;
            this.bitPointer += bitsToGet;
            if (this.bitPointer != 8) {
                return i1;
            }
            this.bitPointer = 0;
            this.bytePointer++;
            return i1;
        }
        i1 = ((table1[bitsLeft] & b) << (-shift)) | ((table2[bitsFromNextByte] & next) >>> (8 - bitsFromNextByte));
        this.bytePointer++;
        this.bitPointer = bitsFromNextByte;
        return i1;
    }

    private void updatePointer(int bitsToMoveBack) {
        int i = this.bitPointer - bitsToMoveBack;
        if (i < 0) {
            this.bytePointer--;
            this.bitPointer = i + 8;
            return;
        }
        this.bitPointer = i;
    }

    private boolean advancePointer() {
        if (this.bitPointer != 0) {
            this.bytePointer++;
            this.bitPointer = 0;
        }
        return true;
    }

    public void setRecoverFromImageError(boolean recoverFromImageError) {
        this.recoverFromImageError = recoverFromImageError;
    }
}

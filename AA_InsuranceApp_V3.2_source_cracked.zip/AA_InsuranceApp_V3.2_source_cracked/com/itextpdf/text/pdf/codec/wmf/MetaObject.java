package com.itextpdf.text.pdf.codec.wmf;

public class MetaObject {
    public static final int META_BRUSH = 2;
    public static final int META_FONT = 3;
    public static final int META_NOT_SUPPORTED = 0;
    public static final int META_PEN = 1;
    public int type;

    public MetaObject() {
        this.type = META_NOT_SUPPORTED;
    }

    public MetaObject(int type) {
        this.type = META_NOT_SUPPORTED;
        this.type = type;
    }

    public int getType() {
        return this.type;
    }
}

package com.itextpdf.text.pdf.codec.wmf;

import com.itextpdf.text.Document;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.BaseFont;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class MetaFont extends MetaObject {
    static final int BOLDTHRESHOLD = 600;
    static final int DEFAULT_PITCH = 0;
    static final int ETO_CLIPPED = 4;
    static final int ETO_OPAQUE = 2;
    static final int FF_DECORATIVE = 5;
    static final int FF_DONTCARE = 0;
    static final int FF_MODERN = 3;
    static final int FF_ROMAN = 1;
    static final int FF_SCRIPT = 4;
    static final int FF_SWISS = 2;
    static final int FIXED_PITCH = 1;
    static final int MARKER_BOLD = 1;
    static final int MARKER_COURIER = 0;
    static final int MARKER_HELVETICA = 4;
    static final int MARKER_ITALIC = 2;
    static final int MARKER_SYMBOL = 12;
    static final int MARKER_TIMES = 8;
    static final int VARIABLE_PITCH = 2;
    static final String[] fontNames;
    static final int nameSize = 32;
    float angle;
    int bold;
    int charset;
    String faceName;
    BaseFont font;
    int height;
    int italic;
    int pitchAndFamily;
    boolean strikeout;
    boolean underline;

    static {
        fontNames = new String[]{BaseFont.COURIER, BaseFont.COURIER_BOLD, BaseFont.COURIER_OBLIQUE, BaseFont.COURIER_BOLDOBLIQUE, BaseFont.HELVETICA, BaseFont.HELVETICA_BOLD, BaseFont.HELVETICA_OBLIQUE, BaseFont.HELVETICA_BOLDOBLIQUE, BaseFont.TIMES_ROMAN, BaseFont.TIMES_BOLD, BaseFont.TIMES_ITALIC, BaseFont.TIMES_BOLDITALIC, BaseFont.SYMBOL, BaseFont.ZAPFDINGBATS};
    }

    public MetaFont() {
        this.faceName = "arial";
        this.font = null;
        this.type = FF_MODERN;
    }

    public void init(InputMeta in) throws IOException {
        int i;
        boolean z;
        boolean z2 = true;
        this.height = Math.abs(in.readShort());
        in.skip(VARIABLE_PITCH);
        this.angle = (float) ((((double) in.readShort()) / 1800.0d) * 3.141592653589793d);
        in.skip(VARIABLE_PITCH);
        if (in.readShort() >= BOLDTHRESHOLD) {
            i = MARKER_BOLD;
        } else {
            i = MARKER_COURIER;
        }
        this.bold = i;
        if (in.readByte() != 0) {
            i = VARIABLE_PITCH;
        } else {
            i = MARKER_COURIER;
        }
        this.italic = i;
        if (in.readByte() != 0) {
            z = true;
        } else {
            z = false;
        }
        this.underline = z;
        if (in.readByte() == 0) {
            z2 = false;
        }
        this.strikeout = z2;
        this.charset = in.readByte();
        in.skip(FF_MODERN);
        this.pitchAndFamily = in.readByte();
        byte[] name = new byte[nameSize];
        int k = MARKER_COURIER;
        while (k < nameSize) {
            int c = in.readByte();
            if (c != 0) {
                name[k] = (byte) c;
                k += MARKER_BOLD;
            }
        }
        try {
            break;
            this.faceName = new String(name, MARKER_COURIER, k, BaseFont.WINANSI);
        } catch (UnsupportedEncodingException e) {
            this.faceName = new String(name, MARKER_COURIER, k);
        }
        this.faceName = this.faceName.toLowerCase();
    }

    public BaseFont getFont() {
        int i = MARKER_COURIER;
        if (this.font != null) {
            return this.font;
        }
        int i2;
        String str = this.faceName;
        String str2 = BaseFont.WINANSI;
        if (this.italic != 0) {
            i2 = VARIABLE_PITCH;
        } else {
            i2 = MARKER_COURIER;
        }
        if (this.bold != 0) {
            i = MARKER_BOLD;
        }
        this.font = FontFactory.getFont(str, str2, true, 10.0f, i2 | i).getBaseFont();
        if (this.font != null) {
            return this.font;
        }
        String fontName;
        if (this.faceName.indexOf("courier") == -1 && this.faceName.indexOf("terminal") == -1 && this.faceName.indexOf("fixedsys") == -1) {
            if (this.faceName.indexOf("ms sans serif") == -1 && this.faceName.indexOf("arial") == -1 && this.faceName.indexOf("system") == -1) {
                if (this.faceName.indexOf("arial black") == -1) {
                    if (this.faceName.indexOf("times") == -1 && this.faceName.indexOf("ms serif") == -1 && this.faceName.indexOf("roman") == -1) {
                        if (this.faceName.indexOf("symbol") == -1) {
                            int pitch = this.pitchAndFamily & FF_MODERN;
                            switch ((this.pitchAndFamily >> MARKER_HELVETICA) & 7) {
                                case MARKER_BOLD /*1*/:
                                    fontName = fontNames[(this.italic + MARKER_TIMES) + this.bold];
                                    break;
                                case VARIABLE_PITCH /*2*/:
                                case MARKER_HELVETICA /*4*/:
                                case FF_DECORATIVE /*5*/:
                                    fontName = fontNames[(this.italic + MARKER_HELVETICA) + this.bold];
                                    break;
                                case FF_MODERN /*3*/:
                                    fontName = fontNames[(this.italic + MARKER_COURIER) + this.bold];
                                    break;
                                default:
                                    switch (pitch) {
                                        case MARKER_BOLD /*1*/:
                                            fontName = fontNames[(this.italic + MARKER_COURIER) + this.bold];
                                            break;
                                        default:
                                            fontName = fontNames[(this.italic + MARKER_HELVETICA) + this.bold];
                                            break;
                                    }
                            }
                        }
                        fontName = fontNames[MARKER_SYMBOL];
                    } else {
                        fontName = fontNames[(this.italic + MARKER_TIMES) + this.bold];
                    }
                } else {
                    fontName = fontNames[(this.italic + MARKER_HELVETICA) + MARKER_BOLD];
                }
            } else {
                fontName = fontNames[(this.italic + MARKER_HELVETICA) + this.bold];
            }
        } else {
            fontName = fontNames[(this.italic + MARKER_COURIER) + this.bold];
        }
        try {
            this.font = BaseFont.createFont(fontName, BaseFont.WINANSI, false);
            return this.font;
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public float getAngle() {
        return this.angle;
    }

    public boolean isUnderline() {
        return this.underline;
    }

    public boolean isStrikeout() {
        return this.strikeout;
    }

    public float getFontSize(MetaState state) {
        return Math.abs(state.transformY(this.height) - state.transformY(MARKER_COURIER)) * Document.wmfFontCorrection;
    }
}

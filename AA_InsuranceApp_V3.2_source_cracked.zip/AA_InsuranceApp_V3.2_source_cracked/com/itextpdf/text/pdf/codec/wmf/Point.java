package com.itextpdf.text.pdf.codec.wmf;

public class Point {
    public int f28x;
    public int f29y;

    public Point(int x, int y) {
        this.f28x = x;
        this.f29y = y;
    }
}

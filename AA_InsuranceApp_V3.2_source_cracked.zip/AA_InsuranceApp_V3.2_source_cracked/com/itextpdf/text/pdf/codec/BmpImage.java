package com.itextpdf.text.pdf.codec;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.ImgRaw;
import com.itextpdf.text.Utilities;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.PdfArray;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfString;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;

public class BmpImage {
    private static final int BI_BITFIELDS = 3;
    private static final int BI_RGB = 0;
    private static final int BI_RLE4 = 2;
    private static final int BI_RLE8 = 1;
    private static final int LCS_CALIBRATED_RGB = 0;
    private static final int LCS_CMYK = 2;
    private static final int LCS_sRGB = 1;
    private static final int VERSION_2_1_BIT = 0;
    private static final int VERSION_2_24_BIT = 3;
    private static final int VERSION_2_4_BIT = 1;
    private static final int VERSION_2_8_BIT = 2;
    private static final int VERSION_3_1_BIT = 4;
    private static final int VERSION_3_24_BIT = 7;
    private static final int VERSION_3_4_BIT = 5;
    private static final int VERSION_3_8_BIT = 6;
    private static final int VERSION_3_NT_16_BIT = 8;
    private static final int VERSION_3_NT_32_BIT = 9;
    private static final int VERSION_4_16_BIT = 13;
    private static final int VERSION_4_1_BIT = 10;
    private static final int VERSION_4_24_BIT = 14;
    private static final int VERSION_4_32_BIT = 15;
    private static final int VERSION_4_4_BIT = 11;
    private static final int VERSION_4_8_BIT = 12;
    private int alphaMask;
    private long bitmapFileSize;
    private long bitmapOffset;
    private int bitsPerPixel;
    private int blueMask;
    private long compression;
    private int greenMask;
    int height;
    private long imageSize;
    private int imageType;
    private InputStream inputStream;
    private boolean isBottomUp;
    private int numBands;
    private byte[] palette;
    public HashMap<String, Object> properties;
    private int redMask;
    int width;
    private long xPelsPerMeter;
    private long yPelsPerMeter;

    BmpImage(InputStream is, boolean noHeader, int size) throws IOException {
        this.properties = new HashMap();
        this.bitmapFileSize = (long) size;
        this.bitmapOffset = 0;
        process(is, noHeader);
    }

    public static Image getImage(URL url) throws IOException {
        InputStream inputStream = null;
        try {
            inputStream = url.openStream();
            Image img = getImage(inputStream);
            img.setUrl(url);
            return img;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    public static Image getImage(InputStream is) throws IOException {
        return getImage(is, false, VERSION_2_1_BIT);
    }

    public static Image getImage(InputStream is, boolean noHeader, int size) throws IOException {
        BmpImage bmp = new BmpImage(is, noHeader, size);
        try {
            Image img = bmp.getImage();
            img.setDpi((int) ((((double) bmp.xPelsPerMeter) * 0.0254d) + 0.5d), (int) ((((double) bmp.yPelsPerMeter) * 0.0254d) + 0.5d));
            img.setOriginalType(VERSION_3_1_BIT);
            return img;
        } catch (BadElementException be) {
            throw new ExceptionConverter(be);
        }
    }

    public static Image getImage(String file) throws IOException {
        return getImage(Utilities.toURL(file));
    }

    public static Image getImage(byte[] data) throws IOException {
        Image img = getImage(new ByteArrayInputStream(data));
        img.setOriginalData(data);
        return img;
    }

    protected void process(InputStream stream, boolean noHeader) throws IOException {
        int i;
        int sizep;
        byte[] r;
        byte[] g;
        byte[] b;
        int i2;
        if (noHeader || (stream instanceof BufferedInputStream)) {
            this.inputStream = stream;
        } else {
            this.inputStream = new BufferedInputStream(stream);
        }
        if (!noHeader) {
            if (readUnsignedByte(this.inputStream) == 66) {
                if (readUnsignedByte(this.inputStream) == 77) {
                    this.bitmapFileSize = readDWord(this.inputStream);
                    readWord(this.inputStream);
                    readWord(this.inputStream);
                    this.bitmapOffset = readDWord(this.inputStream);
                }
            }
            throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.magic.value.for.bmp.file", new Object[VERSION_2_1_BIT]));
        }
        long size = readDWord(this.inputStream);
        if (size == 12) {
            this.width = readWord(this.inputStream);
            this.height = readWord(this.inputStream);
        } else {
            this.width = readLong(this.inputStream);
            this.height = readLong(this.inputStream);
        }
        int planes = readWord(this.inputStream);
        this.bitsPerPixel = readWord(this.inputStream);
        this.properties.put("color_planes", Integer.valueOf(planes));
        this.properties.put("bits_per_pixel", Integer.valueOf(this.bitsPerPixel));
        this.numBands = VERSION_2_24_BIT;
        if (this.bitmapOffset == 0) {
            this.bitmapOffset = size;
        }
        int sizeOfPalette;
        if (size == 12) {
            this.properties.put("bmp_version", "BMP v. 2.x");
            i = this.bitsPerPixel;
            if (r0 == VERSION_2_4_BIT) {
                this.imageType = VERSION_2_1_BIT;
            } else {
                i = this.bitsPerPixel;
                if (r0 == VERSION_3_1_BIT) {
                    this.imageType = VERSION_2_4_BIT;
                } else {
                    i = this.bitsPerPixel;
                    if (r0 == VERSION_3_NT_16_BIT) {
                        this.imageType = VERSION_2_8_BIT;
                    } else {
                        i = this.bitsPerPixel;
                        if (r0 == 24) {
                            this.imageType = VERSION_2_24_BIT;
                        }
                    }
                }
            }
            sizeOfPalette = ((int) (((this.bitmapOffset - 14) - size) / 3)) * VERSION_2_24_BIT;
            if (this.bitmapOffset == size) {
                switch (this.imageType) {
                    case VERSION_2_1_BIT /*0*/:
                        sizeOfPalette = VERSION_3_8_BIT;
                        break;
                    case VERSION_2_4_BIT /*1*/:
                        sizeOfPalette = 48;
                        break;
                    case VERSION_2_8_BIT /*2*/:
                        sizeOfPalette = 768;
                        break;
                    case VERSION_2_24_BIT /*3*/:
                        sizeOfPalette = VERSION_2_1_BIT;
                        break;
                }
                this.bitmapOffset = ((long) sizeOfPalette) + size;
            }
            readPalette(sizeOfPalette);
        } else {
            this.compression = readDWord(this.inputStream);
            this.imageSize = readDWord(this.inputStream);
            this.xPelsPerMeter = (long) readLong(this.inputStream);
            this.yPelsPerMeter = (long) readLong(this.inputStream);
            long colorsUsed = readDWord(this.inputStream);
            long colorsImportant = readDWord(this.inputStream);
            switch ((int) this.compression) {
                case VERSION_2_1_BIT /*0*/:
                    this.properties.put("compression", "BI_RGB");
                    break;
                case VERSION_2_4_BIT /*1*/:
                    this.properties.put("compression", "BI_RLE8");
                    break;
                case VERSION_2_8_BIT /*2*/:
                    this.properties.put("compression", "BI_RLE4");
                    break;
                case VERSION_2_24_BIT /*3*/:
                    this.properties.put("compression", "BI_BITFIELDS");
                    break;
            }
            this.properties.put("x_pixels_per_meter", Long.valueOf(this.xPelsPerMeter));
            this.properties.put("y_pixels_per_meter", Long.valueOf(this.yPelsPerMeter));
            this.properties.put("colors_used", Long.valueOf(colorsUsed));
            this.properties.put("colors_important", Long.valueOf(colorsImportant));
            if (size == 40 || size == 52 || size == 56) {
                switch ((int) this.compression) {
                    case VERSION_2_1_BIT /*0*/:
                    case VERSION_2_4_BIT /*1*/:
                    case VERSION_2_8_BIT /*2*/:
                        i = this.bitsPerPixel;
                        if (r0 == VERSION_2_4_BIT) {
                            this.imageType = VERSION_3_1_BIT;
                        } else {
                            i = this.bitsPerPixel;
                            if (r0 == VERSION_3_1_BIT) {
                                this.imageType = VERSION_3_4_BIT;
                            } else {
                                i = this.bitsPerPixel;
                                if (r0 == VERSION_3_NT_16_BIT) {
                                    this.imageType = VERSION_3_8_BIT;
                                } else {
                                    i = this.bitsPerPixel;
                                    if (r0 == 24) {
                                        this.imageType = VERSION_3_24_BIT;
                                    } else {
                                        i = this.bitsPerPixel;
                                        if (r0 == 16) {
                                            this.imageType = VERSION_3_NT_16_BIT;
                                            this.redMask = 31744;
                                            this.greenMask = 992;
                                            this.blueMask = 31;
                                            this.properties.put("red_mask", Integer.valueOf(this.redMask));
                                            this.properties.put("green_mask", Integer.valueOf(this.greenMask));
                                            this.properties.put("blue_mask", Integer.valueOf(this.blueMask));
                                        } else {
                                            i = this.bitsPerPixel;
                                            if (r0 == 32) {
                                                this.imageType = VERSION_3_NT_32_BIT;
                                                this.redMask = 16711680;
                                                this.greenMask = 65280;
                                                this.blueMask = TIFFConstants.TIFFTAG_OSUBFILETYPE;
                                                this.properties.put("red_mask", Integer.valueOf(this.redMask));
                                                this.properties.put("green_mask", Integer.valueOf(this.greenMask));
                                                this.properties.put("blue_mask", Integer.valueOf(this.blueMask));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (size >= 52) {
                            this.redMask = (int) readDWord(this.inputStream);
                            this.greenMask = (int) readDWord(this.inputStream);
                            this.blueMask = (int) readDWord(this.inputStream);
                            this.properties.put("red_mask", Integer.valueOf(this.redMask));
                            this.properties.put("green_mask", Integer.valueOf(this.greenMask));
                            this.properties.put("blue_mask", Integer.valueOf(this.blueMask));
                        }
                        if (size == 56) {
                            this.alphaMask = (int) readDWord(this.inputStream);
                            this.properties.put("alpha_mask", Integer.valueOf(this.alphaMask));
                        }
                        sizeOfPalette = ((int) (((this.bitmapOffset - 14) - size) / 4)) * VERSION_3_1_BIT;
                        if (this.bitmapOffset == size) {
                            switch (this.imageType) {
                                case VERSION_3_1_BIT /*4*/:
                                    if (colorsUsed == 0) {
                                        colorsUsed = 2;
                                    }
                                    sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                                    break;
                                case VERSION_3_4_BIT /*5*/:
                                    if (colorsUsed == 0) {
                                        colorsUsed = 16;
                                    }
                                    sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                                    break;
                                case VERSION_3_8_BIT /*6*/:
                                    if (colorsUsed == 0) {
                                        colorsUsed = 256;
                                    }
                                    sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                                    break;
                                default:
                                    sizeOfPalette = VERSION_2_1_BIT;
                                    break;
                            }
                            this.bitmapOffset = ((long) sizeOfPalette) + size;
                        }
                        readPalette(sizeOfPalette);
                        this.properties.put("bmp_version", "BMP v. 3.x");
                        break;
                    case VERSION_2_24_BIT /*3*/:
                        i = this.bitsPerPixel;
                        if (r0 == 16) {
                            this.imageType = VERSION_3_NT_16_BIT;
                        } else {
                            i = this.bitsPerPixel;
                            if (r0 == 32) {
                                this.imageType = VERSION_3_NT_32_BIT;
                            }
                        }
                        this.redMask = (int) readDWord(this.inputStream);
                        this.greenMask = (int) readDWord(this.inputStream);
                        this.blueMask = (int) readDWord(this.inputStream);
                        if (size == 56) {
                            this.alphaMask = (int) readDWord(this.inputStream);
                            this.properties.put("alpha_mask", Integer.valueOf(this.alphaMask));
                        }
                        this.properties.put("red_mask", Integer.valueOf(this.redMask));
                        this.properties.put("green_mask", Integer.valueOf(this.greenMask));
                        this.properties.put("blue_mask", Integer.valueOf(this.blueMask));
                        if (colorsUsed != 0) {
                            readPalette(((int) colorsUsed) * VERSION_3_1_BIT);
                        }
                        this.properties.put("bmp_version", "BMP v. 3.x NT");
                        break;
                    default:
                        throw new RuntimeException("Invalid compression specified in BMP file.");
                }
            } else if (size == 108) {
                this.properties.put("bmp_version", "BMP v. 4.x");
                this.redMask = (int) readDWord(this.inputStream);
                this.greenMask = (int) readDWord(this.inputStream);
                this.blueMask = (int) readDWord(this.inputStream);
                this.alphaMask = (int) readDWord(this.inputStream);
                long csType = readDWord(this.inputStream);
                int redX = readLong(this.inputStream);
                int redY = readLong(this.inputStream);
                int redZ = readLong(this.inputStream);
                int greenX = readLong(this.inputStream);
                int greenY = readLong(this.inputStream);
                int greenZ = readLong(this.inputStream);
                int blueX = readLong(this.inputStream);
                int blueY = readLong(this.inputStream);
                int blueZ = readLong(this.inputStream);
                long gammaRed = readDWord(this.inputStream);
                long gammaGreen = readDWord(this.inputStream);
                long gammaBlue = readDWord(this.inputStream);
                i = this.bitsPerPixel;
                if (r0 == VERSION_2_4_BIT) {
                    this.imageType = VERSION_4_1_BIT;
                } else {
                    i = this.bitsPerPixel;
                    if (r0 == VERSION_3_1_BIT) {
                        this.imageType = VERSION_4_4_BIT;
                    } else {
                        i = this.bitsPerPixel;
                        if (r0 == VERSION_3_NT_16_BIT) {
                            this.imageType = VERSION_4_8_BIT;
                        } else {
                            i = this.bitsPerPixel;
                            if (r0 == 16) {
                                this.imageType = VERSION_4_16_BIT;
                                if (((int) this.compression) == 0) {
                                    this.redMask = 31744;
                                    this.greenMask = 992;
                                    this.blueMask = 31;
                                }
                            } else {
                                i = this.bitsPerPixel;
                                if (r0 == 24) {
                                    this.imageType = VERSION_4_24_BIT;
                                } else {
                                    i = this.bitsPerPixel;
                                    if (r0 == 32) {
                                        this.imageType = VERSION_4_32_BIT;
                                        if (((int) this.compression) == 0) {
                                            this.redMask = 16711680;
                                            this.greenMask = 65280;
                                            this.blueMask = TIFFConstants.TIFFTAG_OSUBFILETYPE;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.properties.put("red_mask", Integer.valueOf(this.redMask));
                this.properties.put("green_mask", Integer.valueOf(this.greenMask));
                this.properties.put("blue_mask", Integer.valueOf(this.blueMask));
                this.properties.put("alpha_mask", Integer.valueOf(this.alphaMask));
                sizeOfPalette = ((int) (((this.bitmapOffset - 14) - size) / 4)) * VERSION_3_1_BIT;
                if (this.bitmapOffset == size) {
                    switch (this.imageType) {
                        case VERSION_4_1_BIT /*10*/:
                            if (colorsUsed == 0) {
                                colorsUsed = 2;
                            }
                            sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                            break;
                        case VERSION_4_4_BIT /*11*/:
                            if (colorsUsed == 0) {
                                colorsUsed = 16;
                            }
                            sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                            break;
                        case VERSION_4_8_BIT /*12*/:
                            if (colorsUsed == 0) {
                                colorsUsed = 256;
                            }
                            sizeOfPalette = ((int) colorsUsed) * VERSION_3_1_BIT;
                            break;
                        default:
                            sizeOfPalette = VERSION_2_1_BIT;
                            break;
                    }
                    this.bitmapOffset = ((long) sizeOfPalette) + size;
                }
                readPalette(sizeOfPalette);
                switch ((int) csType) {
                    case VERSION_2_1_BIT /*0*/:
                        this.properties.put("color_space", "LCS_CALIBRATED_RGB");
                        this.properties.put("redX", Integer.valueOf(redX));
                        this.properties.put("redY", Integer.valueOf(redY));
                        this.properties.put("redZ", Integer.valueOf(redZ));
                        this.properties.put("greenX", Integer.valueOf(greenX));
                        this.properties.put("greenY", Integer.valueOf(greenY));
                        this.properties.put("greenZ", Integer.valueOf(greenZ));
                        this.properties.put("blueX", Integer.valueOf(blueX));
                        this.properties.put("blueY", Integer.valueOf(blueY));
                        this.properties.put("blueZ", Integer.valueOf(blueZ));
                        this.properties.put("gamma_red", Long.valueOf(gammaRed));
                        this.properties.put("gamma_green", Long.valueOf(gammaGreen));
                        this.properties.put("gamma_blue", Long.valueOf(gammaBlue));
                        throw new RuntimeException("Not implemented yet.");
                    case VERSION_2_4_BIT /*1*/:
                        this.properties.put("color_space", "LCS_sRGB");
                        break;
                    case VERSION_2_8_BIT /*2*/:
                        this.properties.put("color_space", "LCS_CMYK");
                        throw new RuntimeException("Not implemented yet.");
                    default:
                        break;
                }
            } else {
                this.properties.put("bmp_version", "BMP v. 5.x");
                throw new RuntimeException("BMP version 5 not implemented yet.");
            }
        }
        if (this.height > 0) {
            this.isBottomUp = true;
        } else {
            this.isBottomUp = false;
            this.height = Math.abs(this.height);
        }
        i = this.bitsPerPixel;
        if (r0 != VERSION_2_4_BIT) {
            i = this.bitsPerPixel;
            if (r0 != VERSION_3_1_BIT) {
                i = this.bitsPerPixel;
                if (r0 != VERSION_3_NT_16_BIT) {
                    i = this.bitsPerPixel;
                    if (r0 == 16) {
                        this.numBands = VERSION_2_24_BIT;
                        return;
                    }
                    i = this.bitsPerPixel;
                    if (r0 == 32) {
                        this.numBands = this.alphaMask == 0 ? VERSION_2_24_BIT : VERSION_3_1_BIT;
                        return;
                    } else {
                        this.numBands = VERSION_2_24_BIT;
                        return;
                    }
                }
            }
        }
        this.numBands = VERSION_2_4_BIT;
        if (this.imageType != 0) {
            i = this.imageType;
            if (r0 != VERSION_2_4_BIT) {
                i = this.imageType;
                if (r0 != VERSION_2_8_BIT) {
                    sizep = this.palette.length / VERSION_3_1_BIT;
                    if (sizep > 256) {
                        sizep = PdfWriter.PageModeUseThumbs;
                    }
                    r = new byte[sizep];
                    g = new byte[sizep];
                    b = new byte[sizep];
                    for (i2 = VERSION_2_1_BIT; i2 < sizep; i2 += VERSION_2_4_BIT) {
                        int off = i2 * VERSION_3_1_BIT;
                        b[i2] = this.palette[off];
                        g[i2] = this.palette[off + VERSION_2_4_BIT];
                        r[i2] = this.palette[off + VERSION_2_8_BIT];
                    }
                    return;
                }
            }
        }
        sizep = this.palette.length / VERSION_2_24_BIT;
        if (sizep > 256) {
            sizep = PdfWriter.PageModeUseThumbs;
        }
        r = new byte[sizep];
        g = new byte[sizep];
        b = new byte[sizep];
        for (i2 = VERSION_2_1_BIT; i2 < sizep; i2 += VERSION_2_4_BIT) {
            off = i2 * VERSION_2_24_BIT;
            b[i2] = this.palette[off];
            g[i2] = this.palette[off + VERSION_2_4_BIT];
            r[i2] = this.palette[off + VERSION_2_8_BIT];
        }
    }

    private byte[] getPalette(int group) {
        if (this.palette == null) {
            return null;
        }
        byte[] np = new byte[((this.palette.length / group) * VERSION_2_24_BIT)];
        int e = this.palette.length / group;
        for (int k = VERSION_2_1_BIT; k < e; k += VERSION_2_4_BIT) {
            int src = k * group;
            int dest = k * VERSION_2_24_BIT;
            int src2 = src + VERSION_2_4_BIT;
            np[dest + VERSION_2_8_BIT] = this.palette[src];
            src = src2 + VERSION_2_4_BIT;
            np[dest + VERSION_2_4_BIT] = this.palette[src2];
            np[dest] = this.palette[src];
        }
        return np;
    }

    private Image getImage() throws IOException, BadElementException {
        byte[] bdata;
        switch (this.imageType) {
            case VERSION_2_1_BIT /*0*/:
                return read1Bit(VERSION_2_24_BIT);
            case VERSION_2_4_BIT /*1*/:
                return read4Bit(VERSION_2_24_BIT);
            case VERSION_2_8_BIT /*2*/:
                return read8Bit(VERSION_2_24_BIT);
            case VERSION_2_24_BIT /*3*/:
                bdata = new byte[((this.width * this.height) * VERSION_2_24_BIT)];
                read24Bit(bdata);
                return new ImgRaw(this.width, this.height, VERSION_2_24_BIT, VERSION_3_NT_16_BIT, bdata);
            case VERSION_3_1_BIT /*4*/:
                return read1Bit(VERSION_3_1_BIT);
            case VERSION_3_4_BIT /*5*/:
                switch ((int) this.compression) {
                    case VERSION_2_1_BIT /*0*/:
                        return read4Bit(VERSION_3_1_BIT);
                    case VERSION_2_8_BIT /*2*/:
                        return readRLE4();
                    default:
                        throw new RuntimeException("Invalid compression specified for BMP file.");
                }
            case VERSION_3_8_BIT /*6*/:
                switch ((int) this.compression) {
                    case VERSION_2_1_BIT /*0*/:
                        return read8Bit(VERSION_3_1_BIT);
                    case VERSION_2_4_BIT /*1*/:
                        return readRLE8();
                    default:
                        throw new RuntimeException("Invalid compression specified for BMP file.");
                }
            case VERSION_3_24_BIT /*7*/:
                bdata = new byte[((this.width * this.height) * VERSION_2_24_BIT)];
                read24Bit(bdata);
                return new ImgRaw(this.width, this.height, VERSION_2_24_BIT, VERSION_3_NT_16_BIT, bdata);
            case VERSION_3_NT_16_BIT /*8*/:
                return read1632Bit(false);
            case VERSION_3_NT_32_BIT /*9*/:
                return read1632Bit(true);
            case VERSION_4_1_BIT /*10*/:
                return read1Bit(VERSION_3_1_BIT);
            case VERSION_4_4_BIT /*11*/:
                switch ((int) this.compression) {
                    case VERSION_2_1_BIT /*0*/:
                        return read4Bit(VERSION_3_1_BIT);
                    case VERSION_2_8_BIT /*2*/:
                        return readRLE4();
                    default:
                        throw new RuntimeException("Invalid compression specified for BMP file.");
                }
            case VERSION_4_8_BIT /*12*/:
                switch ((int) this.compression) {
                    case VERSION_2_1_BIT /*0*/:
                        return read8Bit(VERSION_3_1_BIT);
                    case VERSION_2_4_BIT /*1*/:
                        return readRLE8();
                    default:
                        throw new RuntimeException("Invalid compression specified for BMP file.");
                }
            case VERSION_4_16_BIT /*13*/:
                return read1632Bit(false);
            case VERSION_4_24_BIT /*14*/:
                bdata = new byte[((this.width * this.height) * VERSION_2_24_BIT)];
                read24Bit(bdata);
                return new ImgRaw(this.width, this.height, VERSION_2_24_BIT, VERSION_3_NT_16_BIT, bdata);
            case VERSION_4_32_BIT /*15*/:
                return read1632Bit(true);
            default:
                return null;
        }
    }

    private Image indexedModel(byte[] bdata, int bpc, int paletteEntries) throws BadElementException {
        Image img = new ImgRaw(this.width, this.height, VERSION_2_4_BIT, bpc, bdata);
        PdfArray colorspace = new PdfArray();
        colorspace.add(PdfName.INDEXED);
        colorspace.add(PdfName.DEVICERGB);
        byte[] np = getPalette(paletteEntries);
        colorspace.add(new PdfNumber((np.length / VERSION_2_24_BIT) - 1));
        colorspace.add(new PdfString(np));
        PdfDictionary ad = new PdfDictionary();
        ad.put(PdfName.COLORSPACE, colorspace);
        img.setAdditional(ad);
        return img;
    }

    private void readPalette(int sizeOfPalette) throws IOException {
        if (sizeOfPalette != 0) {
            this.palette = new byte[sizeOfPalette];
            int bytesRead = VERSION_2_1_BIT;
            while (bytesRead < sizeOfPalette) {
                int r = this.inputStream.read(this.palette, bytesRead, sizeOfPalette - bytesRead);
                if (r < 0) {
                    throw new RuntimeException(MessageLocalization.getComposedMessage("incomplete.palette", new Object[VERSION_2_1_BIT]));
                }
                bytesRead += r;
            }
            this.properties.put("palette", this.palette);
        }
    }

    private Image read1Bit(int paletteEntries) throws IOException, BadElementException {
        byte[] bdata = new byte[(((this.width + VERSION_3_24_BIT) / VERSION_3_NT_16_BIT) * this.height)];
        int padding = VERSION_2_1_BIT;
        int bytesPerScanline = (int) Math.ceil(((double) this.width) / 8.0d);
        int remainder = bytesPerScanline % VERSION_3_1_BIT;
        if (remainder != 0) {
            padding = 4 - remainder;
        }
        int imSize = (bytesPerScanline + padding) * this.height;
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            bytesRead += this.inputStream.read(values, bytesRead, imSize - bytesRead);
        }
        int i;
        if (this.isBottomUp) {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, imSize - ((i + VERSION_2_4_BIT) * (bytesPerScanline + padding)), bdata, i * bytesPerScanline, bytesPerScanline);
            }
        } else {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, (bytesPerScanline + padding) * i, bdata, i * bytesPerScanline, bytesPerScanline);
            }
        }
        return indexedModel(bdata, VERSION_2_4_BIT, paletteEntries);
    }

    private Image read4Bit(int paletteEntries) throws IOException, BadElementException {
        byte[] bdata = new byte[(((this.width + VERSION_2_4_BIT) / VERSION_2_8_BIT) * this.height)];
        int padding = VERSION_2_1_BIT;
        int bytesPerScanline = (int) Math.ceil(((double) this.width) / 2.0d);
        int remainder = bytesPerScanline % VERSION_3_1_BIT;
        if (remainder != 0) {
            padding = 4 - remainder;
        }
        int imSize = (bytesPerScanline + padding) * this.height;
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            bytesRead += this.inputStream.read(values, bytesRead, imSize - bytesRead);
        }
        int i;
        if (this.isBottomUp) {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, imSize - ((i + VERSION_2_4_BIT) * (bytesPerScanline + padding)), bdata, i * bytesPerScanline, bytesPerScanline);
            }
        } else {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, (bytesPerScanline + padding) * i, bdata, i * bytesPerScanline, bytesPerScanline);
            }
        }
        return indexedModel(bdata, VERSION_3_1_BIT, paletteEntries);
    }

    private Image read8Bit(int paletteEntries) throws IOException, BadElementException {
        byte[] bdata = new byte[(this.width * this.height)];
        int padding = VERSION_2_1_BIT;
        int bitsPerScanline = this.width * VERSION_3_NT_16_BIT;
        if (bitsPerScanline % 32 != 0) {
            padding = (int) Math.ceil(((double) ((((bitsPerScanline / 32) + VERSION_2_4_BIT) * 32) - bitsPerScanline)) / 8.0d);
        }
        int imSize = (this.width + padding) * this.height;
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            bytesRead += this.inputStream.read(values, bytesRead, imSize - bytesRead);
        }
        int i;
        if (this.isBottomUp) {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, imSize - ((i + VERSION_2_4_BIT) * (this.width + padding)), bdata, this.width * i, this.width);
            }
        } else {
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(values, (this.width + padding) * i, bdata, this.width * i, this.width);
            }
        }
        return indexedModel(bdata, VERSION_3_NT_16_BIT, paletteEntries);
    }

    private void read24Bit(byte[] bdata) {
        int padding = VERSION_2_1_BIT;
        int bitsPerScanline = this.width * 24;
        if (bitsPerScanline % 32 != 0) {
            padding = (int) Math.ceil(((double) ((((bitsPerScanline / 32) + VERSION_2_4_BIT) * 32) - bitsPerScanline)) / 8.0d);
        }
        int imSize = ((((this.width * VERSION_2_24_BIT) + VERSION_2_24_BIT) / VERSION_3_1_BIT) * VERSION_3_1_BIT) * this.height;
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            try {
                int r = this.inputStream.read(values, bytesRead, imSize - bytesRead);
                if (r < 0) {
                    break;
                }
                bytesRead += r;
            } catch (IOException ioe) {
                throw new ExceptionConverter(ioe);
            }
        }
        int l = VERSION_2_1_BIT;
        int count;
        int i;
        int j;
        if (this.isBottomUp) {
            int max = ((this.width * this.height) * VERSION_2_24_BIT) - 1;
            count = -padding;
            for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                l = (max - (((i + VERSION_2_4_BIT) * this.width) * VERSION_2_24_BIT)) + VERSION_2_4_BIT;
                count += padding;
                j = VERSION_2_1_BIT;
                while (j < this.width) {
                    int count2 = count + VERSION_2_4_BIT;
                    bdata[l + VERSION_2_8_BIT] = values[count];
                    count = count2 + VERSION_2_4_BIT;
                    bdata[l + VERSION_2_4_BIT] = values[count2];
                    count2 = count + VERSION_2_4_BIT;
                    bdata[l] = values[count];
                    l += VERSION_2_24_BIT;
                    j += VERSION_2_4_BIT;
                    count = count2;
                }
            }
            return;
        }
        count = -padding;
        for (i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
            count += padding;
            j = VERSION_2_1_BIT;
            while (j < this.width) {
                count2 = count + VERSION_2_4_BIT;
                bdata[l + VERSION_2_8_BIT] = values[count];
                count = count2 + VERSION_2_4_BIT;
                bdata[l + VERSION_2_4_BIT] = values[count2];
                count2 = count + VERSION_2_4_BIT;
                bdata[l] = values[count];
                l += VERSION_2_24_BIT;
                j += VERSION_2_4_BIT;
                count = count2;
            }
        }
    }

    private int findMask(int mask) {
        for (int k = VERSION_2_1_BIT; k < 32 && (mask & VERSION_2_4_BIT) != VERSION_2_4_BIT; k += VERSION_2_4_BIT) {
            mask >>>= VERSION_2_4_BIT;
        }
        return mask;
    }

    private int findShift(int mask) {
        int k = VERSION_2_1_BIT;
        while (k < 32 && (mask & VERSION_2_4_BIT) != VERSION_2_4_BIT) {
            mask >>>= VERSION_2_4_BIT;
            k += VERSION_2_4_BIT;
        }
        return k;
    }

    private Image read1632Bit(boolean is32) throws IOException, BadElementException {
        int red_mask = findMask(this.redMask);
        int red_shift = findShift(this.redMask);
        int red_factor = red_mask + VERSION_2_4_BIT;
        int green_mask = findMask(this.greenMask);
        int green_shift = findShift(this.greenMask);
        int green_factor = green_mask + VERSION_2_4_BIT;
        int blue_mask = findMask(this.blueMask);
        int blue_shift = findShift(this.blueMask);
        int blue_factor = blue_mask + VERSION_2_4_BIT;
        byte[] bdata = new byte[((this.width * this.height) * VERSION_2_24_BIT)];
        int padding = VERSION_2_1_BIT;
        if (!is32) {
            int bitsPerScanline = this.width * 16;
            if (bitsPerScanline % 32 != 0) {
                padding = (int) Math.ceil(((double) ((((bitsPerScanline / 32) + VERSION_2_4_BIT) * 32) - bitsPerScanline)) / 8.0d);
            }
        }
        if (((int) this.imageSize) == 0) {
            int imSize = (int) (this.bitmapFileSize - this.bitmapOffset);
        }
        int i = VERSION_2_1_BIT;
        int i2;
        int j;
        int v;
        int i3;
        int m;
        if (this.isBottomUp) {
            for (i2 = this.height - 1; i2 >= 0; i2--) {
                i = (this.width * VERSION_2_24_BIT) * i2;
                j = VERSION_2_1_BIT;
                while (j < this.width) {
                    if (is32) {
                        v = (int) readDWord(this.inputStream);
                    } else {
                        v = readWord(this.inputStream);
                    }
                    i3 = i + VERSION_2_4_BIT;
                    bdata[i] = (byte) ((((v >>> red_shift) & red_mask) * PdfWriter.PageModeUseThumbs) / red_factor);
                    i = i3 + VERSION_2_4_BIT;
                    bdata[i3] = (byte) ((((v >>> green_shift) & green_mask) * PdfWriter.PageModeUseThumbs) / green_factor);
                    i3 = i + VERSION_2_4_BIT;
                    bdata[i] = (byte) ((((v >>> blue_shift) & blue_mask) * PdfWriter.PageModeUseThumbs) / blue_factor);
                    j += VERSION_2_4_BIT;
                    i = i3;
                }
                for (m = VERSION_2_1_BIT; m < padding; m += VERSION_2_4_BIT) {
                    this.inputStream.read();
                }
            }
        } else {
            for (i2 = VERSION_2_1_BIT; i2 < this.height; i2 += VERSION_2_4_BIT) {
                j = VERSION_2_1_BIT;
                while (j < this.width) {
                    if (is32) {
                        v = (int) readDWord(this.inputStream);
                    } else {
                        v = readWord(this.inputStream);
                    }
                    i3 = i + VERSION_2_4_BIT;
                    bdata[i] = (byte) ((((v >>> red_shift) & red_mask) * PdfWriter.PageModeUseThumbs) / red_factor);
                    i = i3 + VERSION_2_4_BIT;
                    bdata[i3] = (byte) ((((v >>> green_shift) & green_mask) * PdfWriter.PageModeUseThumbs) / green_factor);
                    i3 = i + VERSION_2_4_BIT;
                    bdata[i] = (byte) ((((v >>> blue_shift) & blue_mask) * PdfWriter.PageModeUseThumbs) / blue_factor);
                    j += VERSION_2_4_BIT;
                    i = i3;
                }
                for (m = VERSION_2_1_BIT; m < padding; m += VERSION_2_4_BIT) {
                    this.inputStream.read();
                }
            }
        }
        return new ImgRaw(this.width, this.height, VERSION_2_24_BIT, VERSION_3_NT_16_BIT, bdata);
    }

    private Image readRLE8() throws IOException, BadElementException {
        int imSize = (int) this.imageSize;
        if (imSize == 0) {
            imSize = (int) (this.bitmapFileSize - this.bitmapOffset);
        }
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            bytesRead += this.inputStream.read(values, bytesRead, imSize - bytesRead);
        }
        byte[] val = decodeRLE(true, values);
        imSize = this.width * this.height;
        if (this.isBottomUp) {
            byte[] temp = new byte[val.length];
            int bytesPerScanline = this.width;
            for (int i = VERSION_2_1_BIT; i < this.height; i += VERSION_2_4_BIT) {
                System.arraycopy(val, imSize - ((i + VERSION_2_4_BIT) * bytesPerScanline), temp, i * bytesPerScanline, bytesPerScanline);
            }
            val = temp;
        }
        return indexedModel(val, VERSION_3_NT_16_BIT, VERSION_3_1_BIT);
    }

    private Image readRLE4() throws IOException, BadElementException {
        int imSize = (int) this.imageSize;
        if (imSize == 0) {
            imSize = (int) (this.bitmapFileSize - this.bitmapOffset);
        }
        byte[] values = new byte[imSize];
        int bytesRead = VERSION_2_1_BIT;
        while (bytesRead < imSize) {
            bytesRead += this.inputStream.read(values, bytesRead, imSize - bytesRead);
        }
        byte[] val = decodeRLE(false, values);
        if (this.isBottomUp) {
            byte[] inverted = val;
            val = new byte[(this.width * this.height)];
            int l = VERSION_2_1_BIT;
            int i = this.height - 1;
            while (i >= 0) {
                int index = i * this.width;
                int lineEnd = l + this.width;
                int index2 = index;
                int l2 = l;
                while (l2 != lineEnd) {
                    l = l2 + VERSION_2_4_BIT;
                    index = index2 + VERSION_2_4_BIT;
                    val[l2] = inverted[index2];
                    index2 = index;
                    l2 = l;
                }
                i--;
                l = l2;
            }
        }
        int stride = (this.width + VERSION_2_4_BIT) / VERSION_2_8_BIT;
        byte[] bdata = new byte[(this.height * stride)];
        int ptr = VERSION_2_1_BIT;
        int sh = VERSION_2_1_BIT;
        int h = VERSION_2_1_BIT;
        while (true) {
            int i2 = this.height;
            if (h >= r0) {
                return indexedModel(bdata, VERSION_3_1_BIT, VERSION_3_1_BIT);
            }
            for (int w = VERSION_2_1_BIT; w < this.width; w += VERSION_2_4_BIT) {
                int ptr2;
                if ((w & VERSION_2_4_BIT) == 0) {
                    ptr2 = ptr + VERSION_2_4_BIT;
                    bdata[(w / VERSION_2_8_BIT) + sh] = (byte) (val[ptr] << VERSION_3_1_BIT);
                    ptr = ptr2;
                } else {
                    i2 = (w / VERSION_2_8_BIT) + sh;
                    ptr2 = ptr + VERSION_2_4_BIT;
                    bdata[i2] = (byte) (bdata[i2] | ((byte) (val[ptr] & VERSION_4_32_BIT)));
                    ptr = ptr2;
                }
            }
            sh += stride;
            h += VERSION_2_4_BIT;
        }
    }

    private byte[] decodeRLE(boolean is8, byte[] values) {
        int ptr;
        byte[] val = new byte[(this.width * this.height)];
        int x = VERSION_2_1_BIT;
        int q = VERSION_2_1_BIT;
        int y = VERSION_2_1_BIT;
        int ptr2 = VERSION_2_1_BIT;
        while (y < this.height && ptr2 < values.length) {
            ptr = ptr2 + VERSION_2_4_BIT;
            int count = values[ptr2] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            int bt;
            int i;
            int q2;
            if (count != 0) {
                ptr2 = ptr + VERSION_2_4_BIT;
                bt = values[ptr] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                if (is8) {
                    i = count;
                    q2 = q;
                    while (i != 0) {
                        q = q2 + VERSION_2_4_BIT;
                        val[q2] = (byte) bt;
                        i--;
                        q2 = q;
                    }
                    q = q2;
                } else {
                    i = VERSION_2_1_BIT;
                    q2 = q;
                    while (i < count) {
                        q = q2 + VERSION_2_4_BIT;
                        val[q2] = (byte) ((i & VERSION_2_4_BIT) == VERSION_2_4_BIT ? bt & VERSION_4_32_BIT : (bt >>> VERSION_3_1_BIT) & VERSION_4_32_BIT);
                        i += VERSION_2_4_BIT;
                        q2 = q;
                    }
                    q = q2;
                }
                x += count;
                ptr = ptr2;
            } else {
                ptr2 = ptr + VERSION_2_4_BIT;
                count = values[ptr] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                if (count == VERSION_2_4_BIT) {
                    ptr = ptr2;
                    return val;
                }
                switch (count) {
                    case VERSION_2_1_BIT /*0*/:
                        x = VERSION_2_1_BIT;
                        y += VERSION_2_4_BIT;
                        q = y * this.width;
                        ptr = ptr2;
                        continue;
                    case VERSION_2_8_BIT /*2*/:
                        ptr = ptr2 + VERSION_2_4_BIT;
                        x += values[ptr2] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                        ptr2 = ptr + VERSION_2_4_BIT;
                        try {
                            y += values[ptr] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                            q = (this.width * y) + x;
                            ptr = ptr2;
                            continue;
                        } catch (RuntimeException e) {
                            ptr = ptr2;
                            break;
                        }
                    default:
                        if (is8) {
                            i = count;
                            q2 = q;
                            while (i != 0) {
                                q = q2 + VERSION_2_4_BIT;
                                ptr = ptr2 + VERSION_2_4_BIT;
                                val[q2] = (byte) (values[ptr2] & TIFFConstants.TIFFTAG_OSUBFILETYPE);
                                i--;
                                q2 = q;
                                ptr2 = ptr;
                            }
                            q = q2;
                            ptr = ptr2;
                        } else {
                            bt = VERSION_2_1_BIT;
                            i = VERSION_2_1_BIT;
                            q2 = q;
                            while (i < count) {
                                if ((i & VERSION_2_4_BIT) == 0) {
                                    ptr = ptr2 + VERSION_2_4_BIT;
                                    try {
                                        bt = values[ptr2] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                                    } catch (RuntimeException e2) {
                                        q = q2;
                                        break;
                                    }
                                }
                                ptr = ptr2;
                                q = q2 + VERSION_2_4_BIT;
                                try {
                                    val[q2] = (byte) ((i & VERSION_2_4_BIT) == VERSION_2_4_BIT ? bt & VERSION_4_32_BIT : (bt >>> VERSION_3_1_BIT) & VERSION_4_32_BIT);
                                    i += VERSION_2_4_BIT;
                                    q2 = q;
                                    ptr2 = ptr;
                                } catch (RuntimeException e3) {
                                    break;
                                }
                            }
                            q = q2;
                            ptr = ptr2;
                        }
                        x += count;
                        if (!is8) {
                            if ((count & VERSION_2_24_BIT) != VERSION_2_4_BIT && (count & VERSION_2_24_BIT) != VERSION_2_8_BIT) {
                                break;
                            }
                            ptr += VERSION_2_4_BIT;
                            break;
                        } else if ((count & VERSION_2_4_BIT) == VERSION_2_4_BIT) {
                            ptr += VERSION_2_4_BIT;
                            break;
                        } else {
                            continue;
                        }
                        break;
                }
                return val;
            }
            ptr2 = ptr;
        }
        ptr = ptr2;
        return val;
    }

    private int readUnsignedByte(InputStream stream) throws IOException {
        return stream.read() & TIFFConstants.TIFFTAG_OSUBFILETYPE;
    }

    private int readUnsignedShort(InputStream stream) throws IOException {
        return ((readUnsignedByte(stream) << VERSION_3_NT_16_BIT) | readUnsignedByte(stream)) & PdfWriter.GENERATION_MAX;
    }

    private int readShort(InputStream stream) throws IOException {
        return (readUnsignedByte(stream) << VERSION_3_NT_16_BIT) | readUnsignedByte(stream);
    }

    private int readWord(InputStream stream) throws IOException {
        return readUnsignedShort(stream);
    }

    private long readUnsignedInt(InputStream stream) throws IOException {
        int b1 = readUnsignedByte(stream);
        int b2 = readUnsignedByte(stream);
        return -1 & ((long) ((((readUnsignedByte(stream) << 24) | (readUnsignedByte(stream) << 16)) | (b2 << VERSION_3_NT_16_BIT)) | b1));
    }

    private int readInt(InputStream stream) throws IOException {
        int b1 = readUnsignedByte(stream);
        int b2 = readUnsignedByte(stream);
        return (((readUnsignedByte(stream) << 24) | (readUnsignedByte(stream) << 16)) | (b2 << VERSION_3_NT_16_BIT)) | b1;
    }

    private long readDWord(InputStream stream) throws IOException {
        return readUnsignedInt(stream);
    }

    private int readLong(InputStream stream) throws IOException {
        return readInt(stream);
    }
}

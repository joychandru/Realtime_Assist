package com.itextpdf.text.pdf;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.log.Logger;
import com.itextpdf.text.log.LoggerFactory;
import com.itextpdf.text.pdf.PdfPTable.FittingRows;
import com.itextpdf.text.pdf.draw.DrawInterface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

public class ColumnText {
    public static final int AR_COMPOSEDTASHKEEL = 4;
    public static final int AR_LIG = 8;
    public static final int AR_NOVOWEL = 1;
    public static final int DIGITS_AN2EN = 64;
    public static final int DIGITS_EN2AN = 32;
    public static final int DIGITS_EN2AN_INIT_AL = 128;
    public static final int DIGITS_EN2AN_INIT_LR = 96;
    public static final int DIGIT_TYPE_AN = 0;
    public static final int DIGIT_TYPE_AN_EXTENDED = 256;
    public static final float GLOBAL_SPACE_CHAR_RATIO = 0.0f;
    protected static final int LINE_STATUS_NOLINE = 2;
    protected static final int LINE_STATUS_OFFLIMITS = 1;
    protected static final int LINE_STATUS_OK = 0;
    public static final int NO_MORE_COLUMN = 2;
    public static final int NO_MORE_TEXT = 1;
    public static final int START_COLUMN = 0;
    private final Logger LOGGER;
    private boolean adjustFirstLine;
    protected int alignment;
    private int arabicOptions;
    protected BidiLine bidiLine;
    protected PdfContentByte canvas;
    protected PdfContentByte[] canvases;
    protected boolean composite;
    protected ColumnText compositeColumn;
    protected LinkedList<Element> compositeElements;
    protected float currentLeading;
    protected float descender;
    protected float extraParagraphSpace;
    private float filledWidth;
    private float firstLineY;
    private boolean firstLineYDone;
    protected float fixedLeading;
    protected float followingIndent;
    protected float indent;
    private boolean inheritGraphicState;
    private boolean lastWasNewline;
    protected float lastX;
    protected ArrayList<float[]> leftWall;
    protected float leftX;
    protected int lineStatus;
    private int linesWritten;
    protected int listIdx;
    protected float maxY;
    protected float minY;
    protected float multipliedLeading;
    protected boolean rectangularMode;
    protected float rectangularWidth;
    private boolean repeatFirstLineIndent;
    protected float rightIndent;
    protected ArrayList<float[]> rightWall;
    protected float rightX;
    protected int rowIdx;
    protected int runDirection;
    private float spaceCharRatio;
    private int splittedRow;
    private boolean useAscender;
    protected Phrase waitPhrase;
    protected float yLine;

    public ColumnText(PdfContentByte canvas) {
        this.LOGGER = LoggerFactory.getLogger(ColumnText.class);
        this.runDirection = LINE_STATUS_OK;
        this.alignment = LINE_STATUS_OK;
        this.currentLeading = 16.0f;
        this.fixedLeading = 16.0f;
        this.multipliedLeading = GLOBAL_SPACE_CHAR_RATIO;
        this.indent = GLOBAL_SPACE_CHAR_RATIO;
        this.followingIndent = GLOBAL_SPACE_CHAR_RATIO;
        this.rightIndent = GLOBAL_SPACE_CHAR_RATIO;
        this.extraParagraphSpace = GLOBAL_SPACE_CHAR_RATIO;
        this.rectangularWidth = -1.0f;
        this.rectangularMode = false;
        this.spaceCharRatio = GLOBAL_SPACE_CHAR_RATIO;
        this.lastWasNewline = true;
        this.repeatFirstLineIndent = true;
        this.firstLineYDone = false;
        this.arabicOptions = LINE_STATUS_OK;
        this.composite = false;
        this.listIdx = LINE_STATUS_OK;
        this.rowIdx = LINE_STATUS_OK;
        this.splittedRow = -1;
        this.useAscender = false;
        this.adjustFirstLine = true;
        this.inheritGraphicState = false;
        this.canvas = canvas;
    }

    public static ColumnText duplicate(ColumnText org) {
        ColumnText ct = new ColumnText(null);
        ct.setACopy(org);
        return ct;
    }

    public ColumnText setACopy(ColumnText org) {
        setSimpleVars(org);
        if (org.bidiLine != null) {
            this.bidiLine = new BidiLine(org.bidiLine);
        }
        return this;
    }

    protected void setSimpleVars(ColumnText org) {
        this.maxY = org.maxY;
        this.minY = org.minY;
        this.alignment = org.alignment;
        this.leftWall = null;
        if (org.leftWall != null) {
            this.leftWall = new ArrayList(org.leftWall);
        }
        this.rightWall = null;
        if (org.rightWall != null) {
            this.rightWall = new ArrayList(org.rightWall);
        }
        this.yLine = org.yLine;
        this.currentLeading = org.currentLeading;
        this.fixedLeading = org.fixedLeading;
        this.multipliedLeading = org.multipliedLeading;
        this.canvas = org.canvas;
        this.canvases = org.canvases;
        this.lineStatus = org.lineStatus;
        this.indent = org.indent;
        this.followingIndent = org.followingIndent;
        this.rightIndent = org.rightIndent;
        this.extraParagraphSpace = org.extraParagraphSpace;
        this.rectangularWidth = org.rectangularWidth;
        this.rectangularMode = org.rectangularMode;
        this.spaceCharRatio = org.spaceCharRatio;
        this.lastWasNewline = org.lastWasNewline;
        this.repeatFirstLineIndent = org.repeatFirstLineIndent;
        this.linesWritten = org.linesWritten;
        this.arabicOptions = org.arabicOptions;
        this.runDirection = org.runDirection;
        this.descender = org.descender;
        this.composite = org.composite;
        this.splittedRow = org.splittedRow;
        if (org.composite) {
            this.compositeElements = new LinkedList();
            Iterator i$ = org.compositeElements.iterator();
            while (i$.hasNext()) {
                Element element = (Element) i$.next();
                if (element instanceof PdfPTable) {
                    this.compositeElements.add(new PdfPTable((PdfPTable) element));
                } else {
                    this.compositeElements.add(element);
                }
            }
            if (org.compositeColumn != null) {
                this.compositeColumn = duplicate(org.compositeColumn);
            }
        }
        this.listIdx = org.listIdx;
        this.rowIdx = org.rowIdx;
        this.firstLineY = org.firstLineY;
        this.leftX = org.leftX;
        this.rightX = org.rightX;
        this.firstLineYDone = org.firstLineYDone;
        this.waitPhrase = org.waitPhrase;
        this.useAscender = org.useAscender;
        this.filledWidth = org.filledWidth;
        this.adjustFirstLine = org.adjustFirstLine;
        this.inheritGraphicState = org.inheritGraphicState;
    }

    private void addWaitingPhrase() {
        if (this.bidiLine == null && this.waitPhrase != null) {
            this.bidiLine = new BidiLine();
            for (Chunk c : this.waitPhrase.getChunks()) {
                this.bidiLine.addChunk(new PdfChunk(c, null, this.waitPhrase.getTabSettings()));
            }
            this.waitPhrase = null;
        }
    }

    public void addText(Phrase phrase) {
        if (phrase != null && !this.composite) {
            addWaitingPhrase();
            if (this.bidiLine == null) {
                this.waitPhrase = phrase;
                return;
            }
            for (Chunk pdfChunk : phrase.getChunks()) {
                this.bidiLine.addChunk(new PdfChunk(pdfChunk, null, phrase.getTabSettings()));
            }
        }
    }

    public void setText(Phrase phrase) {
        this.bidiLine = null;
        this.composite = false;
        this.compositeColumn = null;
        this.compositeElements = null;
        this.listIdx = LINE_STATUS_OK;
        this.rowIdx = LINE_STATUS_OK;
        this.splittedRow = -1;
        this.waitPhrase = phrase;
    }

    public void addText(Chunk chunk) {
        if (chunk != null && !this.composite) {
            addText(new Phrase(chunk));
        }
    }

    public void addElement(Element element) {
        if (element != null) {
            if (element instanceof Image) {
                Image img = (Image) element;
                PdfPTable t = new PdfPTable((int) NO_MORE_TEXT);
                float w = img.getWidthPercentage();
                if (w == GLOBAL_SPACE_CHAR_RATIO) {
                    t.setTotalWidth(img.getScaledWidth());
                    t.setLockedWidth(true);
                } else {
                    t.setWidthPercentage(w);
                }
                t.setSpacingAfter(img.getSpacingAfter());
                t.setSpacingBefore(img.getSpacingBefore());
                switch (img.getAlignment()) {
                    case LINE_STATUS_OK /*0*/:
                        t.setHorizontalAlignment(LINE_STATUS_OK);
                        break;
                    case NO_MORE_COLUMN /*2*/:
                        t.setHorizontalAlignment(NO_MORE_COLUMN);
                        break;
                    default:
                        t.setHorizontalAlignment(NO_MORE_TEXT);
                        break;
                }
                PdfPCell c = new PdfPCell(img, true);
                c.setPadding(GLOBAL_SPACE_CHAR_RATIO);
                c.setBorder(img.getBorder());
                c.setBorderColor(img.getBorderColor());
                c.setBorderWidth(img.getBorderWidth());
                c.setBackgroundColor(img.getBackgroundColor());
                t.addCell(c);
                element = t;
            }
            if (element.type() == 10) {
                element = new Paragraph((Chunk) element);
            } else if (element.type() == 11) {
                element = new Paragraph((Phrase) element);
            }
            if (element.type() == 12 || element.type() == 14 || element.type() == 23 || element.type() == 55 || element.type() == 37) {
                if (!this.composite) {
                    this.composite = true;
                    this.compositeElements = new LinkedList();
                    this.bidiLine = null;
                    this.waitPhrase = null;
                }
                if (element.type() == 12) {
                    this.compositeElements.addAll(((Paragraph) element).breakUp());
                    return;
                }
                this.compositeElements.add(element);
                return;
            }
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("element.not.allowed", new Object[LINE_STATUS_OK]));
        }
    }

    public static boolean isAllowedElement(Element element) {
        int type = element.type();
        if (type == 10 || type == 11 || type == 37 || type == 12 || type == 14 || type == 55 || type == 23 || (element instanceof Image)) {
            return true;
        }
        return false;
    }

    protected ArrayList<float[]> convertColumn(float[] cLine) {
        if (cLine.length < AR_COMPOSEDTASHKEEL) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("no.valid.column.line.found", new Object[LINE_STATUS_OK]));
        }
        ArrayList<float[]> cc = new ArrayList();
        for (int k = LINE_STATUS_OK; k < cLine.length - 2; k += NO_MORE_COLUMN) {
            float x1 = cLine[k];
            float y1 = cLine[k + NO_MORE_TEXT];
            float x2 = cLine[k + NO_MORE_COLUMN];
            float y2 = cLine[k + 3];
            if (y1 != y2) {
                float a = (x1 - x2) / (y1 - y2);
                float b = x1 - (a * y1);
                float[] r = new float[AR_COMPOSEDTASHKEEL];
                r[LINE_STATUS_OK] = Math.min(y1, y2);
                r[NO_MORE_TEXT] = Math.max(y1, y2);
                r[NO_MORE_COLUMN] = a;
                r[3] = b;
                cc.add(r);
                this.maxY = Math.max(this.maxY, r[NO_MORE_TEXT]);
                this.minY = Math.min(this.minY, r[LINE_STATUS_OK]);
            }
        }
        if (!cc.isEmpty()) {
            return cc;
        }
        throw new RuntimeException(MessageLocalization.getComposedMessage("no.valid.column.line.found", new Object[LINE_STATUS_OK]));
    }

    protected float findLimitsPoint(ArrayList<float[]> wall) {
        this.lineStatus = LINE_STATUS_OK;
        if (this.yLine < this.minY || this.yLine > this.maxY) {
            this.lineStatus = NO_MORE_TEXT;
            return GLOBAL_SPACE_CHAR_RATIO;
        }
        for (int k = LINE_STATUS_OK; k < wall.size(); k += NO_MORE_TEXT) {
            float[] r = (float[]) wall.get(k);
            if (this.yLine >= r[LINE_STATUS_OK] && this.yLine <= r[NO_MORE_TEXT]) {
                return (r[NO_MORE_COLUMN] * this.yLine) + r[3];
            }
        }
        this.lineStatus = NO_MORE_COLUMN;
        return GLOBAL_SPACE_CHAR_RATIO;
    }

    protected float[] findLimitsOneLine() {
        float x1 = findLimitsPoint(this.leftWall);
        if (this.lineStatus == NO_MORE_TEXT || this.lineStatus == NO_MORE_COLUMN) {
            return null;
        }
        float x2 = findLimitsPoint(this.rightWall);
        if (this.lineStatus == NO_MORE_COLUMN) {
            return null;
        }
        float[] fArr = new float[NO_MORE_COLUMN];
        fArr[LINE_STATUS_OK] = x1;
        fArr[NO_MORE_TEXT] = x2;
        return fArr;
    }

    protected float[] findLimitsTwoLines() {
        boolean repeat = false;
        while (true) {
            if (repeat && this.currentLeading == GLOBAL_SPACE_CHAR_RATIO) {
                return null;
            }
            repeat = true;
            float[] x1 = findLimitsOneLine();
            if (this.lineStatus == NO_MORE_TEXT) {
                return null;
            }
            this.yLine -= this.currentLeading;
            if (this.lineStatus != NO_MORE_COLUMN) {
                float[] x2 = findLimitsOneLine();
                if (this.lineStatus == NO_MORE_TEXT) {
                    return null;
                }
                if (this.lineStatus == NO_MORE_COLUMN) {
                    this.yLine -= this.currentLeading;
                } else if (x1[LINE_STATUS_OK] < x2[NO_MORE_TEXT] && x2[LINE_STATUS_OK] < x1[NO_MORE_TEXT]) {
                    float[] fArr = new float[AR_COMPOSEDTASHKEEL];
                    fArr[LINE_STATUS_OK] = x1[LINE_STATUS_OK];
                    fArr[NO_MORE_TEXT] = x1[NO_MORE_TEXT];
                    fArr[NO_MORE_COLUMN] = x2[LINE_STATUS_OK];
                    fArr[3] = x2[NO_MORE_TEXT];
                    return fArr;
                }
            }
        }
    }

    public void setColumns(float[] leftLine, float[] rightLine) {
        this.maxY = -1.0E21f;
        this.minY = 1.0E21f;
        setYLine(Math.max(leftLine[NO_MORE_TEXT], leftLine[leftLine.length - 1]));
        this.rightWall = convertColumn(rightLine);
        this.leftWall = convertColumn(leftLine);
        this.rectangularWidth = -1.0f;
        this.rectangularMode = false;
    }

    public void setSimpleColumn(Phrase phrase, float llx, float lly, float urx, float ury, float leading, int alignment) {
        addText(phrase);
        setSimpleColumn(llx, lly, urx, ury, leading, alignment);
    }

    public void setSimpleColumn(float llx, float lly, float urx, float ury, float leading, int alignment) {
        setLeading(leading);
        this.alignment = alignment;
        setSimpleColumn(llx, lly, urx, ury);
    }

    public void setSimpleColumn(float llx, float lly, float urx, float ury) {
        this.leftX = Math.min(llx, urx);
        this.maxY = Math.max(lly, ury);
        this.minY = Math.min(lly, ury);
        this.rightX = Math.max(llx, urx);
        this.yLine = this.maxY;
        this.rectangularWidth = this.rightX - this.leftX;
        if (this.rectangularWidth < GLOBAL_SPACE_CHAR_RATIO) {
            this.rectangularWidth = GLOBAL_SPACE_CHAR_RATIO;
        }
        this.rectangularMode = true;
    }

    public void setSimpleColumn(Rectangle rect) {
        setSimpleColumn(rect.getLeft(), rect.getBottom(), rect.getRight(), rect.getTop());
    }

    public void setLeading(float leading) {
        this.fixedLeading = leading;
        this.multipliedLeading = GLOBAL_SPACE_CHAR_RATIO;
    }

    public void setLeading(float fixedLeading, float multipliedLeading) {
        this.fixedLeading = fixedLeading;
        this.multipliedLeading = multipliedLeading;
    }

    public float getLeading() {
        return this.fixedLeading;
    }

    public float getMultipliedLeading() {
        return this.multipliedLeading;
    }

    public void setYLine(float yLine) {
        this.yLine = yLine;
    }

    public float getYLine() {
        return this.yLine;
    }

    public int getRowsDrawn() {
        return this.rowIdx;
    }

    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }

    public int getAlignment() {
        return this.alignment;
    }

    public void setIndent(float indent) {
        setIndent(indent, true);
    }

    public void setIndent(float indent, boolean repeatFirstLineIndent) {
        this.indent = indent;
        this.lastWasNewline = true;
        this.repeatFirstLineIndent = repeatFirstLineIndent;
    }

    public float getIndent() {
        return this.indent;
    }

    public void setFollowingIndent(float indent) {
        this.followingIndent = indent;
        this.lastWasNewline = true;
    }

    public float getFollowingIndent() {
        return this.followingIndent;
    }

    public void setRightIndent(float indent) {
        this.rightIndent = indent;
        this.lastWasNewline = true;
    }

    public float getRightIndent() {
        return this.rightIndent;
    }

    public float getCurrentLeading() {
        return this.currentLeading;
    }

    public boolean getInheritGraphicState() {
        return this.inheritGraphicState;
    }

    public void setInheritGraphicState(boolean inheritGraphicState) {
        this.inheritGraphicState = inheritGraphicState;
    }

    public int go() throws DocumentException {
        return go(false);
    }

    public int go(boolean simulate) throws DocumentException {
        return go(simulate, null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int go(boolean r35, com.itextpdf.text.pdf.interfaces.IAccessibleElement r36) throws com.itextpdf.text.DocumentException {
        /*
        r34 = this;
        r0 = r34;
        r2 = r0.composite;
        if (r2 == 0) goto L_0x000b;
    L_0x0006:
        r28 = r34.goComposite(r35);
    L_0x000a:
        return r28;
    L_0x000b:
        r20 = 0;
        r0 = r34;
        r2 = r0.canvas;
        r2 = isTagged(r2);
        if (r2 == 0) goto L_0x0025;
    L_0x0017:
        r0 = r36;
        r2 = r0 instanceof com.itextpdf.text.ListItem;
        if (r2 == 0) goto L_0x0025;
    L_0x001d:
        r2 = r36;
        r2 = (com.itextpdf.text.ListItem) r2;
        r20 = r2.getListBody();
    L_0x0025:
        r34.addWaitingPhrase();
        r0 = r34;
        r2 = r0.bidiLine;
        if (r2 != 0) goto L_0x0031;
    L_0x002e:
        r28 = 1;
        goto L_0x000a;
    L_0x0031:
        r2 = 0;
        r0 = r34;
        r0.descender = r2;
        r2 = 0;
        r0 = r34;
        r0.linesWritten = r2;
        r2 = 0;
        r0 = r34;
        r0.lastX = r2;
        r16 = 0;
        r0 = r34;
        r0 = r0.spaceCharRatio;
        r27 = r0;
        r2 = 2;
        r15 = new java.lang.Object[r2];
        r14 = 0;
        r21 = new java.lang.Float;
        r2 = 0;
        r0 = r21;
        r0.<init>(r2);
        r2 = 1;
        r15[r2] = r21;
        r26 = 0;
        r18 = 0;
        r30 = 0;
        r2 = 2143289344; // 0x7fc00000 float:NaN double:1.058925634E-314;
        r0 = r34;
        r0.firstLineY = r2;
        r6 = 1;
        r0 = r34;
        r2 = r0.runDirection;
        if (r2 == 0) goto L_0x006e;
    L_0x006a:
        r0 = r34;
        r6 = r0.runDirection;
    L_0x006e:
        r0 = r34;
        r2 = r0.canvas;
        if (r2 == 0) goto L_0x00d7;
    L_0x0074:
        r0 = r34;
        r0 = r0.canvas;
        r18 = r0;
        r0 = r34;
        r2 = r0.canvas;
        r26 = r2.getPdfDocument();
        r0 = r34;
        r2 = r0.canvas;
        r2 = isTagged(r2);
        if (r2 != 0) goto L_0x00d0;
    L_0x008c:
        r0 = r34;
        r2 = r0.canvas;
        r0 = r34;
        r4 = r0.inheritGraphicState;
        r30 = r2.getDuplicate(r4);
    L_0x0098:
        if (r35 != 0) goto L_0x00a7;
    L_0x009a:
        r2 = 0;
        r2 = (r27 > r2 ? 1 : (r27 == r2 ? 0 : -1));
        if (r2 != 0) goto L_0x00e8;
    L_0x009f:
        r2 = r30.getPdfWriter();
        r27 = r2.getSpaceCharRatio();
    L_0x00a7:
        r0 = r34;
        r2 = r0.rectangularMode;
        if (r2 != 0) goto L_0x0102;
    L_0x00ad:
        r24 = 0;
        r0 = r34;
        r2 = r0.bidiLine;
        r2 = r2.chunks;
        r19 = r2.iterator();
    L_0x00b9:
        r2 = r19.hasNext();
        if (r2 == 0) goto L_0x00f3;
    L_0x00bf:
        r13 = r19.next();
        r13 = (com.itextpdf.text.pdf.PdfChunk) r13;
        r2 = r13.height();
        r0 = r24;
        r24 = java.lang.Math.max(r0, r2);
        goto L_0x00b9;
    L_0x00d0:
        r0 = r34;
        r0 = r0.canvas;
        r30 = r0;
        goto L_0x0098;
    L_0x00d7:
        if (r35 != 0) goto L_0x0098;
    L_0x00d9:
        r2 = new java.lang.NullPointerException;
        r4 = "columntext.go.with.simulate.eq.eq.false.and.text.eq.eq.null";
        r5 = 0;
        r5 = new java.lang.Object[r5];
        r4 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r4, r5);
        r2.<init>(r4);
        throw r2;
    L_0x00e8:
        r2 = 981668463; // 0x3a83126f float:0.001 double:4.85008663E-315;
        r2 = (r27 > r2 ? 1 : (r27 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x00a7;
    L_0x00ef:
        r27 = 981668463; // 0x3a83126f float:0.001 double:4.85008663E-315;
        goto L_0x00a7;
    L_0x00f3:
        r0 = r34;
        r2 = r0.fixedLeading;
        r0 = r34;
        r4 = r0.multipliedLeading;
        r4 = r4 * r24;
        r2 = r2 + r4;
        r0 = r34;
        r0.currentLeading = r2;
    L_0x0102:
        r17 = 0;
        r28 = 0;
    L_0x0106:
        r0 = r34;
        r2 = r0.lastWasNewline;
        if (r2 == 0) goto L_0x014c;
    L_0x010c:
        r0 = r34;
        r0 = r0.indent;
        r17 = r0;
    L_0x0112:
        r0 = r34;
        r2 = r0.rectangularMode;
        if (r2 == 0) goto L_0x031c;
    L_0x0118:
        r0 = r34;
        r2 = r0.rectangularWidth;
        r0 = r34;
        r4 = r0.rightIndent;
        r4 = r4 + r17;
        r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r2 > 0) goto L_0x0153;
    L_0x0126:
        r28 = 2;
        r0 = r34;
        r2 = r0.bidiLine;
        r2 = r2.isEmpty();
        if (r2 == 0) goto L_0x0134;
    L_0x0132:
        r28 = r28 | 1;
    L_0x0134:
        if (r16 == 0) goto L_0x000a;
    L_0x0136:
        r30.endText();
        r0 = r34;
        r2 = r0.canvas;
        r0 = r30;
        if (r2 == r0) goto L_0x000a;
    L_0x0141:
        r0 = r34;
        r2 = r0.canvas;
        r0 = r30;
        r2.add(r0);
        goto L_0x000a;
    L_0x014c:
        r0 = r34;
        r0 = r0.followingIndent;
        r17 = r0;
        goto L_0x0112;
    L_0x0153:
        r0 = r34;
        r2 = r0.bidiLine;
        r2 = r2.isEmpty();
        if (r2 == 0) goto L_0x0160;
    L_0x015d:
        r28 = 1;
        goto L_0x0134;
    L_0x0160:
        r0 = r34;
        r2 = r0.bidiLine;
        r0 = r34;
        r3 = r0.leftX;
        r0 = r34;
        r4 = r0.rectangularWidth;
        r4 = r4 - r17;
        r0 = r34;
        r5 = r0.rightIndent;
        r4 = r4 - r5;
        r0 = r34;
        r5 = r0.alignment;
        r0 = r34;
        r7 = r0.arabicOptions;
        r0 = r34;
        r8 = r0.minY;
        r0 = r34;
        r9 = r0.yLine;
        r0 = r34;
        r10 = r0.descender;
        r23 = r2.processLine(r3, r4, r5, r6, r7, r8, r9, r10);
        if (r23 != 0) goto L_0x0190;
    L_0x018d:
        r28 = 1;
        goto L_0x0134;
    L_0x0190:
        r0 = r34;
        r2 = r0.fixedLeading;
        r0 = r34;
        r4 = r0.multipliedLeading;
        r0 = r23;
        r25 = r0.getMaxSize(r2, r4);
        r2 = r34.isUseAscender();
        if (r2 == 0) goto L_0x01de;
    L_0x01a4:
        r0 = r34;
        r2 = r0.firstLineY;
        r2 = java.lang.Float.isNaN(r2);
        if (r2 == 0) goto L_0x01de;
    L_0x01ae:
        r2 = r23.getAscender();
        r0 = r34;
        r0.currentLeading = r2;
    L_0x01b6:
        r0 = r34;
        r2 = r0.yLine;
        r0 = r34;
        r4 = r0.maxY;
        r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r2 > 0) goto L_0x01d3;
    L_0x01c2:
        r0 = r34;
        r2 = r0.yLine;
        r0 = r34;
        r4 = r0.currentLeading;
        r2 = r2 - r4;
        r0 = r34;
        r4 = r0.minY;
        r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r2 >= 0) goto L_0x01f2;
    L_0x01d3:
        r28 = 2;
        r0 = r34;
        r2 = r0.bidiLine;
        r2.restore();
        goto L_0x0134;
    L_0x01de:
        r2 = 0;
        r2 = r25[r2];
        r4 = 1;
        r4 = r25[r4];
        r0 = r34;
        r5 = r0.descender;
        r4 = r4 - r5;
        r2 = java.lang.Math.max(r2, r4);
        r0 = r34;
        r0.currentLeading = r2;
        goto L_0x01b6;
    L_0x01f2:
        r0 = r34;
        r2 = r0.yLine;
        r0 = r34;
        r4 = r0.currentLeading;
        r2 = r2 - r4;
        r0 = r34;
        r0.yLine = r2;
        if (r35 != 0) goto L_0x0208;
    L_0x0201:
        if (r16 != 0) goto L_0x0208;
    L_0x0203:
        r30.beginText();
        r16 = 1;
    L_0x0208:
        r0 = r34;
        r2 = r0.firstLineY;
        r2 = java.lang.Float.isNaN(r2);
        if (r2 == 0) goto L_0x021a;
    L_0x0212:
        r0 = r34;
        r2 = r0.yLine;
        r0 = r34;
        r0.firstLineY = r2;
    L_0x021a:
        r0 = r34;
        r2 = r0.rectangularWidth;
        r4 = r23.widthLeft();
        r2 = r2 - r4;
        r0 = r34;
        r0.updateFilledWidth(r2);
        r0 = r34;
        r3 = r0.leftX;
    L_0x022c:
        r0 = r34;
        r2 = r0.canvas;
        r2 = isTagged(r2);
        if (r2 == 0) goto L_0x02a0;
    L_0x0236:
        r0 = r36;
        r2 = r0 instanceof com.itextpdf.text.ListItem;
        if (r2 == 0) goto L_0x02a0;
    L_0x023c:
        r0 = r34;
        r2 = r0.firstLineY;
        r2 = java.lang.Float.isNaN(r2);
        if (r2 != 0) goto L_0x02a0;
    L_0x0246:
        r0 = r34;
        r2 = r0.firstLineYDone;
        if (r2 != 0) goto L_0x02a0;
    L_0x024c:
        if (r35 != 0) goto L_0x029b;
    L_0x024e:
        r2 = r36;
        r2 = (com.itextpdf.text.ListItem) r2;
        r22 = r2.getListLabel();
        r0 = r34;
        r2 = r0.canvas;
        r0 = r22;
        r2.openMCBlock(r0);
        r29 = new com.itextpdf.text.Chunk;
        r2 = r36;
        r2 = (com.itextpdf.text.ListItem) r2;
        r2 = r2.getListSymbol();
        r0 = r29;
        r0.<init>(r2);
        r2 = 0;
        r0 = r29;
        r0.setRole(r2);
        r0 = r34;
        r7 = r0.canvas;
        r8 = 0;
        r9 = new com.itextpdf.text.Phrase;
        r0 = r29;
        r9.<init>(r0);
        r0 = r34;
        r2 = r0.leftX;
        r4 = r22.getIndentation();
        r10 = r2 + r4;
        r0 = r34;
        r11 = r0.firstLineY;
        r12 = 0;
        showTextAligned(r7, r8, r9, r10, r11, r12);
        r0 = r34;
        r2 = r0.canvas;
        r0 = r22;
        r2.closeMCBlock(r0);
    L_0x029b:
        r2 = 1;
        r0 = r34;
        r0.firstLineYDone = r2;
    L_0x02a0:
        if (r35 != 0) goto L_0x02e3;
    L_0x02a2:
        if (r20 == 0) goto L_0x02af;
    L_0x02a4:
        r0 = r34;
        r2 = r0.canvas;
        r0 = r20;
        r2.openMCBlock(r0);
        r20 = 0;
    L_0x02af:
        r2 = 0;
        r15[r2] = r14;
        r2 = r23.isRTL();
        if (r2 == 0) goto L_0x03b0;
    L_0x02b8:
        r0 = r34;
        r2 = r0.rightIndent;
    L_0x02bc:
        r2 = r2 + r3;
        r4 = r23.indentLeft();
        r2 = r2 + r4;
        r0 = r34;
        r4 = r0.yLine;
        r0 = r30;
        r0.setTextMatrix(r2, r4);
        r7 = r26;
        r8 = r23;
        r9 = r30;
        r10 = r18;
        r11 = r15;
        r12 = r27;
        r2 = r7.writeLineToContent(r8, r9, r10, r11, r12);
        r0 = r34;
        r0.lastX = r2;
        r2 = 0;
        r14 = r15[r2];
        r14 = (com.itextpdf.text.pdf.PdfFont) r14;
    L_0x02e3:
        r0 = r34;
        r2 = r0.repeatFirstLineIndent;
        if (r2 == 0) goto L_0x03b4;
    L_0x02e9:
        r2 = r23.isNewlineSplit();
        if (r2 == 0) goto L_0x03b4;
    L_0x02ef:
        r2 = 1;
    L_0x02f0:
        r0 = r34;
        r0.lastWasNewline = r2;
        r0 = r34;
        r4 = r0.yLine;
        r2 = r23.isNewlineSplit();
        if (r2 == 0) goto L_0x03b7;
    L_0x02fe:
        r0 = r34;
        r2 = r0.extraParagraphSpace;
    L_0x0302:
        r2 = r4 - r2;
        r0 = r34;
        r0.yLine = r2;
        r0 = r34;
        r2 = r0.linesWritten;
        r2 = r2 + 1;
        r0 = r34;
        r0.linesWritten = r2;
        r2 = r23.getDescender();
        r0 = r34;
        r0.descender = r2;
        goto L_0x0106;
    L_0x031c:
        r0 = r34;
        r2 = r0.yLine;
        r0 = r34;
        r4 = r0.currentLeading;
        r33 = r2 - r4;
        r32 = r34.findLimitsTwoLines();
        if (r32 != 0) goto L_0x0342;
    L_0x032c:
        r28 = 2;
        r0 = r34;
        r2 = r0.bidiLine;
        r2 = r2.isEmpty();
        if (r2 == 0) goto L_0x033a;
    L_0x0338:
        r28 = r28 | 1;
    L_0x033a:
        r0 = r33;
        r1 = r34;
        r1.yLine = r0;
        goto L_0x0134;
    L_0x0342:
        r0 = r34;
        r2 = r0.bidiLine;
        r2 = r2.isEmpty();
        if (r2 == 0) goto L_0x0356;
    L_0x034c:
        r28 = 1;
        r0 = r33;
        r1 = r34;
        r1.yLine = r0;
        goto L_0x0134;
    L_0x0356:
        r2 = 0;
        r2 = r32[r2];
        r4 = 2;
        r4 = r32[r4];
        r3 = java.lang.Math.max(r2, r4);
        r2 = 1;
        r2 = r32[r2];
        r4 = 3;
        r4 = r32[r4];
        r31 = java.lang.Math.min(r2, r4);
        r2 = r31 - r3;
        r0 = r34;
        r4 = r0.rightIndent;
        r4 = r4 + r17;
        r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r2 <= 0) goto L_0x0106;
    L_0x0376:
        if (r35 != 0) goto L_0x037f;
    L_0x0378:
        if (r16 != 0) goto L_0x037f;
    L_0x037a:
        r30.beginText();
        r16 = 1;
    L_0x037f:
        r0 = r34;
        r2 = r0.bidiLine;
        r4 = r31 - r3;
        r4 = r4 - r17;
        r0 = r34;
        r5 = r0.rightIndent;
        r4 = r4 - r5;
        r0 = r34;
        r5 = r0.alignment;
        r0 = r34;
        r7 = r0.arabicOptions;
        r0 = r34;
        r8 = r0.minY;
        r0 = r34;
        r9 = r0.yLine;
        r0 = r34;
        r10 = r0.descender;
        r23 = r2.processLine(r3, r4, r5, r6, r7, r8, r9, r10);
        if (r23 != 0) goto L_0x022c;
    L_0x03a6:
        r28 = 1;
        r0 = r33;
        r1 = r34;
        r1.yLine = r0;
        goto L_0x0134;
    L_0x03b0:
        r2 = r17;
        goto L_0x02bc;
    L_0x03b4:
        r2 = 0;
        goto L_0x02f0;
    L_0x03b7:
        r2 = 0;
        goto L_0x0302;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.ColumnText.go(boolean, com.itextpdf.text.pdf.interfaces.IAccessibleElement):int");
    }

    public float getExtraParagraphSpace() {
        return this.extraParagraphSpace;
    }

    public void setExtraParagraphSpace(float extraParagraphSpace) {
        this.extraParagraphSpace = extraParagraphSpace;
    }

    public void clearChunks() {
        if (this.bidiLine != null) {
            this.bidiLine.clearChunks();
        }
    }

    public float getSpaceCharRatio() {
        return this.spaceCharRatio;
    }

    public void setSpaceCharRatio(float spaceCharRatio) {
        this.spaceCharRatio = spaceCharRatio;
    }

    public void setRunDirection(int runDirection) {
        if (runDirection < 0 || runDirection > 3) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("invalid.run.direction.1", runDirection));
        }
        this.runDirection = runDirection;
    }

    public int getRunDirection() {
        return this.runDirection;
    }

    public int getLinesWritten() {
        return this.linesWritten;
    }

    public float getLastX() {
        return this.lastX;
    }

    public int getArabicOptions() {
        return this.arabicOptions;
    }

    public void setArabicOptions(int arabicOptions) {
        this.arabicOptions = arabicOptions;
    }

    public float getDescender() {
        return this.descender;
    }

    public static float getWidth(Phrase phrase, int runDirection, int arabicOptions) {
        ColumnText ct = new ColumnText(null);
        ct.addText(phrase);
        ct.addWaitingPhrase();
        PdfLine line = ct.bidiLine.processLine(GLOBAL_SPACE_CHAR_RATIO, PdfPRow.RIGHT_LIMIT, LINE_STATUS_OK, runDirection, arabicOptions, GLOBAL_SPACE_CHAR_RATIO, GLOBAL_SPACE_CHAR_RATIO, GLOBAL_SPACE_CHAR_RATIO);
        if (line == null) {
            return GLOBAL_SPACE_CHAR_RATIO;
        }
        return PdfPRow.RIGHT_LIMIT - line.widthLeft();
    }

    public static float getWidth(Phrase phrase) {
        return getWidth(phrase, NO_MORE_TEXT, LINE_STATUS_OK);
    }

    public static void showTextAligned(PdfContentByte canvas, int alignment, Phrase phrase, float x, float y, float rotation, int runDirection, int arabicOptions) {
        float urx;
        float llx;
        float llx2;
        float lly;
        if (!(alignment == 0 || alignment == NO_MORE_TEXT || alignment == NO_MORE_COLUMN)) {
            alignment = LINE_STATUS_OK;
        }
        canvas.saveState();
        ColumnText ct = new ColumnText(canvas);
        float ury = BaseField.BORDER_WIDTH_MEDIUM;
        switch (alignment) {
            case LINE_STATUS_OK /*0*/:
                urx = PdfPRow.RIGHT_LIMIT;
                llx = GLOBAL_SPACE_CHAR_RATIO;
                break;
            case NO_MORE_COLUMN /*2*/:
                urx = GLOBAL_SPACE_CHAR_RATIO;
                llx = -20000.0f;
                break;
            default:
                urx = PdfPRow.RIGHT_LIMIT;
                llx = -20000.0f;
                break;
        }
        if (rotation == GLOBAL_SPACE_CHAR_RATIO) {
            llx2 = llx + x;
            lly = -1.0f + y;
            urx += x;
            ury = BaseField.BORDER_WIDTH_MEDIUM + y;
        } else {
            double alpha = (((double) rotation) * 3.141592653589793d) / 180.0d;
            float cos = (float) Math.cos(alpha);
            float sin = (float) Math.sin(alpha);
            canvas.concatCTM(cos, sin, -sin, cos, x, y);
            llx2 = llx;
            lly = -1.0f;
        }
        ct.setSimpleColumn(phrase, llx2, lly, urx, ury, BaseField.BORDER_WIDTH_MEDIUM, alignment);
        if (runDirection == 3) {
            if (alignment == 0) {
                alignment = NO_MORE_COLUMN;
            } else if (alignment == NO_MORE_COLUMN) {
                alignment = LINE_STATUS_OK;
            }
        }
        ct.setAlignment(alignment);
        ct.setArabicOptions(arabicOptions);
        ct.setRunDirection(runDirection);
        try {
            ct.go();
            canvas.restoreState();
        } catch (DocumentException e) {
            throw new ExceptionConverter(e);
        }
    }

    public static void showTextAligned(PdfContentByte canvas, int alignment, Phrase phrase, float x, float y, float rotation) {
        showTextAligned(canvas, alignment, phrase, x, y, rotation, NO_MORE_TEXT, LINE_STATUS_OK);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static float fitText(com.itextpdf.text.Font r23, java.lang.String r24, com.itextpdf.text.Rectangle r25, float r26, int r27) {
        /*
        r13 = 0;
        r21 = 0;
        r4 = 0;
        r4 = (r26 > r4 ? 1 : (r26 == r4 ? 0 : -1));
        if (r4 > 0) goto L_0x0042;
    L_0x0008:
        r12 = 0;
        r16 = 0;
        r22 = r24.toCharArray();	 Catch:{ Exception -> 0x00de }
        r15 = 0;
    L_0x0010:
        r0 = r22;
        r4 = r0.length;	 Catch:{ Exception -> 0x00de }
        if (r15 >= r4) goto L_0x0029;
    L_0x0015:
        r4 = r22[r15];	 Catch:{ Exception -> 0x00de }
        r5 = 10;
        if (r4 != r5) goto L_0x0020;
    L_0x001b:
        r16 = r16 + 1;
    L_0x001d:
        r15 = r15 + 1;
        goto L_0x0010;
    L_0x0020:
        r4 = r22[r15];	 Catch:{ Exception -> 0x00de }
        r5 = 13;
        if (r4 != r5) goto L_0x001d;
    L_0x0026:
        r12 = r12 + 1;
        goto L_0x001d;
    L_0x0029:
        r0 = r16;
        r4 = java.lang.Math.max(r12, r0);	 Catch:{ Exception -> 0x00de }
        r19 = r4 + 1;
        r4 = r25.getHeight();	 Catch:{ Exception -> 0x00de }
        r4 = java.lang.Math.abs(r4);	 Catch:{ Exception -> 0x00de }
        r0 = r19;
        r5 = (float) r0;	 Catch:{ Exception -> 0x00de }
        r4 = r4 / r5;
        r5 = 981668463; // 0x3a83126f float:0.001 double:4.85008663E-315;
        r26 = r4 - r5;
    L_0x0042:
        r0 = r23;
        r1 = r26;
        r0.setSize(r1);	 Catch:{ Exception -> 0x00de }
        r3 = new com.itextpdf.text.Phrase;	 Catch:{ Exception -> 0x00de }
        r0 = r24;
        r1 = r23;
        r3.<init>(r0, r1);	 Catch:{ Exception -> 0x00de }
        r2 = new com.itextpdf.text.pdf.ColumnText;	 Catch:{ Exception -> 0x00de }
        r4 = 0;
        r2.<init>(r4);	 Catch:{ Exception -> 0x00de }
        r4 = r25.getLeft();	 Catch:{ Exception -> 0x00e6 }
        r5 = r25.getBottom();	 Catch:{ Exception -> 0x00e6 }
        r6 = r25.getRight();	 Catch:{ Exception -> 0x00e6 }
        r7 = r25.getTop();	 Catch:{ Exception -> 0x00e6 }
        r9 = 0;
        r8 = r26;
        r2.setSimpleColumn(r3, r4, r5, r6, r7, r8, r9);	 Catch:{ Exception -> 0x00e6 }
        r0 = r27;
        r2.setRunDirection(r0);	 Catch:{ Exception -> 0x00e6 }
        r4 = 1;
        r21 = r2.go(r4);	 Catch:{ Exception -> 0x00e6 }
        r4 = r21 & 1;
        if (r4 == 0) goto L_0x007f;
    L_0x007c:
        r10 = r26;
    L_0x007e:
        return r10;
    L_0x007f:
        r20 = 1036831949; // 0x3dcccccd float:0.1 double:5.122630465E-315;
        r18 = 0;
        r17 = r26;
        r10 = r26;
        r15 = 0;
        r13 = r2;
    L_0x008a:
        r4 = 50;
        if (r15 >= r4) goto L_0x00dc;
    L_0x008e:
        r4 = r18 + r17;
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r10 = r4 / r5;
        r2 = new com.itextpdf.text.pdf.ColumnText;	 Catch:{ Exception -> 0x00de }
        r4 = 0;
        r2.<init>(r4);	 Catch:{ Exception -> 0x00de }
        r0 = r23;
        r0.setSize(r10);	 Catch:{ Exception -> 0x00e6 }
        r5 = new com.itextpdf.text.Phrase;	 Catch:{ Exception -> 0x00e6 }
        r0 = r24;
        r1 = r23;
        r5.<init>(r0, r1);	 Catch:{ Exception -> 0x00e6 }
        r6 = r25.getLeft();	 Catch:{ Exception -> 0x00e6 }
        r7 = r25.getBottom();	 Catch:{ Exception -> 0x00e6 }
        r8 = r25.getRight();	 Catch:{ Exception -> 0x00e6 }
        r9 = r25.getTop();	 Catch:{ Exception -> 0x00e6 }
        r11 = 0;
        r4 = r2;
        r4.setSimpleColumn(r5, r6, r7, r8, r9, r10, r11);	 Catch:{ Exception -> 0x00e6 }
        r0 = r27;
        r2.setRunDirection(r0);	 Catch:{ Exception -> 0x00e6 }
        r4 = 1;
        r21 = r2.go(r4);	 Catch:{ Exception -> 0x00e6 }
        r4 = r21 & 1;
        if (r4 == 0) goto L_0x00d9;
    L_0x00cb:
        r4 = r17 - r18;
        r5 = r10 * r20;
        r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1));
        if (r4 < 0) goto L_0x007e;
    L_0x00d3:
        r18 = r10;
    L_0x00d5:
        r15 = r15 + 1;
        r13 = r2;
        goto L_0x008a;
    L_0x00d9:
        r17 = r10;
        goto L_0x00d5;
    L_0x00dc:
        r2 = r13;
        goto L_0x007e;
    L_0x00de:
        r14 = move-exception;
        r2 = r13;
    L_0x00e0:
        r4 = new com.itextpdf.text.ExceptionConverter;
        r4.<init>(r14);
        throw r4;
    L_0x00e6:
        r14 = move-exception;
        goto L_0x00e0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.ColumnText.fitText(com.itextpdf.text.Font, java.lang.String, com.itextpdf.text.Rectangle, float, int):float");
    }

    protected int goComposite(boolean simulate) throws DocumentException {
        if (this.canvas != null) {
            PdfDocument pdf = this.canvas.pdf;
        }
        if (this.rectangularMode) {
            this.linesWritten = LINE_STATUS_OK;
            this.descender = GLOBAL_SPACE_CHAR_RATIO;
            boolean firstPass = true;
            while (!this.compositeElements.isEmpty()) {
                Element element = (Element) this.compositeElements.getFirst();
                int status;
                int keep;
                float lastY;
                boolean createHere;
                ColumnText columnText;
                boolean z;
                boolean keepCandidate;
                boolean s;
                if (element.type() == 12) {
                    Phrase para = (Paragraph) element;
                    status = LINE_STATUS_OK;
                    keep = LINE_STATUS_OK;
                    while (keep < NO_MORE_COLUMN) {
                        lastY = this.yLine;
                        createHere = false;
                        if (this.compositeColumn == null) {
                            this.compositeColumn = new ColumnText(this.canvas);
                            this.compositeColumn.setAlignment(para.getAlignment());
                            this.compositeColumn.setIndent(para.getIndentationLeft() + para.getFirstLineIndent(), false);
                            this.compositeColumn.setExtraParagraphSpace(para.getExtraParagraphSpace());
                            this.compositeColumn.setFollowingIndent(para.getIndentationLeft());
                            this.compositeColumn.setRightIndent(para.getIndentationRight());
                            this.compositeColumn.setLeading(para.getLeading(), para.getMultipliedLeading());
                            this.compositeColumn.setRunDirection(this.runDirection);
                            this.compositeColumn.setArabicOptions(this.arabicOptions);
                            this.compositeColumn.setSpaceCharRatio(this.spaceCharRatio);
                            this.compositeColumn.addText(para);
                            if (!(firstPass && this.adjustFirstLine)) {
                                this.yLine -= para.getSpacingBefore();
                            }
                            createHere = true;
                        }
                        columnText = this.compositeColumn;
                        z = ((firstPass || this.descender == GLOBAL_SPACE_CHAR_RATIO) && this.adjustFirstLine) ? this.useAscender : false;
                        columnText.setUseAscender(z);
                        this.compositeColumn.setInheritGraphicState(this.inheritGraphicState);
                        this.compositeColumn.leftX = this.leftX;
                        this.compositeColumn.rightX = this.rightX;
                        this.compositeColumn.yLine = this.yLine;
                        this.compositeColumn.rectangularWidth = this.rectangularWidth;
                        this.compositeColumn.rectangularMode = this.rectangularMode;
                        this.compositeColumn.minY = this.minY;
                        this.compositeColumn.maxY = this.maxY;
                        keepCandidate = para.getKeepTogether() && createHere && !(firstPass && this.adjustFirstLine);
                        s = simulate || (keepCandidate && keep == 0);
                        if (isTagged(this.canvas) && !s) {
                            this.canvas.openMCBlock(para);
                        }
                        status = this.compositeColumn.go(s);
                        if (isTagged(this.canvas) && !s) {
                            this.canvas.closeMCBlock(para);
                        }
                        this.lastX = this.compositeColumn.getLastX();
                        updateFilledWidth(this.compositeColumn.filledWidth);
                        if ((status & NO_MORE_TEXT) == 0 && keepCandidate) {
                            this.compositeColumn = null;
                            this.yLine = lastY;
                            return NO_MORE_COLUMN;
                        }
                        if (!simulate && keepCandidate) {
                            if (keep == 0) {
                                this.compositeColumn = null;
                                this.yLine = lastY;
                            }
                            keep += NO_MORE_TEXT;
                        }
                        firstPass = false;
                        if (this.compositeColumn.getLinesWritten() > 0) {
                            this.yLine = this.compositeColumn.yLine;
                            this.linesWritten += this.compositeColumn.linesWritten;
                            this.descender = this.compositeColumn.descender;
                        }
                        this.currentLeading = this.compositeColumn.currentLeading;
                        if ((status & NO_MORE_TEXT) != 0) {
                            this.compositeColumn = null;
                            this.compositeElements.removeFirst();
                            this.yLine -= para.getSpacingAfter();
                        }
                        if ((status & NO_MORE_COLUMN) != 0) {
                            return NO_MORE_COLUMN;
                        }
                    }
                    firstPass = false;
                    if (this.compositeColumn.getLinesWritten() > 0) {
                        this.yLine = this.compositeColumn.yLine;
                        this.linesWritten += this.compositeColumn.linesWritten;
                        this.descender = this.compositeColumn.descender;
                    }
                    this.currentLeading = this.compositeColumn.currentLeading;
                    if ((status & NO_MORE_TEXT) != 0) {
                        this.compositeColumn = null;
                        this.compositeElements.removeFirst();
                        this.yLine -= para.getSpacingAfter();
                    }
                    if ((status & NO_MORE_COLUMN) != 0) {
                        return NO_MORE_COLUMN;
                    }
                } else if (element.type() == 14) {
                    List list = (List) element;
                    ArrayList<Element> items = list.getItems();
                    Phrase item = null;
                    float listIndentation = list.getIndentationLeft();
                    int count = LINE_STATUS_OK;
                    Stack<Object[]> stack = new Stack();
                    k = LINE_STATUS_OK;
                    while (k < items.size()) {
                        ListItem obj = items.get(k);
                        if (obj instanceof ListItem) {
                            if (count == this.listIdx) {
                                item = obj;
                                status = LINE_STATUS_OK;
                                keep = LINE_STATUS_OK;
                                while (keep < NO_MORE_COLUMN) {
                                    lastY = this.yLine;
                                    createHere = false;
                                    if (this.compositeColumn == null) {
                                        if (item != null) {
                                            this.listIdx = LINE_STATUS_OK;
                                            this.compositeElements.removeFirst();
                                        } else {
                                            this.compositeColumn = new ColumnText(this.canvas);
                                            columnText = this.compositeColumn;
                                            z = ((firstPass || this.descender == GLOBAL_SPACE_CHAR_RATIO) && this.adjustFirstLine) ? this.useAscender : false;
                                            columnText.setUseAscender(z);
                                            this.compositeColumn.setInheritGraphicState(this.inheritGraphicState);
                                            this.compositeColumn.setAlignment(item.getAlignment());
                                            this.compositeColumn.setIndent((item.getIndentationLeft() + listIndentation) + item.getFirstLineIndent(), false);
                                            this.compositeColumn.setExtraParagraphSpace(item.getExtraParagraphSpace());
                                            this.compositeColumn.setFollowingIndent(this.compositeColumn.getIndent());
                                            this.compositeColumn.setRightIndent(item.getIndentationRight() + list.getIndentationRight());
                                            this.compositeColumn.setLeading(item.getLeading(), item.getMultipliedLeading());
                                            this.compositeColumn.setRunDirection(this.runDirection);
                                            this.compositeColumn.setArabicOptions(this.arabicOptions);
                                            this.compositeColumn.setSpaceCharRatio(this.spaceCharRatio);
                                            this.compositeColumn.addText(item);
                                            if (!(firstPass && this.adjustFirstLine)) {
                                                this.yLine -= item.getSpacingBefore();
                                            }
                                            createHere = true;
                                        }
                                    }
                                    this.compositeColumn.leftX = this.leftX;
                                    this.compositeColumn.rightX = this.rightX;
                                    this.compositeColumn.yLine = this.yLine;
                                    this.compositeColumn.rectangularWidth = this.rectangularWidth;
                                    this.compositeColumn.rectangularMode = this.rectangularMode;
                                    this.compositeColumn.minY = this.minY;
                                    this.compositeColumn.maxY = this.maxY;
                                    keepCandidate = item.getKeepTogether() && createHere && !(firstPass && this.adjustFirstLine);
                                    s = simulate || (keepCandidate && keep == 0);
                                    if (isTagged(this.canvas) && !s) {
                                        item.getListLabel().setIndentation(listIndentation);
                                        if (list.getFirstItem() == item || !(this.compositeColumn == null || this.compositeColumn.bidiLine == null)) {
                                            this.canvas.openMCBlock(list);
                                        }
                                        this.canvas.openMCBlock(item);
                                    }
                                    columnText = this.compositeColumn;
                                    z = simulate || (keepCandidate && keep == 0);
                                    status = columnText.go(z, item);
                                    if (isTagged(this.canvas) && !s) {
                                        this.canvas.closeMCBlock(item.getListBody());
                                        this.canvas.closeMCBlock(item);
                                        if ((list.getLastItem() == item && (status & NO_MORE_TEXT) != 0) || (status & NO_MORE_COLUMN) != 0) {
                                            this.canvas.closeMCBlock(list);
                                        }
                                    }
                                    this.lastX = this.compositeColumn.getLastX();
                                    updateFilledWidth(this.compositeColumn.filledWidth);
                                    if ((status & NO_MORE_TEXT) == 0 || !keepCandidate) {
                                        if (!simulate && keepCandidate) {
                                            if (keep == 0) {
                                                this.compositeColumn = null;
                                                this.yLine = lastY;
                                            }
                                            keep += NO_MORE_TEXT;
                                        }
                                        firstPass = false;
                                        this.yLine = this.compositeColumn.yLine;
                                        this.linesWritten += this.compositeColumn.linesWritten;
                                        this.descender = this.compositeColumn.descender;
                                        this.currentLeading = this.compositeColumn.currentLeading;
                                        if (!(isTagged(this.canvas) || Float.isNaN(this.compositeColumn.firstLineY) || this.compositeColumn.firstLineYDone)) {
                                            if (!simulate) {
                                                showTextAligned(this.canvas, LINE_STATUS_OK, new Phrase(item.getListSymbol()), this.compositeColumn.leftX + listIndentation, this.compositeColumn.firstLineY, GLOBAL_SPACE_CHAR_RATIO);
                                            }
                                            this.compositeColumn.firstLineYDone = true;
                                        }
                                        if ((status & NO_MORE_TEXT) != 0) {
                                            this.compositeColumn = null;
                                            this.listIdx += NO_MORE_TEXT;
                                            this.yLine -= item.getSpacingAfter();
                                        }
                                        if ((status & NO_MORE_COLUMN) == 0) {
                                            return NO_MORE_COLUMN;
                                        }
                                    } else {
                                        this.compositeColumn = null;
                                        this.yLine = lastY;
                                        return NO_MORE_COLUMN;
                                    }
                                }
                                firstPass = false;
                                this.yLine = this.compositeColumn.yLine;
                                this.linesWritten += this.compositeColumn.linesWritten;
                                this.descender = this.compositeColumn.descender;
                                this.currentLeading = this.compositeColumn.currentLeading;
                                if (simulate) {
                                    showTextAligned(this.canvas, LINE_STATUS_OK, new Phrase(item.getListSymbol()), this.compositeColumn.leftX + listIndentation, this.compositeColumn.firstLineY, GLOBAL_SPACE_CHAR_RATIO);
                                }
                                this.compositeColumn.firstLineYDone = true;
                                if ((status & NO_MORE_TEXT) != 0) {
                                    this.compositeColumn = null;
                                    this.listIdx += NO_MORE_TEXT;
                                    this.yLine -= item.getSpacingAfter();
                                }
                                if ((status & NO_MORE_COLUMN) == 0) {
                                    return NO_MORE_COLUMN;
                                }
                            } else {
                                count += NO_MORE_TEXT;
                            }
                        } else if (obj instanceof List) {
                            stack.push(new Object[]{list, Integer.valueOf(k), new Float(listIndentation)});
                            list = (List) obj;
                            items = list.getItems();
                            listIndentation += list.getIndentationLeft();
                            k = -1;
                            k += NO_MORE_TEXT;
                        }
                        if (k == items.size() - 1 && !stack.isEmpty()) {
                            Object[] objs = (Object[]) stack.pop();
                            list = objs[LINE_STATUS_OK];
                            items = list.getItems();
                            k = ((Integer) objs[NO_MORE_TEXT]).intValue();
                            listIndentation = ((Float) objs[NO_MORE_COLUMN]).floatValue();
                        }
                        k += NO_MORE_TEXT;
                    }
                    status = LINE_STATUS_OK;
                    keep = LINE_STATUS_OK;
                    while (keep < NO_MORE_COLUMN) {
                        lastY = this.yLine;
                        createHere = false;
                        if (this.compositeColumn == null) {
                            if (item != null) {
                                this.compositeColumn = new ColumnText(this.canvas);
                                columnText = this.compositeColumn;
                                if (!firstPass) {
                                }
                                columnText.setUseAscender(z);
                                this.compositeColumn.setInheritGraphicState(this.inheritGraphicState);
                                this.compositeColumn.setAlignment(item.getAlignment());
                                this.compositeColumn.setIndent((item.getIndentationLeft() + listIndentation) + item.getFirstLineIndent(), false);
                                this.compositeColumn.setExtraParagraphSpace(item.getExtraParagraphSpace());
                                this.compositeColumn.setFollowingIndent(this.compositeColumn.getIndent());
                                this.compositeColumn.setRightIndent(item.getIndentationRight() + list.getIndentationRight());
                                this.compositeColumn.setLeading(item.getLeading(), item.getMultipliedLeading());
                                this.compositeColumn.setRunDirection(this.runDirection);
                                this.compositeColumn.setArabicOptions(this.arabicOptions);
                                this.compositeColumn.setSpaceCharRatio(this.spaceCharRatio);
                                this.compositeColumn.addText(item);
                                this.yLine -= item.getSpacingBefore();
                                createHere = true;
                            } else {
                                this.listIdx = LINE_STATUS_OK;
                                this.compositeElements.removeFirst();
                            }
                        }
                        this.compositeColumn.leftX = this.leftX;
                        this.compositeColumn.rightX = this.rightX;
                        this.compositeColumn.yLine = this.yLine;
                        this.compositeColumn.rectangularWidth = this.rectangularWidth;
                        this.compositeColumn.rectangularMode = this.rectangularMode;
                        this.compositeColumn.minY = this.minY;
                        this.compositeColumn.maxY = this.maxY;
                        if (!item.getKeepTogether()) {
                        }
                        if (!simulate) {
                        }
                        item.getListLabel().setIndentation(listIndentation);
                        this.canvas.openMCBlock(list);
                        this.canvas.openMCBlock(item);
                        columnText = this.compositeColumn;
                        if (!simulate) {
                        }
                        status = columnText.go(z, item);
                        this.canvas.closeMCBlock(item.getListBody());
                        this.canvas.closeMCBlock(item);
                        this.canvas.closeMCBlock(list);
                        this.lastX = this.compositeColumn.getLastX();
                        updateFilledWidth(this.compositeColumn.filledWidth);
                        if ((status & NO_MORE_TEXT) == 0) {
                        }
                        if (keep == 0) {
                            this.compositeColumn = null;
                            this.yLine = lastY;
                        }
                        keep += NO_MORE_TEXT;
                    }
                    firstPass = false;
                    this.yLine = this.compositeColumn.yLine;
                    this.linesWritten += this.compositeColumn.linesWritten;
                    this.descender = this.compositeColumn.descender;
                    this.currentLeading = this.compositeColumn.currentLeading;
                    if (simulate) {
                        showTextAligned(this.canvas, LINE_STATUS_OK, new Phrase(item.getListSymbol()), this.compositeColumn.leftX + listIndentation, this.compositeColumn.firstLineY, GLOBAL_SPACE_CHAR_RATIO);
                    }
                    this.compositeColumn.firstLineYDone = true;
                    if ((status & NO_MORE_TEXT) != 0) {
                        this.compositeColumn = null;
                        this.listIdx += NO_MORE_TEXT;
                        this.yLine -= item.getSpacingAfter();
                    }
                    if ((status & NO_MORE_COLUMN) == 0) {
                        return NO_MORE_COLUMN;
                    }
                } else if (element.type() == 23) {
                    PdfPTable table = (PdfPTable) element;
                    if (table.size() <= table.getHeaderRows()) {
                        this.compositeElements.removeFirst();
                    } else {
                        float yTemp = this.yLine + this.descender;
                        if (this.rowIdx == 0 && this.adjustFirstLine) {
                            yTemp -= table.spacingBefore();
                        }
                        if (yTemp < this.minY || yTemp > this.maxY) {
                            return NO_MORE_COLUMN;
                        }
                        float tableWidth;
                        ArrayList<PdfPRow> rows;
                        int i;
                        float yLineWrite = yTemp;
                        float x1 = this.leftX;
                        this.currentLeading = GLOBAL_SPACE_CHAR_RATIO;
                        if (table.isLockedWidth()) {
                            tableWidth = table.getTotalWidth();
                            updateFilledWidth(tableWidth);
                        } else {
                            tableWidth = (this.rectangularWidth * table.getWidthPercentage()) / 100.0f;
                            table.setTotalWidth(tableWidth);
                        }
                        table.normalizeHeadersFooters();
                        int headerRows = table.getHeaderRows();
                        int footerRows = table.getFooterRows();
                        int realHeaderRows = headerRows - footerRows;
                        float headerHeight = table.getHeaderHeight();
                        float footerHeight = table.getFooterHeight();
                        boolean skipHeader = table.isSkipFirstHeader() && this.rowIdx <= realHeaderRows && (table.isComplete() || this.rowIdx != realHeaderRows);
                        if (!skipHeader) {
                            yTemp -= headerHeight;
                            if (yTemp < this.minY || yTemp > this.maxY) {
                                return NO_MORE_COLUMN;
                            }
                        }
                        if (this.rowIdx < headerRows) {
                            this.rowIdx = headerRows;
                        }
                        if (!table.isComplete()) {
                            yTemp -= footerHeight;
                        }
                        FittingRows fittingRows = table.getFittingRows(yTemp - this.minY, this.rowIdx);
                        k = fittingRows.lastRow + NO_MORE_TEXT;
                        yTemp -= fittingRows.height;
                        this.LOGGER.info("Want to split at row " + k);
                        int kTemp = k;
                        while (kTemp > this.rowIdx && kTemp < table.size() && table.getRow(kTemp).isMayNotBreak()) {
                            kTemp--;
                        }
                        if ((kTemp > this.rowIdx && kTemp < k) || (kTemp == 0 && table.getRow(LINE_STATUS_OK).isMayNotBreak() && table.isLoopCheck())) {
                            yTemp = this.minY;
                            k = kTemp;
                            table.setLoopCheck(false);
                        }
                        this.LOGGER.info("Will split at row " + k);
                        if (table.isSplitLate() && k > 0) {
                            fittingRows.correctLastRowChosen(table, k - 1);
                        }
                        if (!table.isComplete()) {
                            yTemp += footerHeight;
                        }
                        if (!table.isSplitRows()) {
                            this.splittedRow = -1;
                            if (k == this.rowIdx) {
                                if (k == table.size()) {
                                    this.compositeElements.removeFirst();
                                } else {
                                    table.getRows().remove(k);
                                    return NO_MORE_COLUMN;
                                }
                            }
                        } else if (table.isSplitLate() && this.rowIdx < k) {
                            this.splittedRow = -1;
                        } else if (k < table.size()) {
                            yTemp -= fittingRows.completedRowsHeight - fittingRows.height;
                            PdfPRow newRow = table.getRow(k).splitRow(table, k, yTemp - this.minY);
                            if (newRow == null) {
                                this.LOGGER.info("Didn't split row!");
                                this.splittedRow = -1;
                                if (this.rowIdx == k) {
                                    return NO_MORE_COLUMN;
                                }
                            }
                            if (k != this.splittedRow) {
                                this.splittedRow = k + NO_MORE_TEXT;
                                PdfPTable pdfPTable = new PdfPTable(table);
                                this.compositeElements.set(LINE_STATUS_OK, pdfPTable);
                                rows = pdfPTable.getRows();
                                for (i = headerRows; i < this.rowIdx; i += NO_MORE_TEXT) {
                                    rows.set(i, null);
                                }
                                table = pdfPTable;
                            }
                            yTemp = this.minY;
                            k += NO_MORE_TEXT;
                            table.getRows().add(k, newRow);
                            this.LOGGER.info("Inserting row at position " + k);
                        }
                        firstPass = false;
                        if (!simulate) {
                            PdfPTableEvent tableEvent;
                            switch (table.getHorizontalAlignment()) {
                                case LINE_STATUS_OK /*0*/:
                                    break;
                                case NO_MORE_COLUMN /*2*/:
                                    x1 += this.rectangularWidth - tableWidth;
                                    break;
                                default:
                                    x1 += (this.rectangularWidth - tableWidth) / BaseField.BORDER_WIDTH_MEDIUM;
                                    break;
                            }
                            PdfPTable nt = PdfPTable.shallowCopy(table);
                            ArrayList<PdfPRow> sub = nt.getRows();
                            if (skipHeader || realHeaderRows <= 0) {
                                nt.setHeaderRows(footerRows);
                            } else {
                                rows = table.getRows(LINE_STATUS_OK, realHeaderRows);
                                if (isTagged(this.canvas)) {
                                    nt.getHeader().rows = rows;
                                }
                                sub.addAll(rows);
                            }
                            rows = table.getRows(this.rowIdx, k);
                            if (isTagged(this.canvas)) {
                                nt.getBody().rows = rows;
                            }
                            sub.addAll(rows);
                            boolean showFooter = !table.isSkipLastFooter();
                            boolean newPageFollows = false;
                            if (k < table.size()) {
                                nt.setComplete(true);
                                showFooter = true;
                                newPageFollows = true;
                            }
                            if (footerRows > 0 && nt.isComplete() && showFooter) {
                                rows = table.getRows(realHeaderRows, realHeaderRows + footerRows);
                                if (isTagged(this.canvas)) {
                                    nt.getFooter().rows = rows;
                                }
                                sub.addAll(rows);
                            } else {
                                footerRows = LINE_STATUS_OK;
                            }
                            float rowHeight = GLOBAL_SPACE_CHAR_RATIO;
                            int lastIdx = (sub.size() - 1) - footerRows;
                            PdfPRow last = (PdfPRow) sub.get(lastIdx);
                            if (table.isExtendLastRow(newPageFollows)) {
                                rowHeight = last.getMaxHeights();
                                last.setMaxHeights((yTemp - this.minY) + rowHeight);
                                yTemp = this.minY;
                            }
                            if (newPageFollows) {
                                tableEvent = table.getTableEvent();
                                if (tableEvent instanceof PdfPTableEventSplit) {
                                    ((PdfPTableEventSplit) tableEvent).splitTable(table);
                                }
                            }
                            if (this.canvases != null) {
                                if (isTagged(this.canvases[3])) {
                                    this.canvases[3].openMCBlock(table);
                                }
                                nt.writeSelectedRows((int) LINE_STATUS_OK, -1, (int) LINE_STATUS_OK, -1, x1, yLineWrite, this.canvases, false);
                                if (isTagged(this.canvases[3])) {
                                    this.canvases[3].closeMCBlock(table);
                                }
                            } else {
                                if (isTagged(this.canvas)) {
                                    this.canvas.openMCBlock(table);
                                }
                                nt.writeSelectedRows((int) LINE_STATUS_OK, -1, (int) LINE_STATUS_OK, -1, x1, yLineWrite, this.canvas, false);
                                if (isTagged(this.canvas)) {
                                    this.canvas.closeMCBlock(table);
                                }
                            }
                            if (this.splittedRow == k && k < table.size()) {
                                ((PdfPRow) table.getRows().get(k)).copyRowContent(nt, lastIdx);
                            } else if (k > 0 && k < table.size()) {
                                table.getRow(k).splitRowspans(table, k - 1, nt, lastIdx);
                            }
                            if (table.isExtendLastRow(newPageFollows)) {
                                last.setMaxHeights(rowHeight);
                            }
                            if (newPageFollows) {
                                tableEvent = table.getTableEvent();
                                if (tableEvent instanceof PdfPTableEventAfterSplit) {
                                    ((PdfPTableEventAfterSplit) tableEvent).afterSplitTable(table, table.getRow(k), k);
                                }
                            }
                        } else if (table.isExtendLastRow() && this.minY > PdfPRow.BOTTOM_LIMIT) {
                            yTemp = this.minY;
                        }
                        this.yLine = yTemp;
                        this.descender = GLOBAL_SPACE_CHAR_RATIO;
                        this.currentLeading = GLOBAL_SPACE_CHAR_RATIO;
                        if (!(skipHeader || table.isComplete())) {
                            this.yLine += footerHeight;
                        }
                        while (k < table.size() && table.getRowHeight(k) <= GLOBAL_SPACE_CHAR_RATIO && !table.hasRowspan(k)) {
                            k += NO_MORE_TEXT;
                        }
                        if (k >= table.size()) {
                            if (this.yLine - table.spacingAfter() < this.minY) {
                                this.yLine = this.minY;
                            } else {
                                this.yLine -= table.spacingAfter();
                            }
                            this.compositeElements.removeFirst();
                            this.splittedRow = -1;
                            this.rowIdx = LINE_STATUS_OK;
                        } else {
                            if (this.splittedRow != -1) {
                                rows = table.getRows();
                                for (i = this.rowIdx; i < k; i += NO_MORE_TEXT) {
                                    rows.set(i, null);
                                }
                            }
                            this.rowIdx = k;
                            return NO_MORE_COLUMN;
                        }
                    }
                } else if (element.type() == 55) {
                    if (!simulate) {
                        ((DrawInterface) element).draw(this.canvas, this.leftX, this.minY, this.rightX, this.maxY, this.yLine);
                    }
                    this.compositeElements.removeFirst();
                } else if (element.type() == 37) {
                    FloatLayout floatLayout;
                    ArrayList<Element> floatingElements = new ArrayList();
                    do {
                        floatingElements.add(element);
                        this.compositeElements.removeFirst();
                        element = !this.compositeElements.isEmpty() ? (Element) this.compositeElements.getFirst() : null;
                        if (element != null) {
                        }
                        floatLayout = new FloatLayout(floatingElements, this.useAscender);
                        floatLayout.setSimpleColumn(this.leftX, this.minY, this.rightX, this.yLine);
                        status = floatLayout.layout(this.canvas, simulate);
                        this.yLine = floatLayout.getYLine();
                        this.descender = GLOBAL_SPACE_CHAR_RATIO;
                        if ((status & NO_MORE_TEXT) == 0) {
                            this.compositeElements.addAll(floatingElements);
                            return status;
                        }
                    } while (element.type() == 37);
                    floatLayout = new FloatLayout(floatingElements, this.useAscender);
                    floatLayout.setSimpleColumn(this.leftX, this.minY, this.rightX, this.yLine);
                    status = floatLayout.layout(this.canvas, simulate);
                    this.yLine = floatLayout.getYLine();
                    this.descender = GLOBAL_SPACE_CHAR_RATIO;
                    if ((status & NO_MORE_TEXT) == 0) {
                        this.compositeElements.addAll(floatingElements);
                        return status;
                    }
                } else {
                    this.compositeElements.removeFirst();
                }
            }
            return NO_MORE_TEXT;
        }
        throw new DocumentException(MessageLocalization.getComposedMessage("irregular.columns.are.not.supported.in.composite.mode", new Object[LINE_STATUS_OK]));
    }

    public PdfContentByte getCanvas() {
        return this.canvas;
    }

    public void setCanvas(PdfContentByte canvas) {
        this.canvas = canvas;
        this.canvases = null;
        if (this.compositeColumn != null) {
            this.compositeColumn.setCanvas(canvas);
        }
    }

    public void setCanvases(PdfContentByte[] canvases) {
        this.canvases = canvases;
        this.canvas = canvases[3];
        if (this.compositeColumn != null) {
            this.compositeColumn.setCanvases(canvases);
        }
    }

    public PdfContentByte[] getCanvases() {
        return this.canvases;
    }

    public boolean zeroHeightElement() {
        return this.composite && !this.compositeElements.isEmpty() && ((Element) this.compositeElements.getFirst()).type() == 55;
    }

    public java.util.List<Element> getCompositeElements() {
        return this.compositeElements;
    }

    public boolean isUseAscender() {
        return this.useAscender;
    }

    public void setUseAscender(boolean useAscender) {
        this.useAscender = useAscender;
    }

    public static boolean hasMoreText(int status) {
        return (status & NO_MORE_TEXT) == 0;
    }

    public float getFilledWidth() {
        return this.filledWidth;
    }

    public void setFilledWidth(float filledWidth) {
        this.filledWidth = filledWidth;
    }

    public void updateFilledWidth(float w) {
        if (w > this.filledWidth) {
            this.filledWidth = w;
        }
    }

    public boolean isAdjustFirstLine() {
        return this.adjustFirstLine;
    }

    public void setAdjustFirstLine(boolean adjustFirstLine) {
        this.adjustFirstLine = adjustFirstLine;
    }

    private static boolean isTagged(PdfContentByte canvas) {
        return (canvas == null || canvas.pdf == null || canvas.writer == null || !canvas.writer.isTagged()) ? false : true;
    }
}

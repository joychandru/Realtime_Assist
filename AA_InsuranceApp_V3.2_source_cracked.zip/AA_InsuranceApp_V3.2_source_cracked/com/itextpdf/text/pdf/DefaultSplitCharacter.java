package com.itextpdf.text.pdf;

import com.itextpdf.text.SplitCharacter;

public class DefaultSplitCharacter implements SplitCharacter {
    public static final SplitCharacter DEFAULT;
    protected char[] characters;

    static {
        DEFAULT = new DefaultSplitCharacter();
    }

    public DefaultSplitCharacter(char character) {
        this(new char[]{character});
    }

    public DefaultSplitCharacter(char[] characters) {
        this.characters = characters;
    }

    public boolean isSplitCharacter(int start, int current, int end, char[] cc, PdfChunk[] ck) {
        char c = getCurrentCharacter(current, cc, ck);
        if (this.characters != null) {
            for (char c2 : this.characters) {
                if (c == c2) {
                    return true;
                }
            }
            return false;
        } else if (c <= ' ' || c == '-' || c == '\u2010') {
            return true;
        } else {
            if (c < '\u2002') {
                return false;
            }
            if (c >= '\u2002' && c <= '\u200b') {
                return true;
            }
            if (c >= '\u2e80' && c < '\ud7a0') {
                return true;
            }
            if (c >= '\uf900' && c < '\ufb00') {
                return true;
            }
            if (c >= '\ufe30' && c < '\ufe50') {
                return true;
            }
            if (c < '\uff61' || c >= '\uffa0') {
                return false;
            }
            return true;
        }
    }

    protected char getCurrentCharacter(int current, char[] cc, PdfChunk[] ck) {
        if (ck == null) {
            return cc[current];
        }
        return (char) ck[Math.min(current, ck.length - 1)].getUnicodeEquivalent(cc[current]);
    }
}

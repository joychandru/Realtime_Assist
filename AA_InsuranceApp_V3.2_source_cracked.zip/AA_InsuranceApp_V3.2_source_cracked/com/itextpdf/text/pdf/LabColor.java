package com.itextpdf.text.pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.pdf.codec.TIFFConstants;

public class LabColor extends ExtendedColor {
    private float f85a;
    private float f86b;
    private float f87l;
    PdfLabColor labColorSpace;

    public LabColor(PdfLabColor labColorSpace, float l, float a, float b) {
        super(7);
        this.labColorSpace = labColorSpace;
        this.f87l = l;
        this.f85a = a;
        this.f86b = b;
        BaseColor altRgbColor = labColorSpace.lab2Rgb(l, a, b);
        setValue(altRgbColor.getRed(), altRgbColor.getGreen(), altRgbColor.getBlue(), TIFFConstants.TIFFTAG_OSUBFILETYPE);
    }

    public PdfLabColor getLabColorSpace() {
        return this.labColorSpace;
    }

    public float getL() {
        return this.f87l;
    }

    public float getA() {
        return this.f85a;
    }

    public float getB() {
        return this.f86b;
    }

    public BaseColor toRgb() {
        return this.labColorSpace.lab2Rgb(this.f87l, this.f85a, this.f86b);
    }

    CMYKColor toCmyk() {
        return this.labColorSpace.lab2Cmyk(this.f87l, this.f85a, this.f86b);
    }
}

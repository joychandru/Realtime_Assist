package com.itextpdf.text.pdf;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.collection.PdfCollectionField;
import com.itextpdf.text.pdf.internal.PdfIsoKeys;
import com.itextpdf.text.pdf.languages.DevanagariLigaturizer;
import com.itextpdf.text.pdf.languages.GujaratiLigaturizer;

public final class BidiOrder {
    public static final byte AL = (byte) 4;
    public static final byte AN = (byte) 11;
    public static final byte f10B = (byte) 15;
    public static final byte BN = (byte) 14;
    public static final byte CS = (byte) 12;
    public static final byte EN = (byte) 8;
    public static final byte ES = (byte) 9;
    public static final byte ET = (byte) 10;
    public static final byte f11L = (byte) 0;
    public static final byte LRE = (byte) 1;
    public static final byte LRO = (byte) 2;
    public static final byte NSM = (byte) 13;
    public static final byte ON = (byte) 18;
    public static final byte PDF = (byte) 7;
    public static final byte f12R = (byte) 3;
    public static final byte RLE = (byte) 5;
    public static final byte RLO = (byte) 6;
    public static final byte f13S = (byte) 16;
    public static final byte TYPE_MAX = (byte) 18;
    public static final byte TYPE_MIN = (byte) 0;
    public static final byte WS = (byte) 17;
    private static char[] baseTypes;
    private static final byte[] rtypes;
    private byte[] embeddings;
    private byte[] initialTypes;
    private byte paragraphEmbeddingLevel;
    private byte[] resultLevels;
    private byte[] resultTypes;
    private int textLength;

    public BidiOrder(byte[] types) {
        this.paragraphEmbeddingLevel = (byte) -1;
        validateTypes(types);
        this.initialTypes = (byte[]) types.clone();
        runAlgorithm();
    }

    public BidiOrder(byte[] types, byte paragraphEmbeddingLevel) {
        this.paragraphEmbeddingLevel = (byte) -1;
        validateTypes(types);
        validateParagraphEmbeddingLevel(paragraphEmbeddingLevel);
        this.initialTypes = (byte[]) types.clone();
        this.paragraphEmbeddingLevel = paragraphEmbeddingLevel;
        runAlgorithm();
    }

    public BidiOrder(char[] text, int offset, int length, byte paragraphEmbeddingLevel) {
        this.paragraphEmbeddingLevel = (byte) -1;
        this.initialTypes = new byte[length];
        for (int k = 0; k < length; k++) {
            this.initialTypes[k] = rtypes[text[offset + k]];
        }
        validateParagraphEmbeddingLevel(paragraphEmbeddingLevel);
        this.paragraphEmbeddingLevel = paragraphEmbeddingLevel;
        runAlgorithm();
    }

    public static final byte getDirection(char c) {
        return rtypes[c];
    }

    private void runAlgorithm() {
        this.textLength = this.initialTypes.length;
        this.resultTypes = (byte[]) this.initialTypes.clone();
        if (this.paragraphEmbeddingLevel == -1) {
            determineParagraphEmbeddingLevel();
        }
        this.resultLevels = new byte[this.textLength];
        setLevels(0, this.textLength, this.paragraphEmbeddingLevel);
        determineExplicitEmbeddingLevels();
        this.textLength = removeExplicitCodes();
        byte prevLevel = this.paragraphEmbeddingLevel;
        int limit;
        for (int start = 0; start < this.textLength; start = limit) {
            byte level = this.resultLevels[start];
            byte prevType = typeForLevel(Math.max(prevLevel, level));
            limit = start + 1;
            while (limit < this.textLength && this.resultLevels[limit] == level) {
                limit++;
            }
            byte succType = typeForLevel(Math.max(limit < this.textLength ? this.resultLevels[limit] : this.paragraphEmbeddingLevel, level));
            resolveWeakTypes(start, limit, level, prevType, succType);
            resolveNeutralTypes(start, limit, level, prevType, succType);
            resolveImplicitLevels(start, limit, level, prevType, succType);
            prevLevel = level;
        }
        this.textLength = reinsertExplicitCodes(this.textLength);
    }

    private void determineParagraphEmbeddingLevel() {
        byte strongType = (byte) -1;
        for (int i = 0; i < this.textLength; i++) {
            byte t = this.resultTypes[i];
            if (t == null || t == 4 || t == 3) {
                strongType = t;
                break;
            }
        }
        if (strongType == -1) {
            this.paragraphEmbeddingLevel = TYPE_MIN;
        } else if (strongType == null) {
            this.paragraphEmbeddingLevel = TYPE_MIN;
        } else {
            this.paragraphEmbeddingLevel = LRE;
        }
    }

    private void determineExplicitEmbeddingLevels() {
        this.embeddings = processEmbeddings(this.resultTypes, this.paragraphEmbeddingLevel);
        for (int i = 0; i < this.textLength; i++) {
            byte level = this.embeddings[i];
            if ((level & PdfWriter.PageModeUseOutlines) != 0) {
                level = (byte) (level & 127);
                this.resultTypes[i] = typeForLevel(level);
            }
            this.resultLevels[i] = level;
        }
    }

    private int removeExplicitCodes() {
        int w = 0;
        for (int i = 0; i < this.textLength; i++) {
            byte t = this.initialTypes[i];
            if (!(t == 1 || t == 5 || t == 2 || t == 6 || t == 7 || t == 14)) {
                this.embeddings[w] = this.embeddings[i];
                this.resultTypes[w] = this.resultTypes[i];
                this.resultLevels[w] = this.resultLevels[i];
                w++;
            }
        }
        return w;
    }

    private int reinsertExplicitCodes(int textLength) {
        int i = this.initialTypes.length;
        while (true) {
            i--;
            if (i < 0) {
                break;
            }
            byte t = this.initialTypes[i];
            if (t == 1 || t == 5 || t == 2 || t == 6 || t == 7 || t == 14) {
                this.embeddings[i] = TYPE_MIN;
                this.resultTypes[i] = t;
                this.resultLevels[i] = (byte) -1;
            } else {
                textLength--;
                this.embeddings[i] = this.embeddings[textLength];
                this.resultTypes[i] = this.resultTypes[textLength];
                this.resultLevels[i] = this.resultLevels[textLength];
            }
        }
        if (this.resultLevels[0] == (byte) -1) {
            this.resultLevels[0] = this.paragraphEmbeddingLevel;
        }
        for (i = 1; i < this.initialTypes.length; i++) {
            if (this.resultLevels[i] == (byte) -1) {
                this.resultLevels[i] = this.resultLevels[i - 1];
            }
        }
        return this.initialTypes.length;
    }

    private static byte[] processEmbeddings(byte[] resultTypes, byte paragraphEmbeddingLevel) {
        int textLength = resultTypes.length;
        byte[] embeddings = new byte[textLength];
        byte[] embeddingValueStack = new byte[62];
        int stackCounter = 0;
        int overflowAlmostCounter = 0;
        int overflowCounter = 0;
        byte currentEmbeddingLevel = paragraphEmbeddingLevel;
        byte currentEmbeddingValue = paragraphEmbeddingLevel;
        for (int i = 0; i < textLength; i++) {
            embeddings[i] = currentEmbeddingValue;
            byte t = resultTypes[i];
            switch (t) {
                case PdfWriter.markInlineElementsOnly /*1*/:
                case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
                case PdfFormField.MK_CAPTION_LEFT /*5*/:
                case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                    if (overflowCounter == 0) {
                        byte newLevel;
                        if (t == 5 || t == 6) {
                            newLevel = (byte) ((currentEmbeddingLevel + 1) | 1);
                        } else {
                            newLevel = (byte) ((currentEmbeddingLevel + 2) & -2);
                        }
                        if (newLevel >= 62) {
                            if (currentEmbeddingLevel == 60) {
                                overflowAlmostCounter++;
                                break;
                            }
                        }
                        embeddingValueStack[stackCounter] = currentEmbeddingValue;
                        stackCounter++;
                        currentEmbeddingLevel = newLevel;
                        if (t == 2 || t == 6) {
                            currentEmbeddingValue = (byte) (newLevel | PdfWriter.PageModeUseOutlines);
                        } else {
                            currentEmbeddingValue = newLevel;
                        }
                        embeddings[i] = currentEmbeddingValue;
                        break;
                    }
                    overflowCounter++;
                    break;
                case PdfCollectionField.SIZE /*7*/:
                    if (overflowCounter <= 0) {
                        if (overflowAlmostCounter <= 0 || currentEmbeddingLevel == 61) {
                            if (stackCounter <= 0) {
                                break;
                            }
                            stackCounter--;
                            currentEmbeddingValue = embeddingValueStack[stackCounter];
                            currentEmbeddingLevel = (byte) (currentEmbeddingValue & 127);
                            break;
                        }
                        overflowAlmostCounter--;
                        break;
                    }
                    overflowCounter--;
                    break;
                    break;
                case Rectangle.BOX /*15*/:
                    stackCounter = 0;
                    overflowCounter = 0;
                    overflowAlmostCounter = 0;
                    currentEmbeddingLevel = paragraphEmbeddingLevel;
                    currentEmbeddingValue = paragraphEmbeddingLevel;
                    embeddings[i] = paragraphEmbeddingLevel;
                    break;
                default:
                    break;
            }
        }
        return embeddings;
    }

    private void resolveWeakTypes(int start, int limit, byte level, byte sor, byte eor) {
        int i;
        byte preceedingCharacterType = sor;
        for (i = start; i < limit; i++) {
            byte t = this.resultTypes[i];
            if (t == 13) {
                this.resultTypes[i] = preceedingCharacterType;
            } else {
                preceedingCharacterType = t;
            }
        }
        for (i = start; i < limit; i++) {
            int j;
            if (this.resultTypes[i] == 8) {
                j = i - 1;
                while (j >= start) {
                    t = this.resultTypes[j];
                    if (t != null && t != 3 && t != 4) {
                        j--;
                    } else if (t == 4) {
                        this.resultTypes[i] = AN;
                    }
                }
            }
        }
        for (i = start; i < limit; i++) {
            if (this.resultTypes[i] == 4) {
                this.resultTypes[i] = f12R;
            }
        }
        i = start + 1;
        while (i < limit - 1) {
            if (this.resultTypes[i] == 9 || this.resultTypes[i] == 12) {
                byte prevSepType = this.resultTypes[i - 1];
                byte succSepType = this.resultTypes[i + 1];
                if (prevSepType == 8 && succSepType == 8) {
                    this.resultTypes[i] = EN;
                } else if (this.resultTypes[i] == 12 && prevSepType == 11 && succSepType == 11) {
                    this.resultTypes[i] = AN;
                }
            }
            i++;
        }
        i = start;
        while (i < limit) {
            if (this.resultTypes[i] == 10) {
                int runstart = i;
                int runlimit = findRunLimit(runstart, limit, new byte[]{ET});
                t = runstart == start ? sor : this.resultTypes[runstart - 1];
                if (t != 8) {
                    if (runlimit == limit) {
                        t = eor;
                    } else {
                        t = this.resultTypes[runlimit];
                    }
                }
                if (t == 8) {
                    setTypes(runstart, runlimit, EN);
                }
                i = runlimit;
            }
            i++;
        }
        for (i = start; i < limit; i++) {
            t = this.resultTypes[i];
            if (t == 9 || t == 10 || t == 12) {
                this.resultTypes[i] = TYPE_MAX;
            }
        }
        for (i = start; i < limit; i++) {
            if (this.resultTypes[i] == 8) {
                byte prevStrongType = sor;
                for (j = i - 1; j >= start; j--) {
                    t = this.resultTypes[j];
                    if (t == null || t == 3) {
                        prevStrongType = t;
                        break;
                    }
                }
                if (prevStrongType == null) {
                    this.resultTypes[i] = TYPE_MIN;
                }
            }
        }
    }

    private void resolveNeutralTypes(int start, int limit, byte level, byte sor, byte eor) {
        int i = start;
        while (i < limit) {
            byte t = this.resultTypes[i];
            if (t == 17 || t == 18 || t == 15 || t == 16) {
                byte leadingType;
                byte trailingType;
                byte resolvedType;
                int runstart = i;
                int runlimit = findRunLimit(runstart, limit, new byte[]{f10B, f13S, WS, TYPE_MAX});
                if (runstart == start) {
                    leadingType = sor;
                } else {
                    leadingType = this.resultTypes[runstart - 1];
                    if (!(leadingType == null || leadingType == 3)) {
                        if (leadingType == 11) {
                            leadingType = f12R;
                        } else if (leadingType == 8) {
                            leadingType = f12R;
                        }
                    }
                }
                if (runlimit == limit) {
                    trailingType = eor;
                } else {
                    trailingType = this.resultTypes[runlimit];
                    if (!(trailingType == null || trailingType == 3)) {
                        if (trailingType == 11) {
                            trailingType = f12R;
                        } else if (trailingType == 8) {
                            trailingType = f12R;
                        }
                    }
                }
                if (leadingType == trailingType) {
                    resolvedType = leadingType;
                } else {
                    resolvedType = typeForLevel(level);
                }
                setTypes(runstart, runlimit, resolvedType);
                i = runlimit;
            }
            i++;
        }
    }

    private void resolveImplicitLevels(int start, int limit, byte level, byte sor, byte eor) {
        int i;
        byte[] bArr;
        if ((level & 1) == 0) {
            for (i = start; i < limit; i++) {
                byte t = this.resultTypes[i];
                if (t != null) {
                    if (t == f12R) {
                        bArr = this.resultLevels;
                        bArr[i] = (byte) (bArr[i] + 1);
                    } else {
                        bArr = this.resultLevels;
                        bArr[i] = (byte) (bArr[i] + 2);
                    }
                }
            }
            return;
        }
        for (i = start; i < limit; i++) {
            if (this.resultTypes[i] != f12R) {
                bArr = this.resultLevels;
                bArr[i] = (byte) (bArr[i] + 1);
            }
        }
    }

    public byte[] getLevels() {
        return getLevels(new int[]{this.textLength});
    }

    public byte[] getLevels(int[] linebreaks) {
        int j;
        validateLineBreaks(linebreaks, this.textLength);
        byte[] result = (byte[]) this.resultLevels.clone();
        for (int i = 0; i < result.length; i++) {
            byte t = this.initialTypes[i];
            if (t == 15 || t == 16) {
                result[i] = this.paragraphEmbeddingLevel;
                j = i - 1;
                while (j >= 0 && isWhitespace(this.initialTypes[j])) {
                    result[j] = this.paragraphEmbeddingLevel;
                    j--;
                }
            }
        }
        int start = 0;
        for (int limit : linebreaks) {
            j = limit - 1;
            while (j >= start && isWhitespace(this.initialTypes[j])) {
                result[j] = this.paragraphEmbeddingLevel;
                j--;
            }
            start = limit;
        }
        return result;
    }

    public int[] getReordering(int[] linebreaks) {
        validateLineBreaks(linebreaks, this.textLength);
        return computeMultilineReordering(getLevels(linebreaks), linebreaks);
    }

    private static int[] computeMultilineReordering(byte[] levels, int[] linebreaks) {
        int[] result = new int[levels.length];
        int start = 0;
        for (int limit : linebreaks) {
            byte[] templevels = new byte[(limit - start)];
            System.arraycopy(levels, start, templevels, 0, templevels.length);
            int[] temporder = computeReordering(templevels);
            for (int j = 0; j < temporder.length; j++) {
                result[start + j] = temporder[j] + start;
            }
            start = limit;
        }
        return result;
    }

    private static int[] computeReordering(byte[] levels) {
        int i;
        int[] result = new int[lineLength];
        for (i = 0; i < lineLength; i++) {
            result[i] = i;
        }
        byte highestLevel = TYPE_MIN;
        byte lowestOddLevel = (byte) 63;
        for (byte level : levels) {
            if (level > highestLevel) {
                highestLevel = level;
            }
            if ((level & 1) != 0 && level < lowestOddLevel) {
                lowestOddLevel = level;
            }
        }
        byte level2 = highestLevel;
        while (level2 >= lowestOddLevel) {
            i = 0;
            while (i < lineLength) {
                if (levels[i] >= level2) {
                    int start = i;
                    int limit = i + 1;
                    while (limit < lineLength && levels[limit] >= level2) {
                        limit++;
                    }
                    int j = start;
                    for (int k = limit - 1; j < k; k--) {
                        int temp = result[j];
                        result[j] = result[k];
                        result[k] = temp;
                        j++;
                    }
                    i = limit;
                }
                i++;
            }
            level2--;
        }
        return result;
    }

    public byte getBaseLevel() {
        return this.paragraphEmbeddingLevel;
    }

    private static boolean isWhitespace(byte biditype) {
        switch (biditype) {
            case PdfWriter.markInlineElementsOnly /*1*/:
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
            case PdfCollectionField.SIZE /*7*/:
            case PdfIsoKeys.PDFISOKEY_ACTION /*14*/:
            case PdfIsoKeys.PDFISOKEY_INLINE_IMAGE /*17*/:
                return true;
            default:
                return false;
        }
    }

    private static byte typeForLevel(int level) {
        return (level & 1) == 0 ? TYPE_MIN : f12R;
    }

    private int findRunLimit(int index, int limit, byte[] validSet) {
        index--;
        while (true) {
            index++;
            if (index >= limit) {
                return limit;
            }
            byte t = this.resultTypes[index];
            int i = 0;
            while (i < validSet.length) {
                if (t != validSet[i]) {
                    i++;
                }
            }
            return index;
        }
    }

    private int findRunStart(int index, byte[] validSet) {
        while (true) {
            index--;
            if (index < 0) {
                return 0;
            }
            byte t = this.resultTypes[index];
            int i = 0;
            while (i < validSet.length) {
                if (t != validSet[i]) {
                    i++;
                }
            }
            return index + 1;
        }
    }

    private void setTypes(int start, int limit, byte newType) {
        for (int i = start; i < limit; i++) {
            this.resultTypes[i] = newType;
        }
    }

    private void setLevels(int start, int limit, byte newLevel) {
        for (int i = start; i < limit; i++) {
            this.resultLevels[i] = newLevel;
        }
    }

    private static void validateTypes(byte[] types) {
        if (types == null) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("types.is.null", new Object[0]));
        }
        int i = 0;
        while (i < types.length) {
            if (types[i] < null || types[i] > 18) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("illegal.type.value.at.1.2", String.valueOf(i), String.valueOf(types[i])));
            }
            i++;
        }
        for (i = 0; i < types.length - 1; i++) {
            if (types[i] == 15) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("b.type.before.end.of.paragraph.at.index.1", i));
            }
        }
    }

    private static void validateParagraphEmbeddingLevel(byte paragraphEmbeddingLevel) {
        if (paragraphEmbeddingLevel != -1 && paragraphEmbeddingLevel != null && paragraphEmbeddingLevel != 1) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("illegal.paragraph.embedding.level.1", (int) paragraphEmbeddingLevel));
        }
    }

    private static void validateLineBreaks(int[] linebreaks, int textLength) {
        int prev = 0;
        int i = 0;
        while (i < linebreaks.length) {
            int next = linebreaks[i];
            if (next <= prev) {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("bad.linebreak.1.at.index.2", String.valueOf(next), String.valueOf(i)));
            } else {
                prev = next;
                i++;
            }
        }
        if (prev != textLength) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("last.linebreak.must.be.at.1", textLength));
        }
    }

    static {
        rtypes = new byte[PdfWriter.CenterWindow];
        baseTypes = new char[]{'\u0000', '\b', '\u000e', '\t', '\t', '\u0010', '\n', '\n', '\u000f', '\u000b', '\u000b', '\u0010', '\f', '\f', '\u0011', '\r', '\r', '\u000f', '\u000e', '\u001b', '\u000e', '\u001c', '\u001e', '\u000f', '\u001f', '\u001f', '\u0010', ' ', ' ', '\u0011', '!', '\"', '\u0012', '#', '%', '\n', '&', '*', '\u0012', '+', '+', '\n', ',', ',', '\f', '-', '-', '\n', '.', '.', '\f', '/', '/', '\t', '0', '9', '\b', ':', ':', '\f', ';', '@', '\u0012', 'A', 'Z', '\u0000', '[', '`', '\u0012', 'a', 'z', '\u0000', '{', '~', '\u0012', '\u007f', '\u0084', '\u000e', '\u0085', '\u0085', '\u000f', '\u0086', '\u009f', '\u000e', '\u00a0', '\u00a0', '\f', '\u00a1', '\u00a1', '\u0012', '\u00a2', '\u00a5', '\n', '\u00a6', '\u00a9', '\u0012', '\u00aa', '\u00aa', '\u0000', '\u00ab', '\u00af', '\u0012', '\u00b0', '\u00b1', '\n', '\u00b2', '\u00b3', '\b', '\u00b4', '\u00b4', '\u0012', '\u00b5', '\u00b5', '\u0000', '\u00b6', '\u00b8', '\u0012', '\u00b9', '\u00b9', '\b', '\u00ba', '\u00ba', '\u0000', '\u00bb', '\u00bf', '\u0012', '\u00c0', '\u00d6', '\u0000', '\u00d7', '\u00d7', '\u0012', '\u00d8', '\u00f6', '\u0000', '\u00f7', '\u00f7', '\u0012', '\u00f8', '\u02b8', '\u0000', '\u02b9', '\u02ba', '\u0012', '\u02bb', '\u02c1', '\u0000', '\u02c2', '\u02cf', '\u0012', '\u02d0', '\u02d1', '\u0000', '\u02d2', '\u02df', '\u0012', '\u02e0', '\u02e4', '\u0000', '\u02e5', '\u02ed', '\u0012', '\u02ee', '\u02ee', '\u0000', '\u02ef', '\u02ff', '\u0012', '\u0300', '\u0357', '\r', '\u0358', '\u035c', '\u0000', '\u035d', '\u036f', '\r', '\u0370', '\u0373', '\u0000', '\u0374', '\u0375', '\u0012', '\u0376', '\u037d', '\u0000', '\u037e', '\u037e', '\u0012', '\u037f', '\u0383', '\u0000', '\u0384', '\u0385', '\u0012', '\u0386', '\u0386', '\u0000', '\u0387', '\u0387', '\u0012', '\u0388', '\u03f5', '\u0000', '\u03f6', '\u03f6', '\u0012', '\u03f7', '\u0482', '\u0000', '\u0483', '\u0486', '\r', '\u0487', '\u0487', '\u0000', '\u0488', '\u0489', '\r', '\u048a', '\u0589', '\u0000', '\u058a', '\u058a', '\u0012', '\u058b', '\u0590', '\u0000', '\u0591', '\u05a1', '\r', '\u05a2', '\u05a2', '\u0000', '\u05a3', '\u05b9', '\r', '\u05ba', '\u05ba', '\u0000', '\u05bb', '\u05bd', '\r', '\u05be', '\u05be', '\u0003', '\u05bf', '\u05bf', '\r', '\u05c0', '\u05c0', '\u0003', '\u05c1', '\u05c2', '\r', '\u05c3', '\u05c3', '\u0003', '\u05c4', '\u05c4', '\r', '\u05c5', '\u05cf', '\u0000', '\u05d0', '\u05ea', '\u0003', '\u05eb', '\u05ef', '\u0000', '\u05f0', '\u05f4', '\u0003', '\u05f5', '\u05ff', '\u0000', '\u0600', '\u0603', '\u0004', '\u0604', '\u060b', '\u0000', '\u060c', '\u060c', '\f', '\u060d', '\u060d', '\u0004', '\u060e', '\u060f', '\u0012', '\u0610', '\u0615', '\r', '\u0616', '\u061a', '\u0000', '\u061b', '\u061b', '\u0004', '\u061c', '\u061e', '\u0000', '\u061f', '\u061f', '\u0004', '\u0620', '\u0620', '\u0000', '\u0621', '\u063a', '\u0004', '\u063b', '\u063f', '\u0000', '\u0640', '\u064a', '\u0004', '\u064b', '\u0658', '\r', '\u0659', '\u065f', '\u0000', '\u0660', '\u0669', '\u000b', '\u066a', '\u066a', '\n', '\u066b', '\u066c', '\u000b', '\u066d', '\u066f', '\u0004', '\u0670', '\u0670', '\r', '\u0671', '\u06d5', '\u0004', '\u06d6', '\u06dc', '\r', '\u06dd', '\u06dd', '\u0004', '\u06de', '\u06e4', '\r', '\u06e5', '\u06e6', '\u0004', '\u06e7', '\u06e8', '\r', '\u06e9', '\u06e9', '\u0012', '\u06ea', '\u06ed', '\r', '\u06ee', '\u06ef', '\u0004', '\u06f0', '\u06f9', '\b', '\u06fa', '\u070d', '\u0004', '\u070e', '\u070e', '\u0000', '\u070f', '\u070f', '\u000e', '\u0710', '\u0710', '\u0004', '\u0711', '\u0711', '\r', '\u0712', '\u072f', '\u0004', '\u0730', '\u074a', '\r', '\u074b', '\u074c', '\u0000', '\u074d', '\u074f', '\u0004', '\u0750', '\u077f', '\u0000', '\u0780', '\u07a5', '\u0004', '\u07a6', '\u07b0', '\r', '\u07b1', '\u07b1', '\u0004', '\u07b2', '\u0900', '\u0000', '\u0901', '\u0902', '\r', '\u0903', '\u093b', '\u0000', '\u093c', '\u093c', '\r', '\u093d', '\u0940', '\u0000', '\u0941', DevanagariLigaturizer.DEVA_MATRA_AI, '\r', '\u0949', '\u094c', '\u0000', DevanagariLigaturizer.DEVA_HALANTA, DevanagariLigaturizer.DEVA_HALANTA, '\r', '\u094e', '\u0950', '\u0000', '\u0951', '\u0954', '\r', '\u0955', '\u0961', '\u0000', DevanagariLigaturizer.DEVA_MATRA_HLR, DevanagariLigaturizer.DEVA_MATRA_HLRR, '\r', '\u0964', '\u0980', '\u0000', '\u0981', '\u0981', '\r', '\u0982', '\u09bb', '\u0000', '\u09bc', '\u09bc', '\r', '\u09bd', '\u09c0', '\u0000', '\u09c1', '\u09c4', '\r', '\u09c5', '\u09cc', '\u0000', '\u09cd', '\u09cd', '\r', '\u09ce', '\u09e1', '\u0000', '\u09e2', '\u09e3', '\r', '\u09e4', '\u09f1', '\u0000', '\u09f2', '\u09f3', '\n', '\u09f4', '\u0a00', '\u0000', '\u0a01', '\u0a02', '\r', '\u0a03', '\u0a3b', '\u0000', '\u0a3c', '\u0a3c', '\r', '\u0a3d', '\u0a40', '\u0000', '\u0a41', '\u0a42', '\r', '\u0a43', '\u0a46', '\u0000', '\u0a47', '\u0a48', '\r', '\u0a49', '\u0a4a', '\u0000', '\u0a4b', '\u0a4d', '\r', '\u0a4e', '\u0a6f', '\u0000', '\u0a70', '\u0a71', '\r', '\u0a72', '\u0a80', '\u0000', '\u0a81', '\u0a82', '\r', '\u0a83', '\u0abb', '\u0000', '\u0abc', '\u0abc', '\r', '\u0abd', '\u0ac0', '\u0000', '\u0ac1', '\u0ac5', '\r', '\u0ac6', '\u0ac6', '\u0000', GujaratiLigaturizer.GUJR_MATRA_E, GujaratiLigaturizer.GUJR_MATRA_AI, '\r', '\u0ac9', '\u0acc', '\u0000', GujaratiLigaturizer.GUJR_HALANTA, GujaratiLigaturizer.GUJR_HALANTA, '\r', '\u0ace', '\u0ae1', '\u0000', GujaratiLigaturizer.GUJR_MATRA_HLR, GujaratiLigaturizer.GUJR_MATRA_HLRR, '\r', '\u0ae4', '\u0af0', '\u0000', '\u0af1', '\u0af1', '\n', '\u0af2', '\u0b00', '\u0000', '\u0b01', '\u0b01', '\r', '\u0b02', '\u0b3b', '\u0000', '\u0b3c', '\u0b3c', '\r', '\u0b3d', '\u0b3e', '\u0000', '\u0b3f', '\u0b3f', '\r', '\u0b40', '\u0b40', '\u0000', '\u0b41', '\u0b43', '\r', '\u0b44', '\u0b4c', '\u0000', '\u0b4d', '\u0b4d', '\r', '\u0b4e', '\u0b55', '\u0000', '\u0b56', '\u0b56', '\r', '\u0b57', '\u0b81', '\u0000', '\u0b82', '\u0b82', '\r', '\u0b83', '\u0bbf', '\u0000', '\u0bc0', '\u0bc0', '\r', '\u0bc1', '\u0bcc', '\u0000', '\u0bcd', '\u0bcd', '\r', '\u0bce', '\u0bf2', '\u0000', '\u0bf3', '\u0bf8', '\u0012', '\u0bf9', '\u0bf9', '\n', '\u0bfa', '\u0bfa', '\u0012', '\u0bfb', '\u0c3d', '\u0000', '\u0c3e', '\u0c40', '\r', '\u0c41', '\u0c45', '\u0000', '\u0c46', '\u0c48', '\r', '\u0c49', '\u0c49', '\u0000', '\u0c4a', '\u0c4d', '\r', '\u0c4e', '\u0c54', '\u0000', '\u0c55', '\u0c56', '\r', '\u0c57', '\u0cbb', '\u0000', '\u0cbc', '\u0cbc', '\r', '\u0cbd', '\u0ccb', '\u0000', '\u0ccc', '\u0ccd', '\r', '\u0cce', '\u0d40', '\u0000', '\u0d41', '\u0d43', '\r', '\u0d44', '\u0d4c', '\u0000', '\u0d4d', '\u0d4d', '\r', '\u0d4e', '\u0dc9', '\u0000', '\u0dca', '\u0dca', '\r', '\u0dcb', '\u0dd1', '\u0000', '\u0dd2', '\u0dd4', '\r', '\u0dd5', '\u0dd5', '\u0000', '\u0dd6', '\u0dd6', '\r', '\u0dd7', '\u0e30', '\u0000', '\u0e31', '\u0e31', '\r', '\u0e32', '\u0e33', '\u0000', '\u0e34', '\u0e3a', '\r', '\u0e3b', '\u0e3e', '\u0000', '\u0e3f', '\u0e3f', '\n', '\u0e40', '\u0e46', '\u0000', '\u0e47', '\u0e4e', '\r', '\u0e4f', '\u0eb0', '\u0000', '\u0eb1', '\u0eb1', '\r', '\u0eb2', '\u0eb3', '\u0000', '\u0eb4', '\u0eb9', '\r', '\u0eba', '\u0eba', '\u0000', '\u0ebb', '\u0ebc', '\r', '\u0ebd', '\u0ec7', '\u0000', '\u0ec8', '\u0ecd', '\r', '\u0ece', '\u0f17', '\u0000', '\u0f18', '\u0f19', '\r', '\u0f1a', '\u0f34', '\u0000', '\u0f35', '\u0f35', '\r', '\u0f36', '\u0f36', '\u0000', '\u0f37', '\u0f37', '\r', '\u0f38', '\u0f38', '\u0000', '\u0f39', '\u0f39', '\r', '\u0f3a', '\u0f3d', '\u0012', '\u0f3e', '\u0f70', '\u0000', '\u0f71', '\u0f7e', '\r', '\u0f7f', '\u0f7f', '\u0000', '\u0f80', '\u0f84', '\r', '\u0f85', '\u0f85', '\u0000', '\u0f86', '\u0f87', '\r', '\u0f88', '\u0f8f', '\u0000', '\u0f90', '\u0f97', '\r', '\u0f98', '\u0f98', '\u0000', '\u0f99', '\u0fbc', '\r', '\u0fbd', '\u0fc5', '\u0000', '\u0fc6', '\u0fc6', '\r', '\u0fc7', '\u102c', '\u0000', '\u102d', '\u1030', '\r', '\u1031', '\u1031', '\u0000', '\u1032', '\u1032', '\r', '\u1033', '\u1035', '\u0000', '\u1036', '\u1037', '\r', '\u1038', '\u1038', '\u0000', '\u1039', '\u1039', '\r', '\u103a', '\u1057', '\u0000', '\u1058', '\u1059', '\r', '\u105a', '\u167f', '\u0000', '\u1680', '\u1680', '\u0011', '\u1681', '\u169a', '\u0000', '\u169b', '\u169c', '\u0012', '\u169d', '\u1711', '\u0000', '\u1712', '\u1714', '\r', '\u1715', '\u1731', '\u0000', '\u1732', '\u1734', '\r', '\u1735', '\u1751', '\u0000', '\u1752', '\u1753', '\r', '\u1754', '\u1771', '\u0000', '\u1772', '\u1773', '\r', '\u1774', '\u17b6', '\u0000', '\u17b7', '\u17bd', '\r', '\u17be', '\u17c5', '\u0000', '\u17c6', '\u17c6', '\r', '\u17c7', '\u17c8', '\u0000', '\u17c9', '\u17d3', '\r', '\u17d4', '\u17da', '\u0000', '\u17db', '\u17db', '\n', '\u17dc', '\u17dc', '\u0000', '\u17dd', '\u17dd', '\r', '\u17de', '\u17ef', '\u0000', '\u17f0', '\u17f9', '\u0012', '\u17fa', '\u17ff', '\u0000', '\u1800', '\u180a', '\u0012', '\u180b', '\u180d', '\r', '\u180e', '\u180e', '\u0011', '\u180f', '\u18a8', '\u0000', '\u18a9', '\u18a9', '\r', '\u18aa', '\u191f', '\u0000', '\u1920', '\u1922', '\r', '\u1923', '\u1926', '\u0000', '\u1927', '\u192b', '\r', '\u192c', '\u1931', '\u0000', '\u1932', '\u1932', '\r', '\u1933', '\u1938', '\u0000', '\u1939', '\u193b', '\r', '\u193c', '\u193f', '\u0000', '\u1940', '\u1940', '\u0012', '\u1941', '\u1943', '\u0000', '\u1944', '\u1945', '\u0012', '\u1946', '\u19df', '\u0000', '\u19e0', '\u19ff', '\u0012', '\u1a00', '\u1fbc', '\u0000', '\u1fbd', '\u1fbd', '\u0012', '\u1fbe', '\u1fbe', '\u0000', '\u1fbf', '\u1fc1', '\u0012', '\u1fc2', '\u1fcc', '\u0000', '\u1fcd', '\u1fcf', '\u0012', '\u1fd0', '\u1fdc', '\u0000', '\u1fdd', '\u1fdf', '\u0012', '\u1fe0', '\u1fec', '\u0000', '\u1fed', '\u1fef', '\u0012', '\u1ff0', '\u1ffc', '\u0000', '\u1ffd', '\u1ffe', '\u0012', '\u1fff', '\u1fff', '\u0000', '\u2000', '\u200a', '\u0011', '\u200b', '\u200d', '\u000e', '\u200e', '\u200e', '\u0000', '\u200f', '\u200f', '\u0003', '\u2010', '\u2027', '\u0012', '\u2028', '\u2028', '\u0011', BaseFont.PARAGRAPH_SEPARATOR, BaseFont.PARAGRAPH_SEPARATOR, '\u000f', '\u202a', '\u202a', '\u0001', '\u202b', '\u202b', '\u0005', '\u202c', '\u202c', '\u0007', '\u202d', '\u202d', '\u0002', '\u202e', '\u202e', '\u0006', '\u202f', '\u202f', '\u0011', '\u2030', '\u2034', '\n', '\u2035', '\u2054', '\u0012', '\u2055', '\u2056', '\u0000', '\u2057', '\u2057', '\u0012', '\u2058', '\u205e', '\u0000', '\u205f', '\u205f', '\u0011', '\u2060', '\u2063', '\u000e', '\u2064', '\u2069', '\u0000', '\u206a', '\u206f', '\u000e', '\u2070', '\u2070', '\b', '\u2071', '\u2073', '\u0000', '\u2074', '\u2079', '\b', '\u207a', '\u207b', '\n', '\u207c', '\u207e', '\u0012', '\u207f', '\u207f', '\u0000', '\u2080', '\u2089', '\b', '\u208a', '\u208b', '\n', '\u208c', '\u208e', '\u0012', '\u208f', '\u209f', '\u0000', '\u20a0', '\u20b1', '\n', '\u20b2', '\u20cf', '\u0000', '\u20d0', '\u20ea', '\r', '\u20eb', '\u20ff', '\u0000', '\u2100', '\u2101', '\u0012', '\u2102', '\u2102', '\u0000', '\u2103', '\u2106', '\u0012', '\u2107', '\u2107', '\u0000', '\u2108', '\u2109', '\u0012', '\u210a', '\u2113', '\u0000', '\u2114', '\u2114', '\u0012', '\u2115', '\u2115', '\u0000', '\u2116', '\u2118', '\u0012', '\u2119', '\u211d', '\u0000', '\u211e', '\u2123', '\u0012', '\u2124', '\u2124', '\u0000', '\u2125', '\u2125', '\u0012', '\u2126', '\u2126', '\u0000', '\u2127', '\u2127', '\u0012', '\u2128', '\u2128', '\u0000', '\u2129', '\u2129', '\u0012', '\u212a', '\u212d', '\u0000', '\u212e', '\u212e', '\n', '\u212f', '\u2131', '\u0000', '\u2132', '\u2132', '\u0012', '\u2133', '\u2139', '\u0000', '\u213a', '\u213b', '\u0012', '\u213c', '\u213f', '\u0000', '\u2140', '\u2144', '\u0012', '\u2145', '\u2149', '\u0000', '\u214a', '\u214b', '\u0012', '\u214c', '\u2152', '\u0000', '\u2153', '\u215f', '\u0012', '\u2160', '\u218f', '\u0000', '\u2190', '\u2211', '\u0012', '\u2212', '\u2213', '\n', '\u2214', '\u2335', '\u0012', '\u2336', '\u237a', '\u0000', '\u237b', '\u2394', '\u0012', '\u2395', '\u2395', '\u0000', '\u2396', '\u23d0', '\u0012', '\u23d1', '\u23ff', '\u0000', '\u2400', '\u2426', '\u0012', '\u2427', '\u243f', '\u0000', '\u2440', '\u244a', '\u0012', '\u244b', '\u245f', '\u0000', '\u2460', '\u249b', '\b', '\u249c', '\u24e9', '\u0000', '\u24ea', '\u24ea', '\b', '\u24eb', '\u2617', '\u0012', '\u2618', '\u2618', '\u0000', '\u2619', '\u267d', '\u0012', '\u267e', '\u267f', '\u0000', '\u2680', '\u2691', '\u0012', '\u2692', '\u269f', '\u0000', '\u26a0', '\u26a1', '\u0012', '\u26a2', '\u2700', '\u0000', '\u2701', '\u2704', '\u0012', '\u2705', '\u2705', '\u0000', '\u2706', '\u2709', '\u0012', '\u270a', '\u270b', '\u0000', '\u270c', '\u2727', '\u0012', '\u2728', '\u2728', '\u0000', '\u2729', '\u274b', '\u0012', '\u274c', '\u274c', '\u0000', '\u274d', '\u274d', '\u0012', '\u274e', '\u274e', '\u0000', '\u274f', '\u2752', '\u0012', '\u2753', '\u2755', '\u0000', '\u2756', '\u2756', '\u0012', '\u2757', '\u2757', '\u0000', '\u2758', '\u275e', '\u0012', '\u275f', '\u2760', '\u0000', '\u2761', '\u2794', '\u0012', '\u2795', '\u2797', '\u0000', '\u2798', '\u27af', '\u0012', '\u27b0', '\u27b0', '\u0000', '\u27b1', '\u27be', '\u0012', '\u27bf', '\u27cf', '\u0000', '\u27d0', '\u27eb', '\u0012', '\u27ec', '\u27ef', '\u0000', '\u27f0', '\u2b0d', '\u0012', '\u2b0e', '\u2e7f', '\u0000', '\u2e80', '\u2e99', '\u0012', '\u2e9a', '\u2e9a', '\u0000', '\u2e9b', '\u2ef3', '\u0012', '\u2ef4', '\u2eff', '\u0000', '\u2f00', '\u2fd5', '\u0012', '\u2fd6', '\u2fef', '\u0000', '\u2ff0', '\u2ffb', '\u0012', '\u2ffc', '\u2fff', '\u0000', '\u3000', '\u3000', '\u0011', '\u3001', '\u3004', '\u0012', '\u3005', '\u3007', '\u0000', '\u3008', '\u3020', '\u0012', '\u3021', '\u3029', '\u0000', '\u302a', '\u302f', '\r', '\u3030', '\u3030', '\u0012', '\u3031', '\u3035', '\u0000', '\u3036', '\u3037', '\u0012', '\u3038', '\u303c', '\u0000', '\u303d', '\u303f', '\u0012', '\u3040', '\u3098', '\u0000', '\u3099', '\u309a', '\r', '\u309b', '\u309c', '\u0012', '\u309d', '\u309f', '\u0000', '\u30a0', '\u30a0', '\u0012', '\u30a1', '\u30fa', '\u0000', '\u30fb', '\u30fb', '\u0012', '\u30fc', '\u321c', '\u0000', '\u321d', '\u321e', '\u0012', '\u321f', '\u324f', '\u0000', '\u3250', '\u325f', '\u0012', '\u3260', '\u327b', '\u0000', '\u327c', '\u327d', '\u0012', '\u327e', '\u32b0', '\u0000', '\u32b1', '\u32bf', '\u0012', '\u32c0', '\u32cb', '\u0000', '\u32cc', '\u32cf', '\u0012', '\u32d0', '\u3376', '\u0000', '\u3377', '\u337a', '\u0012', '\u337b', '\u33dd', '\u0000', '\u33de', '\u33df', '\u0012', '\u33e0', '\u33fe', '\u0000', '\u33ff', '\u33ff', '\u0012', '\u3400', '\u4dbf', '\u0000', '\u4dc0', '\u4dff', '\u0012', '\u4e00', '\ua48f', '\u0000', '\ua490', '\ua4c6', '\u0012', '\ua4c7', '\ufb1c', '\u0000', '\ufb1d', '\ufb1d', '\u0003', '\ufb1e', '\ufb1e', '\r', '\ufb1f', '\ufb28', '\u0003', '\ufb29', '\ufb29', '\n', '\ufb2a', '\ufb36', '\u0003', '\ufb37', '\ufb37', '\u0000', '\ufb38', '\ufb3c', '\u0003', '\ufb3d', '\ufb3d', '\u0000', '\ufb3e', '\ufb3e', '\u0003', '\ufb3f', '\ufb3f', '\u0000', '\ufb40', '\ufb41', '\u0003', '\ufb42', '\ufb42', '\u0000', '\ufb43', '\ufb44', '\u0003', '\ufb45', '\ufb45', '\u0000', '\ufb46', '\ufb4f', '\u0003', '\ufb50', '\ufbb1', '\u0004', '\ufbb2', '\ufbd2', '\u0000', '\ufbd3', '\ufd3d', '\u0004', '\ufd3e', '\ufd3f', '\u0012', '\ufd40', '\ufd4f', '\u0000', '\ufd50', '\ufd8f', '\u0004', '\ufd90', '\ufd91', '\u0000', '\ufd92', '\ufdc7', '\u0004', '\ufdc8', '\ufdef', '\u0000', '\ufdf0', '\ufdfc', '\u0004', '\ufdfd', '\ufdfd', '\u0012', '\ufdfe', '\ufdff', '\u0000', '\ufe00', '\ufe0f', '\r', '\ufe10', '\ufe1f', '\u0000', '\ufe20', '\ufe23', '\r', '\ufe24', '\ufe2f', '\u0000', '\ufe30', '\ufe4f', '\u0012', '\ufe50', '\ufe50', '\f', '\ufe51', '\ufe51', '\u0012', '\ufe52', '\ufe52', '\f', '\ufe53', '\ufe53', '\u0000', '\ufe54', '\ufe54', '\u0012', '\ufe55', '\ufe55', '\f', '\ufe56', '\ufe5e', '\u0012', '\ufe5f', '\ufe5f', '\n', '\ufe60', '\ufe61', '\u0012', '\ufe62', '\ufe63', '\n', '\ufe64', '\ufe66', '\u0012', '\ufe67', '\ufe67', '\u0000', '\ufe68', '\ufe68', '\u0012', '\ufe69', '\ufe6a', '\n', '\ufe6b', '\ufe6b', '\u0012', '\ufe6c', '\ufe6f', '\u0000', '\ufe70', '\ufe74', '\u0004', '\ufe75', '\ufe75', '\u0000', '\ufe76', '\ufefc', '\u0004', '\ufefd', '\ufefe', '\u0000', '\ufeff', '\ufeff', '\u000e', '\uff00', '\uff00', '\u0000', '\uff01', '\uff02', '\u0012', '\uff03', '\uff05', '\n', '\uff06', '\uff0a', '\u0012', '\uff0b', '\uff0b', '\n', '\uff0c', '\uff0c', '\f', '\uff0d', '\uff0d', '\n', '\uff0e', '\uff0e', '\f', '\uff0f', '\uff0f', '\t', '\uff10', '\uff19', '\b', '\uff1a', '\uff1a', '\f', '\uff1b', '\uff20', '\u0012', '\uff21', '\uff3a', '\u0000', '\uff3b', '\uff40', '\u0012', '\uff41', '\uff5a', '\u0000', '\uff5b', '\uff65', '\u0012', '\uff66', '\uffdf', '\u0000', '\uffe0', '\uffe1', '\n', '\uffe2', '\uffe4', '\u0012', '\uffe5', '\uffe6', '\n', '\uffe7', '\uffe7', '\u0000', '\uffe8', '\uffee', '\u0012', '\uffef', '\ufff8', '\u0000', '\ufff9', '\ufffb', '\u000e', '\ufffc', '\ufffd', '\u0012', '\ufffe', '\uffff', '\u0000'};
        int k = 0;
        while (k < baseTypes.length) {
            int start = baseTypes[k];
            k++;
            int end = baseTypes[k];
            k++;
            byte b = (byte) baseTypes[k];
            int start2 = start;
            while (start2 <= end) {
                start = start2 + 1;
                rtypes[start2] = b;
                start2 = start;
            }
            k++;
        }
    }
}

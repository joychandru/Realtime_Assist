package com.itextpdf.text.pdf.hyphenation;

public class HyphenationException extends Exception {
    private static final long serialVersionUID = 4721513606846982325L;

    public HyphenationException(String msg) {
        super(msg);
    }
}

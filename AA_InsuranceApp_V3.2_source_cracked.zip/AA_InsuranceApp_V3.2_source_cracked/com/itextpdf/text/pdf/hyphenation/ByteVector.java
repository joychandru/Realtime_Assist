package com.itextpdf.text.pdf.hyphenation;

import java.io.Serializable;

public class ByteVector implements Serializable {
    private static final int DEFAULT_BLOCK_SIZE = 2048;
    private static final long serialVersionUID = -1096301185375029343L;
    private byte[] array;
    private int blockSize;
    private int f32n;

    public ByteVector() {
        this((int) DEFAULT_BLOCK_SIZE);
    }

    public ByteVector(int capacity) {
        if (capacity > 0) {
            this.blockSize = capacity;
        } else {
            this.blockSize = DEFAULT_BLOCK_SIZE;
        }
        this.array = new byte[this.blockSize];
        this.f32n = 0;
    }

    public ByteVector(byte[] a) {
        this.blockSize = DEFAULT_BLOCK_SIZE;
        this.array = a;
        this.f32n = 0;
    }

    public ByteVector(byte[] a, int capacity) {
        if (capacity > 0) {
            this.blockSize = capacity;
        } else {
            this.blockSize = DEFAULT_BLOCK_SIZE;
        }
        this.array = a;
        this.f32n = 0;
    }

    public byte[] getArray() {
        return this.array;
    }

    public int length() {
        return this.f32n;
    }

    public int capacity() {
        return this.array.length;
    }

    public void put(int index, byte val) {
        this.array[index] = val;
    }

    public byte get(int index) {
        return this.array[index];
    }

    public int alloc(int size) {
        int index = this.f32n;
        int len = this.array.length;
        if (this.f32n + size >= len) {
            byte[] aux = new byte[(this.blockSize + len)];
            System.arraycopy(this.array, 0, aux, 0, len);
            this.array = aux;
        }
        this.f32n += size;
        return index;
    }

    public void trimToSize() {
        if (this.f32n < this.array.length) {
            byte[] aux = new byte[this.f32n];
            System.arraycopy(this.array, 0, aux, 0, this.f32n);
            this.array = aux;
        }
    }
}

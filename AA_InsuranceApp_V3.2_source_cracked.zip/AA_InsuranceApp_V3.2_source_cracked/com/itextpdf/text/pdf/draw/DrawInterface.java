package com.itextpdf.text.pdf.draw;

import com.itextpdf.text.pdf.PdfContentByte;

public interface DrawInterface {
    void draw(PdfContentByte pdfContentByte, float f, float f2, float f3, float f4, float f5);
}

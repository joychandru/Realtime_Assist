package com.itextpdf.text.pdf;

import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.factories.RomanAlphabetFactory;
import com.itextpdf.text.factories.RomanNumberFactory;
import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.xmp.XMPError;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

public class PdfPageLabels {
    public static final int DECIMAL_ARABIC_NUMERALS = 0;
    public static final int EMPTY = 5;
    public static final int LOWERCASE_LETTERS = 4;
    public static final int LOWERCASE_ROMAN_NUMERALS = 2;
    public static final int UPPERCASE_LETTERS = 3;
    public static final int UPPERCASE_ROMAN_NUMERALS = 1;
    static PdfName[] numberingStyle;
    private HashMap<Integer, PdfDictionary> map;

    public static class PdfPageLabelFormat {
        public int logicalPage;
        public int numberStyle;
        public int physicalPage;
        public String prefix;

        public PdfPageLabelFormat(int physicalPage, int numberStyle, String prefix, int logicalPage) {
            this.physicalPage = physicalPage;
            this.numberStyle = numberStyle;
            this.prefix = prefix;
            this.logicalPage = logicalPage;
        }
    }

    static {
        PdfName[] pdfNameArr = new PdfName[EMPTY];
        pdfNameArr[DECIMAL_ARABIC_NUMERALS] = PdfName.f65D;
        pdfNameArr[UPPERCASE_ROMAN_NUMERALS] = PdfName.f77R;
        pdfNameArr[LOWERCASE_ROMAN_NUMERALS] = new PdfName("r");
        pdfNameArr[UPPERCASE_LETTERS] = PdfName.f62A;
        pdfNameArr[LOWERCASE_LETTERS] = new PdfName(HtmlTags.f0A);
        numberingStyle = pdfNameArr;
    }

    public PdfPageLabels() {
        this.map = new HashMap();
        addPageLabel(UPPERCASE_ROMAN_NUMERALS, DECIMAL_ARABIC_NUMERALS, null, UPPERCASE_ROMAN_NUMERALS);
    }

    public void addPageLabel(int page, int numberStyle, String text, int firstPage) {
        if (page < UPPERCASE_ROMAN_NUMERALS || firstPage < UPPERCASE_ROMAN_NUMERALS) {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("in.a.page.label.the.page.numbers.must.be.greater.or.equal.to.1", new Object[DECIMAL_ARABIC_NUMERALS]));
        }
        PdfDictionary dic = new PdfDictionary();
        if (numberStyle >= 0 && numberStyle < numberingStyle.length) {
            dic.put(PdfName.f78S, numberingStyle[numberStyle]);
        }
        if (text != null) {
            dic.put(PdfName.f75P, new PdfString(text, PdfObject.TEXT_UNICODE));
        }
        if (firstPage != UPPERCASE_ROMAN_NUMERALS) {
            dic.put(PdfName.ST, new PdfNumber(firstPage));
        }
        this.map.put(Integer.valueOf(page - 1), dic);
    }

    public void addPageLabel(int page, int numberStyle, String text) {
        addPageLabel(page, numberStyle, text, UPPERCASE_ROMAN_NUMERALS);
    }

    public void addPageLabel(int page, int numberStyle) {
        addPageLabel(page, numberStyle, null, UPPERCASE_ROMAN_NUMERALS);
    }

    public void addPageLabel(PdfPageLabelFormat format) {
        addPageLabel(format.physicalPage, format.numberStyle, format.prefix, format.logicalPage);
    }

    public void removePageLabel(int page) {
        if (page > UPPERCASE_ROMAN_NUMERALS) {
            this.map.remove(Integer.valueOf(page - 1));
        }
    }

    public PdfDictionary getDictionary(PdfWriter writer) {
        try {
            return PdfNumberTree.writeTree(this.map, writer);
        } catch (IOException e) {
            throw new ExceptionConverter(e);
        }
    }

    public static String[] getPageLabels(PdfReader reader) {
        int n = reader.getNumberOfPages();
        PdfDictionary labels = (PdfDictionary) PdfReader.getPdfObjectRelease(reader.getCatalog().get(PdfName.PAGELABELS));
        if (labels == null) {
            return null;
        }
        String[] labelstrings = new String[n];
        HashMap<Integer, PdfObject> numberTree = PdfNumberTree.readTree(labels);
        int pagecount = UPPERCASE_ROMAN_NUMERALS;
        String prefix = PdfObject.NOTHING;
        char type = 'D';
        for (int i = DECIMAL_ARABIC_NUMERALS; i < n; i += UPPERCASE_ROMAN_NUMERALS) {
            Integer current = Integer.valueOf(i);
            if (numberTree.containsKey(current)) {
                PdfDictionary d = (PdfDictionary) PdfReader.getPdfObjectRelease((PdfObject) numberTree.get(current));
                if (d.contains(PdfName.ST)) {
                    pagecount = ((PdfNumber) d.get(PdfName.ST)).intValue();
                } else {
                    pagecount = UPPERCASE_ROMAN_NUMERALS;
                }
                if (d.contains(PdfName.f75P)) {
                    prefix = ((PdfString) d.get(PdfName.f75P)).toUnicodeString();
                }
                if (d.contains(PdfName.f78S)) {
                    type = ((PdfName) d.get(PdfName.f78S)).toString().charAt(UPPERCASE_ROMAN_NUMERALS);
                } else {
                    type = Barcode128.CODE_BC_TO_A;
                }
            }
            switch (type) {
                case 'A':
                    labelstrings[i] = prefix + RomanAlphabetFactory.getUpperCaseString(pagecount);
                    break;
                case 'R':
                    labelstrings[i] = prefix + RomanNumberFactory.getUpperCaseString(pagecount);
                    break;
                case 'a':
                    labelstrings[i] = prefix + RomanAlphabetFactory.getLowerCaseString(pagecount);
                    break;
                case XMPError.BADSCHEMA /*101*/:
                    labelstrings[i] = prefix;
                    break;
                case 'r':
                    labelstrings[i] = prefix + RomanNumberFactory.getLowerCaseString(pagecount);
                    break;
                default:
                    labelstrings[i] = prefix + pagecount;
                    break;
            }
            pagecount += UPPERCASE_ROMAN_NUMERALS;
        }
        return labelstrings;
    }

    public static PdfPageLabelFormat[] getPageLabelFormats(PdfReader reader) {
        PdfDictionary labels = (PdfDictionary) PdfReader.getPdfObjectRelease(reader.getCatalog().get(PdfName.PAGELABELS));
        if (labels == null) {
            return null;
        }
        HashMap<Integer, PdfObject> numberTree = PdfNumberTree.readTree(labels);
        Integer[] numbers = (Integer[]) numberTree.keySet().toArray(new Integer[numberTree.size()]);
        Arrays.sort(numbers);
        PdfPageLabelFormat[] formats = new PdfPageLabelFormat[numberTree.size()];
        for (int k = DECIMAL_ARABIC_NUMERALS; k < numbers.length; k += UPPERCASE_ROMAN_NUMERALS) {
            int pagecount;
            String prefix;
            int numberStyle;
            Integer key = numbers[k];
            PdfDictionary d = (PdfDictionary) PdfReader.getPdfObjectRelease((PdfObject) numberTree.get(key));
            if (d.contains(PdfName.ST)) {
                pagecount = ((PdfNumber) d.get(PdfName.ST)).intValue();
            } else {
                pagecount = UPPERCASE_ROMAN_NUMERALS;
            }
            if (d.contains(PdfName.f75P)) {
                prefix = ((PdfString) d.get(PdfName.f75P)).toUnicodeString();
            } else {
                prefix = PdfObject.NOTHING;
            }
            if (d.contains(PdfName.f78S)) {
                switch (((PdfName) d.get(PdfName.f78S)).toString().charAt(UPPERCASE_ROMAN_NUMERALS)) {
                    case 'A':
                        numberStyle = UPPERCASE_LETTERS;
                        break;
                    case 'R':
                        numberStyle = UPPERCASE_ROMAN_NUMERALS;
                        break;
                    case 'a':
                        numberStyle = LOWERCASE_LETTERS;
                        break;
                    case 'r':
                        numberStyle = LOWERCASE_ROMAN_NUMERALS;
                        break;
                    default:
                        numberStyle = DECIMAL_ARABIC_NUMERALS;
                        break;
                }
            }
            numberStyle = EMPTY;
            formats[k] = new PdfPageLabelFormat(key.intValue() + UPPERCASE_ROMAN_NUMERALS, numberStyle, prefix, pagecount);
        }
        return formats;
    }
}

package com.itextpdf.text.pdf;

public class PdfIsoConformanceException extends RuntimeException {
    private static final long serialVersionUID = -8972376258066225871L;

    public PdfIsoConformanceException(String s) {
        super(s);
    }
}

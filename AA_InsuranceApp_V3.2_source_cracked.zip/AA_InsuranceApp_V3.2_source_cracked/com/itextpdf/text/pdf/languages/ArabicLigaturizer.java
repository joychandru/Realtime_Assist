package com.itextpdf.text.pdf.languages;

import com.itextpdf.text.pdf.BidiLine;
import com.itextpdf.text.pdf.BidiOrder;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.HashMap;

public class ArabicLigaturizer implements LanguageProcessor {
    private static final char ALEF = '\u0627';
    private static final char ALEFHAMZA = '\u0623';
    private static final char ALEFHAMZABELOW = '\u0625';
    private static final char ALEFMADDA = '\u0622';
    private static final char ALEFMAKSURA = '\u0649';
    private static final char DAMMA = '\u064f';
    public static final int DIGITS_AN2EN = 64;
    public static final int DIGITS_EN2AN = 32;
    public static final int DIGITS_EN2AN_INIT_AL = 128;
    public static final int DIGITS_EN2AN_INIT_LR = 96;
    public static final int DIGITS_MASK = 224;
    private static final int DIGITS_RESERVED = 160;
    public static final int DIGIT_TYPE_AN = 0;
    public static final int DIGIT_TYPE_AN_EXTENDED = 256;
    public static final int DIGIT_TYPE_MASK = 256;
    private static final char FARSIYEH = '\u06cc';
    private static final char FATHA = '\u064e';
    private static final char HAMZA = '\u0621';
    private static final char HAMZAABOVE = '\u0654';
    private static final char HAMZABELOW = '\u0655';
    private static final char KASRA = '\u0650';
    private static final char LAM = '\u0644';
    private static final char LAM_ALEF = '\ufefb';
    private static final char LAM_ALEFHAMZA = '\ufef7';
    private static final char LAM_ALEFHAMZABELOW = '\ufef9';
    private static final char LAM_ALEFMADDA = '\ufef5';
    private static final char MADDA = '\u0653';
    private static final char SHADDA = '\u0651';
    private static final char TATWEEL = '\u0640';
    private static final char WAW = '\u0648';
    private static final char WAWHAMZA = '\u0624';
    private static final char YEH = '\u064a';
    private static final char YEHHAMZA = '\u0626';
    private static final char ZWJ = '\u200d';
    public static final int ar_composedtashkeel = 4;
    public static final int ar_lig = 8;
    public static final int ar_nothing = 0;
    public static final int ar_novowel = 1;
    private static final char[][] chartable;
    private static HashMap<Character, char[]> maptable;
    protected int options;
    protected int runDirection;

    static class charstruct {
        char basechar;
        int lignum;
        char mark1;
        int numshapes;
        char vowel;

        charstruct() {
            this.numshapes = ArabicLigaturizer.ar_novowel;
        }
    }

    static {
        maptable = new HashMap();
        chartable = new char[][]{new char[]{HAMZA, '\ufe80'}, new char[]{ALEFMADDA, '\ufe81', '\ufe82'}, new char[]{ALEFHAMZA, '\ufe83', '\ufe84'}, new char[]{WAWHAMZA, '\ufe85', '\ufe86'}, new char[]{ALEFHAMZABELOW, '\ufe87', '\ufe88'}, new char[]{YEHHAMZA, '\ufe89', '\ufe8a', '\ufe8b', '\ufe8c'}, new char[]{ALEF, '\ufe8d', '\ufe8e'}, new char[]{'\u0628', '\ufe8f', '\ufe90', '\ufe91', '\ufe92'}, new char[]{'\u0629', '\ufe93', '\ufe94'}, new char[]{'\u062a', '\ufe95', '\ufe96', '\ufe97', '\ufe98'}, new char[]{'\u062b', '\ufe99', '\ufe9a', '\ufe9b', '\ufe9c'}, new char[]{'\u062c', '\ufe9d', '\ufe9e', '\ufe9f', '\ufea0'}, new char[]{'\u062d', '\ufea1', '\ufea2', '\ufea3', '\ufea4'}, new char[]{'\u062e', '\ufea5', '\ufea6', '\ufea7', '\ufea8'}, new char[]{'\u062f', '\ufea9', '\ufeaa'}, new char[]{'\u0630', '\ufeab', '\ufeac'}, new char[]{'\u0631', '\ufead', '\ufeae'}, new char[]{'\u0632', '\ufeaf', '\ufeb0'}, new char[]{'\u0633', '\ufeb1', '\ufeb2', '\ufeb3', '\ufeb4'}, new char[]{'\u0634', '\ufeb5', '\ufeb6', '\ufeb7', '\ufeb8'}, new char[]{'\u0635', '\ufeb9', '\ufeba', '\ufebb', '\ufebc'}, new char[]{'\u0636', '\ufebd', '\ufebe', '\ufebf', '\ufec0'}, new char[]{'\u0637', '\ufec1', '\ufec2', '\ufec3', '\ufec4'}, new char[]{'\u0638', '\ufec5', '\ufec6', '\ufec7', '\ufec8'}, new char[]{'\u0639', '\ufec9', '\ufeca', '\ufecb', '\ufecc'}, new char[]{'\u063a', '\ufecd', '\ufece', '\ufecf', '\ufed0'}, new char[]{TATWEEL, TATWEEL, TATWEEL, TATWEEL, TATWEEL}, new char[]{'\u0641', '\ufed1', '\ufed2', '\ufed3', '\ufed4'}, new char[]{'\u0642', '\ufed5', '\ufed6', '\ufed7', '\ufed8'}, new char[]{'\u0643', '\ufed9', '\ufeda', '\ufedb', '\ufedc'}, new char[]{LAM, '\ufedd', '\ufede', '\ufedf', '\ufee0'}, new char[]{'\u0645', '\ufee1', '\ufee2', '\ufee3', '\ufee4'}, new char[]{'\u0646', '\ufee5', '\ufee6', '\ufee7', '\ufee8'}, new char[]{'\u0647', '\ufee9', '\ufeea', '\ufeeb', '\ufeec'}, new char[]{WAW, '\ufeed', '\ufeee'}, new char[]{ALEFMAKSURA, '\ufeef', '\ufef0', '\ufbe8', '\ufbe9'}, new char[]{YEH, '\ufef1', '\ufef2', '\ufef3', '\ufef4'}, new char[]{'\u0671', '\ufb50', '\ufb51'}, new char[]{'\u0679', '\ufb66', '\ufb67', '\ufb68', '\ufb69'}, new char[]{'\u067a', '\ufb5e', '\ufb5f', '\ufb60', '\ufb61'}, new char[]{'\u067b', '\ufb52', '\ufb53', '\ufb54', '\ufb55'}, new char[]{'\u067e', '\ufb56', '\ufb57', '\ufb58', '\ufb59'}, new char[]{'\u067f', '\ufb62', '\ufb63', '\ufb64', '\ufb65'}, new char[]{'\u0680', '\ufb5a', '\ufb5b', '\ufb5c', '\ufb5d'}, new char[]{'\u0683', '\ufb76', '\ufb77', '\ufb78', '\ufb79'}, new char[]{'\u0684', '\ufb72', '\ufb73', '\ufb74', '\ufb75'}, new char[]{'\u0686', '\ufb7a', '\ufb7b', '\ufb7c', '\ufb7d'}, new char[]{'\u0687', '\ufb7e', '\ufb7f', '\ufb80', '\ufb81'}, new char[]{'\u0688', '\ufb88', '\ufb89'}, new char[]{'\u068c', '\ufb84', '\ufb85'}, new char[]{'\u068d', '\ufb82', '\ufb83'}, new char[]{'\u068e', '\ufb86', '\ufb87'}, new char[]{'\u0691', '\ufb8c', '\ufb8d'}, new char[]{'\u0698', '\ufb8a', '\ufb8b'}, new char[]{'\u06a4', '\ufb6a', '\ufb6b', '\ufb6c', '\ufb6d'}, new char[]{'\u06a6', '\ufb6e', '\ufb6f', '\ufb70', '\ufb71'}, new char[]{'\u06a9', '\ufb8e', '\ufb8f', '\ufb90', '\ufb91'}, new char[]{'\u06ad', '\ufbd3', '\ufbd4', '\ufbd5', '\ufbd6'}, new char[]{'\u06af', '\ufb92', '\ufb93', '\ufb94', '\ufb95'}, new char[]{'\u06b1', '\ufb9a', '\ufb9b', '\ufb9c', '\ufb9d'}, new char[]{'\u06b3', '\ufb96', '\ufb97', '\ufb98', '\ufb99'}, new char[]{'\u06ba', '\ufb9e', '\ufb9f'}, new char[]{'\u06bb', '\ufba0', '\ufba1', '\ufba2', '\ufba3'}, new char[]{'\u06be', '\ufbaa', '\ufbab', '\ufbac', '\ufbad'}, new char[]{'\u06c0', '\ufba4', '\ufba5'}, new char[]{'\u06c1', '\ufba6', '\ufba7', '\ufba8', '\ufba9'}, new char[]{'\u06c5', '\ufbe0', '\ufbe1'}, new char[]{'\u06c6', '\ufbd9', '\ufbda'}, new char[]{'\u06c7', '\ufbd7', '\ufbd8'}, new char[]{'\u06c8', '\ufbdb', '\ufbdc'}, new char[]{'\u06c9', '\ufbe2', '\ufbe3'}, new char[]{'\u06cb', '\ufbde', '\ufbdf'}, new char[]{FARSIYEH, '\ufbfc', '\ufbfd', '\ufbfe', '\ufbff'}, new char[]{'\u06d0', '\ufbe4', '\ufbe5', '\ufbe6', '\ufbe7'}, new char[]{'\u06d2', '\ufbae', '\ufbaf'}, new char[]{'\u06d3', '\ufbb0', '\ufbb1'}};
        char[][] arr$ = chartable;
        int len$ = arr$.length;
        for (int i$ = ar_nothing; i$ < len$; i$ += ar_novowel) {
            char[] c = arr$[i$];
            maptable.put(Character.valueOf(c[ar_nothing]), c);
        }
    }

    static boolean isVowel(char s) {
        return (s >= '\u064b' && s <= HAMZABELOW) || s == '\u0670';
    }

    static char charshape(char s, int which) {
        if (s >= HAMZA && s <= '\u06d3') {
            char[] c = (char[]) maptable.get(Character.valueOf(s));
            if (c != null) {
                return c[which + ar_novowel];
            }
            return s;
        } else if (s < LAM_ALEFMADDA || s > LAM_ALEF) {
            return s;
        } else {
            return (char) (s + which);
        }
    }

    static int shapecount(char s) {
        if (s >= HAMZA && s <= '\u06d3' && !isVowel(s)) {
            char[] c = (char[]) maptable.get(Character.valueOf(s));
            if (c != null) {
                return c.length - 1;
            }
        } else if (s == ZWJ) {
            return ar_composedtashkeel;
        }
        return ar_novowel;
    }

    static int ligature(char newchar, charstruct oldchar) {
        int retval = ar_nothing;
        if (oldchar.basechar == '\u0000') {
            return ar_nothing;
        }
        if (isVowel(newchar)) {
            retval = ar_novowel;
            if (!(oldchar.vowel == '\u0000' || newchar == SHADDA)) {
                retval = 2;
            }
            switch (newchar) {
                case '\u0651':
                    if (oldchar.mark1 == '\u0000') {
                        oldchar.mark1 = SHADDA;
                        break;
                    }
                    return ar_nothing;
                case '\u0653':
                    switch (oldchar.basechar) {
                        case '\u0627':
                            oldchar.basechar = ALEFMADDA;
                            retval = 2;
                            break;
                        default:
                            break;
                    }
                case '\u0654':
                    switch (oldchar.basechar) {
                        case '\u0627':
                            oldchar.basechar = ALEFHAMZA;
                            retval = 2;
                            break;
                        case '\u0648':
                            oldchar.basechar = WAWHAMZA;
                            retval = 2;
                            break;
                        case '\u0649':
                        case '\u064a':
                        case '\u06cc':
                            oldchar.basechar = YEHHAMZA;
                            retval = 2;
                            break;
                        case '\ufefb':
                            oldchar.basechar = LAM_ALEFHAMZA;
                            retval = 2;
                            break;
                        default:
                            oldchar.mark1 = HAMZAABOVE;
                            break;
                    }
                case '\u0655':
                    switch (oldchar.basechar) {
                        case '\u0627':
                            oldchar.basechar = ALEFHAMZABELOW;
                            retval = 2;
                            break;
                        case '\ufefb':
                            oldchar.basechar = LAM_ALEFHAMZABELOW;
                            retval = 2;
                            break;
                        default:
                            oldchar.mark1 = HAMZABELOW;
                            break;
                    }
                default:
                    oldchar.vowel = newchar;
                    break;
            }
            if (retval == ar_novowel) {
                oldchar.lignum += ar_novowel;
            }
            return retval;
        } else if (oldchar.vowel != '\u0000') {
            return ar_nothing;
        } else {
            switch (oldchar.basechar) {
                case ar_nothing /*0*/:
                    oldchar.basechar = newchar;
                    oldchar.numshapes = shapecount(newchar);
                    retval = ar_novowel;
                    break;
                case '\u0644':
                    switch (newchar) {
                        case '\u0622':
                            oldchar.basechar = LAM_ALEFMADDA;
                            oldchar.numshapes = 2;
                            retval = 3;
                            break;
                        case '\u0623':
                            oldchar.basechar = LAM_ALEFHAMZA;
                            oldchar.numshapes = 2;
                            retval = 3;
                            break;
                        case '\u0625':
                            oldchar.basechar = LAM_ALEFHAMZABELOW;
                            oldchar.numshapes = 2;
                            retval = 3;
                            break;
                        case '\u0627':
                            oldchar.basechar = LAM_ALEF;
                            oldchar.numshapes = 2;
                            retval = 3;
                            break;
                        default:
                            break;
                    }
            }
            return retval;
        }
    }

    static void copycstostring(StringBuffer string, charstruct s, int level) {
        if (s.basechar != '\u0000') {
            string.append(s.basechar);
            s.lignum--;
            if (s.mark1 != '\u0000') {
                if ((level & ar_novowel) == 0) {
                    string.append(s.mark1);
                    s.lignum--;
                } else {
                    s.lignum--;
                }
            }
            if (s.vowel == '\u0000') {
                return;
            }
            if ((level & ar_novowel) == 0) {
                string.append(s.vowel);
                s.lignum--;
                return;
            }
            s.lignum--;
        }
    }

    static void doublelig(StringBuffer string, int level) {
        int len = string.length();
        int olen = len;
        int j = ar_nothing;
        int si = ar_novowel;
        while (si < olen) {
            char lapresult = '\u0000';
            if ((level & ar_composedtashkeel) != 0) {
                switch (string.charAt(j)) {
                    case '\u064e':
                        if (string.charAt(si) == SHADDA) {
                            lapresult = '\ufc60';
                            break;
                        }
                        break;
                    case '\u064f':
                        if (string.charAt(si) == SHADDA) {
                            lapresult = '\ufc61';
                            break;
                        }
                        break;
                    case '\u0650':
                        if (string.charAt(si) == SHADDA) {
                            lapresult = '\ufc62';
                            break;
                        }
                        break;
                    case '\u0651':
                        switch (string.charAt(si)) {
                            case '\u064c':
                                lapresult = '\ufc5e';
                                break;
                            case '\u064d':
                                lapresult = '\ufc5f';
                                break;
                            case '\u064e':
                                lapresult = '\ufc60';
                                break;
                            case '\u064f':
                                lapresult = '\ufc61';
                                break;
                            case '\u0650':
                                lapresult = '\ufc62';
                                break;
                            default:
                                break;
                        }
                }
            }
            if ((level & ar_lig) != 0) {
                switch (string.charAt(j)) {
                    case '\ufe91':
                        switch (string.charAt(si)) {
                            case '\ufea0':
                                lapresult = '\ufc9c';
                                break;
                            case '\ufea4':
                                lapresult = '\ufc9d';
                                break;
                            case '\ufea8':
                                lapresult = '\ufc9e';
                                break;
                            default:
                                break;
                        }
                    case '\ufe97':
                        switch (string.charAt(si)) {
                            case '\ufea0':
                                lapresult = '\ufca1';
                                break;
                            case '\ufea4':
                                lapresult = '\ufca2';
                                break;
                            case '\ufea8':
                                lapresult = '\ufca3';
                                break;
                            default:
                                break;
                        }
                    case '\ufed3':
                        switch (string.charAt(si)) {
                            case '\ufef2':
                                lapresult = '\ufc32';
                                break;
                            default:
                                break;
                        }
                    case '\ufedf':
                        switch (string.charAt(si)) {
                            case '\ufe9e':
                                lapresult = '\ufc3f';
                                break;
                            case '\ufea0':
                                lapresult = '\ufcc9';
                                break;
                            case '\ufea2':
                                lapresult = '\ufc40';
                                break;
                            case '\ufea4':
                                lapresult = '\ufcca';
                                break;
                            case '\ufea6':
                                lapresult = '\ufc41';
                                break;
                            case '\ufea8':
                                lapresult = '\ufccb';
                                break;
                            case '\ufee2':
                                lapresult = '\ufc42';
                                break;
                            case '\ufee4':
                                lapresult = '\ufccc';
                                break;
                            default:
                                break;
                        }
                    case '\ufee3':
                        switch (string.charAt(si)) {
                            case '\ufea0':
                                lapresult = '\ufcce';
                                break;
                            case '\ufea4':
                                lapresult = '\ufccf';
                                break;
                            case '\ufea8':
                                lapresult = '\ufcd0';
                                break;
                            case '\ufee4':
                                lapresult = '\ufcd1';
                                break;
                            default:
                                break;
                        }
                    case '\ufee7':
                        switch (string.charAt(si)) {
                            case '\ufea0':
                                lapresult = '\ufcd2';
                                break;
                            case '\ufea4':
                                lapresult = '\ufcd3';
                                break;
                            case '\ufea8':
                                lapresult = '\ufcd4';
                                break;
                            default:
                                break;
                        }
                    case '\ufee8':
                        switch (string.charAt(si)) {
                            case '\ufeae':
                                lapresult = '\ufc8a';
                                break;
                            case '\ufeb0':
                                lapresult = '\ufc8b';
                                break;
                            default:
                                break;
                        }
                }
            }
            if (lapresult != '\u0000') {
                string.setCharAt(j, lapresult);
                len--;
                si += ar_novowel;
            } else {
                j += ar_novowel;
                string.setCharAt(j, string.charAt(si));
                si += ar_novowel;
            }
        }
        string.setLength(len);
    }

    static boolean connects_to_left(charstruct a) {
        return a.numshapes > 2;
    }

    static void shape(char[] text, StringBuffer string, int level) {
        int which;
        int p = ar_nothing;
        charstruct oldchar = new charstruct();
        charstruct curchar = new charstruct();
        while (p < text.length) {
            int p2 = p + ar_novowel;
            char nextletter = text[p];
            int join = ligature(nextletter, curchar);
            if (join == 0) {
                int nc = shapecount(nextletter);
                if (nc == ar_novowel) {
                    which = ar_nothing;
                } else {
                    which = 2;
                }
                if (connects_to_left(oldchar)) {
                    which += ar_novowel;
                }
                curchar.basechar = charshape(curchar.basechar, which % curchar.numshapes);
                copycstostring(string, oldchar, level);
                oldchar = curchar;
                curchar = new charstruct();
                curchar.basechar = nextletter;
                curchar.numshapes = nc;
                curchar.lignum += ar_novowel;
                p = p2;
            } else if (join == ar_novowel) {
                p = p2;
            } else {
                p = p2;
            }
        }
        if (connects_to_left(oldchar)) {
            which = ar_novowel;
        } else {
            which = ar_nothing;
        }
        curchar.basechar = charshape(curchar.basechar, which % curchar.numshapes);
        copycstostring(string, oldchar, level);
        copycstostring(string, curchar, level);
    }

    public static int arabic_shape(char[] src, int srcoffset, int srclength, char[] dest, int destoffset, int destlength, int level) {
        char[] str = new char[srclength];
        for (int k = (srclength + srcoffset) - 1; k >= srcoffset; k--) {
            str[k - srcoffset] = src[k];
        }
        StringBuffer string = new StringBuffer(srclength);
        shape(str, string, level);
        if ((level & 12) != 0) {
            doublelig(string, level);
        }
        System.arraycopy(string.toString().toCharArray(), ar_nothing, dest, destoffset, string.length());
        return string.length();
    }

    public static void processNumbers(char[] text, int offset, int length, int options) {
        int limit = offset + length;
        if ((options & DIGITS_MASK) != 0) {
            char digitBase = '0';
            switch (options & DIGIT_TYPE_MASK) {
                case ar_nothing /*0*/:
                    digitBase = '\u0660';
                    break;
                case DIGIT_TYPE_MASK /*256*/:
                    digitBase = '\u06f0';
                    break;
            }
            int digitDelta;
            int i;
            char ch;
            switch (options & DIGITS_MASK) {
                case DIGITS_EN2AN /*32*/:
                    digitDelta = digitBase - 48;
                    for (i = offset; i < limit; i += ar_novowel) {
                        ch = text[i];
                        if (ch <= '9' && ch >= '0') {
                            text[i] = (char) (text[i] + digitDelta);
                        }
                    }
                case DIGITS_AN2EN /*64*/:
                    char digitTop = (char) (digitBase + 9);
                    digitDelta = 48 - digitBase;
                    for (i = offset; i < limit; i += ar_novowel) {
                        ch = text[i];
                        if (ch <= digitTop && ch >= digitBase) {
                            text[i] = (char) (text[i] + digitDelta);
                        }
                    }
                case DIGITS_EN2AN_INIT_LR /*96*/:
                    shapeToArabicDigitsWithContext(text, ar_nothing, length, digitBase, false);
                case DIGITS_EN2AN_INIT_AL /*128*/:
                    shapeToArabicDigitsWithContext(text, ar_nothing, length, digitBase, true);
                default:
            }
        }
    }

    static void shapeToArabicDigitsWithContext(char[] dest, int start, int length, char digitBase, boolean lastStrongWasAL) {
        digitBase = (char) (digitBase - 48);
        int limit = start + length;
        for (int i = start; i < limit; i += ar_novowel) {
            char ch = dest[i];
            switch (BidiOrder.getDirection(ch)) {
                case ar_nothing /*0*/:
                case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                    lastStrongWasAL = false;
                    break;
                case ar_composedtashkeel /*4*/:
                    lastStrongWasAL = true;
                    break;
                case ar_lig /*8*/:
                    if (lastStrongWasAL && ch <= '9') {
                        dest[i] = (char) (ch + digitBase);
                        break;
                    }
                default:
                    break;
            }
        }
    }

    public ArabicLigaturizer() {
        this.options = ar_nothing;
        this.runDirection = 3;
    }

    public ArabicLigaturizer(int runDirection, int options) {
        this.options = ar_nothing;
        this.runDirection = 3;
        this.runDirection = runDirection;
        this.options = options;
    }

    public String process(String s) {
        return BidiLine.processLTR(s, this.runDirection, this.options);
    }

    public boolean isRTL() {
        return true;
    }
}

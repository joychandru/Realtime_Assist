package com.itextpdf.text.pdf.qrcode;

public final class ReedSolomonException extends Exception {
    private static final long serialVersionUID = 2168232776886684292L;

    public ReedSolomonException(String message) {
        super(message);
    }
}

package com.itextpdf.text.pdf.qrcode;

import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfStream;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.collection.PdfCollectionField;

public final class Mode {
    public static final Mode ALPHANUMERIC;
    public static final Mode BYTE;
    public static final Mode ECI;
    public static final Mode FNC1_FIRST_POSITION;
    public static final Mode FNC1_SECOND_POSITION;
    public static final Mode KANJI;
    public static final Mode NUMERIC;
    public static final Mode STRUCTURED_APPEND;
    public static final Mode TERMINATOR;
    private final int bits;
    private final int[] characterCountBitsForVersions;
    private final String name;

    static {
        TERMINATOR = new Mode(new int[]{0, 0, 0}, 0, "TERMINATOR");
        NUMERIC = new Mode(new int[]{10, 12, 14}, 1, "NUMERIC");
        ALPHANUMERIC = new Mode(new int[]{9, 11, 13}, 2, "ALPHANUMERIC");
        STRUCTURED_APPEND = new Mode(new int[]{0, 0, 0}, 3, "STRUCTURED_APPEND");
        BYTE = new Mode(new int[]{8, 16, 16}, 4, "BYTE");
        ECI = new Mode(null, 7, "ECI");
        KANJI = new Mode(new int[]{8, 10, 12}, 8, "KANJI");
        FNC1_FIRST_POSITION = new Mode(null, 5, "FNC1_FIRST_POSITION");
        FNC1_SECOND_POSITION = new Mode(null, 9, "FNC1_SECOND_POSITION");
    }

    private Mode(int[] characterCountBitsForVersions, int bits, String name) {
        this.characterCountBitsForVersions = characterCountBitsForVersions;
        this.bits = bits;
        this.name = name;
    }

    public static Mode forBits(int bits) {
        switch (bits) {
            case PdfWriter.markAll /*0*/:
                return TERMINATOR;
            case PdfWriter.markInlineElementsOnly /*1*/:
                return NUMERIC;
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
                return ALPHANUMERIC;
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                return STRUCTURED_APPEND;
            case PdfWriter.PageLayoutTwoColumnLeft /*4*/:
                return BYTE;
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                return FNC1_FIRST_POSITION;
            case PdfCollectionField.SIZE /*7*/:
                return ECI;
            case PdfWriter.PageLayoutTwoColumnRight /*8*/:
                return KANJI;
            case PdfStream.BEST_COMPRESSION /*9*/:
                return FNC1_SECOND_POSITION;
            default:
                throw new IllegalArgumentException();
        }
    }

    public int getCharacterCountBits(Version version) {
        if (this.characterCountBitsForVersions == null) {
            throw new IllegalArgumentException("Character count doesn't apply to this mode");
        }
        int offset;
        int number = version.getVersionNumber();
        if (number <= 9) {
            offset = 0;
        } else if (number <= 26) {
            offset = 1;
        } else {
            offset = 2;
        }
        return this.characterCountBitsForVersions[offset];
    }

    public int getBits() {
        return this.bits;
    }

    public String getName() {
        return this.name;
    }

    public String toString() {
        return this.name;
    }
}

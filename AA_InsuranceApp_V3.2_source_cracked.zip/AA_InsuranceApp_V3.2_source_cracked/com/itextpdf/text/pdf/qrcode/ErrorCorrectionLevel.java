package com.itextpdf.text.pdf.qrcode;

public final class ErrorCorrectionLevel {
    private static final ErrorCorrectionLevel[] FOR_BITS;
    public static final ErrorCorrectionLevel f34H;
    public static final ErrorCorrectionLevel f35L;
    public static final ErrorCorrectionLevel f36M;
    public static final ErrorCorrectionLevel f37Q;
    private final int bits;
    private final String name;
    private final int ordinal;

    static {
        f35L = new ErrorCorrectionLevel(0, 1, "L");
        f36M = new ErrorCorrectionLevel(1, 0, "M");
        f37Q = new ErrorCorrectionLevel(2, 3, "Q");
        f34H = new ErrorCorrectionLevel(3, 2, "H");
        FOR_BITS = new ErrorCorrectionLevel[]{f36M, f35L, f34H, f37Q};
    }

    private ErrorCorrectionLevel(int ordinal, int bits, String name) {
        this.ordinal = ordinal;
        this.bits = bits;
        this.name = name;
    }

    public int ordinal() {
        return this.ordinal;
    }

    public int getBits() {
        return this.bits;
    }

    public String getName() {
        return this.name;
    }

    public String toString() {
        return this.name;
    }

    public static ErrorCorrectionLevel forBits(int bits) {
        if (bits >= 0 && bits < FOR_BITS.length) {
            return FOR_BITS[bits];
        }
        throw new IllegalArgumentException();
    }
}

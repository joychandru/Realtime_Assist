package com.itextpdf.text.pdf.qrcode;

public final class WriterException extends Exception {
    private static final long serialVersionUID = 1;

    public WriterException(String message) {
        super(message);
    }
}

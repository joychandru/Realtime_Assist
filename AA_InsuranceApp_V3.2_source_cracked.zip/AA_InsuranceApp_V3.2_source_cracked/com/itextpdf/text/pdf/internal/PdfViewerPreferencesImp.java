package com.itextpdf.text.pdf.internal;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfArray;
import com.itextpdf.text.pdf.PdfBoolean;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStream;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.collection.PdfCollectionField;
import com.itextpdf.text.pdf.interfaces.PdfViewerPreferences;
import com.itextpdf.xmp.impl.ParseRDF;

public class PdfViewerPreferencesImp implements PdfViewerPreferences {
    public static final PdfName[] DIRECTION_PREFERENCES;
    public static final PdfName[] DUPLEX_PREFERENCES;
    public static final PdfName[] NONFULLSCREENPAGEMODE_PREFERENCES;
    public static final PdfName[] PAGE_BOUNDARIES;
    public static final PdfName[] PRINTSCALING_PREFERENCES;
    public static final PdfName[] VIEWER_PREFERENCES;
    private static final int viewerPreferencesMask = 16773120;
    private int pageLayoutAndMode;
    private PdfDictionary viewerPreferences;

    public PdfViewerPreferencesImp() {
        this.pageLayoutAndMode = 0;
        this.viewerPreferences = new PdfDictionary();
    }

    static {
        VIEWER_PREFERENCES = new PdfName[]{PdfName.HIDETOOLBAR, PdfName.HIDEMENUBAR, PdfName.HIDEWINDOWUI, PdfName.FITWINDOW, PdfName.CENTERWINDOW, PdfName.DISPLAYDOCTITLE, PdfName.NONFULLSCREENPAGEMODE, PdfName.DIRECTION, PdfName.VIEWAREA, PdfName.VIEWCLIP, PdfName.PRINTAREA, PdfName.PRINTCLIP, PdfName.PRINTSCALING, PdfName.DUPLEX, PdfName.PICKTRAYBYPDFSIZE, PdfName.PRINTPAGERANGE, PdfName.NUMCOPIES};
        NONFULLSCREENPAGEMODE_PREFERENCES = new PdfName[]{PdfName.USENONE, PdfName.USEOUTLINES, PdfName.USETHUMBS, PdfName.USEOC};
        DIRECTION_PREFERENCES = new PdfName[]{PdfName.L2R, PdfName.R2L};
        PAGE_BOUNDARIES = new PdfName[]{PdfName.MEDIABOX, PdfName.CROPBOX, PdfName.BLEEDBOX, PdfName.TRIMBOX, PdfName.ARTBOX};
        PRINTSCALING_PREFERENCES = new PdfName[]{PdfName.APPDEFAULT, PdfName.NONE};
        DUPLEX_PREFERENCES = new PdfName[]{PdfName.SIMPLEX, PdfName.DUPLEXFLIPSHORTEDGE, PdfName.DUPLEXFLIPLONGEDGE};
    }

    public int getPageLayoutAndMode() {
        return this.pageLayoutAndMode;
    }

    public PdfDictionary getViewerPreferences() {
        return this.viewerPreferences;
    }

    public void setViewerPreferences(int preferences) {
        this.pageLayoutAndMode |= preferences;
        if ((viewerPreferencesMask & preferences) != 0) {
            this.pageLayoutAndMode = -16773121 & this.pageLayoutAndMode;
            if ((preferences & PdfWriter.HideToolbar) != 0) {
                this.viewerPreferences.put(PdfName.HIDETOOLBAR, PdfBoolean.PDFTRUE);
            }
            if ((preferences & PdfWriter.HideMenubar) != 0) {
                this.viewerPreferences.put(PdfName.HIDEMENUBAR, PdfBoolean.PDFTRUE);
            }
            if ((preferences & PdfWriter.HideWindowUI) != 0) {
                this.viewerPreferences.put(PdfName.HIDEWINDOWUI, PdfBoolean.PDFTRUE);
            }
            if ((PdfWriter.FitWindow & preferences) != 0) {
                this.viewerPreferences.put(PdfName.FITWINDOW, PdfBoolean.PDFTRUE);
            }
            if ((PdfWriter.CenterWindow & preferences) != 0) {
                this.viewerPreferences.put(PdfName.CENTERWINDOW, PdfBoolean.PDFTRUE);
            }
            if ((PdfWriter.DisplayDocTitle & preferences) != 0) {
                this.viewerPreferences.put(PdfName.DISPLAYDOCTITLE, PdfBoolean.PDFTRUE);
            }
            if ((PdfWriter.NonFullScreenPageModeUseNone & preferences) != 0) {
                this.viewerPreferences.put(PdfName.NONFULLSCREENPAGEMODE, PdfName.USENONE);
            } else if ((PdfWriter.NonFullScreenPageModeUseOutlines & preferences) != 0) {
                this.viewerPreferences.put(PdfName.NONFULLSCREENPAGEMODE, PdfName.USEOUTLINES);
            } else if ((PdfWriter.NonFullScreenPageModeUseThumbs & preferences) != 0) {
                this.viewerPreferences.put(PdfName.NONFULLSCREENPAGEMODE, PdfName.USETHUMBS);
            } else if ((PdfWriter.NonFullScreenPageModeUseOC & preferences) != 0) {
                this.viewerPreferences.put(PdfName.NONFULLSCREENPAGEMODE, PdfName.USEOC);
            }
            if ((PdfWriter.DirectionL2R & preferences) != 0) {
                this.viewerPreferences.put(PdfName.DIRECTION, PdfName.L2R);
            } else if ((PdfWriter.DirectionR2L & preferences) != 0) {
                this.viewerPreferences.put(PdfName.DIRECTION, PdfName.R2L);
            }
            if ((PdfWriter.PrintScalingNone & preferences) != 0) {
                this.viewerPreferences.put(PdfName.PRINTSCALING, PdfName.NONE);
            }
        }
    }

    private int getIndex(PdfName key) {
        for (int i = 0; i < VIEWER_PREFERENCES.length; i++) {
            if (VIEWER_PREFERENCES[i].equals(key)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isPossibleValue(PdfName value, PdfName[] accepted) {
        for (PdfName equals : accepted) {
            if (equals.equals(value)) {
                return true;
            }
        }
        return false;
    }

    public void addViewerPreference(PdfName key, PdfObject value) {
        switch (getIndex(key)) {
            case PdfWriter.markAll /*0*/:
            case PdfWriter.markInlineElementsOnly /*1*/:
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
            case PdfWriter.PageLayoutTwoColumnLeft /*4*/:
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
            case PdfIsoKeys.PDFISOKEY_ACTION /*14*/:
                if (value instanceof PdfBoolean) {
                    this.viewerPreferences.put(key, value);
                }
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                if ((value instanceof PdfName) && isPossibleValue((PdfName) value, NONFULLSCREENPAGEMODE_PREFERENCES)) {
                    this.viewerPreferences.put(key, value);
                }
            case PdfCollectionField.SIZE /*7*/:
                if ((value instanceof PdfName) && isPossibleValue((PdfName) value, DIRECTION_PREFERENCES)) {
                    this.viewerPreferences.put(key, value);
                }
            case PdfWriter.PageLayoutTwoColumnRight /*8*/:
            case PdfStream.BEST_COMPRESSION /*9*/:
            case ParseRDF.RDFTERM_FIRST_OLD /*10*/:
            case ParseRDF.RDFTERM_ABOUT_EACH_PREFIX /*11*/:
                if ((value instanceof PdfName) && isPossibleValue((PdfName) value, PAGE_BOUNDARIES)) {
                    this.viewerPreferences.put(key, value);
                }
            case ParseRDF.RDFTERM_LAST_OLD /*12*/:
                if ((value instanceof PdfName) && isPossibleValue((PdfName) value, PRINTSCALING_PREFERENCES)) {
                    this.viewerPreferences.put(key, value);
                }
            case PdfIsoKeys.PDFISOKEY_ANNOTATION /*13*/:
                if ((value instanceof PdfName) && isPossibleValue((PdfName) value, DUPLEX_PREFERENCES)) {
                    this.viewerPreferences.put(key, value);
                }
            case Rectangle.BOX /*15*/:
                if (value instanceof PdfArray) {
                    this.viewerPreferences.put(key, value);
                }
            case PdfWriter.PageLayoutTwoPageLeft /*16*/:
                if (value instanceof PdfNumber) {
                    this.viewerPreferences.put(key, value);
                }
            default:
        }
    }

    public void addToCatalog(PdfDictionary catalog) {
        catalog.remove(PdfName.PAGELAYOUT);
        if ((this.pageLayoutAndMode & 1) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.SINGLEPAGE);
        } else if ((this.pageLayoutAndMode & 2) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.ONECOLUMN);
        } else if ((this.pageLayoutAndMode & 4) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.TWOCOLUMNLEFT);
        } else if ((this.pageLayoutAndMode & 8) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.TWOCOLUMNRIGHT);
        } else if ((this.pageLayoutAndMode & 16) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.TWOPAGELEFT);
        } else if ((this.pageLayoutAndMode & 32) != 0) {
            catalog.put(PdfName.PAGELAYOUT, PdfName.TWOPAGERIGHT);
        }
        catalog.remove(PdfName.PAGEMODE);
        if ((this.pageLayoutAndMode & 64) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.USENONE);
        } else if ((this.pageLayoutAndMode & PdfWriter.PageModeUseOutlines) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.USEOUTLINES);
        } else if ((this.pageLayoutAndMode & PdfWriter.PageModeUseThumbs) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.USETHUMBS);
        } else if ((this.pageLayoutAndMode & PdfWriter.PageModeFullScreen) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.FULLSCREEN);
        } else if ((this.pageLayoutAndMode & PdfWriter.PageModeUseOC) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.USEOC);
        } else if ((this.pageLayoutAndMode & PdfWriter.PageModeUseAttachments) != 0) {
            catalog.put(PdfName.PAGEMODE, PdfName.USEATTACHMENTS);
        }
        catalog.remove(PdfName.VIEWERPREFERENCES);
        if (this.viewerPreferences.size() > 0) {
            catalog.put(PdfName.VIEWERPREFERENCES, this.viewerPreferences);
        }
    }

    public static PdfViewerPreferencesImp getViewerPreferences(PdfDictionary catalog) {
        PdfName name;
        PdfViewerPreferencesImp preferences = new PdfViewerPreferencesImp();
        int prefs = 0;
        PdfObject obj = PdfReader.getPdfObjectRelease(catalog.get(PdfName.PAGELAYOUT));
        if (obj != null && obj.isName()) {
            name = (PdfName) obj;
            if (name.equals(PdfName.SINGLEPAGE)) {
                prefs = 0 | 1;
            } else if (name.equals(PdfName.ONECOLUMN)) {
                prefs = 0 | 2;
            } else if (name.equals(PdfName.TWOCOLUMNLEFT)) {
                prefs = 0 | 4;
            } else if (name.equals(PdfName.TWOCOLUMNRIGHT)) {
                prefs = 0 | 8;
            } else if (name.equals(PdfName.TWOPAGELEFT)) {
                prefs = 0 | 16;
            } else if (name.equals(PdfName.TWOPAGERIGHT)) {
                prefs = 0 | 32;
            }
        }
        obj = PdfReader.getPdfObjectRelease(catalog.get(PdfName.PAGEMODE));
        if (obj != null && obj.isName()) {
            name = (PdfName) obj;
            if (name.equals(PdfName.USENONE)) {
                prefs |= 64;
            } else if (name.equals(PdfName.USEOUTLINES)) {
                prefs |= PdfWriter.PageModeUseOutlines;
            } else if (name.equals(PdfName.USETHUMBS)) {
                prefs |= PdfWriter.PageModeUseThumbs;
            } else if (name.equals(PdfName.FULLSCREEN)) {
                prefs |= PdfWriter.PageModeFullScreen;
            } else if (name.equals(PdfName.USEOC)) {
                prefs |= PdfWriter.PageModeUseOC;
            } else if (name.equals(PdfName.USEATTACHMENTS)) {
                prefs |= PdfWriter.PageModeUseAttachments;
            }
        }
        preferences.setViewerPreferences(prefs);
        obj = PdfReader.getPdfObjectRelease(catalog.get(PdfName.VIEWERPREFERENCES));
        if (obj != null && obj.isDictionary()) {
            PdfDictionary vp = (PdfDictionary) obj;
            for (int i = 0; i < VIEWER_PREFERENCES.length; i++) {
                preferences.addViewerPreference(VIEWER_PREFERENCES[i], PdfReader.getPdfObjectRelease(vp.get(VIEWER_PREFERENCES[i])));
            }
        }
        return preferences;
    }
}

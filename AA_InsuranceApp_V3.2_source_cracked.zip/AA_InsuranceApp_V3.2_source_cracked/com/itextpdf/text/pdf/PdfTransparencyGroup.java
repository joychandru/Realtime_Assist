package com.itextpdf.text.pdf;

public class PdfTransparencyGroup extends PdfDictionary {
    public PdfTransparencyGroup() {
        put(PdfName.f78S, PdfName.TRANSPARENCY);
    }

    public void setIsolated(boolean isolated) {
        if (isolated) {
            put(PdfName.f69I, PdfBoolean.PDFTRUE);
        } else {
            remove(PdfName.f69I);
        }
    }

    public void setKnockout(boolean knockout) {
        if (knockout) {
            put(PdfName.f70K, PdfBoolean.PDFTRUE);
        } else {
            remove(PdfName.f70K);
        }
    }
}

package com.itextpdf.text.pdf;

import java.util.Arrays;

public class PdfDeviceNColor implements ICachedColorSpace, IPdfSpecialColorSpace {
    ColorDetails[] colorantsDetails;
    PdfSpotColor[] spotColors;

    public PdfDeviceNColor(PdfSpotColor[] spotColors) {
        this.spotColors = spotColors;
    }

    public int getNumberOfColorants() {
        return this.spotColors.length;
    }

    public PdfSpotColor[] getSpotColors() {
        return this.spotColors;
    }

    public ColorDetails[] getColorantDetails(PdfWriter writer) {
        if (this.colorantsDetails == null) {
            this.colorantsDetails = new ColorDetails[this.spotColors.length];
            int i = 0;
            for (ICachedColorSpace spotColorant : this.spotColors) {
                this.colorantsDetails[i] = writer.addSimple(spotColorant);
                i++;
            }
        }
        return this.colorantsDetails;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.itextpdf.text.pdf.PdfObject getPdfObject(com.itextpdf.text.pdf.PdfWriter r36) {
        /*
        r35 = this;
        r4 = new com.itextpdf.text.pdf.PdfArray;
        r28 = com.itextpdf.text.pdf.PdfName.DEVICEN;
        r0 = r28;
        r4.<init>(r0);
        r9 = new com.itextpdf.text.pdf.PdfArray;
        r9.<init>();
        r0 = r35;
        r0 = r0.spotColors;
        r28 = r0;
        r0 = r28;
        r0 = r0.length;
        r28 = r0;
        r28 = r28 * 2;
        r0 = r28;
        r11 = new float[r0];
        r10 = new com.itextpdf.text.pdf.PdfDictionary;
        r10.<init>();
        r23 = "";
        r0 = r35;
        r0 = r0.spotColors;
        r28 = r0;
        r0 = r28;
        r0 = r0.length;
        r21 = r0;
        r28 = 4;
        r0 = r28;
        r1 = r21;
        r28 = new int[]{r0, r1};
        r29 = java.lang.Float.TYPE;
        r0 = r29;
        r1 = r28;
        r3 = java.lang.reflect.Array.newInstance(r0, r1);
        r3 = (float[][]) r3;
        r18 = 0;
    L_0x0049:
        r0 = r18;
        r1 = r21;
        if (r0 >= r1) goto L_0x021d;
    L_0x004f:
        r0 = r35;
        r0 = r0.spotColors;
        r28 = r0;
        r26 = r28[r18];
        r28 = r18 * 2;
        r29 = 0;
        r11[r28] = r29;
        r28 = r18 * 2;
        r28 = r28 + 1;
        r29 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r11[r28] = r29;
        r28 = r26.getName();
        r0 = r28;
        r9.add(r0);
        r28 = r26.getName();
        r0 = r28;
        r28 = r10.get(r0);
        if (r28 == 0) goto L_0x008e;
    L_0x007a:
        r28 = new java.lang.RuntimeException;
        r29 = "devicen.component.names.shall.be.different";
        r30 = 0;
        r0 = r30;
        r0 = new java.lang.Object[r0];
        r30 = r0;
        r29 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r29, r30);
        r28.<init>(r29);
        throw r28;
    L_0x008e:
        r0 = r35;
        r0 = r0.colorantsDetails;
        r28 = r0;
        if (r28 == 0) goto L_0x00d8;
    L_0x0096:
        r28 = r26.getName();
        r0 = r35;
        r0 = r0.colorantsDetails;
        r29 = r0;
        r29 = r29[r18];
        r29 = r29.getIndirectReference();
        r0 = r28;
        r1 = r29;
        r10.put(r0, r1);
    L_0x00ad:
        r8 = r26.getAlternativeCS();
        r0 = r8 instanceof com.itextpdf.text.pdf.ExtendedColor;
        r28 = r0;
        if (r28 == 0) goto L_0x0195;
    L_0x00b7:
        r28 = r8;
        r28 = (com.itextpdf.text.pdf.ExtendedColor) r28;
        r0 = r28;
        r0 = r0.type;
        r27 = r0;
        switch(r27) {
            case 1: goto L_0x00ec;
            case 2: goto L_0x012f;
            case 7: goto L_0x0166;
            default: goto L_0x00c4;
        };
    L_0x00c4:
        r28 = new java.lang.RuntimeException;
        r29 = "only.rgb.gray.and.cmyk.are.supported.as.alternative.color.spaces";
        r30 = 0;
        r0 = r30;
        r0 = new java.lang.Object[r0];
        r30 = r0;
        r29 = com.itextpdf.text.error_messages.MessageLocalization.getComposedMessage(r29, r30);
        r28.<init>(r29);
        throw r28;
    L_0x00d8:
        r28 = r26.getName();
        r0 = r26;
        r1 = r36;
        r29 = r0.getPdfObject(r1);
        r0 = r28;
        r1 = r29;
        r10.put(r0, r1);
        goto L_0x00ad;
    L_0x00ec:
        r28 = 0;
        r28 = r3[r28];
        r29 = 0;
        r28[r18] = r29;
        r28 = 1;
        r28 = r3[r28];
        r29 = 0;
        r28[r18] = r29;
        r28 = 2;
        r28 = r3[r28];
        r29 = 0;
        r28[r18] = r29;
        r28 = 3;
        r28 = r3[r28];
        r29 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r8 = (com.itextpdf.text.pdf.GrayColor) r8;
        r30 = r8.getGray();
        r29 = r29 - r30;
        r28[r18] = r29;
    L_0x0114:
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r23;
        r28 = r0.append(r1);
        r29 = "pop ";
        r28 = r28.append(r29);
        r23 = r28.toString();
        r18 = r18 + 1;
        goto L_0x0049;
    L_0x012f:
        r28 = 0;
        r29 = r3[r28];
        r28 = r8;
        r28 = (com.itextpdf.text.pdf.CMYKColor) r28;
        r28 = r28.getCyan();
        r29[r18] = r28;
        r28 = 1;
        r29 = r3[r28];
        r28 = r8;
        r28 = (com.itextpdf.text.pdf.CMYKColor) r28;
        r28 = r28.getMagenta();
        r29[r18] = r28;
        r28 = 2;
        r29 = r3[r28];
        r28 = r8;
        r28 = (com.itextpdf.text.pdf.CMYKColor) r28;
        r28 = r28.getYellow();
        r29[r18] = r28;
        r28 = 3;
        r28 = r3[r28];
        r8 = (com.itextpdf.text.pdf.CMYKColor) r8;
        r29 = r8.getBlack();
        r28[r18] = r29;
        goto L_0x0114;
    L_0x0166:
        r8 = (com.itextpdf.text.pdf.LabColor) r8;
        r7 = r8.toCmyk();
        r28 = 0;
        r28 = r3[r28];
        r29 = r7.getCyan();
        r28[r18] = r29;
        r28 = 1;
        r28 = r3[r28];
        r29 = r7.getMagenta();
        r28[r18] = r29;
        r28 = 2;
        r28 = r3[r28];
        r29 = r7.getYellow();
        r28[r18] = r29;
        r28 = 3;
        r28 = r3[r28];
        r29 = r7.getBlack();
        r28[r18] = r29;
        goto L_0x0114;
    L_0x0195:
        r28 = r8.getRed();
        r0 = r28;
        r0 = (float) r0;
        r25 = r0;
        r28 = r8.getGreen();
        r0 = r28;
        r0 = (float) r0;
        r17 = r0;
        r28 = r8.getBlue();
        r0 = r28;
        r6 = (float) r0;
        r12 = 0;
        r14 = 0;
        r15 = 0;
        r13 = 0;
        r28 = 0;
        r28 = (r25 > r28 ? 1 : (r25 == r28 ? 0 : -1));
        if (r28 != 0) goto L_0x01e0;
    L_0x01b8:
        r28 = 0;
        r28 = (r17 > r28 ? 1 : (r17 == r28 ? 0 : -1));
        if (r28 != 0) goto L_0x01e0;
    L_0x01be:
        r28 = 0;
        r28 = (r6 > r28 ? 1 : (r6 == r28 ? 0 : -1));
        if (r28 != 0) goto L_0x01e0;
    L_0x01c4:
        r13 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
    L_0x01c6:
        r28 = 0;
        r28 = r3[r28];
        r28[r18] = r12;
        r28 = 1;
        r28 = r3[r28];
        r28[r18] = r14;
        r28 = 2;
        r28 = r3[r28];
        r28[r18] = r15;
        r28 = 3;
        r28 = r3[r28];
        r28[r18] = r13;
        goto L_0x0114;
    L_0x01e0:
        r28 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = 1132396544; // 0x437f0000 float:255.0 double:5.5947823E-315;
        r29 = r25 / r29;
        r12 = r28 - r29;
        r28 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = 1132396544; // 0x437f0000 float:255.0 double:5.5947823E-315;
        r29 = r17 / r29;
        r14 = r28 - r29;
        r28 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = 1132396544; // 0x437f0000 float:255.0 double:5.5947823E-315;
        r29 = r6 / r29;
        r15 = r28 - r29;
        r28 = java.lang.Math.min(r14, r15);
        r0 = r28;
        r20 = java.lang.Math.min(r12, r0);
        r28 = r12 - r20;
        r29 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = r29 - r20;
        r12 = r28 / r29;
        r28 = r14 - r20;
        r29 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = r29 - r20;
        r14 = r28 / r29;
        r28 = r15 - r20;
        r29 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r29 = r29 - r20;
        r15 = r28 / r29;
        r13 = r20;
        goto L_0x01c6;
    L_0x021d:
        r4.add(r9);
        r28 = java.util.Locale.US;
        r29 = "1.000000 %d 1 roll ";
        r30 = 1;
        r0 = r30;
        r0 = new java.lang.Object[r0];
        r30 = r0;
        r31 = 0;
        r32 = r21 + 1;
        r32 = java.lang.Integer.valueOf(r32);
        r30[r31] = r32;
        r24 = java.lang.String.format(r28, r29, r30);
        r28 = com.itextpdf.text.pdf.PdfName.DEVICECMYK;
        r0 = r28;
        r4.add(r0);
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r24;
        r28 = r0.append(r1);
        r0 = r28;
        r1 = r24;
        r28 = r0.append(r1);
        r0 = r28;
        r1 = r24;
        r28 = r0.append(r1);
        r0 = r28;
        r1 = r24;
        r28 = r0.append(r1);
        r24 = r28.toString();
        r22 = "";
        r18 = r21 + 4;
    L_0x026e:
        r0 = r18;
        r1 = r21;
        if (r0 <= r1) goto L_0x0318;
    L_0x0274:
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r22;
        r28 = r0.append(r1);
        r29 = java.util.Locale.US;
        r30 = "%d -1 roll ";
        r31 = 1;
        r0 = r31;
        r0 = new java.lang.Object[r0];
        r31 = r0;
        r32 = 0;
        r33 = java.lang.Integer.valueOf(r18);
        r31[r32] = r33;
        r29 = java.lang.String.format(r29, r30, r31);
        r28 = r28.append(r29);
        r22 = r28.toString();
        r19 = r21;
    L_0x02a3:
        if (r19 <= 0) goto L_0x02e7;
    L_0x02a5:
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r22;
        r28 = r0.append(r1);
        r29 = java.util.Locale.US;
        r30 = "%d index %f mul 1.000000 cvr exch sub mul ";
        r31 = 2;
        r0 = r31;
        r0 = new java.lang.Object[r0];
        r31 = r0;
        r32 = 0;
        r33 = java.lang.Integer.valueOf(r19);
        r31[r32] = r33;
        r32 = 1;
        r33 = r21 + 4;
        r33 = r33 - r18;
        r33 = r3[r33];
        r34 = r21 - r19;
        r33 = r33[r34];
        r33 = java.lang.Float.valueOf(r33);
        r31[r32] = r33;
        r29 = java.lang.String.format(r29, r30, r31);
        r28 = r28.append(r29);
        r22 = r28.toString();
        r19 = r19 + -1;
        goto L_0x02a3;
    L_0x02e7:
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r22;
        r28 = r0.append(r1);
        r29 = java.util.Locale.US;
        r30 = "1.000000 cvr exch sub %d 1 roll ";
        r31 = 1;
        r0 = r31;
        r0 = new java.lang.Object[r0];
        r31 = r0;
        r32 = 0;
        r33 = java.lang.Integer.valueOf(r18);
        r31[r32] = r33;
        r29 = java.lang.String.format(r29, r30, r31);
        r28 = r28.append(r29);
        r22 = r28.toString();
        r18 = r18 + -1;
        goto L_0x026e;
    L_0x0318:
        r28 = 8;
        r0 = r28;
        r0 = new float[r0];
        r28 = r0;
        r28 = {0, 1065353216, 0, 1065353216, 0, 1065353216, 0, 1065353216};
        r29 = new java.lang.StringBuilder;
        r29.<init>();
        r30 = "{ ";
        r29 = r29.append(r30);
        r0 = r29;
        r1 = r24;
        r29 = r0.append(r1);
        r0 = r29;
        r1 = r22;
        r29 = r0.append(r1);
        r0 = r29;
        r1 = r23;
        r29 = r0.append(r1);
        r30 = "}";
        r29 = r29.append(r30);
        r29 = r29.toString();
        r0 = r36;
        r1 = r28;
        r2 = r29;
        r16 = com.itextpdf.text.pdf.PdfFunction.type4(r0, r11, r1, r2);
        r28 = r16.getReference();
        r0 = r28;
        r4.add(r0);
        r5 = new com.itextpdf.text.pdf.PdfDictionary;
        r5.<init>();
        r28 = com.itextpdf.text.pdf.PdfName.SUBTYPE;
        r29 = com.itextpdf.text.pdf.PdfName.NCHANNEL;
        r0 = r28;
        r1 = r29;
        r5.put(r0, r1);
        r28 = com.itextpdf.text.pdf.PdfName.COLORANTS;
        r0 = r28;
        r5.put(r0, r10);
        r4.add(r5);
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.PdfDeviceNColor.getPdfObject(com.itextpdf.text.pdf.PdfWriter):com.itextpdf.text.pdf.PdfObject");
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PdfDeviceNColor)) {
            return false;
        }
        if (Arrays.equals(this.spotColors, ((PdfDeviceNColor) o).spotColors)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return Arrays.hashCode(this.spotColors);
    }
}

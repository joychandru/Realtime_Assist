package com.itextpdf.text.pdf;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Jpeg;
import com.itextpdf.text.pdf.codec.CCITTG4Encoder;
import com.itextpdf.text.pdf.codec.JBIG2SegmentReader;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.codec.wmf.MetaDo;
import com.itextpdf.text.pdf.internal.PdfIsoKeys;
import com.itextpdf.xmp.XMPError;
import com.itextpdf.xmp.impl.ParseRDF;
import com.itextpdf.xmp.impl.Utils;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Hashtable;

public class BarcodeDatamatrix {
    public static final int DM_ASCII = 1;
    public static final int DM_AUTO = 0;
    public static final int DM_B256 = 4;
    public static final int DM_C40 = 2;
    public static final int DM_EDIFACT = 6;
    public static final int DM_ERROR_EXTENSION = 5;
    public static final int DM_ERROR_INVALID_SQUARE = 3;
    public static final int DM_ERROR_TEXT_TOO_BIG = 1;
    public static final int DM_EXTENSION = 32;
    public static final int DM_NO_ERROR = 0;
    public static final int DM_RAW = 7;
    public static final int DM_TEST = 64;
    public static final int DM_TEXT = 3;
    public static final int DM_X21 = 5;
    private static final DmParams[] dmSizes;
    private static final String x12 = "\r*> 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private int extOut;
    private int height;
    private byte[] image;
    private int options;
    private short[] place;
    private int width;
    private int ws;

    private static class DmParams {
        int dataBlock;
        int dataSize;
        int errorBlock;
        int height;
        int heightSection;
        int width;
        int widthSection;

        DmParams(int height, int width, int heightSection, int widthSection, int dataSize, int dataBlock, int errorBlock) {
            this.height = height;
            this.width = width;
            this.heightSection = heightSection;
            this.widthSection = widthSection;
            this.dataSize = dataSize;
            this.dataBlock = dataBlock;
            this.errorBlock = errorBlock;
        }
    }

    static class Placement {
        private static final Hashtable<Integer, short[]> cache;
        private short[] array;
        private int ncol;
        private int nrow;

        static {
            cache = new Hashtable();
        }

        private Placement() {
        }

        static short[] doPlacement(int nrow, int ncol) {
            Integer key = Integer.valueOf((nrow * 1000) + ncol);
            short[] pc = (short[]) cache.get(key);
            if (pc != null) {
                return pc;
            }
            Placement p = new Placement();
            p.nrow = nrow;
            p.ncol = ncol;
            p.array = new short[(nrow * ncol)];
            p.ecc200();
            cache.put(key, p.array);
            return p.array;
        }

        private void module(int row, int col, int chr, int bit) {
            if (row < 0) {
                row += this.nrow;
                col += 4 - ((this.nrow + BarcodeDatamatrix.DM_B256) % 8);
            }
            if (col < 0) {
                col += this.ncol;
                row += 4 - ((this.ncol + BarcodeDatamatrix.DM_B256) % 8);
            }
            this.array[(this.ncol * row) + col] = (short) ((chr * 8) + bit);
        }

        private void utah(int row, int col, int chr) {
            module(row - 2, col - 2, chr, BarcodeDatamatrix.DM_NO_ERROR);
            module(row - 2, col - 1, chr, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG);
            module(row - 1, col - 2, chr, BarcodeDatamatrix.DM_C40);
            module(row - 1, col - 1, chr, BarcodeDatamatrix.DM_TEXT);
            module(row - 1, col, chr, BarcodeDatamatrix.DM_B256);
            module(row, col - 2, chr, BarcodeDatamatrix.DM_X21);
            module(row, col - 1, chr, BarcodeDatamatrix.DM_EDIFACT);
            module(row, col, chr, BarcodeDatamatrix.DM_RAW);
        }

        private void corner1(int chr) {
            module(this.nrow - 1, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_NO_ERROR);
            module(this.nrow - 1, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, chr, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG);
            module(this.nrow - 1, BarcodeDatamatrix.DM_C40, chr, BarcodeDatamatrix.DM_C40);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 2, chr, BarcodeDatamatrix.DM_TEXT);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 1, chr, BarcodeDatamatrix.DM_B256);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 1, chr, BarcodeDatamatrix.DM_X21);
            module(BarcodeDatamatrix.DM_C40, this.ncol - 1, chr, BarcodeDatamatrix.DM_EDIFACT);
            module(BarcodeDatamatrix.DM_TEXT, this.ncol - 1, chr, BarcodeDatamatrix.DM_RAW);
        }

        private void corner2(int chr) {
            module(this.nrow - 3, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_NO_ERROR);
            module(this.nrow - 2, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG);
            module(this.nrow - 1, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_C40);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 4, chr, BarcodeDatamatrix.DM_TEXT);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 3, chr, BarcodeDatamatrix.DM_B256);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 2, chr, BarcodeDatamatrix.DM_X21);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 1, chr, BarcodeDatamatrix.DM_EDIFACT);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 1, chr, BarcodeDatamatrix.DM_RAW);
        }

        private void corner3(int chr) {
            module(this.nrow - 3, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_NO_ERROR);
            module(this.nrow - 2, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG);
            module(this.nrow - 1, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_C40);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 2, chr, BarcodeDatamatrix.DM_TEXT);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 1, chr, BarcodeDatamatrix.DM_B256);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 1, chr, BarcodeDatamatrix.DM_X21);
            module(BarcodeDatamatrix.DM_C40, this.ncol - 1, chr, BarcodeDatamatrix.DM_EDIFACT);
            module(BarcodeDatamatrix.DM_TEXT, this.ncol - 1, chr, BarcodeDatamatrix.DM_RAW);
        }

        private void corner4(int chr) {
            module(this.nrow - 1, BarcodeDatamatrix.DM_NO_ERROR, chr, BarcodeDatamatrix.DM_NO_ERROR);
            module(this.nrow - 1, this.ncol - 1, chr, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 3, chr, BarcodeDatamatrix.DM_C40);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 2, chr, BarcodeDatamatrix.DM_TEXT);
            module(BarcodeDatamatrix.DM_NO_ERROR, this.ncol - 1, chr, BarcodeDatamatrix.DM_B256);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 3, chr, BarcodeDatamatrix.DM_X21);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 2, chr, BarcodeDatamatrix.DM_EDIFACT);
            module(BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, this.ncol - 1, chr, BarcodeDatamatrix.DM_RAW);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void ecc200() {
            /*
            r9 = this;
            r4 = r9.array;
            r5 = 0;
            java.util.Arrays.fill(r4, r5);
            r0 = 1;
            r3 = 4;
            r2 = 0;
        L_0x0009:
            r4 = r9.nrow;
            if (r3 != r4) goto L_0x0015;
        L_0x000d:
            if (r2 != 0) goto L_0x0015;
        L_0x000f:
            r1 = r0 + 1;
            r9.corner1(r0);
            r0 = r1;
        L_0x0015:
            r4 = r9.nrow;
            r4 = r4 + -2;
            if (r3 != r4) goto L_0x0029;
        L_0x001b:
            if (r2 != 0) goto L_0x0029;
        L_0x001d:
            r4 = r9.ncol;
            r4 = r4 % 4;
            if (r4 == 0) goto L_0x0029;
        L_0x0023:
            r1 = r0 + 1;
            r9.corner2(r0);
            r0 = r1;
        L_0x0029:
            r4 = r9.nrow;
            r4 = r4 + -2;
            if (r3 != r4) goto L_0x003e;
        L_0x002f:
            if (r2 != 0) goto L_0x003e;
        L_0x0031:
            r4 = r9.ncol;
            r4 = r4 % 8;
            r5 = 4;
            if (r4 != r5) goto L_0x003e;
        L_0x0038:
            r1 = r0 + 1;
            r9.corner3(r0);
            r0 = r1;
        L_0x003e:
            r4 = r9.nrow;
            r4 = r4 + 4;
            if (r3 != r4) goto L_0x0053;
        L_0x0044:
            r4 = 2;
            if (r2 != r4) goto L_0x0053;
        L_0x0047:
            r4 = r9.ncol;
            r4 = r4 % 8;
            if (r4 != 0) goto L_0x0053;
        L_0x004d:
            r1 = r0 + 1;
            r9.corner4(r0);
            r0 = r1;
        L_0x0053:
            r4 = r9.nrow;
            if (r3 >= r4) goto L_0x0069;
        L_0x0057:
            if (r2 < 0) goto L_0x0069;
        L_0x0059:
            r4 = r9.array;
            r5 = r9.ncol;
            r5 = r5 * r3;
            r5 = r5 + r2;
            r4 = r4[r5];
            if (r4 != 0) goto L_0x0069;
        L_0x0063:
            r1 = r0 + 1;
            r9.utah(r3, r2, r0);
            r0 = r1;
        L_0x0069:
            r3 = r3 + -2;
            r2 = r2 + 2;
            if (r3 < 0) goto L_0x0073;
        L_0x006f:
            r4 = r9.ncol;
            if (r2 < r4) goto L_0x0053;
        L_0x0073:
            r3 = r3 + 1;
            r2 = r2 + 3;
            r1 = r0;
        L_0x0078:
            if (r3 < 0) goto L_0x00cd;
        L_0x007a:
            r4 = r9.ncol;
            if (r2 >= r4) goto L_0x00cd;
        L_0x007e:
            r4 = r9.array;
            r5 = r9.ncol;
            r5 = r5 * r3;
            r5 = r5 + r2;
            r4 = r4[r5];
            if (r4 != 0) goto L_0x00cd;
        L_0x0088:
            r0 = r1 + 1;
            r9.utah(r3, r2, r1);
        L_0x008d:
            r3 = r3 + 2;
            r2 = r2 + -2;
            r4 = r9.nrow;
            if (r3 >= r4) goto L_0x0097;
        L_0x0095:
            if (r2 >= 0) goto L_0x00cb;
        L_0x0097:
            r3 = r3 + 3;
            r2 = r2 + 1;
            r4 = r9.nrow;
            if (r3 < r4) goto L_0x0009;
        L_0x009f:
            r4 = r9.ncol;
            if (r2 < r4) goto L_0x0009;
        L_0x00a3:
            r4 = r9.array;
            r5 = r9.nrow;
            r6 = r9.ncol;
            r5 = r5 * r6;
            r5 = r5 + -1;
            r4 = r4[r5];
            if (r4 != 0) goto L_0x00ca;
        L_0x00b0:
            r4 = r9.array;
            r5 = r9.nrow;
            r6 = r9.ncol;
            r5 = r5 * r6;
            r5 = r5 + -1;
            r6 = r9.array;
            r7 = r9.nrow;
            r8 = r9.ncol;
            r7 = r7 * r8;
            r8 = r9.ncol;
            r7 = r7 - r8;
            r7 = r7 + -2;
            r8 = 1;
            r6[r7] = r8;
            r4[r5] = r8;
        L_0x00ca:
            return;
        L_0x00cb:
            r1 = r0;
            goto L_0x0078;
        L_0x00cd:
            r0 = r1;
            goto L_0x008d;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.BarcodeDatamatrix.Placement.ecc200():void");
        }
    }

    static class ReedSolomon {
        private static final int[] alog;
        private static final int[] log;
        private static final int[] poly10;
        private static final int[] poly11;
        private static final int[] poly12;
        private static final int[] poly14;
        private static final int[] poly18;
        private static final int[] poly20;
        private static final int[] poly24;
        private static final int[] poly28;
        private static final int[] poly36;
        private static final int[] poly42;
        private static final int[] poly48;
        private static final int[] poly5;
        private static final int[] poly56;
        private static final int[] poly62;
        private static final int[] poly68;
        private static final int[] poly7;

        ReedSolomon() {
        }

        static {
            log = new int[]{BarcodeDatamatrix.DM_NO_ERROR, TIFFConstants.TIFFTAG_OSUBFILETYPE, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, 240, BarcodeDatamatrix.DM_C40, 225, 241, 53, BarcodeDatamatrix.DM_TEXT, 38, Jpeg.M_APP2, 133, 242, 43, 54, 210, BarcodeDatamatrix.DM_B256, 195, 39, 114, 227, 106, 134, 28, 243, 140, 44, 23, 55, 118, 211, 234, BarcodeDatamatrix.DM_X21, 219, 196, 96, 40, 222, 115, XMPError.BADOPTIONS, 228, 78, XMPError.BADSERIALIZE, 125, 135, 8, 29, 162, 244, 186, 141, 180, 45, 99, 24, 49, 56, 13, 119, 153, 212, 199, 235, 91, BarcodeDatamatrix.DM_EDIFACT, 76, 220, 217, 197, 11, 97, 184, 41, 36, 223, 253, 116, 138, XMPError.BADINDEX, 193, 229, 86, 79, 171, 108, 165, 126, 145, 136, 34, 9, 74, 30, BarcodeDatamatrix.DM_EXTENSION, 163, 84, 245, 173, 187, XMPError.BADSTREAM, 142, 81, 181, 190, 46, 88, 100, 159, 25, 231, 50, 207, 57, 147, 14, 67, 120, PdfWriter.PageModeUseOutlines, 154, 248, 213, 167, PdfContentParser.COMMAND_TYPE, 63, 236, 110, 92, 176, BarcodeDatamatrix.DM_RAW, 161, 77, 124, 221, XMPError.BADXPATH, 218, 95, 198, 90, 12, 152, 98, 48, 185, 179, 42, 209, 37, 132, Jpeg.M_APP0, 52, TIFFConstants.TIFFTAG_SUBFILETYPE, 239, 117, 233, 139, 22, 105, 27, 194, 113, 230, 206, 87, 158, 80, 189, 172, XMPError.BADXMP, 109, 175, 166, 62, 127, MetaDo.META_CREATEPALETTE, 146, 66, 137, 192, 35, 252, 10, 183, 75, 216, 31, 83, 33, 73, 164, 144, 85, 170, 246, 65, 174, 61, 188, XMPError.BADRDF, 205, 157, 143, 169, 82, 72, 182, 215, 191, 251, 47, 178, 89, 151, XMPError.BADSCHEMA, 94, 160, 123, 26, 112, 232, 21, 51, Jpeg.M_APPE, 208, 131, 58, 69, 148, 18, 15, 16, 68, 17, 121, 149, 129, 19, 155, 59, 249, 70, 214, 250, 168, 71, XMPError.BADXML, 156, BarcodeDatamatrix.DM_TEST, 60, Jpeg.M_APPD, 130, 111, 20, 93, 122, 177, 150};
            alog = new int[]{BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, BarcodeDatamatrix.DM_C40, BarcodeDatamatrix.DM_B256, 8, 16, BarcodeDatamatrix.DM_EXTENSION, BarcodeDatamatrix.DM_TEST, PdfWriter.PageModeUseOutlines, 45, 90, 180, 69, 138, 57, 114, 228, 229, 231, 227, 235, 251, 219, 155, 27, 54, 108, 216, 157, 23, 46, 92, 184, 93, 186, 89, 178, 73, 146, 9, 18, 36, 72, 144, 13, 26, 52, XMPError.BADINDEX, 208, 141, 55, 110, 220, 149, BarcodeDatamatrix.DM_RAW, 14, 28, 56, 112, Jpeg.M_APP0, Jpeg.M_APPD, MetaDo.META_CREATEPALETTE, 195, 171, 123, 246, 193, 175, 115, 230, 225, 239, 243, XMPError.BADXMP, 187, 91, 182, 65, 130, 41, 82, 164, XMPError.BADSCHEMA, XMPError.BADRDF, 185, 95, 190, 81, 162, 105, 210, 137, 63, 126, 252, 213, 135, 35, 70, 140, 53, 106, 212, 133, 39, 78, 156, 21, 42, 84, 168, 125, 250, 217, 159, 19, 38, 76, 152, 29, 58, 116, 232, 253, 215, 131, 43, 86, 172, 117, 234, 249, 223, 147, 11, 22, 44, 88, 176, 77, 154, 25, 50, 100, PdfContentParser.COMMAND_TYPE, 189, 87, 174, 113, Jpeg.M_APP2, 233, TIFFConstants.TIFFTAG_OSUBFILETYPE, 211, 139, 59, 118, 236, 245, 199, 163, XMPError.BADSERIALIZE, 214, 129, 47, 94, 188, 85, 170, 121, 242, XMPError.BADXML, 191, 83, 166, 97, 194, 169, 127, TIFFConstants.TIFFTAG_SUBFILETYPE, 209, 143, 51, XMPError.BADXPATH, XMPError.BADSTREAM, 181, 71, 142, 49, 98, 196, 165, XMPError.BADOPTIONS, 206, 177, 79, 158, 17, 34, 68, 136, 61, 122, 244, 197, 167, 99, 198, 161, 111, 222, 145, 15, 30, 60, 120, 240, 205, 183, 67, 134, 33, 66, 132, 37, 74, 148, BarcodeDatamatrix.DM_X21, 10, 20, 40, 80, 160, 109, 218, 153, 31, 62, 124, 248, 221, 151, BarcodeDatamatrix.DM_TEXT, BarcodeDatamatrix.DM_EDIFACT, 12, 24, 48, 96, 192, 173, 119, Jpeg.M_APPE, 241, 207, 179, 75, 150, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG};
            poly5 = new int[]{228, 48, 15, 111, 62};
            poly7 = new int[]{23, 68, 144, 134, 240, 92, TIFFConstants.TIFFTAG_SUBFILETYPE};
            poly10 = new int[]{28, 24, 185, 166, 223, 248, 116, TIFFConstants.TIFFTAG_OSUBFILETYPE, 110, 61};
            poly11 = new int[]{175, 138, 205, 12, 194, 168, 39, 245, 60, 97, 120};
            poly12 = new int[]{41, 153, 158, 91, 61, 42, 142, 213, 97, 178, 100, 242};
            poly14 = new int[]{156, 97, 192, 252, 95, 9, 157, 119, 138, 45, 18, 186, 83, 185};
            poly18 = new int[]{83, 195, 100, 39, 188, 75, 66, 61, 241, 213, 109, 129, 94, TIFFConstants.TIFFTAG_SUBFILETYPE, 225, 48, 90, 188};
            poly20 = new int[]{15, 195, 244, 9, 233, 71, 168, BarcodeDatamatrix.DM_C40, 188, 160, 153, 145, 253, 79, 108, 82, 27, 174, 186, 172};
            poly24 = new int[]{52, 190, 88, 205, 109, 39, 176, 21, 155, 197, 251, 223, 155, 21, BarcodeDatamatrix.DM_X21, 172, TIFFConstants.TIFFTAG_SUBFILETYPE, 124, 12, 181, 184, 96, 50, 193};
            poly28 = new int[]{211, 231, 43, 97, 71, 96, XMPError.BADOPTIONS, 174, 37, 151, 170, 53, 75, 34, 249, 121, 17, 138, 110, 213, 141, 136, 120, 151, 233, 168, 93, TIFFConstants.TIFFTAG_OSUBFILETYPE};
            poly36 = new int[]{245, 127, 242, 218, 130, 250, 162, 181, XMPError.BADXPATH, 120, 84, 179, 220, 251, 80, 182, 229, 18, BarcodeDatamatrix.DM_C40, BarcodeDatamatrix.DM_B256, 68, 33, XMPError.BADSCHEMA, 137, 95, 119, 115, 44, 175, 184, 59, 25, 225, 98, 81, 112};
            poly42 = new int[]{77, 193, 137, 31, 19, 38, 22, 153, MetaDo.META_CREATEPALETTE, 105, 122, BarcodeDatamatrix.DM_C40, 245, 133, 242, 8, 175, 95, 100, 9, 167, 105, 214, 111, 57, 121, 21, BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG, 253, 57, 54, XMPError.BADSCHEMA, 248, XMPError.BADRDF, 69, 50, 150, 177, Jpeg.M_APP2, BarcodeDatamatrix.DM_X21, 9, BarcodeDatamatrix.DM_X21};
            poly48 = new int[]{245, 132, 172, 223, 96, BarcodeDatamatrix.DM_EXTENSION, 117, 22, Jpeg.M_APPE, 133, Jpeg.M_APPE, 231, 205, 188, Jpeg.M_APPD, 87, 191, 106, 16, 147, 118, 23, 37, 90, 170, 205, 131, 88, 120, 100, 66, 138, 186, 240, 82, 44, 176, 87, 187, 147, 160, 175, 69, 213, 92, 253, 225, 19};
            poly56 = new int[]{175, 9, 223, Jpeg.M_APPE, 12, 17, 220, 208, 100, 29, 175, 170, 230, 192, 215, 235, 150, 159, 36, 223, 38, PdfContentParser.COMMAND_TYPE, 132, 54, 228, 146, 218, 234, 117, XMPError.BADXMP, 29, 232, 144, Jpeg.M_APPE, 22, 150, XMPError.BADXML, 117, 62, 207, 164, 13, 137, 245, 127, 67, MetaDo.META_CREATEPALETTE, 28, 155, 43, XMPError.BADXMP, XMPError.BADSERIALIZE, 233, 53, 143, 46};
            poly62 = new int[]{242, 93, 169, 50, 144, 210, 39, 118, XMPError.BADRDF, 188, XMPError.BADXML, 189, 143, 108, 196, 37, 185, 112, 134, 230, 245, 63, 197, 190, 250, 106, 185, 221, 175, BarcodeDatamatrix.DM_TEST, 114, 71, 161, 44, 147, BarcodeDatamatrix.DM_EDIFACT, 27, 218, 51, 63, 87, 10, 40, 130, 188, 17, 163, 31, 176, 170, BarcodeDatamatrix.DM_B256, XMPError.BADSERIALIZE, 232, BarcodeDatamatrix.DM_RAW, 94, 166, Jpeg.M_APP0, 124, 86, 47, 11, XMPError.BADSTREAM};
            poly68 = new int[]{220, 228, 173, 89, 251, 149, 159, 56, 89, 33, 147, 244, 154, 36, 73, 127, 213, 136, 248, 180, 234, 197, 158, 177, 68, 122, 93, 213, 15, 160, 227, 236, 66, 139, 153, 185, XMPError.BADRDF, 167, 179, 25, 220, 232, 96, 210, 231, 136, 223, 239, 181, 241, 59, 52, 172, 25, 49, 232, 211, 189, BarcodeDatamatrix.DM_TEST, 54, 108, 153, 132, 63, 96, XMPError.BADOPTIONS, 82, 186};
        }

        private static int[] getPoly(int nc) {
            switch (nc) {
                case BarcodeDatamatrix.DM_X21 /*5*/:
                    return poly5;
                case BarcodeDatamatrix.DM_RAW /*7*/:
                    return poly7;
                case ParseRDF.RDFTERM_FIRST_OLD /*10*/:
                    return poly10;
                case ParseRDF.RDFTERM_ABOUT_EACH_PREFIX /*11*/:
                    return poly11;
                case ParseRDF.RDFTERM_LAST_OLD /*12*/:
                    return poly12;
                case PdfIsoKeys.PDFISOKEY_ACTION /*14*/:
                    return poly14;
                case PdfIsoKeys.PDFISOKEY_GRAY /*18*/:
                    return poly18;
                case PdfIsoKeys.PDFISOKEY_FORM_XOBJ /*20*/:
                    return poly20;
                case PdfWriter.EMBEDDED_FILES_ONLY /*24*/:
                    return poly24;
                case 28:
                    return poly28;
                case Utils.UUID_LENGTH /*36*/:
                    return poly36;
                case JBIG2SegmentReader.IMMEDIATE_GENERIC_REFINEMENT_REGION /*42*/:
                    return poly42;
                case JBIG2SegmentReader.PAGE_INFORMATION /*48*/:
                    return poly48;
                case 56:
                    return poly56;
                case JBIG2SegmentReader.EXTENSION /*62*/:
                    return poly62;
                case 68:
                    return poly68;
                default:
                    return null;
            }
        }

        private static void reedSolomonBlock(byte[] wd, int nd, byte[] ncout, int nc, int[] c) {
            int i;
            for (i = BarcodeDatamatrix.DM_NO_ERROR; i <= nc; i += BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG) {
                ncout[i] = (byte) 0;
            }
            for (i = BarcodeDatamatrix.DM_NO_ERROR; i < nd; i += BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG) {
                int k = (ncout[BarcodeDatamatrix.DM_NO_ERROR] ^ wd[i]) & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                for (int j = BarcodeDatamatrix.DM_NO_ERROR; j < nc; j += BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG) {
                    ncout[j] = (byte) ((k == 0 ? BarcodeDatamatrix.DM_NO_ERROR : (byte) alog[(log[k] + log[c[(nc - j) - 1]]) % TIFFConstants.TIFFTAG_OSUBFILETYPE]) ^ ncout[j + BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG]);
                }
            }
        }

        static void generateECC(byte[] wd, int nd, int datablock, int nc) {
            int blocks = (nd + BarcodeDatamatrix.DM_C40) / datablock;
            byte[] buf = new byte[PdfWriter.PageModeUseThumbs];
            byte[] ecc = new byte[PdfWriter.PageModeUseThumbs];
            int[] c = getPoly(nc);
            for (int b = BarcodeDatamatrix.DM_NO_ERROR; b < blocks; b += BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG) {
                int n = b;
                int p = BarcodeDatamatrix.DM_NO_ERROR;
                while (n < nd) {
                    int p2 = p + BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG;
                    buf[p] = wd[n];
                    n += blocks;
                    p = p2;
                }
                reedSolomonBlock(buf, p, ecc, nc, c);
                n = b;
                p = BarcodeDatamatrix.DM_NO_ERROR;
                while (n < nc * blocks) {
                    p2 = p + BarcodeDatamatrix.DM_ERROR_TEXT_TOO_BIG;
                    wd[nd + n] = ecc[p];
                    n += blocks;
                    p = p2;
                }
            }
        }
    }

    static {
        dmSizes = new DmParams[]{new DmParams(10, 10, 10, 10, DM_TEXT, DM_TEXT, DM_X21), new DmParams(12, 12, 12, 12, DM_X21, DM_X21, DM_RAW), new DmParams(8, 18, 8, 18, DM_X21, DM_X21, DM_RAW), new DmParams(14, 14, 14, 14, 8, 8, 10), new DmParams(8, DM_EXTENSION, 8, 16, 10, 10, 11), new DmParams(16, 16, 16, 16, 12, 12, 12), new DmParams(12, 26, 12, 26, 16, 16, 14), new DmParams(18, 18, 18, 18, 18, 18, 14), new DmParams(20, 20, 20, 20, 22, 22, 18), new DmParams(12, 36, 12, 18, 22, 22, 18), new DmParams(22, 22, 22, 22, 30, 30, 20), new DmParams(16, 36, 16, 18, DM_EXTENSION, DM_EXTENSION, 24), new DmParams(24, 24, 24, 24, 36, 36, 24), new DmParams(26, 26, 26, 26, 44, 44, 28), new DmParams(16, 48, 16, 24, 49, 49, 28), new DmParams(DM_EXTENSION, DM_EXTENSION, 16, 16, 62, 62, 36), new DmParams(36, 36, 18, 18, 86, 86, 42), new DmParams(40, 40, 20, 20, 114, 114, 48), new DmParams(44, 44, 22, 22, 144, 144, 56), new DmParams(48, 48, 24, 24, 174, 174, 68), new DmParams(52, 52, 26, 26, XMPError.BADSTREAM, XMPError.BADXPATH, 42), new DmParams(DM_TEST, DM_TEST, 16, 16, TIFFConstants.TIFFTAG_MINSAMPLEVALUE, 140, 56), new DmParams(72, 72, 18, 18, 368, 92, 36), new DmParams(80, 80, 20, 20, 456, 114, 48), new DmParams(88, 88, 22, 22, 576, 144, 56), new DmParams(96, 96, 24, 24, 696, 174, 68), new DmParams(XMPError.BADINDEX, XMPError.BADINDEX, 26, 26, 816, 136, 56), new DmParams(120, 120, 20, 20, 1050, 175, 68), new DmParams(132, 132, 22, 22, 1304, 163, 62), new DmParams(144, 144, 24, 24, 1558, 156, 62)};
    }

    private void setBit(int x, int y, int xByte) {
        byte[] bArr = this.image;
        int i = (y * xByte) + (x / 8);
        bArr[i] = (byte) (bArr[i] | ((byte) (PdfWriter.PageModeUseOutlines >> (x & DM_RAW))));
    }

    private void draw(byte[] data, int dataSize, DmParams dm) {
        int j;
        int xByte = ((dm.width + (this.ws * DM_C40)) + DM_RAW) / 8;
        Arrays.fill(this.image, (byte) 0);
        int i = this.ws;
        while (i < dm.height + this.ws) {
            for (j = this.ws; j < dm.width + this.ws; j += DM_C40) {
                setBit(j, i, xByte);
            }
            i += dm.heightSection;
        }
        i = (dm.heightSection - 1) + this.ws;
        while (i < dm.height + this.ws) {
            for (j = this.ws; j < dm.width + this.ws; j += DM_ERROR_TEXT_TOO_BIG) {
                setBit(j, i, xByte);
            }
            i += dm.heightSection;
        }
        i = this.ws;
        while (i < dm.width + this.ws) {
            for (j = this.ws; j < dm.height + this.ws; j += DM_ERROR_TEXT_TOO_BIG) {
                setBit(i, j, xByte);
            }
            i += dm.widthSection;
        }
        i = (dm.widthSection - 1) + this.ws;
        while (i < dm.width + this.ws) {
            for (j = this.ws + DM_ERROR_TEXT_TOO_BIG; j < dm.height + this.ws; j += DM_C40) {
                setBit(i, j, xByte);
            }
            i += dm.widthSection;
        }
        int p = DM_NO_ERROR;
        int ys = DM_NO_ERROR;
        while (ys < dm.height) {
            for (int y = DM_ERROR_TEXT_TOO_BIG; y < dm.heightSection - 1; y += DM_ERROR_TEXT_TOO_BIG) {
                int xs = DM_NO_ERROR;
                while (xs < dm.width) {
                    int x = DM_ERROR_TEXT_TOO_BIG;
                    while (x < dm.widthSection - 1) {
                        int p2 = p + DM_ERROR_TEXT_TOO_BIG;
                        int z = this.place[p];
                        if (z == DM_ERROR_TEXT_TOO_BIG || (z > DM_ERROR_TEXT_TOO_BIG && ((data[(z / 8) - 1] & TIFFConstants.TIFFTAG_OSUBFILETYPE) & (PdfWriter.PageModeUseOutlines >> (z % 8))) != 0)) {
                            setBit((x + xs) + this.ws, (y + ys) + this.ws, xByte);
                        }
                        x += DM_ERROR_TEXT_TOO_BIG;
                        p = p2;
                    }
                    xs += dm.widthSection;
                }
            }
            ys += dm.heightSection;
        }
    }

    private static void makePadding(byte[] data, int position, int count) {
        if (count > 0) {
            int position2 = position + DM_ERROR_TEXT_TOO_BIG;
            data[position] = (byte) -127;
            while (true) {
                count--;
                if (count > 0) {
                    int t = ((((position2 + DM_ERROR_TEXT_TOO_BIG) * 149) % 253) + 129) + DM_ERROR_TEXT_TOO_BIG;
                    if (t > TIFFConstants.TIFFTAG_SUBFILETYPE) {
                        t -= 254;
                    }
                    position = position2 + DM_ERROR_TEXT_TOO_BIG;
                    data[position2] = (byte) t;
                    position2 = position;
                } else {
                    position = position2;
                    return;
                }
            }
        }
    }

    private static boolean isDigit(int c) {
        return c >= 48 && c <= 57;
    }

    private static int asciiEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength) {
        int i;
        textLength += textOffset;
        dataLength += dataOffset;
        int ptrOut = dataOffset;
        int ptrIn = textOffset;
        while (ptrIn < textLength) {
            if (ptrOut >= dataLength) {
                i = ptrIn;
                return -1;
            }
            i = ptrIn + DM_ERROR_TEXT_TOO_BIG;
            int c = text[ptrIn] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            int ptrOut2;
            if (isDigit(c) && i < textLength && isDigit(text[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE)) {
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                ptrIn = i + DM_ERROR_TEXT_TOO_BIG;
                data[ptrOut] = (byte) (((((c - 48) * 10) + (text[i] & TIFFConstants.TIFFTAG_OSUBFILETYPE)) - 48) + 130);
                ptrOut = ptrOut2;
            } else if (c <= 127) {
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[ptrOut] = (byte) (c + DM_ERROR_TEXT_TOO_BIG);
                ptrOut = ptrOut2;
                ptrIn = i;
            } else if (ptrOut + DM_ERROR_TEXT_TOO_BIG >= dataLength) {
                return -1;
            } else {
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[ptrOut] = (byte) -21;
                ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                data[ptrOut2] = (byte) ((c - 128) + DM_ERROR_TEXT_TOO_BIG);
                ptrIn = i;
            }
        }
        i = ptrIn;
        return ptrOut - dataOffset;
    }

    private static int b256Encodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength) {
        if (textLength == 0) {
            return DM_NO_ERROR;
        }
        if (textLength < 250 && textLength + DM_C40 > dataLength) {
            return -1;
        }
        if (textLength >= 250 && textLength + DM_TEXT > dataLength) {
            return -1;
        }
        int k;
        data[dataOffset] = (byte) -25;
        if (textLength < 250) {
            data[dataOffset + DM_ERROR_TEXT_TOO_BIG] = (byte) textLength;
            k = DM_C40;
        } else {
            data[dataOffset + DM_ERROR_TEXT_TOO_BIG] = (byte) ((textLength / 250) + 249);
            data[dataOffset + DM_C40] = (byte) (textLength % 250);
            k = DM_TEXT;
        }
        System.arraycopy(text, textOffset, data, k + dataOffset, textLength);
        k += textLength + dataOffset;
        for (int j = dataOffset + DM_ERROR_TEXT_TOO_BIG; j < k; j += DM_ERROR_TEXT_TOO_BIG) {
            int tv = (data[j] & TIFFConstants.TIFFTAG_OSUBFILETYPE) + ((((j + DM_ERROR_TEXT_TOO_BIG) * 149) % TIFFConstants.TIFFTAG_OSUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
            if (tv > TIFFConstants.TIFFTAG_OSUBFILETYPE) {
                tv -= 256;
            }
            data[j] = (byte) tv;
        }
        return k - dataOffset;
    }

    private static int X12Encodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength) {
        if (textLength == 0) {
            return DM_NO_ERROR;
        }
        byte c;
        int ptrIn = DM_NO_ERROR;
        byte[] x = new byte[textLength];
        int count = DM_NO_ERROR;
        while (ptrIn < textLength) {
            int k;
            int i = x12.indexOf((char) text[ptrIn + textOffset]);
            if (i >= 0) {
                x[ptrIn] = (byte) i;
                count += DM_ERROR_TEXT_TOO_BIG;
            } else {
                x[ptrIn] = (byte) 100;
                if (count >= DM_EDIFACT) {
                    count -= (count / DM_TEXT) * DM_TEXT;
                }
                for (k = DM_NO_ERROR; k < count; k += DM_ERROR_TEXT_TOO_BIG) {
                    x[(ptrIn - k) - 1] = (byte) 100;
                }
                count = DM_NO_ERROR;
            }
            ptrIn += DM_ERROR_TEXT_TOO_BIG;
        }
        if (count >= DM_EDIFACT) {
            count -= (count / DM_TEXT) * DM_TEXT;
        }
        for (k = DM_NO_ERROR; k < count; k += DM_ERROR_TEXT_TOO_BIG) {
            x[(ptrIn - k) - 1] = (byte) 100;
        }
        ptrIn = DM_NO_ERROR;
        int ptrOut = DM_NO_ERROR;
        while (ptrIn < textLength) {
            c = x[ptrIn];
            if (ptrOut >= dataLength) {
                break;
            }
            int ptrOut2;
            if (c >= 40) {
                if (ptrIn <= 0 || x[ptrIn - 1] >= 40) {
                    ptrOut2 = ptrOut;
                } else {
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) -2;
                }
                int ci = text[ptrIn + textOffset] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                if (ci > 127) {
                    ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut2] = (byte) -21;
                    ci -= 128;
                } else {
                    ptrOut = ptrOut2;
                }
                if (ptrOut >= dataLength) {
                    break;
                }
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) (ci + DM_ERROR_TEXT_TOO_BIG);
            } else {
                if (ptrIn == 0 || (ptrIn > 0 && x[ptrIn - 1] > 40)) {
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) -18;
                    ptrOut = ptrOut2;
                }
                if (ptrOut + DM_C40 > dataLength) {
                    break;
                }
                int n = (((x[ptrIn] * 1600) + (x[ptrIn + DM_ERROR_TEXT_TOO_BIG] * 40)) + x[ptrIn + DM_C40]) + DM_ERROR_TEXT_TOO_BIG;
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) (n / PdfWriter.PageModeUseThumbs);
                ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut2] = (byte) n;
                ptrIn += DM_C40;
                ptrOut2 = ptrOut;
            }
            ptrIn += DM_ERROR_TEXT_TOO_BIG;
            ptrOut = ptrOut2;
        }
        c = (byte) 100;
        if (textLength > 0) {
            c = x[textLength - 1];
        }
        if (ptrIn != textLength || (c < 40 && ptrOut >= dataLength)) {
            return -1;
        }
        if (c >= 40) {
            return ptrOut;
        }
        ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
        data[dataOffset + ptrOut] = (byte) -2;
        return ptrOut2;
    }

    private static int EdifactEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength) {
        if (textLength == 0) {
            return DM_NO_ERROR;
        }
        int ptrIn = DM_NO_ERROR;
        int edi = DM_NO_ERROR;
        int pedi = 18;
        boolean ascii = true;
        int ptrOut = DM_NO_ERROR;
        while (ptrIn < textLength) {
            int ptrOut2;
            int c = text[ptrIn + textOffset] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            if (((c & Jpeg.M_APP0) != DM_TEST && (c & Jpeg.M_APP0) != DM_EXTENSION) || c == 95) {
                if (!ascii) {
                    edi |= 31 << pedi;
                    if ((ptrOut + DM_TEXT) - (pedi / 8) > dataLength) {
                        break;
                    }
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) (edi >> 16);
                    if (pedi <= 12) {
                        ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                        data[dataOffset + ptrOut2] = (byte) (edi >> 8);
                    } else {
                        ptrOut = ptrOut2;
                    }
                    if (pedi <= DM_EDIFACT) {
                        ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                        data[dataOffset + ptrOut] = (byte) edi;
                    } else {
                        ptrOut2 = ptrOut;
                    }
                    ascii = true;
                    pedi = 18;
                    edi = DM_NO_ERROR;
                    ptrOut = ptrOut2;
                }
                if (c > 127) {
                    if (ptrOut >= dataLength) {
                        break;
                    }
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) -21;
                    c -= 128;
                    ptrOut = ptrOut2;
                }
                if (ptrOut >= dataLength) {
                    break;
                }
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) (c + DM_ERROR_TEXT_TOO_BIG);
            } else {
                if (ascii) {
                    if (ptrOut + DM_ERROR_TEXT_TOO_BIG > dataLength) {
                        break;
                    }
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) -16;
                    ascii = false;
                    ptrOut = ptrOut2;
                }
                edi |= (c & 63) << pedi;
                if (pedi == 0) {
                    if (ptrOut + DM_TEXT > dataLength) {
                        break;
                    }
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) (edi >> 16);
                    ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut2] = (byte) (edi >> 8);
                    ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                    data[dataOffset + ptrOut] = (byte) edi;
                    edi = DM_NO_ERROR;
                    pedi = 18;
                } else {
                    pedi -= 6;
                    ptrOut2 = ptrOut;
                }
            }
            ptrIn += DM_ERROR_TEXT_TOO_BIG;
            ptrOut = ptrOut2;
        }
        if (ptrIn != textLength) {
            return -1;
        }
        int dataSize = Integer.MAX_VALUE;
        for (int i = DM_NO_ERROR; i < dmSizes.length; i += DM_ERROR_TEXT_TOO_BIG) {
            if (dmSizes[i].dataSize >= (dataOffset + ptrOut) + (3 - (pedi / DM_EDIFACT))) {
                dataSize = dmSizes[i].dataSize;
                break;
            }
        }
        if ((dataSize - dataOffset) - ptrOut <= DM_C40 && pedi >= DM_EDIFACT) {
            byte val;
            if (pedi <= 12) {
                val = (byte) ((edi >> 18) & 63);
                if ((val & DM_EXTENSION) == 0) {
                    val = (byte) (val | DM_TEST);
                }
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) (val + DM_ERROR_TEXT_TOO_BIG);
                ptrOut = ptrOut2;
            }
            if (pedi <= DM_EDIFACT) {
                val = (byte) ((edi >> 12) & 63);
                if ((val & DM_EXTENSION) == 0) {
                    val = (byte) (val | DM_TEST);
                }
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) (val + DM_ERROR_TEXT_TOO_BIG);
                return ptrOut2;
            }
        } else if (!ascii) {
            edi |= 31 << pedi;
            if ((ptrOut + DM_TEXT) - (pedi / 8) > dataLength) {
                return -1;
            }
            ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
            data[dataOffset + ptrOut] = (byte) (edi >> 16);
            if (pedi <= 12) {
                ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut2] = (byte) (edi >> 8);
            } else {
                ptrOut = ptrOut2;
            }
            if (pedi <= DM_EDIFACT) {
                ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                data[dataOffset + ptrOut] = (byte) edi;
                return ptrOut2;
            }
        }
        return ptrOut;
    }

    private static int C40OrTextEncodation(byte[] text, int textOffset, int textLength, byte[] data, int dataOffset, int dataLength, boolean c40) {
        if (textLength == 0) {
            return DM_NO_ERROR;
        }
        int ptrOut;
        int ptrOut2;
        String basic;
        String shift3;
        if (c40) {
            ptrOut = DM_NO_ERROR + DM_ERROR_TEXT_TOO_BIG;
            data[dataOffset + DM_NO_ERROR] = (byte) -26;
            ptrOut2 = ptrOut;
        } else {
            ptrOut = DM_NO_ERROR + DM_ERROR_TEXT_TOO_BIG;
            data[dataOffset + DM_NO_ERROR] = (byte) -17;
            ptrOut2 = ptrOut;
        }
        String shift2 = "!\"#$%&'()*+,-./:;<=>?@[\\]^_";
        if (c40) {
            basic = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            shift3 = "`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        } else {
            basic = " 0123456789abcdefghijklmnopqrstuvwxyz";
            shift3 = "`ABCDEFGHIJKLMNOPQRSTUVWXYZ{|}~\u007f";
        }
        int[] enc = new int[((textLength * DM_B256) + 10)];
        int last0 = DM_NO_ERROR;
        int last1 = DM_NO_ERROR;
        int encPtr = DM_NO_ERROR;
        int ptrIn = DM_NO_ERROR;
        while (ptrIn < textLength) {
            int i;
            if (encPtr % DM_TEXT == 0) {
                last0 = ptrIn;
                last1 = encPtr;
            }
            int ptrIn2 = ptrIn + DM_ERROR_TEXT_TOO_BIG;
            int c = text[textOffset + ptrIn] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            if (c > 127) {
                c -= 128;
                i = encPtr + DM_ERROR_TEXT_TOO_BIG;
                enc[encPtr] = DM_ERROR_TEXT_TOO_BIG;
                encPtr = i + DM_ERROR_TEXT_TOO_BIG;
                enc[i] = 30;
            }
            i = encPtr;
            int idx = basic.indexOf((char) c);
            if (idx >= 0) {
                encPtr = i + DM_ERROR_TEXT_TOO_BIG;
                enc[i] = idx + DM_TEXT;
                i = encPtr;
            } else if (c < DM_EXTENSION) {
                encPtr = i + DM_ERROR_TEXT_TOO_BIG;
                enc[i] = DM_NO_ERROR;
                i = encPtr + DM_ERROR_TEXT_TOO_BIG;
                enc[encPtr] = c;
            } else {
                idx = shift2.indexOf((char) c);
                if (idx >= 0) {
                    encPtr = i + DM_ERROR_TEXT_TOO_BIG;
                    enc[i] = DM_ERROR_TEXT_TOO_BIG;
                    i = encPtr + DM_ERROR_TEXT_TOO_BIG;
                    enc[encPtr] = idx;
                } else {
                    idx = shift3.indexOf((char) c);
                    if (idx >= 0) {
                        encPtr = i + DM_ERROR_TEXT_TOO_BIG;
                        enc[i] = DM_C40;
                        i = encPtr + DM_ERROR_TEXT_TOO_BIG;
                        enc[encPtr] = idx;
                    }
                }
            }
            encPtr = i;
            ptrIn = ptrIn2;
        }
        if (encPtr % DM_TEXT != 0) {
            ptrIn2 = last0;
            i = last1;
        } else {
            i = encPtr;
            ptrIn2 = ptrIn;
        }
        if ((i / DM_TEXT) * DM_C40 > dataLength - 2) {
            return -1;
        }
        int i2;
        ptrOut = ptrOut2;
        for (i2 = DM_NO_ERROR; i2 < i; i2 += DM_TEXT) {
            int a = (((enc[i2] * 1600) + (enc[i2 + DM_ERROR_TEXT_TOO_BIG] * 40)) + enc[i2 + DM_C40]) + DM_ERROR_TEXT_TOO_BIG;
            ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
            data[dataOffset + ptrOut] = (byte) (a / PdfWriter.PageModeUseThumbs);
            ptrOut = ptrOut2 + DM_ERROR_TEXT_TOO_BIG;
            data[dataOffset + ptrOut2] = (byte) a;
        }
        ptrOut2 = ptrOut + DM_ERROR_TEXT_TOO_BIG;
        data[ptrOut] = (byte) -2;
        i2 = asciiEncodation(text, ptrIn2, textLength - ptrIn2, data, ptrOut2, dataLength - ptrOut2);
        return i2 >= 0 ? i2 + ptrOut2 : i2;
    }

    private static int getEncodation(byte[] text, int textOffset, int textSize, byte[] data, int dataOffset, int dataSize, int options, boolean firstMatch) {
        int[] e1 = new int[DM_EDIFACT];
        if (dataSize < 0) {
            return -1;
        }
        options &= DM_RAW;
        if (options == 0) {
            e1[DM_NO_ERROR] = asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
            if (firstMatch && e1[DM_NO_ERROR] >= 0) {
                return e1[DM_NO_ERROR];
            }
            e1[DM_ERROR_TEXT_TOO_BIG] = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
            if (firstMatch && e1[DM_ERROR_TEXT_TOO_BIG] >= 0) {
                return e1[DM_ERROR_TEXT_TOO_BIG];
            }
            e1[DM_C40] = C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
            if (firstMatch && e1[DM_C40] >= 0) {
                return e1[DM_C40];
            }
            e1[DM_TEXT] = b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            if (firstMatch && e1[DM_TEXT] >= 0) {
                return e1[DM_TEXT];
            }
            e1[DM_B256] = X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            if (firstMatch && e1[DM_B256] >= 0) {
                return e1[DM_B256];
            }
            e1[DM_X21] = EdifactEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
            if (firstMatch && e1[DM_X21] >= 0) {
                return e1[DM_X21];
            }
            if (e1[DM_NO_ERROR] < 0 && e1[DM_ERROR_TEXT_TOO_BIG] < 0 && e1[DM_C40] < 0 && e1[DM_TEXT] < 0 && e1[DM_B256] < 0 && e1[DM_X21] < 0) {
                return -1;
            }
            int j = DM_NO_ERROR;
            int e = 99999;
            int k = DM_NO_ERROR;
            while (k < DM_EDIFACT) {
                if (e1[k] >= 0 && e1[k] < e) {
                    e = e1[k];
                    j = k;
                }
                k += DM_ERROR_TEXT_TOO_BIG;
            }
            if (j == 0) {
                return asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
            }
            if (j == DM_ERROR_TEXT_TOO_BIG) {
                return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
            }
            if (j == DM_C40) {
                return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
            }
            if (j == DM_TEXT) {
                return b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            }
            if (j == DM_B256) {
                return X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            }
            return e;
        }
        switch (options) {
            case DM_ERROR_TEXT_TOO_BIG /*1*/:
                return asciiEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
            case DM_C40 /*2*/:
                return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, true);
            case DM_TEXT /*3*/:
                return C40OrTextEncodation(text, textOffset, textSize, data, dataOffset, dataSize, false);
            case DM_B256 /*4*/:
                return b256Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            case DM_X21 /*5*/:
                return X12Encodation(text, textOffset, textSize, data, dataOffset, dataSize);
            case DM_EDIFACT /*6*/:
                return EdifactEncodation(text, textOffset, textSize, data, dataOffset, dataSize);
            case DM_RAW /*7*/:
                if (textSize > dataSize) {
                    return -1;
                }
                System.arraycopy(text, textOffset, data, dataOffset, textSize);
                return textSize;
            default:
                return -1;
        }
    }

    private static int getNumber(byte[] text, int ptrIn, int n) {
        int v = DM_NO_ERROR;
        int j = DM_NO_ERROR;
        int ptrIn2 = ptrIn;
        while (j < n) {
            ptrIn = ptrIn2 + DM_ERROR_TEXT_TOO_BIG;
            int c = text[ptrIn2] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            if (c < 48 || c > 57) {
                return -1;
            }
            v = ((v * 10) + c) - 48;
            j += DM_ERROR_TEXT_TOO_BIG;
            ptrIn2 = ptrIn;
        }
        ptrIn = ptrIn2;
        return v;
    }

    private int processExtensions(byte[] text, int textOffset, int textSize, byte[] data) {
        if ((this.options & DM_EXTENSION) == 0) {
            return DM_NO_ERROR;
        }
        int order = DM_NO_ERROR;
        int ptrOut = DM_NO_ERROR;
        int ptrIn = DM_NO_ERROR;
        while (ptrIn < textSize) {
            if (order > 20) {
                return -1;
            }
            int i;
            int ptrIn2 = ptrIn + DM_ERROR_TEXT_TOO_BIG;
            order += DM_ERROR_TEXT_TOO_BIG;
            switch (text[textOffset + ptrIn] & TIFFConstants.TIFFTAG_OSUBFILETYPE) {
                case 46:
                    this.extOut = ptrIn2;
                    return ptrOut;
                case XMPError.BADSCHEMA /*101*/:
                    if (ptrIn2 + DM_EDIFACT <= textSize) {
                        int eci = getNumber(text, textOffset + ptrIn2, DM_EDIFACT);
                        if (eci >= 0) {
                            ptrIn2 += DM_EDIFACT;
                            i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                            data[ptrOut] = (byte) -15;
                            if (eci >= 127) {
                                if (eci >= 16383) {
                                    ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                                    data[i] = (byte) (((eci - 16383) / 64516) + 192);
                                    i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                                    data[ptrOut] = (byte) ((((eci - 16383) / TIFFConstants.TIFFTAG_SUBFILETYPE) % TIFFConstants.TIFFTAG_SUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
                                    ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                                    data[i] = (byte) (((eci - 16383) % TIFFConstants.TIFFTAG_SUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
                                    i = ptrOut;
                                    break;
                                }
                                ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                                data[i] = (byte) (((eci - 127) / TIFFConstants.TIFFTAG_SUBFILETYPE) + PdfWriter.PageModeUseOutlines);
                                i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                                data[ptrOut] = (byte) (((eci - 127) % TIFFConstants.TIFFTAG_SUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
                                break;
                            }
                            ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                            data[i] = (byte) (eci + DM_ERROR_TEXT_TOO_BIG);
                            i = ptrOut;
                            break;
                        }
                        return -1;
                    }
                    return -1;
                case XMPError.BADXPATH /*102*/:
                    if (order == DM_ERROR_TEXT_TOO_BIG || (order == DM_C40 && (text[textOffset] == 115 || text[textOffset] == 109))) {
                        i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                        data[ptrOut] = (byte) -24;
                        break;
                    }
                    return -1;
                case 109:
                    if (order != DM_ERROR_TEXT_TOO_BIG) {
                        return -1;
                    }
                    if (ptrIn2 + DM_ERROR_TEXT_TOO_BIG > textSize) {
                        return -1;
                    }
                    ptrIn = ptrIn2 + DM_ERROR_TEXT_TOO_BIG;
                    int c = text[textOffset + ptrIn2] & TIFFConstants.TIFFTAG_OSUBFILETYPE;
                    if (c == 53 || c == 53) {
                        i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                        data[ptrOut] = (byte) -22;
                        ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                        data[i] = (byte) (c == 53 ? 236 : Jpeg.M_APPD);
                        i = ptrOut;
                        ptrIn2 = ptrIn;
                        break;
                    }
                    return -1;
                    break;
                case 112:
                    if (order == DM_ERROR_TEXT_TOO_BIG) {
                        i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                        data[ptrOut] = (byte) -22;
                        break;
                    }
                    return -1;
                case 115:
                    if (order == DM_ERROR_TEXT_TOO_BIG) {
                        if (ptrIn2 + 9 <= textSize) {
                            int fn = getNumber(text, textOffset + ptrIn2, DM_C40);
                            if (fn > 0 && fn <= 16) {
                                ptrIn2 += DM_C40;
                                int ft = getNumber(text, textOffset + ptrIn2, DM_C40);
                                if (ft > DM_ERROR_TEXT_TOO_BIG && ft <= 16) {
                                    ptrIn2 += DM_C40;
                                    int fi = getNumber(text, textOffset + ptrIn2, DM_X21);
                                    if (fi >= 0 && fn < 64516) {
                                        ptrIn2 += DM_X21;
                                        i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                                        data[ptrOut] = (byte) -23;
                                        ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                                        data[i] = (byte) (((fn - 1) << DM_B256) | (17 - ft));
                                        i = ptrOut + DM_ERROR_TEXT_TOO_BIG;
                                        data[ptrOut] = (byte) ((fi / TIFFConstants.TIFFTAG_SUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
                                        ptrOut = i + DM_ERROR_TEXT_TOO_BIG;
                                        data[i] = (byte) ((fi % TIFFConstants.TIFFTAG_SUBFILETYPE) + DM_ERROR_TEXT_TOO_BIG);
                                        i = ptrOut;
                                        break;
                                    }
                                    return -1;
                                }
                                return -1;
                            }
                            return -1;
                        }
                        return -1;
                    }
                    return -1;
                default:
                    i = ptrOut;
                    break;
            }
            ptrOut = i;
            ptrIn = ptrIn2;
        }
        return -1;
    }

    public int generate(String text) throws UnsupportedEncodingException {
        byte[] t = text.getBytes("iso-8859-1");
        return generate(t, DM_NO_ERROR, t.length);
    }

    public int generate(byte[] text, int textOffset, int textSize) {
        byte[] data = new byte[2500];
        this.extOut = DM_NO_ERROR;
        int extCount = processExtensions(text, textOffset, textSize, data);
        if (extCount < 0) {
            return DM_X21;
        }
        int e;
        DmParams dm;
        int k;
        if (this.height == 0 || this.width == 0) {
            byte[] bArr = text;
            e = getEncodation(bArr, textOffset + this.extOut, textSize - this.extOut, data, extCount, dmSizes[dmSizes.length - 1].dataSize - extCount, this.options, false);
            if (e < 0) {
                return DM_ERROR_TEXT_TOO_BIG;
            }
            e += extCount;
            k = DM_NO_ERROR;
            while (k < dmSizes.length && dmSizes[k].dataSize < e) {
                k += DM_ERROR_TEXT_TOO_BIG;
            }
            dm = dmSizes[k];
            this.height = dm.height;
            this.width = dm.width;
        } else {
            k = DM_NO_ERROR;
            while (k < dmSizes.length && (this.height != dmSizes[k].height || this.width != dmSizes[k].width)) {
                k += DM_ERROR_TEXT_TOO_BIG;
            }
            if (k == dmSizes.length) {
                return DM_TEXT;
            }
            dm = dmSizes[k];
            e = getEncodation(text, textOffset + this.extOut, textSize - this.extOut, data, extCount, dm.dataSize - extCount, this.options, true);
            if (e < 0) {
                return DM_ERROR_TEXT_TOO_BIG;
            }
            e += extCount;
        }
        if ((this.options & DM_TEST) != 0) {
            return DM_NO_ERROR;
        }
        this.image = new byte[((((dm.width + (this.ws * DM_C40)) + DM_RAW) / 8) * (dm.height + (this.ws * DM_C40)))];
        makePadding(data, e, dm.dataSize - e);
        this.place = Placement.doPlacement(dm.height - ((dm.height / dm.heightSection) * DM_C40), dm.width - ((dm.width / dm.widthSection) * DM_C40));
        int full = dm.dataSize + (((dm.dataSize + DM_C40) / dm.dataBlock) * dm.errorBlock);
        ReedSolomon.generateECC(data, dm.dataSize, dm.dataBlock, dm.errorBlock);
        draw(data, full, dm);
        return DM_NO_ERROR;
    }

    public Image createImage() throws BadElementException {
        if (this.image == null) {
            return null;
        }
        return Image.getInstance(this.width + (this.ws * DM_C40), this.height + (this.ws * DM_C40), false, PdfWriter.PageModeUseThumbs, DM_NO_ERROR, CCITTG4Encoder.compress(this.image, this.width + (this.ws * DM_C40), this.height + (this.ws * DM_C40)), null);
    }

    public byte[] getImage() {
        return this.image;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getWs() {
        return this.ws;
    }

    public void setWs(int ws) {
        this.ws = ws;
    }

    public int getOptions() {
        return this.options;
    }

    public void setOptions(int options) {
        this.options = options;
    }
}

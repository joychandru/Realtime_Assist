package com.itextpdf.text.pdf;

import com.itextpdf.text.pdf.codec.TIFFConstants;

public class PdfTransition {
    public static final int BLINDH = 6;
    public static final int BLINDV = 5;
    public static final int BTWIPE = 11;
    public static final int DGLITTER = 16;
    public static final int DISSOLVE = 13;
    public static final int INBOX = 7;
    public static final int LRGLITTER = 14;
    public static final int LRWIPE = 9;
    public static final int OUTBOX = 8;
    public static final int RLWIPE = 10;
    public static final int SPLITHIN = 4;
    public static final int SPLITHOUT = 2;
    public static final int SPLITVIN = 3;
    public static final int SPLITVOUT = 1;
    public static final int TBGLITTER = 15;
    public static final int TBWIPE = 12;
    protected int duration;
    protected int type;

    public PdfTransition() {
        this(BLINDH);
    }

    public PdfTransition(int type) {
        this(type, SPLITVOUT);
    }

    public PdfTransition(int type, int duration) {
        this.duration = duration;
        this.type = type;
    }

    public int getDuration() {
        return this.duration;
    }

    public int getType() {
        return this.type;
    }

    public PdfDictionary getTransitionDictionary() {
        PdfDictionary trans = new PdfDictionary(PdfName.TRANS);
        switch (this.type) {
            case SPLITVOUT /*1*/:
                trans.put(PdfName.f78S, PdfName.SPLIT);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f81V);
                trans.put(PdfName.f72M, PdfName.f74O);
                break;
            case SPLITHOUT /*2*/:
                trans.put(PdfName.f78S, PdfName.SPLIT);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f68H);
                trans.put(PdfName.f72M, PdfName.f74O);
                break;
            case SPLITVIN /*3*/:
                trans.put(PdfName.f78S, PdfName.SPLIT);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f81V);
                trans.put(PdfName.f72M, PdfName.f69I);
                break;
            case SPLITHIN /*4*/:
                trans.put(PdfName.f78S, PdfName.SPLIT);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f68H);
                trans.put(PdfName.f72M, PdfName.f69I);
                break;
            case BLINDV /*5*/:
                trans.put(PdfName.f78S, PdfName.BLINDS);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f81V);
                break;
            case BLINDH /*6*/:
                trans.put(PdfName.f78S, PdfName.BLINDS);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DM, PdfName.f68H);
                break;
            case INBOX /*7*/:
                trans.put(PdfName.f78S, PdfName.BOX);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.f72M, PdfName.f69I);
                break;
            case OUTBOX /*8*/:
                trans.put(PdfName.f78S, PdfName.BOX);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.f72M, PdfName.f74O);
                break;
            case LRWIPE /*9*/:
                trans.put(PdfName.f78S, PdfName.WIPE);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber(0));
                break;
            case RLWIPE /*10*/:
                trans.put(PdfName.f78S, PdfName.WIPE);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber(180));
                break;
            case BTWIPE /*11*/:
                trans.put(PdfName.f78S, PdfName.WIPE);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber(90));
                break;
            case TBWIPE /*12*/:
                trans.put(PdfName.f78S, PdfName.WIPE);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber((int) TIFFConstants.TIFFTAG_IMAGEDESCRIPTION));
                break;
            case DISSOLVE /*13*/:
                trans.put(PdfName.f78S, PdfName.DISSOLVE);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                break;
            case LRGLITTER /*14*/:
                trans.put(PdfName.f78S, PdfName.GLITTER);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber(0));
                break;
            case TBGLITTER /*15*/:
                trans.put(PdfName.f78S, PdfName.GLITTER);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber((int) TIFFConstants.TIFFTAG_IMAGEDESCRIPTION));
                break;
            case DGLITTER /*16*/:
                trans.put(PdfName.f78S, PdfName.GLITTER);
                trans.put(PdfName.f65D, new PdfNumber(this.duration));
                trans.put(PdfName.DI, new PdfNumber((int) TIFFConstants.TIFFTAG_ARTIST));
                break;
        }
        return trans;
    }
}

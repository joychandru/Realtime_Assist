package com.itextpdf.text.pdf;

import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.PRTokeniser.TokenType;
import java.io.IOException;
import java.util.ArrayList;

public class PdfContentParser {
    public static final int COMMAND_TYPE = 200;
    private PRTokeniser tokeniser;

    /* renamed from: com.itextpdf.text.pdf.PdfContentParser.1 */
    static /* synthetic */ class C00371 {
        static final /* synthetic */ int[] $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType;

        static {
            $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType = new int[TokenType.values().length];
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.START_DIC.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.START_ARRAY.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.STRING.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.NAME.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.NUMBER.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[TokenType.OTHER.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
        }
    }

    public PdfContentParser(PRTokeniser tokeniser) {
        this.tokeniser = tokeniser;
    }

    public ArrayList<PdfObject> parse(ArrayList<PdfObject> ls) throws IOException {
        if (ls == null) {
            ls = new ArrayList();
        } else {
            ls.clear();
        }
        PdfObject ob;
        do {
            ob = readPRObject();
            if (ob == null) {
                break;
            }
            ls.add(ob);
        } while (ob.type() != COMMAND_TYPE);
        return ls;
    }

    public PRTokeniser getTokeniser() {
        return this.tokeniser;
    }

    public void setTokeniser(PRTokeniser tokeniser) {
        this.tokeniser = tokeniser;
    }

    public PdfDictionary readDictionary() throws IOException {
        PdfDictionary dic = new PdfDictionary();
        while (nextValidToken()) {
            if (this.tokeniser.getTokenType() == TokenType.END_DIC) {
                return dic;
            }
            if (this.tokeniser.getTokenType() != TokenType.OTHER || !"def".equals(this.tokeniser.getStringValue())) {
                if (this.tokeniser.getTokenType() != TokenType.NAME) {
                    throw new IOException(MessageLocalization.getComposedMessage("dictionary.key.1.is.not.a.name", this.tokeniser.getStringValue()));
                }
                PdfName name = new PdfName(this.tokeniser.getStringValue(), false);
                PdfObject obj = readPRObject();
                int type = obj.type();
                if ((-type) == TokenType.END_DIC.ordinal()) {
                    throw new IOException(MessageLocalization.getComposedMessage("unexpected.gt.gt", new Object[0]));
                } else if ((-type) == TokenType.END_ARRAY.ordinal()) {
                    throw new IOException(MessageLocalization.getComposedMessage("unexpected.close.bracket", new Object[0]));
                } else {
                    dic.put(name, obj);
                }
            }
        }
        throw new IOException(MessageLocalization.getComposedMessage("unexpected.end.of.file", new Object[0]));
    }

    public PdfArray readArray() throws IOException {
        PdfArray array = new PdfArray();
        while (true) {
            PdfObject obj = readPRObject();
            int type = obj.type();
            if ((-type) == TokenType.END_ARRAY.ordinal()) {
                return array;
            }
            if ((-type) == TokenType.END_DIC.ordinal()) {
                break;
            }
            array.add(obj);
        }
        throw new IOException(MessageLocalization.getComposedMessage("unexpected.gt.gt", new Object[0]));
    }

    public PdfObject readPRObject() throws IOException {
        if (!nextValidToken()) {
            return null;
        }
        TokenType type = this.tokeniser.getTokenType();
        switch (C00371.$SwitchMap$com$itextpdf$text$pdf$PRTokeniser$TokenType[type.ordinal()]) {
            case PdfWriter.markInlineElementsOnly /*1*/:
                return readDictionary();
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
                return readArray();
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                return new PdfString(this.tokeniser.getStringValue(), null).setHexWriting(this.tokeniser.isHexString());
            case PdfWriter.PageLayoutTwoColumnLeft /*4*/:
                return new PdfName(this.tokeniser.getStringValue(), false);
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                return new PdfNumber(this.tokeniser.getStringValue());
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                return new PdfLiteral((int) COMMAND_TYPE, this.tokeniser.getStringValue());
            default:
                return new PdfLiteral(-type.ordinal(), this.tokeniser.getStringValue());
        }
    }

    public boolean nextValidToken() throws IOException {
        while (this.tokeniser.nextToken()) {
            if (this.tokeniser.getTokenType() != TokenType.COMMENT) {
                return true;
            }
        }
        return false;
    }
}

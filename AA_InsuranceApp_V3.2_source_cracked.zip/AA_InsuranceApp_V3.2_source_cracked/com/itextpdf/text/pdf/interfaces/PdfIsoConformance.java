package com.itextpdf.text.pdf.interfaces;

public interface PdfIsoConformance {
    void checkPdfIsoConformance(int i, Object obj);

    boolean isPdfIso();
}

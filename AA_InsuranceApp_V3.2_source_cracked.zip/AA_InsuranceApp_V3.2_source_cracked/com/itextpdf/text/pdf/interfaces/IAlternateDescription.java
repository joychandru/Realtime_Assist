package com.itextpdf.text.pdf.interfaces;

public interface IAlternateDescription {
    String getAlt();

    void setAlt(String str);
}

package com.itextpdf.text.pdf.interfaces;

public interface PdfRunDirection {
    int getRunDirection();

    void setRunDirection(int i);
}

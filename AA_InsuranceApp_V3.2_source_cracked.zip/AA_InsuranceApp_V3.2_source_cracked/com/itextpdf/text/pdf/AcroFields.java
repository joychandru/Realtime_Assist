package com.itextpdf.text.pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.text.io.RASInputStream;
import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.io.WindowRandomAccessSource;
import com.itextpdf.text.pdf.PRTokeniser.TokenType;
import com.itextpdf.text.pdf.XfaForm.Xml2Som;
import com.itextpdf.text.pdf.XfaForm.Xml2SomDatasets;
import com.itextpdf.text.pdf.codec.Base64;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.text.pdf.security.PdfPKCS7;
import com.itextpdf.text.xml.XmlToTxt;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.w3c.dom.Node;

public class AcroFields {
    public static final int DA_COLOR = 2;
    public static final int DA_FONT = 0;
    public static final int DA_SIZE = 1;
    public static final int FIELD_TYPE_CHECKBOX = 2;
    public static final int FIELD_TYPE_COMBO = 6;
    public static final int FIELD_TYPE_LIST = 5;
    public static final int FIELD_TYPE_NONE = 0;
    public static final int FIELD_TYPE_PUSHBUTTON = 1;
    public static final int FIELD_TYPE_RADIOBUTTON = 3;
    public static final int FIELD_TYPE_SIGNATURE = 7;
    public static final int FIELD_TYPE_TEXT = 4;
    private static final PdfName[] buttonRemove;
    private static final HashMap<String, String[]> stdFieldFontNames;
    private boolean append;
    private HashMap<Integer, BaseFont> extensionFonts;
    private float extraMarginLeft;
    private float extraMarginTop;
    private Map<String, TextField> fieldCache;
    Map<String, Item> fields;
    private boolean generateAppearances;
    private boolean lastWasString;
    private HashMap<String, BaseFont> localFonts;
    private ArrayList<String> orderedSignatureNames;
    PdfReader reader;
    private HashMap<String, int[]> sigNames;
    private ArrayList<BaseFont> substitutionFonts;
    private int topFirst;
    private int totalRevisions;
    PdfWriter writer;
    private XfaForm xfa;

    public static class FieldPosition {
        public int page;
        public Rectangle position;
    }

    private static class InstHit {
        IntHashtable hits;

        public InstHit(int[] inst) {
            if (inst != null) {
                this.hits = new IntHashtable();
                for (int k = AcroFields.FIELD_TYPE_NONE; k < inst.length; k += AcroFields.FIELD_TYPE_PUSHBUTTON) {
                    this.hits.put(inst[k], AcroFields.FIELD_TYPE_PUSHBUTTON);
                }
            }
        }

        public boolean isHit(int n) {
            if (this.hits == null) {
                return true;
            }
            return this.hits.containsKey(n);
        }
    }

    public static class Item {
        public static final int WRITE_MERGED = 1;
        public static final int WRITE_VALUE = 4;
        public static final int WRITE_WIDGET = 2;
        protected ArrayList<PdfDictionary> merged;
        protected ArrayList<Integer> page;
        protected ArrayList<Integer> tabOrder;
        protected ArrayList<PdfDictionary> values;
        protected ArrayList<PdfIndirectReference> widget_refs;
        protected ArrayList<PdfDictionary> widgets;

        public Item() {
            this.values = new ArrayList();
            this.widgets = new ArrayList();
            this.widget_refs = new ArrayList();
            this.merged = new ArrayList();
            this.page = new ArrayList();
            this.tabOrder = new ArrayList();
        }

        public void writeToAll(PdfName key, PdfObject value, int writeFlags) {
            int i;
            if ((writeFlags & WRITE_MERGED) != 0) {
                for (i = AcroFields.FIELD_TYPE_NONE; i < this.merged.size(); i += WRITE_MERGED) {
                    getMerged(i).put(key, value);
                }
            }
            if ((writeFlags & WRITE_WIDGET) != 0) {
                for (i = AcroFields.FIELD_TYPE_NONE; i < this.widgets.size(); i += WRITE_MERGED) {
                    getWidget(i).put(key, value);
                }
            }
            if ((writeFlags & WRITE_VALUE) != 0) {
                for (i = AcroFields.FIELD_TYPE_NONE; i < this.values.size(); i += WRITE_MERGED) {
                    getValue(i).put(key, value);
                }
            }
        }

        public void markUsed(AcroFields parentFields, int writeFlags) {
            int i;
            if ((writeFlags & WRITE_VALUE) != 0) {
                for (i = AcroFields.FIELD_TYPE_NONE; i < size(); i += WRITE_MERGED) {
                    parentFields.markUsed(getValue(i));
                }
            }
            if ((writeFlags & WRITE_WIDGET) != 0) {
                for (i = AcroFields.FIELD_TYPE_NONE; i < size(); i += WRITE_MERGED) {
                    parentFields.markUsed(getWidget(i));
                }
            }
        }

        public int size() {
            return this.values.size();
        }

        void remove(int killIdx) {
            this.values.remove(killIdx);
            this.widgets.remove(killIdx);
            this.widget_refs.remove(killIdx);
            this.merged.remove(killIdx);
            this.page.remove(killIdx);
            this.tabOrder.remove(killIdx);
        }

        public PdfDictionary getValue(int idx) {
            return (PdfDictionary) this.values.get(idx);
        }

        void addValue(PdfDictionary value) {
            this.values.add(value);
        }

        public PdfDictionary getWidget(int idx) {
            return (PdfDictionary) this.widgets.get(idx);
        }

        void addWidget(PdfDictionary widget) {
            this.widgets.add(widget);
        }

        public PdfIndirectReference getWidgetRef(int idx) {
            return (PdfIndirectReference) this.widget_refs.get(idx);
        }

        void addWidgetRef(PdfIndirectReference widgRef) {
            this.widget_refs.add(widgRef);
        }

        public PdfDictionary getMerged(int idx) {
            return (PdfDictionary) this.merged.get(idx);
        }

        void addMerged(PdfDictionary mergeDict) {
            this.merged.add(mergeDict);
        }

        public Integer getPage(int idx) {
            return (Integer) this.page.get(idx);
        }

        void addPage(int pg) {
            this.page.add(Integer.valueOf(pg));
        }

        void forcePage(int idx, int pg) {
            this.page.set(idx, Integer.valueOf(pg));
        }

        public Integer getTabOrder(int idx) {
            return (Integer) this.tabOrder.get(idx);
        }

        void addTabOrder(int order) {
            this.tabOrder.add(Integer.valueOf(order));
        }
    }

    private static class SorterComparator implements Comparator<Object[]> {
        private SorterComparator() {
        }

        public int compare(Object[] o1, Object[] o2) {
            return ((int[]) o1[AcroFields.FIELD_TYPE_PUSHBUTTON])[AcroFields.FIELD_TYPE_NONE] - ((int[]) o2[AcroFields.FIELD_TYPE_PUSHBUTTON])[AcroFields.FIELD_TYPE_NONE];
        }
    }

    AcroFields(PdfReader reader, PdfWriter writer) {
        this.extensionFonts = new HashMap();
        this.generateAppearances = true;
        this.localFonts = new HashMap();
        this.reader = reader;
        this.writer = writer;
        try {
            this.xfa = new XfaForm(reader);
            if (writer instanceof PdfStamperImp) {
                this.append = ((PdfStamperImp) writer).isAppend();
            }
            fill();
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    void fill() {
        this.fields = new HashMap();
        PdfDictionary top = (PdfDictionary) PdfReader.getPdfObjectRelease(this.reader.getCatalog().get(PdfName.ACROFORM));
        if (top != null) {
            PdfBoolean needappearances = top.getAsBoolean(PdfName.NEEDAPPEARANCES);
            if (needappearances == null || !needappearances.booleanValue()) {
                setGenerateAppearances(true);
            } else {
                setGenerateAppearances(false);
            }
            PdfArray arrfds = (PdfArray) PdfReader.getPdfObjectRelease(top.get(PdfName.FIELDS));
            if (arrfds != null && arrfds.size() != 0) {
                int j;
                PdfDictionary annot;
                PdfDictionary dic;
                String name;
                PdfString t;
                Item item;
                int k = FIELD_TYPE_PUSHBUTTON;
                while (true) {
                    if (k > this.reader.getNumberOfPages()) {
                        break;
                    }
                    PdfDictionary page = this.reader.getPageNRelease(k);
                    PdfArray annots = (PdfArray) PdfReader.getPdfObjectRelease(page.get(PdfName.ANNOTS), page);
                    if (annots != null) {
                        for (j = FIELD_TYPE_NONE; j < annots.size(); j += FIELD_TYPE_PUSHBUTTON) {
                            annot = annots.getAsDict(j);
                            if (annot == null) {
                                PdfReader.releaseLastXrefPartial(annots.getAsIndirectObject(j));
                            } else {
                                if (PdfName.WIDGET.equals(annot.getAsName(PdfName.SUBTYPE))) {
                                    PdfDictionary widget = annot;
                                    dic = new PdfDictionary();
                                    dic.putAll(annot);
                                    name = PdfObject.NOTHING;
                                    PdfDictionary value = null;
                                    PdfObject lastV = null;
                                    while (annot != null) {
                                        dic.mergeDifferent(annot);
                                        t = annot.getAsString(PdfName.f79T);
                                        if (t != null) {
                                            name = t.toUnicodeString() + "." + name;
                                        }
                                        if (lastV == null) {
                                            if (annot.get(PdfName.f81V) != null) {
                                                lastV = PdfReader.getPdfObjectRelease(annot.get(PdfName.f81V));
                                            }
                                        }
                                        if (value == null && t != null) {
                                            value = annot;
                                            if (annot.get(PdfName.f81V) == null && lastV != null) {
                                                value.put(PdfName.f81V, lastV);
                                            }
                                        }
                                        annot = annot.getAsDict(PdfName.PARENT);
                                    }
                                    if (name.length() > 0) {
                                        name = name.substring(FIELD_TYPE_NONE, name.length() - 1);
                                    }
                                    item = (Item) this.fields.get(name);
                                    if (item == null) {
                                        item = new Item();
                                        this.fields.put(name, item);
                                    }
                                    if (value == null) {
                                        item.addValue(widget);
                                    } else {
                                        item.addValue(value);
                                    }
                                    item.addWidget(widget);
                                    item.addWidgetRef(annots.getAsIndirectObject(j));
                                    if (top != null) {
                                        dic.mergeDifferent(top);
                                    }
                                    item.addMerged(dic);
                                    item.addPage(k);
                                    item.addTabOrder(j);
                                } else {
                                    PdfReader.releaseLastXrefPartial(annots.getAsIndirectObject(j));
                                }
                            }
                        }
                    }
                    k += FIELD_TYPE_PUSHBUTTON;
                }
                PdfNumber sigFlags = top.getAsNumber(PdfName.SIGFLAGS);
                if (sigFlags != null && (sigFlags.intValue() & FIELD_TYPE_PUSHBUTTON) == FIELD_TYPE_PUSHBUTTON) {
                    for (j = FIELD_TYPE_NONE; j < arrfds.size(); j += FIELD_TYPE_PUSHBUTTON) {
                        annot = arrfds.getAsDict(j);
                        if (annot == null) {
                            PdfReader.releaseLastXrefPartial(arrfds.getAsIndirectObject(j));
                        } else {
                            if (PdfName.WIDGET.equals(annot.getAsName(PdfName.SUBTYPE))) {
                                if (((PdfArray) PdfReader.getPdfObjectRelease(annot.get(PdfName.KIDS))) == null) {
                                    dic = new PdfDictionary();
                                    dic.putAll(annot);
                                    t = annot.getAsString(PdfName.f79T);
                                    if (t != null) {
                                        name = t.toUnicodeString();
                                        if (!this.fields.containsKey(name)) {
                                            item = new Item();
                                            this.fields.put(name, item);
                                            item.addValue(dic);
                                            item.addWidget(dic);
                                            item.addWidgetRef(arrfds.getAsIndirectObject(j));
                                            item.addMerged(dic);
                                            item.addPage(-1);
                                            item.addTabOrder(-1);
                                        }
                                    }
                                }
                            } else {
                                PdfReader.releaseLastXrefPartial(arrfds.getAsIndirectObject(j));
                            }
                        }
                    }
                }
            }
        }
    }

    public String[] getAppearanceStates(String fieldName) {
        Item fd = (Item) this.fields.get(fieldName);
        if (fd == null) {
            return null;
        }
        int k;
        HashSet<String> names = new LinkedHashSet();
        PdfDictionary vals = fd.getValue(FIELD_TYPE_NONE);
        PdfString stringOpt = vals.getAsString(PdfName.OPT);
        if (stringOpt != null) {
            names.add(stringOpt.toUnicodeString());
        } else {
            PdfArray arrayOpt = vals.getAsArray(PdfName.OPT);
            if (arrayOpt != null) {
                for (k = FIELD_TYPE_NONE; k < arrayOpt.size(); k += FIELD_TYPE_PUSHBUTTON) {
                    PdfObject pdfObject = arrayOpt.getDirectObject(k);
                    PdfString valStr = null;
                    switch (pdfObject.type()) {
                        case FIELD_TYPE_RADIOBUTTON /*3*/:
                            valStr = (PdfString) pdfObject;
                            break;
                        case FIELD_TYPE_LIST /*5*/:
                            valStr = ((PdfArray) pdfObject).getAsString(FIELD_TYPE_PUSHBUTTON);
                            break;
                    }
                    if (valStr != null) {
                        names.add(valStr.toUnicodeString());
                    }
                }
            }
        }
        for (k = FIELD_TYPE_NONE; k < fd.size(); k += FIELD_TYPE_PUSHBUTTON) {
            PdfDictionary dic = fd.getWidget(k).getAsDict(PdfName.AP);
            if (dic != null) {
                dic = dic.getAsDict(PdfName.f73N);
                if (dic != null) {
                    for (PdfName element : dic.getKeys()) {
                        names.add(PdfName.decodeName(element.toString()));
                    }
                }
            }
        }
        return (String[]) names.toArray(new String[names.size()]);
    }

    private String[] getListOption(String fieldName, int idx) {
        String[] strArr = null;
        Item fd = getFieldItem(fieldName);
        if (fd != null) {
            PdfArray ar = fd.getMerged(FIELD_TYPE_NONE).getAsArray(PdfName.OPT);
            if (ar != null) {
                strArr = new String[ar.size()];
                for (int k = FIELD_TYPE_NONE; k < ar.size(); k += FIELD_TYPE_PUSHBUTTON) {
                    PdfObject obj = ar.getDirectObject(k);
                    try {
                        if (obj.isArray()) {
                            obj = ((PdfArray) obj).getDirectObject(idx);
                        }
                        if (obj.isString()) {
                            strArr[k] = ((PdfString) obj).toUnicodeString();
                        } else {
                            strArr[k] = obj.toString();
                        }
                    } catch (Exception e) {
                        strArr[k] = PdfObject.NOTHING;
                    }
                }
            }
        }
        return strArr;
    }

    public String[] getListOptionExport(String fieldName) {
        return getListOption(fieldName, FIELD_TYPE_NONE);
    }

    public String[] getListOptionDisplay(String fieldName) {
        return getListOption(fieldName, FIELD_TYPE_PUSHBUTTON);
    }

    public boolean setListOption(String fieldName, String[] exportValues, String[] displayValues) {
        if (exportValues == null && displayValues == null) {
            return false;
        }
        if (exportValues == null || displayValues == null || exportValues.length == displayValues.length) {
            int ftype = getFieldType(fieldName);
            if (ftype != FIELD_TYPE_COMBO && ftype != FIELD_TYPE_LIST) {
                return false;
            }
            Item fd = (Item) this.fields.get(fieldName);
            String[] sing = null;
            if (exportValues == null && displayValues != null) {
                sing = displayValues;
            } else if (exportValues != null && displayValues == null) {
                sing = exportValues;
            }
            PdfArray opt = new PdfArray();
            int k;
            if (sing != null) {
                for (k = FIELD_TYPE_NONE; k < sing.length; k += FIELD_TYPE_PUSHBUTTON) {
                    opt.add(new PdfString(sing[k], PdfObject.TEXT_UNICODE));
                }
            } else {
                for (k = FIELD_TYPE_NONE; k < exportValues.length; k += FIELD_TYPE_PUSHBUTTON) {
                    PdfObject a = new PdfArray();
                    a.add(new PdfString(exportValues[k], PdfObject.TEXT_UNICODE));
                    a.add(new PdfString(displayValues[k], PdfObject.TEXT_UNICODE));
                    opt.add(a);
                }
            }
            fd.writeToAll(PdfName.OPT, opt, FIELD_TYPE_LIST);
            return true;
        }
        throw new IllegalArgumentException(MessageLocalization.getComposedMessage("the.export.and.the.display.array.must.have.the.same.size", new Object[FIELD_TYPE_NONE]));
    }

    public int getFieldType(String fieldName) {
        Item fd = getFieldItem(fieldName);
        if (fd == null) {
            return FIELD_TYPE_NONE;
        }
        PdfDictionary merged = fd.getMerged(FIELD_TYPE_NONE);
        PdfName type = merged.getAsName(PdfName.FT);
        if (type == null) {
            return FIELD_TYPE_NONE;
        }
        int ff = FIELD_TYPE_NONE;
        PdfNumber ffo = merged.getAsNumber(PdfName.FF);
        if (ffo != null) {
            ff = ffo.intValue();
        }
        if (PdfName.BTN.equals(type)) {
            if ((PdfWriter.CenterWindow & ff) != 0) {
                return FIELD_TYPE_PUSHBUTTON;
            }
            if ((PdfWriter.FitWindow & ff) != 0) {
                return FIELD_TYPE_RADIOBUTTON;
            }
            return FIELD_TYPE_CHECKBOX;
        } else if (PdfName.TX.equals(type)) {
            return FIELD_TYPE_TEXT;
        } else {
            if (PdfName.CH.equals(type)) {
                if ((PdfWriter.DisplayDocTitle & ff) != 0) {
                    return FIELD_TYPE_COMBO;
                }
                return FIELD_TYPE_LIST;
            } else if (PdfName.SIG.equals(type)) {
                return FIELD_TYPE_SIGNATURE;
            } else {
                return FIELD_TYPE_NONE;
            }
        }
    }

    public void exportAsFdf(FdfWriter writer) {
        for (Entry<String, Item> entry : this.fields.entrySet()) {
            String name = (String) entry.getKey();
            if (((Item) entry.getValue()).getMerged(FIELD_TYPE_NONE).get(PdfName.f81V) != null) {
                String value = getField(name);
                if (this.lastWasString) {
                    writer.setFieldAsString(name, value);
                } else {
                    writer.setFieldAsName(name, value);
                }
            }
        }
    }

    public boolean renameField(String oldName, String newName) {
        int idx1 = oldName.lastIndexOf(46) + FIELD_TYPE_PUSHBUTTON;
        int idx2 = newName.lastIndexOf(46) + FIELD_TYPE_PUSHBUTTON;
        if (idx1 != idx2 || !oldName.substring(FIELD_TYPE_NONE, idx1).equals(newName.substring(FIELD_TYPE_NONE, idx2)) || this.fields.containsKey(newName)) {
            return false;
        }
        Item item = (Item) this.fields.get(oldName);
        if (item == null) {
            return false;
        }
        newName = newName.substring(idx2);
        item.writeToAll(PdfName.f79T, new PdfString(newName, PdfObject.TEXT_UNICODE), FIELD_TYPE_LIST);
        item.markUsed(this, FIELD_TYPE_TEXT);
        this.fields.remove(oldName);
        this.fields.put(newName, item);
        return true;
    }

    public static Object[] splitDAelements(String da) {
        try {
            PRTokeniser tk = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(PdfEncodings.convertToBytes(da, null))));
            ArrayList<String> stack = new ArrayList();
            Object[] ret = new Object[FIELD_TYPE_RADIOBUTTON];
            while (tk.nextToken()) {
                if (tk.getTokenType() != TokenType.COMMENT) {
                    if (tk.getTokenType() == TokenType.OTHER) {
                        String operator = tk.getStringValue();
                        if (operator.equals("Tf")) {
                            if (stack.size() >= FIELD_TYPE_CHECKBOX) {
                                ret[FIELD_TYPE_NONE] = stack.get(stack.size() - 2);
                                ret[FIELD_TYPE_PUSHBUTTON] = new Float((String) stack.get(stack.size() - 1));
                            }
                        } else if (operator.equals("g")) {
                            if (stack.size() >= FIELD_TYPE_PUSHBUTTON) {
                                float gray = new Float((String) stack.get(stack.size() - 1)).floatValue();
                                if (gray != 0.0f) {
                                    ret[FIELD_TYPE_CHECKBOX] = new GrayColor(gray);
                                }
                            }
                        } else if (operator.equals("rg")) {
                            if (stack.size() >= FIELD_TYPE_RADIOBUTTON) {
                                ret[FIELD_TYPE_CHECKBOX] = new BaseColor(new Float((String) stack.get(stack.size() - 3)).floatValue(), new Float((String) stack.get(stack.size() - 2)).floatValue(), new Float((String) stack.get(stack.size() - 1)).floatValue());
                            }
                        } else if (operator.equals("k") && stack.size() >= FIELD_TYPE_TEXT) {
                            ret[FIELD_TYPE_CHECKBOX] = new CMYKColor(new Float((String) stack.get(stack.size() - 4)).floatValue(), new Float((String) stack.get(stack.size() - 3)).floatValue(), new Float((String) stack.get(stack.size() - 2)).floatValue(), new Float((String) stack.get(stack.size() - 1)).floatValue());
                        }
                        stack.clear();
                    } else {
                        stack.add(tk.getStringValue());
                    }
                }
            }
            return ret;
        } catch (IOException ioe) {
            throw new ExceptionConverter(ioe);
        }
    }

    public void decodeGenericDictionary(PdfDictionary merged, BaseField tx) throws IOException, DocumentException {
        int flags;
        PdfString da = merged.getAsString(PdfName.DA);
        if (da != null) {
            Object[] dab = splitDAelements(da.toUnicodeString());
            if (dab[FIELD_TYPE_PUSHBUTTON] != null) {
                tx.setFontSize(((Float) dab[FIELD_TYPE_PUSHBUTTON]).floatValue());
            }
            if (dab[FIELD_TYPE_CHECKBOX] != null) {
                tx.setTextColor((BaseColor) dab[FIELD_TYPE_CHECKBOX]);
            }
            if (dab[FIELD_TYPE_NONE] != null) {
                PdfDictionary font = merged.getAsDict(PdfName.DR);
                if (font != null) {
                    font = font.getAsDict(PdfName.FONT);
                    if (font != null) {
                        PdfObject po = font.get(new PdfName((String) dab[FIELD_TYPE_NONE]));
                        if (po == null || po.type() != 10) {
                            BaseFont bf = (BaseFont) this.localFonts.get(dab[FIELD_TYPE_NONE]);
                            if (bf == null) {
                                String[] fn = (String[]) stdFieldFontNames.get(dab[FIELD_TYPE_NONE]);
                                if (fn != null) {
                                    try {
                                        String enc = "winansi";
                                        if (fn.length > FIELD_TYPE_PUSHBUTTON) {
                                            enc = fn[FIELD_TYPE_PUSHBUTTON];
                                        }
                                        tx.setFont(BaseFont.createFont(fn[FIELD_TYPE_NONE], enc, false));
                                    } catch (Exception e) {
                                    }
                                }
                            } else {
                                tx.setFont(bf);
                            }
                        } else {
                            PRIndirectReference por = (PRIndirectReference) po;
                            tx.setFont(new DocumentFont((PRIndirectReference) po));
                            Integer porkey = Integer.valueOf(por.getNumber());
                            BaseFont porf = (BaseFont) this.extensionFonts.get(porkey);
                            if (porf == null && !this.extensionFonts.containsKey(porkey)) {
                                PdfDictionary pdfDictionary = (PdfDictionary) PdfReader.getPdfObject(po);
                                PdfDictionary fd = fo.getAsDict(PdfName.FONTDESCRIPTOR);
                                if (fd != null) {
                                    PRStream prs = (PRStream) PdfReader.getPdfObject(fd.get(PdfName.FONTFILE2));
                                    if (prs == null) {
                                        prs = (PRStream) PdfReader.getPdfObject(fd.get(PdfName.FONTFILE3));
                                    }
                                    if (prs == null) {
                                        this.extensionFonts.put(porkey, null);
                                    } else {
                                        try {
                                            porf = BaseFont.createFont("font.ttf", BaseFont.IDENTITY_H, true, false, PdfReader.getStreamBytes(prs), null);
                                        } catch (Exception e2) {
                                        }
                                        this.extensionFonts.put(porkey, porf);
                                    }
                                }
                            }
                            if (tx instanceof TextField) {
                                ((TextField) tx).setExtensionFont(porf);
                            }
                        }
                    }
                }
            }
        }
        PdfDictionary mk = merged.getAsDict(PdfName.MK);
        if (mk != null) {
            BaseColor border = getMKColor(mk.getAsArray(PdfName.BC));
            tx.setBorderColor(border);
            if (border != null) {
                tx.setBorderWidth(BaseField.BORDER_WIDTH_THIN);
            }
            tx.setBackgroundColor(getMKColor(mk.getAsArray(PdfName.BG)));
            PdfNumber rotation = mk.getAsNumber(PdfName.f77R);
            if (rotation != null) {
                tx.setRotation(rotation.intValue());
            }
        }
        PdfNumber nfl = merged.getAsNumber(PdfName.f67F);
        tx.setVisibility(FIELD_TYPE_CHECKBOX);
        if (nfl != null) {
            flags = nfl.intValue();
            if ((flags & FIELD_TYPE_TEXT) != 0 && (flags & FIELD_TYPE_CHECKBOX) != 0) {
                tx.setVisibility(FIELD_TYPE_PUSHBUTTON);
            } else if ((flags & FIELD_TYPE_TEXT) != 0 && (flags & 32) != 0) {
                tx.setVisibility(FIELD_TYPE_RADIOBUTTON);
            } else if ((flags & FIELD_TYPE_TEXT) != 0) {
                tx.setVisibility(FIELD_TYPE_NONE);
            }
        }
        nfl = merged.getAsNumber(PdfName.FF);
        flags = FIELD_TYPE_NONE;
        if (nfl != null) {
            flags = nfl.intValue();
        }
        tx.setOptions(flags);
        if ((PdfWriter.PrintScalingNone & flags) != 0) {
            PdfNumber maxLen = merged.getAsNumber(PdfName.MAXLEN);
            int len = FIELD_TYPE_NONE;
            if (maxLen != null) {
                len = maxLen.intValue();
            }
            tx.setMaxCharacterLength(len);
        }
        nfl = merged.getAsNumber(PdfName.f76Q);
        if (nfl != null) {
            if (nfl.intValue() == FIELD_TYPE_PUSHBUTTON) {
                tx.setAlignment(FIELD_TYPE_PUSHBUTTON);
            } else if (nfl.intValue() == FIELD_TYPE_CHECKBOX) {
                tx.setAlignment(FIELD_TYPE_CHECKBOX);
            }
        }
        PdfDictionary bs = merged.getAsDict(PdfName.BS);
        if (bs != null) {
            PdfNumber w = bs.getAsNumber(PdfName.f82W);
            if (w != null) {
                tx.setBorderWidth(w.floatValue());
            }
            PdfName s = bs.getAsName(PdfName.f78S);
            if (PdfName.f65D.equals(s)) {
                tx.setBorderStyle(FIELD_TYPE_PUSHBUTTON);
                return;
            } else if (PdfName.f63B.equals(s)) {
                tx.setBorderStyle(FIELD_TYPE_CHECKBOX);
                return;
            } else if (PdfName.f69I.equals(s)) {
                tx.setBorderStyle(FIELD_TYPE_RADIOBUTTON);
                return;
            } else if (PdfName.f80U.equals(s)) {
                tx.setBorderStyle(FIELD_TYPE_TEXT);
                return;
            } else {
                return;
            }
        }
        PdfArray bd = merged.getAsArray(PdfName.BORDER);
        if (bd != null) {
            if (bd.size() >= FIELD_TYPE_RADIOBUTTON) {
                tx.setBorderWidth(bd.getAsNumber(FIELD_TYPE_CHECKBOX).floatValue());
            }
            if (bd.size() >= FIELD_TYPE_TEXT) {
                tx.setBorderStyle(FIELD_TYPE_PUSHBUTTON);
            }
        }
    }

    PdfAppearance getAppearance(PdfDictionary merged, String[] values, String fieldName) throws IOException, DocumentException {
        TextField tx;
        PdfName fieldType;
        PdfArray opt;
        int flags;
        PdfNumber nfl;
        String[] choices;
        String[] choicesExp;
        int k;
        PdfObject obj;
        int length;
        ArrayList<Integer> indexes;
        int j;
        String val;
        this.topFirst = FIELD_TYPE_NONE;
        String text = values.length > 0 ? values[FIELD_TYPE_NONE] : null;
        if (this.fieldCache != null) {
            if (this.fieldCache.containsKey(fieldName)) {
                tx = (TextField) this.fieldCache.get(fieldName);
                tx.setWriter(this.writer);
                fieldType = merged.getAsName(PdfName.FT);
                if (PdfName.TX.equals(fieldType)) {
                    if (PdfName.CH.equals(fieldType)) {
                        throw new DocumentException(MessageLocalization.getComposedMessage("an.appearance.was.requested.without.a.variable.text.field", new Object[FIELD_TYPE_NONE]));
                    }
                    opt = merged.getAsArray(PdfName.OPT);
                    flags = FIELD_TYPE_NONE;
                    nfl = merged.getAsNumber(PdfName.FF);
                    if (nfl != null) {
                        flags = nfl.intValue();
                    }
                    if ((PdfWriter.DisplayDocTitle & flags) == 0 && opt == null) {
                        tx.setText(text);
                        return tx.getAppearance();
                    }
                    if (opt != null) {
                        choices = new String[opt.size()];
                        choicesExp = new String[opt.size()];
                        for (k = FIELD_TYPE_NONE; k < opt.size(); k += FIELD_TYPE_PUSHBUTTON) {
                            obj = opt.getPdfObject(k);
                            if (obj.isString()) {
                                PdfArray a = (PdfArray) obj;
                                choicesExp[k] = a.getAsString(FIELD_TYPE_NONE).toUnicodeString();
                                choices[k] = a.getAsString(FIELD_TYPE_PUSHBUTTON).toUnicodeString();
                            } else {
                                String toUnicodeString = ((PdfString) obj).toUnicodeString();
                                choicesExp[k] = toUnicodeString;
                                choices[k] = toUnicodeString;
                            }
                        }
                        if ((PdfWriter.DisplayDocTitle & flags) == 0) {
                            k = FIELD_TYPE_NONE;
                            while (true) {
                                length = choices.length;
                                if (k < r0) {
                                    break;
                                }
                                if (text.equals(choicesExp[k])) {
                                    break;
                                }
                                k += FIELD_TYPE_PUSHBUTTON;
                            }
                            tx.setText(text);
                            return tx.getAppearance();
                        }
                        indexes = new ArrayList();
                        k = FIELD_TYPE_NONE;
                        while (true) {
                            length = choicesExp.length;
                            if (k < r0) {
                                break;
                            }
                            j = FIELD_TYPE_NONE;
                            while (true) {
                                length = values.length;
                                if (j < r0) {
                                    break;
                                }
                                val = values[j];
                                if (val == null && val.equals(choicesExp[k])) {
                                    break;
                                }
                                j += FIELD_TYPE_PUSHBUTTON;
                            }
                            indexes.add(Integer.valueOf(k));
                            k += FIELD_TYPE_PUSHBUTTON;
                        }
                        tx.setChoices(choices);
                        tx.setChoiceExports(choicesExp);
                        tx.setChoiceSelections(indexes);
                    }
                    PdfAppearance app = tx.getListAppearance();
                    this.topFirst = tx.getTopFirst();
                    return app;
                }
                if (values.length > 0 && values[FIELD_TYPE_NONE] != null) {
                    tx.setText(values[FIELD_TYPE_NONE]);
                }
                return tx.getAppearance();
            }
        }
        TextField textField = new TextField(this.writer, null, null);
        textField.setExtraMargin(this.extraMarginLeft, this.extraMarginTop);
        textField.setBorderWidth(0.0f);
        textField.setSubstitutionFonts(this.substitutionFonts);
        decodeGenericDictionary(merged, textField);
        Rectangle box = PdfReader.getNormalizedRectangle(merged.getAsArray(PdfName.RECT));
        if (textField.getRotation() == 90 || textField.getRotation() == 270) {
            box = box.rotate();
        }
        textField.setBox(box);
        if (this.fieldCache != null) {
            this.fieldCache.put(fieldName, textField);
        }
        fieldType = merged.getAsName(PdfName.FT);
        if (PdfName.TX.equals(fieldType)) {
            if (PdfName.CH.equals(fieldType)) {
                opt = merged.getAsArray(PdfName.OPT);
                flags = FIELD_TYPE_NONE;
                nfl = merged.getAsNumber(PdfName.FF);
                if (nfl != null) {
                    flags = nfl.intValue();
                }
                if ((PdfWriter.DisplayDocTitle & flags) == 0) {
                }
                if (opt != null) {
                    choices = new String[opt.size()];
                    choicesExp = new String[opt.size()];
                    for (k = FIELD_TYPE_NONE; k < opt.size(); k += FIELD_TYPE_PUSHBUTTON) {
                        obj = opt.getPdfObject(k);
                        if (obj.isString()) {
                            PdfArray a2 = (PdfArray) obj;
                            choicesExp[k] = a2.getAsString(FIELD_TYPE_NONE).toUnicodeString();
                            choices[k] = a2.getAsString(FIELD_TYPE_PUSHBUTTON).toUnicodeString();
                        } else {
                            String toUnicodeString2 = ((PdfString) obj).toUnicodeString();
                            choicesExp[k] = toUnicodeString2;
                            choices[k] = toUnicodeString2;
                        }
                    }
                    if ((PdfWriter.DisplayDocTitle & flags) == 0) {
                        indexes = new ArrayList();
                        k = FIELD_TYPE_NONE;
                        while (true) {
                            length = choicesExp.length;
                            if (k < r0) {
                                break;
                                tx.setChoices(choices);
                                tx.setChoiceExports(choicesExp);
                                tx.setChoiceSelections(indexes);
                            } else {
                                j = FIELD_TYPE_NONE;
                                while (true) {
                                    length = values.length;
                                    if (j < r0) {
                                        break;
                                    }
                                    val = values[j];
                                    if (val == null) {
                                    }
                                    j += FIELD_TYPE_PUSHBUTTON;
                                    k += FIELD_TYPE_PUSHBUTTON;
                                }
                            }
                        }
                    } else {
                        k = FIELD_TYPE_NONE;
                        while (true) {
                            length = choices.length;
                            if (k < r0) {
                                break;
                            }
                            if (text.equals(choicesExp[k])) {
                                break;
                                text = choices[k];
                            } else {
                                k += FIELD_TYPE_PUSHBUTTON;
                            }
                            tx.setText(text);
                            return tx.getAppearance();
                        }
                    }
                }
                PdfAppearance app2 = tx.getListAppearance();
                this.topFirst = tx.getTopFirst();
                return app2;
            }
            throw new DocumentException(MessageLocalization.getComposedMessage("an.appearance.was.requested.without.a.variable.text.field", new Object[FIELD_TYPE_NONE]));
        }
        tx.setText(values[FIELD_TYPE_NONE]);
        return tx.getAppearance();
    }

    PdfAppearance getAppearance(PdfDictionary merged, String text, String fieldName) throws IOException, DocumentException {
        String[] valueArr = new String[FIELD_TYPE_PUSHBUTTON];
        valueArr[FIELD_TYPE_NONE] = text;
        return getAppearance(merged, valueArr, fieldName);
    }

    BaseColor getMKColor(PdfArray ar) {
        if (ar == null) {
            return null;
        }
        switch (ar.size()) {
            case FIELD_TYPE_PUSHBUTTON /*1*/:
                return new GrayColor(ar.getAsNumber(FIELD_TYPE_NONE).floatValue());
            case FIELD_TYPE_RADIOBUTTON /*3*/:
                return new BaseColor(ExtendedColor.normalize(ar.getAsNumber(FIELD_TYPE_NONE).floatValue()), ExtendedColor.normalize(ar.getAsNumber(FIELD_TYPE_PUSHBUTTON).floatValue()), ExtendedColor.normalize(ar.getAsNumber(FIELD_TYPE_CHECKBOX).floatValue()));
            case FIELD_TYPE_TEXT /*4*/:
                return new CMYKColor(ar.getAsNumber(FIELD_TYPE_NONE).floatValue(), ar.getAsNumber(FIELD_TYPE_PUSHBUTTON).floatValue(), ar.getAsNumber(FIELD_TYPE_CHECKBOX).floatValue(), ar.getAsNumber(FIELD_TYPE_RADIOBUTTON).floatValue());
            default:
                return null;
        }
    }

    public String getFieldRichValue(String name) {
        if (this.xfa.isXfaPresent()) {
            return null;
        }
        Item item = (Item) this.fields.get(name);
        if (item == null) {
            return null;
        }
        PdfString rich = item.getMerged(FIELD_TYPE_NONE).getAsString(PdfName.RV);
        if (rich != null) {
            return rich.toString();
        }
        return null;
    }

    public String getField(String name) {
        if (this.xfa.isXfaPresent()) {
            name = this.xfa.findFieldName(name, this);
            if (name == null) {
                return null;
            }
            return XfaForm.getNodeText(this.xfa.findDatasetsNode(Xml2Som.getShortName(name)));
        }
        Item item = (Item) this.fields.get(name);
        if (item == null) {
            return null;
        }
        this.lastWasString = false;
        PdfDictionary mergedDict = item.getMerged(FIELD_TYPE_NONE);
        PdfObject v = PdfReader.getPdfObject(mergedDict.get(PdfName.f81V));
        if (v == null) {
            return PdfObject.NOTHING;
        }
        if (v instanceof PRStream) {
            try {
                return new String(PdfReader.getStreamBytes((PRStream) v));
            } catch (IOException e) {
                throw new ExceptionConverter(e);
            }
        }
        if (PdfName.BTN.equals(mergedDict.getAsName(PdfName.FT))) {
            PdfNumber ff = mergedDict.getAsNumber(PdfName.FF);
            int flags = FIELD_TYPE_NONE;
            if (ff != null) {
                flags = ff.intValue();
            }
            if ((PdfWriter.CenterWindow & flags) != 0) {
                return PdfObject.NOTHING;
            }
            String value = PdfObject.NOTHING;
            if (v instanceof PdfName) {
                value = PdfName.decodeName(v.toString());
            } else if (v instanceof PdfString) {
                value = ((PdfString) v).toUnicodeString();
            }
            PdfArray opts = item.getValue(FIELD_TYPE_NONE).getAsArray(PdfName.OPT);
            if (opts == null) {
                return value;
            }
            try {
                value = opts.getAsString(Integer.parseInt(value)).toUnicodeString();
                this.lastWasString = true;
                return value;
            } catch (Exception e2) {
                return value;
            }
        } else if (v instanceof PdfString) {
            this.lastWasString = true;
            return ((PdfString) v).toUnicodeString();
        } else if (v instanceof PdfName) {
            return PdfName.decodeName(v.toString());
        } else {
            return PdfObject.NOTHING;
        }
    }

    public String[] getListSelection(String name) {
        String[] ret;
        String s = getField(name);
        if (s == null) {
            ret = new String[FIELD_TYPE_NONE];
        } else {
            ret = new String[FIELD_TYPE_PUSHBUTTON];
            ret[FIELD_TYPE_NONE] = s;
        }
        Item item = (Item) this.fields.get(name);
        if (item == null) {
            return ret;
        }
        PdfArray values = item.getMerged(FIELD_TYPE_NONE).getAsArray(PdfName.f69I);
        if (values == null) {
            return ret;
        }
        ret = new String[values.size()];
        String[] options = getListOptionExport(name);
        int idx = FIELD_TYPE_NONE;
        Iterator<PdfObject> i = values.listIterator();
        while (i.hasNext()) {
            int idx2 = idx + FIELD_TYPE_PUSHBUTTON;
            ret[idx] = options[((PdfNumber) i.next()).intValue()];
            idx = idx2;
        }
        return ret;
    }

    public boolean setFieldProperty(String field, String name, Object value, int[] inst) {
        if (this.writer == null) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[FIELD_TYPE_NONE]));
        }
        try {
            Item item = (Item) this.fields.get(field);
            if (item == null) {
                return false;
            }
            InstHit instHit = new InstHit(inst);
            int k;
            PdfString da;
            Object[] dao;
            PdfAppearance cb;
            PdfObject pdfString;
            if (name.equalsIgnoreCase("textfont")) {
                for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                    if (instHit.isHit(k)) {
                        PdfDictionary merged = item.getMerged(k);
                        da = merged.getAsString(PdfName.DA);
                        PdfDictionary dr = merged.getAsDict(PdfName.DR);
                        if (da == null) {
                            continue;
                        } else {
                            if (dr == null) {
                                dr = new PdfDictionary();
                                merged.put(PdfName.DR, dr);
                            }
                            dao = splitDAelements(da.toUnicodeString());
                            cb = new PdfAppearance();
                            if (dao[FIELD_TYPE_NONE] != null) {
                                BaseFont bf = (BaseFont) value;
                                PdfName psn = (PdfName) PdfAppearance.stdFieldFontNames.get(bf.getPostscriptFontName());
                                if (psn == null) {
                                    PdfName pdfName = new PdfName(bf.getPostscriptFontName());
                                }
                                PdfDictionary fonts = dr.getAsDict(PdfName.FONT);
                                if (fonts == null) {
                                    fonts = new PdfDictionary();
                                    dr.put(PdfName.FONT, fonts);
                                }
                                PdfIndirectReference fref = (PdfIndirectReference) fonts.get(psn);
                                PdfObject top = this.reader.getCatalog().getAsDict(PdfName.ACROFORM);
                                markUsed(top);
                                dr = top.getAsDict(PdfName.DR);
                                if (dr == null) {
                                    dr = new PdfDictionary();
                                    top.put(PdfName.DR, dr);
                                }
                                markUsed(dr);
                                PdfDictionary fontsTop = dr.getAsDict(PdfName.FONT);
                                if (fontsTop == null) {
                                    fontsTop = new PdfDictionary();
                                    dr.put(PdfName.FONT, fontsTop);
                                }
                                markUsed(fontsTop);
                                PdfIndirectReference frefTop = (PdfIndirectReference) fontsTop.get(psn);
                                if (frefTop != null) {
                                    if (fref == null) {
                                        fonts.put(psn, frefTop);
                                    }
                                } else if (fref == null) {
                                    FontDetails fd;
                                    if (bf.getFontType() == FIELD_TYPE_TEXT) {
                                        fd = new FontDetails(null, ((DocumentFont) bf).getIndirectReference(), bf);
                                    } else {
                                        bf.setSubset(false);
                                        fd = this.writer.addSimple(bf);
                                        this.localFonts.put(psn.toString().substring(FIELD_TYPE_PUSHBUTTON), bf);
                                    }
                                    fontsTop.put(psn, fd.getIndirectReference());
                                    fonts.put(psn, fd.getIndirectReference());
                                }
                                cb.getInternalBuffer().append(psn.getBytes()).append(' ').append(((Float) dao[FIELD_TYPE_PUSHBUTTON]).floatValue()).append(" Tf ");
                                if (dao[FIELD_TYPE_CHECKBOX] != null) {
                                    cb.setColorFill((BaseColor) dao[FIELD_TYPE_CHECKBOX]);
                                }
                                pdfString = new PdfString(cb.toString());
                                item.getMerged(k).put(PdfName.DA, pdfString);
                                item.getWidget(k).put(PdfName.DA, pdfString);
                                markUsed(item.getWidget(k));
                            } else {
                                continue;
                            }
                        }
                    }
                }
            } else {
                if (name.equalsIgnoreCase("textcolor")) {
                    for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                        if (instHit.isHit(k)) {
                            da = item.getMerged(k).getAsString(PdfName.DA);
                            if (da != null) {
                                dao = splitDAelements(da.toUnicodeString());
                                cb = new PdfAppearance();
                                if (dao[FIELD_TYPE_NONE] != null) {
                                    cb.getInternalBuffer().append(new PdfName((String) dao[FIELD_TYPE_NONE]).getBytes()).append(' ').append(((Float) dao[FIELD_TYPE_PUSHBUTTON]).floatValue()).append(" Tf ");
                                    cb.setColorFill((BaseColor) value);
                                    pdfString = new PdfString(cb.toString());
                                    item.getMerged(k).put(PdfName.DA, pdfString);
                                    item.getWidget(k).put(PdfName.DA, pdfString);
                                    markUsed(item.getWidget(k));
                                }
                            }
                        }
                    }
                } else {
                    if (name.equalsIgnoreCase("textsize")) {
                        for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                            if (instHit.isHit(k)) {
                                da = item.getMerged(k).getAsString(PdfName.DA);
                                if (da != null) {
                                    dao = splitDAelements(da.toUnicodeString());
                                    cb = new PdfAppearance();
                                    if (dao[FIELD_TYPE_NONE] != null) {
                                        cb.getInternalBuffer().append(new PdfName((String) dao[FIELD_TYPE_NONE]).getBytes()).append(' ').append(((Float) value).floatValue()).append(" Tf ");
                                        if (dao[FIELD_TYPE_CHECKBOX] != null) {
                                            cb.setColorFill((BaseColor) dao[FIELD_TYPE_CHECKBOX]);
                                        }
                                        pdfString = new PdfString(cb.toString());
                                        item.getMerged(k).put(PdfName.DA, pdfString);
                                        item.getWidget(k).put(PdfName.DA, pdfString);
                                        markUsed(item.getWidget(k));
                                    }
                                }
                            }
                        }
                    } else {
                        if (!name.equalsIgnoreCase(HtmlTags.BGCOLOR)) {
                            if (!name.equalsIgnoreCase("bordercolor")) {
                                return false;
                            }
                        }
                        PdfName dname = name.equalsIgnoreCase(HtmlTags.BGCOLOR) ? PdfName.BG : PdfName.BC;
                        for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                            if (instHit.isHit(k)) {
                                PdfDictionary mk;
                                PdfObject mk2 = item.getMerged(k).getAsDict(PdfName.MK);
                                if (mk2 != null) {
                                    markUsed(mk2);
                                } else if (value == null) {
                                    return true;
                                } else {
                                    mk = new PdfDictionary();
                                    item.getMerged(k).put(PdfName.MK, mk);
                                    item.getWidget(k).put(PdfName.MK, mk);
                                    markUsed(item.getWidget(k));
                                }
                                if (value == null) {
                                    mk.remove(dname);
                                } else {
                                    mk.put(dname, PdfAnnotation.getMKColor((BaseColor) value));
                                }
                            }
                        }
                    }
                }
            }
            return true;
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public boolean setFieldProperty(String field, String name, int value, int[] inst) {
        if (this.writer == null) {
            throw new RuntimeException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[FIELD_TYPE_NONE]));
        }
        Item item = (Item) this.fields.get(field);
        if (item == null) {
            return false;
        }
        InstHit hit = new InstHit(inst);
        PdfNumber num;
        int k;
        if (name.equalsIgnoreCase("flags")) {
            num = new PdfNumber(value);
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    item.getMerged(k).put(PdfName.f67F, num);
                    item.getWidget(k).put(PdfName.f67F, num);
                    markUsed(item.getWidget(k));
                }
            }
        } else if (name.equalsIgnoreCase("setflags")) {
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    num = item.getWidget(k).getAsNumber(PdfName.f67F);
                    val = FIELD_TYPE_NONE;
                    if (num != null) {
                        val = num.intValue();
                    }
                    num = new PdfNumber(val | value);
                    item.getMerged(k).put(PdfName.f67F, num);
                    item.getWidget(k).put(PdfName.f67F, num);
                    markUsed(item.getWidget(k));
                }
            }
        } else if (name.equalsIgnoreCase("clrflags")) {
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    PdfDictionary widget = item.getWidget(k);
                    num = widget.getAsNumber(PdfName.f67F);
                    val = FIELD_TYPE_NONE;
                    if (num != null) {
                        val = num.intValue();
                    }
                    num = new PdfNumber((value ^ -1) & val);
                    item.getMerged(k).put(PdfName.f67F, num);
                    widget.put(PdfName.f67F, num);
                    markUsed(widget);
                }
            }
        } else if (name.equalsIgnoreCase("fflags")) {
            num = new PdfNumber(value);
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    item.getMerged(k).put(PdfName.FF, num);
                    item.getValue(k).put(PdfName.FF, num);
                    markUsed(item.getValue(k));
                }
            }
        } else if (name.equalsIgnoreCase("setfflags")) {
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    valDict = item.getValue(k);
                    num = valDict.getAsNumber(PdfName.FF);
                    val = FIELD_TYPE_NONE;
                    if (num != null) {
                        val = num.intValue();
                    }
                    num = new PdfNumber(val | value);
                    item.getMerged(k).put(PdfName.FF, num);
                    valDict.put(PdfName.FF, num);
                    markUsed(valDict);
                }
            }
        } else if (!name.equalsIgnoreCase("clrfflags")) {
            return false;
        } else {
            for (k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
                if (hit.isHit(k)) {
                    valDict = item.getValue(k);
                    num = valDict.getAsNumber(PdfName.FF);
                    val = FIELD_TYPE_NONE;
                    if (num != null) {
                        val = num.intValue();
                    }
                    num = new PdfNumber((value ^ -1) & val);
                    item.getMerged(k).put(PdfName.FF, num);
                    valDict.put(PdfName.FF, num);
                    markUsed(valDict);
                }
            }
        }
        return true;
    }

    public void mergeXfaData(Node n) throws IOException, DocumentException {
        Xml2SomDatasets data = new Xml2SomDatasets(n);
        Iterator i$ = data.getOrder().iterator();
        while (i$.hasNext()) {
            String name = (String) i$.next();
            setField(name, XfaForm.getNodeText((Node) data.getName2Node().get(name)));
        }
    }

    public void setFields(FdfReader fdf) throws IOException, DocumentException {
        for (String f : fdf.getFields().keySet()) {
            String v = fdf.getFieldValue(f);
            if (v != null) {
                setField(f, v);
            }
        }
    }

    public void setFields(XfdfReader xfdf) throws IOException, DocumentException {
        for (String f : xfdf.getFields().keySet()) {
            String v = xfdf.getFieldValue(f);
            if (v != null) {
                setField(f, v);
            }
            List<String> l = xfdf.getListValues(f);
            if (l != null) {
                setListSelection(v, (String[]) l.toArray(new String[l.size()]));
            }
        }
    }

    public boolean regenerateField(String name) throws IOException, DocumentException {
        String value = getField(name);
        return setField(name, value, value);
    }

    public boolean setField(String name, String value) throws IOException, DocumentException {
        return setField(name, value, null);
    }

    public boolean setFieldRichValue(String name, String richValue) throws DocumentException, IOException {
        if (this.writer == null) {
            throw new DocumentException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[FIELD_TYPE_NONE]));
        }
        Item item = getFieldItem(name);
        if (item == null || getFieldType(name) != FIELD_TYPE_TEXT) {
            return false;
        }
        PdfNumber ffNum = item.getMerged(FIELD_TYPE_NONE).getAsNumber(PdfName.FF);
        int flagVal = FIELD_TYPE_NONE;
        if (ffNum != null) {
            flagVal = ffNum.intValue();
        }
        if ((PdfFormField.FF_RICHTEXT & flagVal) == 0) {
            return false;
        }
        item.writeToAll(PdfName.RV, new PdfString(richValue), FIELD_TYPE_LIST);
        item.writeToAll(PdfName.f81V, new PdfString(XmlToTxt.parse(new ByteArrayInputStream(richValue.getBytes()))), FIELD_TYPE_LIST);
        return true;
    }

    public boolean setField(String name, String value, String display) throws IOException, DocumentException {
        if (this.writer == null) {
            throw new DocumentException(MessageLocalization.getComposedMessage("this.acrofields.instance.is.read.only", new Object[FIELD_TYPE_NONE]));
        }
        if (this.xfa.isXfaPresent()) {
            name = this.xfa.findFieldName(name, this);
            if (name == null) {
                return false;
            }
            String shortName = Xml2Som.getShortName(name);
            Node xn = this.xfa.findDatasetsNode(shortName);
            if (xn == null) {
                xn = this.xfa.getDatasetsSom().insertNode(this.xfa.getDatasetsNode(), shortName);
            }
            this.xfa.setNodeText(xn, value);
        }
        Item item = (Item) this.fields.get(name);
        if (item == null) {
            return false;
        }
        PdfObject pdfName;
        int idx;
        PdfObject widget;
        PdfDictionary appDic;
        PdfDictionary merged = item.getMerged(FIELD_TYPE_NONE);
        PdfName type = merged.getAsName(PdfName.FT);
        if (PdfName.TX.equals(type)) {
            PdfNumber maxLen = merged.getAsNumber(PdfName.MAXLEN);
            int len = FIELD_TYPE_NONE;
            if (maxLen != null) {
                len = maxLen.intValue();
            }
            if (len > 0) {
                value = value.substring(FIELD_TYPE_NONE, Math.min(len, value.length()));
            }
        }
        if (display == null) {
            display = value;
        }
        if (!PdfName.TX.equals(type)) {
            if (!PdfName.CH.equals(type)) {
                if (!PdfName.BTN.equals(type)) {
                    return false;
                }
                PdfNumber ff = item.getMerged(FIELD_TYPE_NONE).getAsNumber(PdfName.FF);
                int flags = FIELD_TYPE_NONE;
                if (ff != null) {
                    flags = ff.intValue();
                }
                if ((PdfWriter.CenterWindow & flags) != 0) {
                    try {
                        Image img = Image.getInstance(Base64.decode(value));
                        PushbuttonField pb = getNewPushbuttonFromField(name);
                        pb.setImage(img);
                        replacePushbuttonField(name, pb.getField());
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
                PdfObject vt;
                pdfName = new PdfName(value);
                ArrayList<String> lopt = new ArrayList();
                PdfArray opts = item.getValue(FIELD_TYPE_NONE).getAsArray(PdfName.OPT);
                if (opts != null) {
                    for (int k = FIELD_TYPE_NONE; k < opts.size(); k += FIELD_TYPE_PUSHBUTTON) {
                        PdfString valStr = opts.getAsString(k);
                        if (valStr != null) {
                            lopt.add(valStr.toUnicodeString());
                        } else {
                            lopt.add(null);
                        }
                    }
                }
                int vidx = lopt.indexOf(value);
                if (vidx >= 0) {
                    pdfName = new PdfName(String.valueOf(vidx));
                } else {
                    vt = pdfName;
                }
                for (idx = FIELD_TYPE_NONE; idx < item.size(); idx += FIELD_TYPE_PUSHBUTTON) {
                    merged = item.getMerged(idx);
                    widget = item.getWidget(idx);
                    PdfDictionary valDict = item.getValue(idx);
                    markUsed(item.getValue(idx));
                    valDict.put(PdfName.f81V, vt);
                    merged.put(PdfName.f81V, vt);
                    markUsed(widget);
                    appDic = widget.getAsDict(PdfName.AP);
                    if (appDic == null) {
                        return false;
                    }
                    PdfDictionary normal = appDic.getAsDict(PdfName.f73N);
                    if (isInAP(normal, vt) || normal == null) {
                        merged.put(PdfName.AS, vt);
                        widget.put(PdfName.AS, vt);
                    } else {
                        merged.put(PdfName.AS, PdfName.Off);
                        widget.put(PdfName.AS, PdfName.Off);
                    }
                }
                return true;
            }
        }
        pdfName = new PdfString(value, PdfObject.TEXT_UNICODE);
        for (idx = FIELD_TYPE_NONE; idx < item.size(); idx += FIELD_TYPE_PUSHBUTTON) {
            PdfObject valueDic = item.getValue(idx);
            valueDic.put(PdfName.f81V, pdfName);
            valueDic.remove(PdfName.f69I);
            markUsed(valueDic);
            merged = item.getMerged(idx);
            merged.remove(PdfName.f69I);
            merged.put(PdfName.f81V, pdfName);
            widget = item.getWidget(idx);
            if (this.generateAppearances) {
                PdfAppearance app = getAppearance(merged, display, name);
                if (PdfName.CH.equals(type)) {
                    pdfName = new PdfNumber(this.topFirst);
                    widget.put(PdfName.TI, pdfName);
                    merged.put(PdfName.TI, pdfName);
                }
                appDic = widget.getAsDict(PdfName.AP);
                if (appDic == null) {
                    appDic = new PdfDictionary();
                    widget.put(PdfName.AP, appDic);
                    merged.put(PdfName.AP, appDic);
                }
                appDic.put(PdfName.f73N, app.getIndirectReference());
                this.writer.releaseTemplate(app);
            } else {
                widget.remove(PdfName.AP);
                merged.remove(PdfName.AP);
            }
            markUsed(widget);
        }
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean setListSelection(java.lang.String r20, java.lang.String[] r21) throws java.io.IOException, com.itextpdf.text.DocumentException {
        /*
        r19 = this;
        r10 = r19.getFieldItem(r20);
        if (r10 != 0) goto L_0x0009;
    L_0x0006:
        r17 = 0;
    L_0x0008:
        return r17;
    L_0x0009:
        r17 = 0;
        r0 = r17;
        r13 = r10.getMerged(r0);
        r17 = com.itextpdf.text.pdf.PdfName.FT;
        r0 = r17;
        r15 = r13.getAsName(r0);
        r17 = com.itextpdf.text.pdf.PdfName.CH;
        r0 = r17;
        r17 = r0.equals(r15);
        if (r17 != 0) goto L_0x0026;
    L_0x0023:
        r17 = 0;
        goto L_0x0008;
    L_0x0026:
        r14 = r19.getListOptionExport(r20);
        r6 = new com.itextpdf.text.pdf.PdfArray;
        r6.<init>();
        r5 = r21;
        r12 = r5.length;
        r9 = 0;
    L_0x0033:
        if (r9 >= r12) goto L_0x005b;
    L_0x0035:
        r7 = r5[r9];
        r11 = 0;
    L_0x0038:
        r0 = r14.length;
        r17 = r0;
        r0 = r17;
        if (r11 >= r0) goto L_0x0055;
    L_0x003f:
        r17 = r14[r11];
        r0 = r17;
        r17 = r0.equals(r7);
        if (r17 == 0) goto L_0x0058;
    L_0x0049:
        r17 = new com.itextpdf.text.pdf.PdfNumber;
        r0 = r17;
        r0.<init>(r11);
        r0 = r17;
        r6.add(r0);
    L_0x0055:
        r9 = r9 + 1;
        goto L_0x0033;
    L_0x0058:
        r11 = r11 + 1;
        goto L_0x0038;
    L_0x005b:
        r17 = com.itextpdf.text.pdf.PdfName.f69I;
        r18 = 5;
        r0 = r17;
        r1 = r18;
        r10.writeToAll(r0, r6, r1);
        r16 = new com.itextpdf.text.pdf.PdfArray;
        r16.<init>();
        r8 = 0;
    L_0x006c:
        r0 = r21;
        r0 = r0.length;
        r17 = r0;
        r0 = r17;
        if (r8 >= r0) goto L_0x0082;
    L_0x0075:
        r17 = new com.itextpdf.text.pdf.PdfString;
        r18 = r21[r8];
        r17.<init>(r18);
        r16.add(r17);
        r8 = r8 + 1;
        goto L_0x006c;
    L_0x0082:
        r17 = com.itextpdf.text.pdf.PdfName.f81V;
        r18 = 5;
        r0 = r17;
        r1 = r16;
        r2 = r18;
        r10.writeToAll(r0, r1, r2);
        r0 = r19;
        r1 = r21;
        r2 = r20;
        r4 = r0.getAppearance(r13, r1, r2);
        r3 = new com.itextpdf.text.pdf.PdfDictionary;
        r3.<init>();
        r17 = com.itextpdf.text.pdf.PdfName.f73N;
        r18 = r4.getIndirectReference();
        r0 = r17;
        r1 = r18;
        r3.put(r0, r1);
        r17 = com.itextpdf.text.pdf.PdfName.AP;
        r18 = 3;
        r0 = r17;
        r1 = r18;
        r10.writeToAll(r0, r3, r1);
        r0 = r19;
        r0 = r0.writer;
        r17 = r0;
        r0 = r17;
        r0.releaseTemplate(r4);
        r17 = 6;
        r0 = r19;
        r1 = r17;
        r10.markUsed(r0, r1);
        r17 = 1;
        goto L_0x0008;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.itextpdf.text.pdf.AcroFields.setListSelection(java.lang.String, java.lang.String[]):boolean");
    }

    boolean isInAP(PdfDictionary nDic, PdfName check) {
        return (nDic == null || nDic.get(check) == null) ? false : true;
    }

    public Map<String, Item> getFields() {
        return this.fields;
    }

    public Item getFieldItem(String name) {
        if (this.xfa.isXfaPresent()) {
            name = this.xfa.findFieldName(name, this);
            if (name == null) {
                return null;
            }
        }
        return (Item) this.fields.get(name);
    }

    public String getTranslatedFieldName(String name) {
        if (!this.xfa.isXfaPresent()) {
            return name;
        }
        String namex = this.xfa.findFieldName(name, this);
        if (namex != null) {
            return namex;
        }
        return name;
    }

    public List<FieldPosition> getFieldPositions(String name) {
        Item item = getFieldItem(name);
        if (item == null) {
            return null;
        }
        List<FieldPosition> ret = new ArrayList();
        for (int k = FIELD_TYPE_NONE; k < item.size(); k += FIELD_TYPE_PUSHBUTTON) {
            try {
                PdfArray rect = item.getWidget(k).getAsArray(PdfName.RECT);
                if (rect != null) {
                    Rectangle r = PdfReader.getNormalizedRectangle(rect);
                    int page = item.getPage(k).intValue();
                    int rotation = this.reader.getPageRotation(page);
                    FieldPosition fp = new FieldPosition();
                    fp.page = page;
                    if (rotation != 0) {
                        Rectangle pageSize = this.reader.getPageSize(page);
                        switch (rotation) {
                            case 90:
                                r = new Rectangle(r.getBottom(), pageSize.getRight() - r.getLeft(), r.getTop(), pageSize.getRight() - r.getRight());
                                break;
                            case 180:
                                r = new Rectangle(pageSize.getRight() - r.getLeft(), pageSize.getTop() - r.getBottom(), pageSize.getRight() - r.getRight(), pageSize.getTop() - r.getTop());
                                break;
                            case TIFFConstants.TIFFTAG_IMAGEDESCRIPTION /*270*/:
                                r = new Rectangle(pageSize.getTop() - r.getBottom(), r.getLeft(), pageSize.getTop() - r.getTop(), r.getRight());
                                break;
                        }
                        r.normalize();
                    }
                    fp.position = r;
                    ret.add(fp);
                }
            } catch (Exception e) {
            }
        }
        return ret;
    }

    private int removeRefFromArray(PdfArray array, PdfObject refo) {
        if (refo == null || !refo.isIndirect()) {
            return array.size();
        }
        PdfIndirectReference ref = (PdfIndirectReference) refo;
        int j = FIELD_TYPE_NONE;
        while (j < array.size()) {
            PdfObject obj = array.getPdfObject(j);
            if (obj.isIndirect() && ((PdfIndirectReference) obj).getNumber() == ref.getNumber()) {
                int j2 = j - 1;
                array.remove(j);
                j = j2;
            }
            j += FIELD_TYPE_PUSHBUTTON;
        }
        return array.size();
    }

    public boolean removeFieldsFromPage(int page) {
        if (page < FIELD_TYPE_PUSHBUTTON) {
            return false;
        }
        String[] names = new String[this.fields.size()];
        this.fields.keySet().toArray(names);
        boolean found = false;
        for (int k = FIELD_TYPE_NONE; k < names.length; k += FIELD_TYPE_PUSHBUTTON) {
            boolean fr = removeField(names[k], page);
            if (found || fr) {
                found = true;
            } else {
                found = false;
            }
        }
        return found;
    }

    public boolean removeField(String name, int page) {
        Item item = getFieldItem(name);
        if (item == null) {
            return false;
        }
        PdfDictionary acroForm = (PdfDictionary) PdfReader.getPdfObject(this.reader.getCatalog().get(PdfName.ACROFORM), this.reader.getCatalog());
        if (acroForm == null) {
            return false;
        }
        PdfArray arrayf = acroForm.getAsArray(PdfName.FIELDS);
        if (arrayf == null) {
            return false;
        }
        int k = FIELD_TYPE_NONE;
        while (k < item.size()) {
            int pageV = item.getPage(k).intValue();
            if (page == -1 || page == pageV) {
                PdfIndirectReference ref = item.getWidgetRef(k);
                PdfDictionary wd = item.getWidget(k);
                PdfDictionary pageDic = this.reader.getPageN(pageV);
                PdfArray annots = pageDic.getAsArray(PdfName.ANNOTS);
                if (annots != null) {
                    if (removeRefFromArray(annots, ref) == 0) {
                        pageDic.remove(PdfName.ANNOTS);
                        markUsed(pageDic);
                    } else {
                        markUsed(annots);
                    }
                }
                PdfReader.killIndirect(ref);
                PdfIndirectReference kid = ref;
                while (true) {
                    ref = wd.getAsIndirectObject(PdfName.PARENT);
                    if (ref == null) {
                        break;
                    }
                    wd = wd.getAsDict(PdfName.PARENT);
                    if (removeRefFromArray(wd.getAsArray(PdfName.KIDS), kid) != 0) {
                        break;
                    }
                    kid = ref;
                    PdfReader.killIndirect(ref);
                }
                if (ref == null) {
                    removeRefFromArray(arrayf, kid);
                    markUsed(arrayf);
                }
                if (page != -1) {
                    item.remove(k);
                    k--;
                }
            }
            k += FIELD_TYPE_PUSHBUTTON;
        }
        if (page == -1 || item.size() == 0) {
            this.fields.remove(name);
        }
        return true;
    }

    public boolean removeField(String name) {
        return removeField(name, -1);
    }

    public boolean isGenerateAppearances() {
        return this.generateAppearances;
    }

    public void setGenerateAppearances(boolean generateAppearances) {
        this.generateAppearances = generateAppearances;
        PdfDictionary top = this.reader.getCatalog().getAsDict(PdfName.ACROFORM);
        if (generateAppearances) {
            top.remove(PdfName.NEEDAPPEARANCES);
        } else {
            top.put(PdfName.NEEDAPPEARANCES, PdfBoolean.PDFTRUE);
        }
    }

    public boolean clearSignatureField(String name) {
        this.sigNames = null;
        getSignatureNames();
        if (!this.sigNames.containsKey(name)) {
            return false;
        }
        Item sig = (Item) this.fields.get(name);
        sig.markUsed(this, FIELD_TYPE_COMBO);
        int n = sig.size();
        for (int k = FIELD_TYPE_NONE; k < n; k += FIELD_TYPE_PUSHBUTTON) {
            clearSigDic(sig.getMerged(k));
            clearSigDic(sig.getWidget(k));
            clearSigDic(sig.getValue(k));
        }
        return true;
    }

    private static void clearSigDic(PdfDictionary dic) {
        dic.remove(PdfName.AP);
        dic.remove(PdfName.AS);
        dic.remove(PdfName.f81V);
        dic.remove(PdfName.DV);
        dic.remove(PdfName.SV);
        dic.remove(PdfName.FF);
        dic.put(PdfName.f67F, new PdfNumber((int) FIELD_TYPE_TEXT));
    }

    public ArrayList<String> getSignatureNames() {
        if (this.sigNames != null) {
            return new ArrayList(this.orderedSignatureNames);
        }
        this.sigNames = new HashMap();
        this.orderedSignatureNames = new ArrayList();
        ArrayList<Object[]> sorter = new ArrayList();
        for (Entry<String, Item> entry : this.fields.entrySet()) {
            PdfDictionary merged = ((Item) entry.getValue()).getMerged(FIELD_TYPE_NONE);
            if (PdfName.SIG.equals(merged.get(PdfName.FT))) {
                PdfDictionary v = merged.getAsDict(PdfName.f81V);
                if (!(v == null || v.getAsString(PdfName.CONTENTS) == null)) {
                    PdfArray ro = v.getAsArray(PdfName.BYTERANGE);
                    if (ro != null) {
                        int rangeSize = ro.size();
                        if (rangeSize >= FIELD_TYPE_CHECKBOX) {
                            int length = ro.getAsNumber(rangeSize - 1).intValue() + ro.getAsNumber(rangeSize - 2).intValue();
                            Object obj = new Object[FIELD_TYPE_CHECKBOX];
                            obj[FIELD_TYPE_NONE] = entry.getKey();
                            int[] iArr = new int[FIELD_TYPE_CHECKBOX];
                            iArr[FIELD_TYPE_NONE] = length;
                            iArr[FIELD_TYPE_PUSHBUTTON] = FIELD_TYPE_NONE;
                            obj[FIELD_TYPE_PUSHBUTTON] = iArr;
                            sorter.add(obj);
                        }
                    }
                }
            }
        }
        Collections.sort(sorter, new SorterComparator());
        if (!sorter.isEmpty()) {
            if (((long) ((int[]) ((Object[]) sorter.get(sorter.size() - 1))[FIELD_TYPE_PUSHBUTTON])[FIELD_TYPE_NONE]) == this.reader.getFileLength()) {
                this.totalRevisions = sorter.size();
            } else {
                this.totalRevisions = sorter.size() + FIELD_TYPE_PUSHBUTTON;
            }
            for (int k = FIELD_TYPE_NONE; k < sorter.size(); k += FIELD_TYPE_PUSHBUTTON) {
                Object[] objs = (Object[]) sorter.get(k);
                String name = objs[FIELD_TYPE_NONE];
                int[] p = (int[]) objs[FIELD_TYPE_PUSHBUTTON];
                p[FIELD_TYPE_PUSHBUTTON] = k + FIELD_TYPE_PUSHBUTTON;
                this.sigNames.put(name, p);
                this.orderedSignatureNames.add(name);
            }
        }
        return new ArrayList(this.orderedSignatureNames);
    }

    public ArrayList<String> getBlankSignatureNames() {
        getSignatureNames();
        ArrayList<String> sigs = new ArrayList();
        for (Entry<String, Item> entry : this.fields.entrySet()) {
            if (PdfName.SIG.equals(((Item) entry.getValue()).getMerged(FIELD_TYPE_NONE).getAsName(PdfName.FT)) && !this.sigNames.containsKey(entry.getKey())) {
                sigs.add(entry.getKey());
            }
        }
        return sigs;
    }

    public PdfDictionary getSignatureDictionary(String name) {
        getSignatureNames();
        name = getTranslatedFieldName(name);
        if (this.sigNames.containsKey(name)) {
            return ((Item) this.fields.get(name)).getMerged(FIELD_TYPE_NONE).getAsDict(PdfName.f81V);
        }
        return null;
    }

    public PdfIndirectReference getNormalAppearance(String name) {
        getSignatureNames();
        Item item = (Item) this.fields.get(getTranslatedFieldName(name));
        if (item == null) {
            return null;
        }
        PdfDictionary ap = item.getMerged(FIELD_TYPE_NONE).getAsDict(PdfName.AP);
        if (ap == null) {
            return null;
        }
        PdfIndirectReference ref = ap.getAsIndirectObject(PdfName.f73N);
        if (ref == null) {
            return null;
        }
        return ref;
    }

    public boolean signatureCoversWholeDocument(String name) {
        getSignatureNames();
        name = getTranslatedFieldName(name);
        if (!this.sigNames.containsKey(name)) {
            return false;
        }
        return ((long) ((int[]) this.sigNames.get(name))[FIELD_TYPE_NONE]) == this.reader.getFileLength();
    }

    public PdfPKCS7 verifySignature(String name) {
        return verifySignature(name, null);
    }

    public PdfPKCS7 verifySignature(String name, String provider) {
        PdfDictionary v = getSignatureDictionary(name);
        if (v == null) {
            return null;
        }
        try {
            PdfPKCS7 pk;
            PdfName sub = v.getAsName(PdfName.SUBFILTER);
            PdfString contents = v.getAsString(PdfName.CONTENTS);
            if (sub.equals(PdfName.ADBE_X509_RSA_SHA1)) {
                PdfString cert = v.getAsString(PdfName.CERT);
                if (cert == null) {
                    cert = v.getAsArray(PdfName.CERT).getAsString(FIELD_TYPE_NONE);
                }
                pk = new PdfPKCS7(contents.getOriginalBytes(), cert.getBytes(), provider);
            } else {
                pk = new PdfPKCS7(contents.getOriginalBytes(), sub, provider);
            }
            updateByteRange(pk, v);
            PdfString str = v.getAsString(PdfName.f72M);
            if (str != null) {
                pk.setSignDate(PdfDate.decode(str.toString()));
            }
            PdfObject obj = PdfReader.getPdfObject(v.get(PdfName.NAME));
            if (obj != null) {
                if (obj.isString()) {
                    pk.setSignName(((PdfString) obj).toUnicodeString());
                } else if (obj.isName()) {
                    pk.setSignName(PdfName.decodeName(obj.toString()));
                }
            }
            str = v.getAsString(PdfName.REASON);
            if (str != null) {
                pk.setReason(str.toUnicodeString());
            }
            str = v.getAsString(PdfName.LOCATION);
            if (str == null) {
                return pk;
            }
            pk.setLocation(str.toUnicodeString());
            return pk;
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    private void updateByteRange(PdfPKCS7 pkcs7, PdfDictionary v) {
        Exception e;
        Throwable th;
        PdfArray b = v.getAsArray(PdfName.BYTERANGE);
        InputStream inputStream = null;
        try {
            InputStream rg = new RASInputStream(new RandomAccessSourceFactory().createRanged(this.reader.getSafeFile().createSourceView(), b.asLongArray()));
            try {
                byte[] buf = new byte[PdfWriter.HideMenubar];
                while (true) {
                    int rd = rg.read(buf, FIELD_TYPE_NONE, buf.length);
                    if (rd <= 0) {
                        break;
                    }
                    pkcs7.update(buf, FIELD_TYPE_NONE, rd);
                }
                if (rg != null) {
                    try {
                        rg.close();
                    } catch (IOException e2) {
                        throw new ExceptionConverter(e2);
                    }
                }
            } catch (Exception e3) {
                e = e3;
                inputStream = rg;
                try {
                    throw new ExceptionConverter(e);
                } catch (Throwable th2) {
                    th = th2;
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e22) {
                            throw new ExceptionConverter(e22);
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                inputStream = rg;
                if (inputStream != null) {
                    inputStream.close();
                }
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            throw new ExceptionConverter(e);
        }
    }

    private void markUsed(PdfObject obj) {
        if (this.append) {
            ((PdfStamperImp) this.writer).markUsed(obj);
        }
    }

    public int getTotalRevisions() {
        getSignatureNames();
        return this.totalRevisions;
    }

    public int getRevision(String field) {
        getSignatureNames();
        field = getTranslatedFieldName(field);
        if (this.sigNames.containsKey(field)) {
            return ((int[]) this.sigNames.get(field))[FIELD_TYPE_PUSHBUTTON];
        }
        return FIELD_TYPE_NONE;
    }

    public InputStream extractRevision(String field) throws IOException {
        getSignatureNames();
        field = getTranslatedFieldName(field);
        if (!this.sigNames.containsKey(field)) {
            return null;
        }
        return new RASInputStream(new WindowRandomAccessSource(this.reader.getSafeFile().createSourceView(), 0, (long) ((int[]) this.sigNames.get(field))[FIELD_TYPE_NONE]));
    }

    public Map<String, TextField> getFieldCache() {
        return this.fieldCache;
    }

    public void setFieldCache(Map<String, TextField> fieldCache) {
        this.fieldCache = fieldCache;
    }

    public void setExtraMargin(float extraMarginLeft, float extraMarginTop) {
        this.extraMarginLeft = extraMarginLeft;
        this.extraMarginTop = extraMarginTop;
    }

    public void addSubstitutionFont(BaseFont font) {
        if (this.substitutionFonts == null) {
            this.substitutionFonts = new ArrayList();
        }
        this.substitutionFonts.add(font);
    }

    static {
        stdFieldFontNames = new HashMap();
        Object obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.COURIER_BOLDOBLIQUE;
        stdFieldFontNames.put("CoBO", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.COURIER_BOLD;
        stdFieldFontNames.put("CoBo", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.COURIER_OBLIQUE;
        stdFieldFontNames.put("CoOb", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.COURIER;
        stdFieldFontNames.put("Cour", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.HELVETICA_BOLDOBLIQUE;
        stdFieldFontNames.put("HeBO", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.HELVETICA_BOLD;
        stdFieldFontNames.put("HeBo", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.HELVETICA_OBLIQUE;
        stdFieldFontNames.put("HeOb", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.HELVETICA;
        stdFieldFontNames.put("Helv", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.SYMBOL;
        stdFieldFontNames.put("Symb", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.TIMES_BOLDITALIC;
        stdFieldFontNames.put("TiBI", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.TIMES_BOLD;
        stdFieldFontNames.put("TiBo", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.TIMES_ITALIC;
        stdFieldFontNames.put("TiIt", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.TIMES_ROMAN;
        stdFieldFontNames.put("TiRo", obj);
        obj = new String[FIELD_TYPE_PUSHBUTTON];
        obj[FIELD_TYPE_NONE] = BaseFont.ZAPFDINGBATS;
        stdFieldFontNames.put("ZaDb", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "HYSMyeongJo-Medium";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniKS-UCS2-H";
        stdFieldFontNames.put("HySm", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "HYGoThic-Medium";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniKS-UCS2-H";
        stdFieldFontNames.put("HyGo", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "HeiseiKakuGo-W5";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniKS-UCS2-H";
        stdFieldFontNames.put("KaGo", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "HeiseiMin-W3";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniJIS-UCS2-H";
        stdFieldFontNames.put("KaMi", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "MHei-Medium";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniCNS-UCS2-H";
        stdFieldFontNames.put("MHei", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "MSung-Light";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniCNS-UCS2-H";
        stdFieldFontNames.put("MSun", obj);
        obj = new String[FIELD_TYPE_CHECKBOX];
        obj[FIELD_TYPE_NONE] = "STSong-Light";
        obj[FIELD_TYPE_PUSHBUTTON] = "UniGB-UCS2-H";
        stdFieldFontNames.put("STSo", obj);
        PdfName[] pdfNameArr = new PdfName[FIELD_TYPE_COMBO];
        pdfNameArr[FIELD_TYPE_NONE] = PdfName.MK;
        pdfNameArr[FIELD_TYPE_PUSHBUTTON] = PdfName.f67F;
        pdfNameArr[FIELD_TYPE_CHECKBOX] = PdfName.FF;
        pdfNameArr[FIELD_TYPE_RADIOBUTTON] = PdfName.f76Q;
        pdfNameArr[FIELD_TYPE_TEXT] = PdfName.BS;
        pdfNameArr[FIELD_TYPE_LIST] = PdfName.BORDER;
        buttonRemove = pdfNameArr;
    }

    public ArrayList<BaseFont> getSubstitutionFonts() {
        return this.substitutionFonts;
    }

    public void setSubstitutionFonts(ArrayList<BaseFont> substitutionFonts) {
        this.substitutionFonts = substitutionFonts;
    }

    public XfaForm getXfa() {
        return this.xfa;
    }

    public void removeXfa() {
        this.reader.getCatalog().getAsDict(PdfName.ACROFORM).remove(PdfName.XFA);
        try {
            this.xfa = new XfaForm(this.reader);
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public PushbuttonField getNewPushbuttonFromField(String field) {
        return getNewPushbuttonFromField(field, FIELD_TYPE_NONE);
    }

    public PushbuttonField getNewPushbuttonFromField(String field, int order) {
        try {
            if (getFieldType(field) != FIELD_TYPE_PUSHBUTTON) {
                return null;
            }
            Item item = getFieldItem(field);
            if (order >= item.size()) {
                return null;
            }
            Rectangle box = ((FieldPosition) getFieldPositions(field).get(order)).position;
            PushbuttonField newButton = new PushbuttonField(this.writer, box, null);
            PdfDictionary dic = item.getMerged(order);
            decodeGenericDictionary(dic, newButton);
            PdfDictionary mk = dic.getAsDict(PdfName.MK);
            if (mk == null) {
                return newButton;
            }
            PdfString text = mk.getAsString(PdfName.CA);
            if (text != null) {
                newButton.setText(text.toUnicodeString());
            }
            PdfNumber tp = mk.getAsNumber(PdfName.TP);
            if (tp != null) {
                newButton.setLayout(tp.intValue() + FIELD_TYPE_PUSHBUTTON);
            }
            PdfDictionary ifit = mk.getAsDict(PdfName.IF);
            if (ifit != null) {
                PdfName sw = ifit.getAsName(PdfName.SW);
                if (sw != null) {
                    int scale = FIELD_TYPE_PUSHBUTTON;
                    if (sw.equals(PdfName.f63B)) {
                        scale = FIELD_TYPE_RADIOBUTTON;
                    } else {
                        if (sw.equals(PdfName.f78S)) {
                            scale = FIELD_TYPE_TEXT;
                        } else {
                            if (sw.equals(PdfName.f73N)) {
                                scale = FIELD_TYPE_CHECKBOX;
                            }
                        }
                    }
                    newButton.setScaleIcon(scale);
                }
                sw = ifit.getAsName(PdfName.f78S);
                if (sw != null) {
                    if (sw.equals(PdfName.f62A)) {
                        newButton.setProportionalIcon(false);
                    }
                }
                PdfArray aj = ifit.getAsArray(PdfName.f62A);
                if (aj != null && aj.size() == FIELD_TYPE_CHECKBOX) {
                    float left = aj.getAsNumber(FIELD_TYPE_NONE).floatValue();
                    float bottom = aj.getAsNumber(FIELD_TYPE_PUSHBUTTON).floatValue();
                    newButton.setIconHorizontalAdjustment(left);
                    newButton.setIconVerticalAdjustment(bottom);
                }
                PdfBoolean fb = ifit.getAsBoolean(PdfName.FB);
                if (fb != null && fb.booleanValue()) {
                    newButton.setIconFitToBounds(true);
                }
            }
            PdfObject i = mk.get(PdfName.f69I);
            if (i == null || !i.isIndirect()) {
                return newButton;
            }
            newButton.setIconReference((PRIndirectReference) i);
            return newButton;
        } catch (Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public boolean replacePushbuttonField(String field, PdfFormField button) {
        return replacePushbuttonField(field, button, FIELD_TYPE_NONE);
    }

    public boolean replacePushbuttonField(String field, PdfFormField button, int order) {
        if (getFieldType(field) != FIELD_TYPE_PUSHBUTTON) {
            return false;
        }
        Item item = getFieldItem(field);
        if (order >= item.size()) {
            return false;
        }
        PdfDictionary merged = item.getMerged(order);
        PdfDictionary values = item.getValue(order);
        PdfDictionary widgets = item.getWidget(order);
        for (int k = FIELD_TYPE_NONE; k < buttonRemove.length; k += FIELD_TYPE_PUSHBUTTON) {
            merged.remove(buttonRemove[k]);
            values.remove(buttonRemove[k]);
            widgets.remove(buttonRemove[k]);
        }
        for (PdfName key : button.getKeys()) {
            if (!(key.equals(PdfName.f79T) || key.equals(PdfName.RECT))) {
                if (key.equals(PdfName.FF)) {
                    values.put(key, button.get(key));
                } else {
                    widgets.put(key, button.get(key));
                }
                merged.put(key, button.get(key));
                markUsed(values);
                markUsed(widgets);
            }
        }
        return true;
    }

    public boolean doesSignatureFieldExist(String name) {
        return getBlankSignatureNames().contains(name) || getSignatureNames().contains(name);
    }
}

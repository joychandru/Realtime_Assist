package com.itextpdf.text.pdf;

import com.itextpdf.text.error_messages.MessageLocalization;

public class PdfBorderDictionary extends PdfDictionary {
    public static final int STYLE_BEVELED = 2;
    public static final int STYLE_DASHED = 1;
    public static final int STYLE_INSET = 3;
    public static final int STYLE_SOLID = 0;
    public static final int STYLE_UNDERLINE = 4;

    public PdfBorderDictionary(float borderWidth, int borderStyle, PdfDashPattern dashes) {
        put(PdfName.f82W, new PdfNumber(borderWidth));
        switch (borderStyle) {
            case STYLE_SOLID /*0*/:
                put(PdfName.f78S, PdfName.f78S);
            case STYLE_DASHED /*1*/:
                if (dashes != null) {
                    put(PdfName.f65D, dashes);
                }
                put(PdfName.f78S, PdfName.f65D);
            case STYLE_BEVELED /*2*/:
                put(PdfName.f78S, PdfName.f63B);
            case STYLE_INSET /*3*/:
                put(PdfName.f78S, PdfName.f69I);
            case STYLE_UNDERLINE /*4*/:
                put(PdfName.f78S, PdfName.f80U);
            default:
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("invalid.border.style", new Object[STYLE_SOLID]));
        }
    }

    public PdfBorderDictionary(float borderWidth, int borderStyle) {
        this(borderWidth, borderStyle, null);
    }
}

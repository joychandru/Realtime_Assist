package com.itextpdf.text.pdf;

public class PdfOCProperties extends PdfDictionary {
}

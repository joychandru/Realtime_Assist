package com.itextpdf.text.pdf;

import java.io.IOException;
import java.io.OutputStream;

public class PdfGState extends PdfDictionary {
    public static final PdfName BM_COLORBURN;
    public static final PdfName BM_COLORDODGE;
    public static final PdfName BM_COMPATIBLE;
    public static final PdfName BM_DARKEN;
    public static final PdfName BM_DIFFERENCE;
    public static final PdfName BM_EXCLUSION;
    public static final PdfName BM_HARDLIGHT;
    public static final PdfName BM_LIGHTEN;
    public static final PdfName BM_MULTIPLY;
    public static final PdfName BM_NORMAL;
    public static final PdfName BM_OVERLAY;
    public static final PdfName BM_SCREEN;
    public static final PdfName BM_SOFTLIGHT;

    static {
        BM_NORMAL = new PdfName("Normal");
        BM_COMPATIBLE = new PdfName("Compatible");
        BM_MULTIPLY = new PdfName("Multiply");
        BM_SCREEN = new PdfName("Screen");
        BM_OVERLAY = new PdfName("Overlay");
        BM_DARKEN = new PdfName("Darken");
        BM_LIGHTEN = new PdfName("Lighten");
        BM_COLORDODGE = new PdfName("ColorDodge");
        BM_COLORBURN = new PdfName("ColorBurn");
        BM_HARDLIGHT = new PdfName("HardLight");
        BM_SOFTLIGHT = new PdfName("SoftLight");
        BM_DIFFERENCE = new PdfName("Difference");
        BM_EXCLUSION = new PdfName("Exclusion");
    }

    public void setOverPrintStroking(boolean op) {
        put(PdfName.OP, op ? PdfBoolean.PDFTRUE : PdfBoolean.PDFFALSE);
    }

    public void setOverPrintNonStroking(boolean op) {
        put(PdfName.op, op ? PdfBoolean.PDFTRUE : PdfBoolean.PDFFALSE);
    }

    public void setOverPrintMode(int opm) {
        put(PdfName.OPM, new PdfNumber(opm == 0 ? 0 : 1));
    }

    public void setStrokeOpacity(float ca) {
        put(PdfName.CA, new PdfNumber(ca));
    }

    public void setFillOpacity(float ca) {
        put(PdfName.ca, new PdfNumber(ca));
    }

    public void setAlphaIsShape(boolean ais) {
        put(PdfName.AIS, ais ? PdfBoolean.PDFTRUE : PdfBoolean.PDFFALSE);
    }

    public void setTextKnockout(boolean tk) {
        put(PdfName.TK, tk ? PdfBoolean.PDFTRUE : PdfBoolean.PDFFALSE);
    }

    public void setBlendMode(PdfName bm) {
        put(PdfName.BM, bm);
    }

    public void setRenderingIntent(PdfName ri) {
        put(PdfName.RI, ri);
    }

    public void toPdf(PdfWriter writer, OutputStream os) throws IOException {
        PdfWriter.checkPdfIsoConformance(writer, 6, this);
        super.toPdf(writer, os);
    }
}

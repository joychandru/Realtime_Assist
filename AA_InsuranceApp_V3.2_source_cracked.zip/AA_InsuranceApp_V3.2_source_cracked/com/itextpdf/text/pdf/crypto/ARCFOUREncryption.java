package com.itextpdf.text.pdf.crypto;

import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.TIFFConstants;

public class ARCFOUREncryption {
    private byte[] state;
    private int f30x;
    private int f31y;

    public ARCFOUREncryption() {
        this.state = new byte[PdfWriter.PageModeUseThumbs];
    }

    public void prepareARCFOURKey(byte[] key) {
        prepareARCFOURKey(key, 0, key.length);
    }

    public void prepareARCFOURKey(byte[] key, int off, int len) {
        int k;
        int index1 = 0;
        int index2 = 0;
        for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
            this.state[k] = (byte) k;
        }
        this.f30x = 0;
        this.f31y = 0;
        for (k = 0; k < PdfWriter.PageModeUseThumbs; k++) {
            index2 = ((key[index1 + off] + this.state[k]) + index2) & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            byte tmp = this.state[k];
            this.state[k] = this.state[index2];
            this.state[index2] = tmp;
            index1 = (index1 + 1) % len;
        }
    }

    public void encryptARCFOUR(byte[] dataIn, int off, int len, byte[] dataOut, int offOut) {
        int length = len + off;
        for (int k = off; k < length; k++) {
            this.f30x = (this.f30x + 1) & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            this.f31y = (this.state[this.f30x] + this.f31y) & TIFFConstants.TIFFTAG_OSUBFILETYPE;
            byte tmp = this.state[this.f30x];
            this.state[this.f30x] = this.state[this.f31y];
            this.state[this.f31y] = tmp;
            dataOut[(k - off) + offOut] = (byte) (dataIn[k] ^ this.state[(this.state[this.f30x] + this.state[this.f31y]) & TIFFConstants.TIFFTAG_OSUBFILETYPE]);
        }
    }

    public void encryptARCFOUR(byte[] data, int off, int len) {
        encryptARCFOUR(data, off, len, data, off);
    }

    public void encryptARCFOUR(byte[] dataIn, byte[] dataOut) {
        encryptARCFOUR(dataIn, 0, dataIn.length, dataOut, 0);
    }

    public void encryptARCFOUR(byte[] data) {
        encryptARCFOUR(data, 0, data.length, data, 0);
    }
}

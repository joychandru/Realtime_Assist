package com.itextpdf.text.pdf.collection;

import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfString;

public class PdfTargetDictionary extends PdfDictionary {
    public PdfTargetDictionary(PdfTargetDictionary nested) {
        put(PdfName.f77R, PdfName.f75P);
        if (nested != null) {
            setAdditionalPath(nested);
        }
    }

    public PdfTargetDictionary(boolean child) {
        if (child) {
            put(PdfName.f77R, PdfName.f64C);
        } else {
            put(PdfName.f77R, PdfName.f75P);
        }
    }

    public void setEmbeddedFileName(String target) {
        put(PdfName.f73N, new PdfString(target, null));
    }

    public void setFileAttachmentPagename(String name) {
        put(PdfName.f75P, new PdfString(name, null));
    }

    public void setFileAttachmentPage(int page) {
        put(PdfName.f75P, new PdfNumber(page));
    }

    public void setFileAttachmentName(String name) {
        put(PdfName.f62A, new PdfString(name, PdfObject.TEXT_UNICODE));
    }

    public void setFileAttachmentIndex(int annotation) {
        put(PdfName.f62A, new PdfNumber(annotation));
    }

    public void setAdditionalPath(PdfTargetDictionary nested) {
        put(PdfName.f79T, nested);
    }
}

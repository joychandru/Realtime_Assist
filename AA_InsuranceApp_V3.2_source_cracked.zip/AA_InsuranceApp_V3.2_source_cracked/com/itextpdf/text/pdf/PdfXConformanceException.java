package com.itextpdf.text.pdf;

public class PdfXConformanceException extends PdfIsoConformanceException {
    private static final long serialVersionUID = 9199144538884293397L;

    public PdfXConformanceException(String s) {
        super(s);
    }
}

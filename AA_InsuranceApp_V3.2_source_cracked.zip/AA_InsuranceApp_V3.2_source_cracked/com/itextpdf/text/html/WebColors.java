package com.itextpdf.text.html;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Jpeg;
import com.itextpdf.text.error_messages.MessageLocalization;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.TIFFConstants;
import com.itextpdf.xmp.XMPError;
import java.util.HashMap;
import java.util.StringTokenizer;

@Deprecated
public class WebColors extends HashMap<String, int[]> {
    public static final WebColors NAMES;
    private static final long serialVersionUID = 3542523100813372896L;

    static {
        NAMES = new WebColors();
        NAMES.put("aliceblue", new int[]{240, 248, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("antiquewhite", new int[]{250, 235, 215, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("aqua", new int[]{0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("aquamarine", new int[]{127, TIFFConstants.TIFFTAG_OSUBFILETYPE, 212, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("azure", new int[]{240, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("beige", new int[]{245, 245, 220, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("bisque", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 228, 196, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("black", new int[]{0, 0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("blanchedalmond", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 235, 205, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("blue", new int[]{0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("blueviolet", new int[]{138, 43, Jpeg.M_APP2, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("brown", new int[]{165, 42, 42, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("burlywood", new int[]{222, 184, 135, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("cadetblue", new int[]{95, 158, 160, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("chartreuse", new int[]{127, TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("chocolate", new int[]{210, 105, 30, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("coral", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 127, 80, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("cornflowerblue", new int[]{100, 149, Jpeg.M_APPD, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("cornsilk", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 248, 220, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("crimson", new int[]{220, 20, 60, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("cyan", new int[]{0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkblue", new int[]{0, 0, 139, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkcyan", new int[]{0, 139, 139, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkgoldenrod", new int[]{184, 134, 11, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkgray", new int[]{169, 169, 169, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkgreen", new int[]{0, 100, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkkhaki", new int[]{189, 183, XMPError.BADSERIALIZE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkmagenta", new int[]{139, 0, 139, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkolivegreen", new int[]{85, XMPError.BADSERIALIZE, 47, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkorange", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 140, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkorchid", new int[]{153, 50, XMPError.BADSTREAM, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkred", new int[]{139, 0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darksalmon", new int[]{233, 150, 122, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkseagreen", new int[]{143, 188, 143, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkslateblue", new int[]{72, 61, 139, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkslategray", new int[]{47, 79, 79, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkturquoise", new int[]{0, 206, 209, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("darkviolet", new int[]{148, 0, 211, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("deeppink", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 20, 147, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("deepskyblue", new int[]{0, 191, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("dimgray", new int[]{105, 105, 105, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("dodgerblue", new int[]{30, 144, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("firebrick", new int[]{178, 34, 34, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("floralwhite", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 250, 240, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("forestgreen", new int[]{34, 139, 34, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("fuchsia", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("gainsboro", new int[]{220, 220, 220, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("ghostwhite", new int[]{248, 248, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("gold", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 215, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("goldenrod", new int[]{218, 165, 32, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("gray", new int[]{PdfWriter.PageModeUseOutlines, PdfWriter.PageModeUseOutlines, PdfWriter.PageModeUseOutlines, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("green", new int[]{0, PdfWriter.PageModeUseOutlines, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("greenyellow", new int[]{173, TIFFConstants.TIFFTAG_OSUBFILETYPE, 47, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("honeydew", new int[]{240, TIFFConstants.TIFFTAG_OSUBFILETYPE, 240, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("hotpink", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 105, 180, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("indianred", new int[]{205, 92, 92, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("indigo", new int[]{75, 0, 130, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("ivory", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, 240, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("khaki", new int[]{240, 230, 140, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lavender", new int[]{230, 230, 250, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lavenderblush", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 240, 245, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lawngreen", new int[]{124, 252, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lemonchiffon", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 250, 205, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightblue", new int[]{173, 216, 230, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightcoral", new int[]{240, PdfWriter.PageModeUseOutlines, PdfWriter.PageModeUseOutlines, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightcyan", new int[]{Jpeg.M_APP0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightgoldenrodyellow", new int[]{250, 250, 210, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightgreen", new int[]{144, Jpeg.M_APPE, 144, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightgrey", new int[]{211, 211, 211, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightpink", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 182, 193, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightsalmon", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 160, 122, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightseagreen", new int[]{32, 178, 170, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightskyblue", new int[]{135, 206, 250, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightslategray", new int[]{119, 136, 153, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightsteelblue", new int[]{176, 196, 222, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lightyellow", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, Jpeg.M_APP0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("lime", new int[]{0, TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("limegreen", new int[]{50, 205, 50, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("linen", new int[]{250, 240, 230, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("magenta", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("maroon", new int[]{PdfWriter.PageModeUseOutlines, 0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumaquamarine", new int[]{XMPError.BADXPATH, 205, 170, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumblue", new int[]{0, 0, 205, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumorchid", new int[]{186, 85, 211, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumpurple", new int[]{147, 112, 219, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumseagreen", new int[]{60, 179, 113, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumslateblue", new int[]{123, XMPError.BADINDEX, Jpeg.M_APPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumspringgreen", new int[]{0, 250, 154, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumturquoise", new int[]{72, 209, XMPError.BADSTREAM, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mediumvioletred", new int[]{199, 21, 133, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("midnightblue", new int[]{25, 25, 112, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mintcream", new int[]{245, TIFFConstants.TIFFTAG_OSUBFILETYPE, 250, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("mistyrose", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 228, 225, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("moccasin", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 228, 181, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("navajowhite", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 222, 173, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("navy", new int[]{0, 0, PdfWriter.PageModeUseOutlines, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("oldlace", new int[]{253, 245, 230, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("olive", new int[]{PdfWriter.PageModeUseOutlines, PdfWriter.PageModeUseOutlines, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("olivedrab", new int[]{XMPError.BADSERIALIZE, 142, 35, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("orange", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 165, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("orangered", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 69, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("orchid", new int[]{218, 112, 214, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("palegoldenrod", new int[]{Jpeg.M_APPE, 232, 170, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("palegreen", new int[]{152, 251, 152, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("paleturquoise", new int[]{175, Jpeg.M_APPE, Jpeg.M_APPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("palevioletred", new int[]{219, 112, 147, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("papayawhip", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 239, 213, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("peachpuff", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 218, 185, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("peru", new int[]{205, 133, 63, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("pink", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 192, XMPError.BADXMP, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("plum", new int[]{221, 160, 221, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("powderblue", new int[]{176, Jpeg.M_APP0, 230, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("purple", new int[]{PdfWriter.PageModeUseOutlines, 0, PdfWriter.PageModeUseOutlines, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("red", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("rosybrown", new int[]{188, 143, 143, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("royalblue", new int[]{65, 105, 225, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("saddlebrown", new int[]{139, 69, 19, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("salmon", new int[]{250, PdfWriter.PageModeUseOutlines, 114, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("sandybrown", new int[]{244, 164, 96, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("seagreen", new int[]{46, 139, 87, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("seashell", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 245, Jpeg.M_APPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("sienna", new int[]{160, 82, 45, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("silver", new int[]{192, 192, 192, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("skyblue", new int[]{135, 206, 235, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("slateblue", new int[]{106, 90, 205, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("slategray", new int[]{112, PdfWriter.PageModeUseOutlines, 144, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("snow", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 250, 250, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("springgreen", new int[]{0, TIFFConstants.TIFFTAG_OSUBFILETYPE, 127, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("steelblue", new int[]{70, 130, 180, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("tan", new int[]{210, 180, 140, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("teal", new int[]{0, PdfWriter.PageModeUseOutlines, PdfWriter.PageModeUseOutlines, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("thistle", new int[]{216, 191, 216, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("tomato", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, 99, 71, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("transparent", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, 0});
        NAMES.put("turquoise", new int[]{64, Jpeg.M_APP0, 208, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("violet", new int[]{Jpeg.M_APPE, 130, Jpeg.M_APPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("wheat", new int[]{245, 222, 179, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("white", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("whitesmoke", new int[]{245, 245, 245, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("yellow", new int[]{TIFFConstants.TIFFTAG_OSUBFILETYPE, TIFFConstants.TIFFTAG_OSUBFILETYPE, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE});
        NAMES.put("yellowgreen", new int[]{154, 205, 50, TIFFConstants.TIFFTAG_OSUBFILETYPE});
    }

    private static boolean missingHashColorFormat(String colStr) {
        int len = colStr.length();
        if (len == 3 || len == 6) {
            return colStr.matches("[0-9a-f]{" + len + "}");
        }
        return false;
    }

    public static BaseColor getRGBColor(String name) {
        int[] color = new int[]{0, 0, 0, TIFFConstants.TIFFTAG_OSUBFILETYPE};
        String colorName = name.toLowerCase();
        boolean colorStrWithoutHash = missingHashColorFormat(colorName);
        if (colorName.startsWith("#") || colorStrWithoutHash) {
            if (!colorStrWithoutHash) {
                colorName = colorName.substring(1);
            }
            if (colorName.length() == 3) {
                String red = colorName.substring(0, 1);
                color[0] = Integer.parseInt(red + red, 16);
                String green = colorName.substring(1, 2);
                color[1] = Integer.parseInt(green + green, 16);
                String blue = colorName.substring(2);
                color[2] = Integer.parseInt(blue + blue, 16);
                return new BaseColor(color[0], color[1], color[2], color[3]);
            } else if (colorName.length() == 6) {
                color[0] = Integer.parseInt(colorName.substring(0, 2), 16);
                color[1] = Integer.parseInt(colorName.substring(2, 4), 16);
                color[2] = Integer.parseInt(colorName.substring(4), 16);
                return new BaseColor(color[0], color[1], color[2], color[3]);
            } else {
                throw new IllegalArgumentException(MessageLocalization.getComposedMessage("unknown.color.format.must.be.rgb.or.rrggbb", new Object[0]));
            }
        } else if (colorName.startsWith("rgb(")) {
            String delim = "rgb(), \t\r\n\f";
            StringTokenizer tok = new StringTokenizer(colorName, "rgb(), \t\r\n\f");
            for (int k = 0; k < 3; k++) {
                if (tok.hasMoreElements()) {
                    color[k] = getRGBChannelValue(tok.nextToken());
                    color[k] = Math.max(0, color[k]);
                    color[k] = Math.min(TIFFConstants.TIFFTAG_OSUBFILETYPE, color[k]);
                }
            }
            return new BaseColor(color[0], color[1], color[2], color[3]);
        } else if (NAMES.containsKey(colorName)) {
            color = (int[]) NAMES.get(colorName);
            return new BaseColor(color[0], color[1], color[2], color[3]);
        } else {
            throw new IllegalArgumentException(MessageLocalization.getComposedMessage("color.not.found", colorName));
        }
    }

    private static int getRGBChannelValue(String rgbChannel) {
        if (rgbChannel.endsWith("%")) {
            return (Integer.parseInt(rgbChannel.substring(0, rgbChannel.length() - 1)) * TIFFConstants.TIFFTAG_OSUBFILETYPE) / 100;
        }
        return Integer.parseInt(rgbChannel);
    }
}

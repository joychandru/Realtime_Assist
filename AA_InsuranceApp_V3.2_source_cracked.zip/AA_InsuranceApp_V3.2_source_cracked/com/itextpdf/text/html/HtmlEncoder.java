package com.itextpdf.text.html;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.collection.PdfCollectionField;
import java.util.HashSet;
import java.util.Set;

@Deprecated
public final class HtmlEncoder {
    private static final String[] HTML_CODE;
    private static final Set<String> NEWLINETAGS;

    private HtmlEncoder() {
    }

    static {
        int i;
        HTML_CODE = new String[PdfWriter.PageModeUseThumbs];
        for (i = 0; i < 10; i++) {
            HTML_CODE[i] = "&#00" + i + ";";
        }
        for (i = 10; i < 32; i++) {
            HTML_CODE[i] = "&#0" + i + ";";
        }
        for (i = 32; i < PdfWriter.PageModeUseOutlines; i++) {
            HTML_CODE[i] = String.valueOf((char) i);
        }
        HTML_CODE[9] = "\t";
        HTML_CODE[10] = "<br />\n";
        HTML_CODE[34] = "&quot;";
        HTML_CODE[38] = "&amp;";
        HTML_CODE[60] = "&lt;";
        HTML_CODE[62] = "&gt;";
        for (i = PdfWriter.PageModeUseOutlines; i < PdfWriter.PageModeUseThumbs; i++) {
            HTML_CODE[i] = "&#" + i + ";";
        }
        NEWLINETAGS = new HashSet();
        NEWLINETAGS.add(HtmlTags.f3P);
        NEWLINETAGS.add(HtmlTags.BLOCKQUOTE);
        NEWLINETAGS.add(HtmlTags.BR);
    }

    public static String encode(String string) {
        int n = string.length();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < n; i++) {
            char character = string.charAt(i);
            if (character < '\u0100') {
                buffer.append(HTML_CODE[character]);
            } else {
                buffer.append("&#").append(character).append(';');
            }
        }
        return buffer.toString();
    }

    public static String encode(BaseColor color) {
        StringBuffer buffer = new StringBuffer("#");
        if (color.getRed() < 16) {
            buffer.append('0');
        }
        buffer.append(Integer.toString(color.getRed(), 16));
        if (color.getGreen() < 16) {
            buffer.append('0');
        }
        buffer.append(Integer.toString(color.getGreen(), 16));
        if (color.getBlue() < 16) {
            buffer.append('0');
        }
        buffer.append(Integer.toString(color.getBlue(), 16));
        return buffer.toString();
    }

    public static String getAlignment(int alignment) {
        switch (alignment) {
            case PdfWriter.markAll /*0*/:
                return HtmlTags.ALIGN_LEFT;
            case PdfWriter.markInlineElementsOnly /*1*/:
                return HtmlTags.ALIGN_CENTER;
            case PdfWriter.SIGNATURE_APPEND_ONLY /*2*/:
                return HtmlTags.ALIGN_RIGHT;
            case PdfWriter.RUN_DIRECTION_RTL /*3*/:
            case PdfWriter.PageLayoutTwoColumnRight /*8*/:
                return HtmlTags.ALIGN_JUSTIFY;
            case PdfWriter.PageLayoutTwoColumnLeft /*4*/:
                return HtmlTags.ALIGN_TOP;
            case PdfFormField.MK_CAPTION_LEFT /*5*/:
                return HtmlTags.ALIGN_MIDDLE;
            case PdfFormField.MK_CAPTION_OVERLAID /*6*/:
                return HtmlTags.ALIGN_BOTTOM;
            case PdfCollectionField.SIZE /*7*/:
                return HtmlTags.ALIGN_BASELINE;
            default:
                return PdfObject.NOTHING;
        }
    }

    public static boolean isNewLineTag(String tag) {
        return NEWLINETAGS.contains(tag);
    }
}

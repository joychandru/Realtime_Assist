package com.itextpdf.text.html.simpleparser;

import com.itextpdf.text.Image;
import java.util.HashMap;

@Deprecated
public class ImageStore extends HashMap<String, Image> {
    private static final long serialVersionUID = -148924031490995024L;
}

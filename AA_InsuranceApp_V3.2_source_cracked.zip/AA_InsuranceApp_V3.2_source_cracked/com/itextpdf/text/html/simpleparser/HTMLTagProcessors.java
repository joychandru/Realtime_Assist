package com.itextpdf.text.html.simpleparser;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.text.pdf.BaseFont;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Deprecated
public class HTMLTagProcessors extends HashMap<String, HTMLTagProcessor> {
    public static final HTMLTagProcessor f6A;
    public static final HTMLTagProcessor BR;
    public static final HTMLTagProcessor DIV;
    public static final HTMLTagProcessor EM_STRONG_STRIKE_SUP_SUP;
    public static final HTMLTagProcessor f7H;
    public static final HTMLTagProcessor HR;
    public static final HTMLTagProcessor IMG;
    public static final HTMLTagProcessor LI;
    public static final HTMLTagProcessor PRE;
    public static final HTMLTagProcessor SPAN;
    public static final HTMLTagProcessor TABLE;
    public static final HTMLTagProcessor TD;
    public static final HTMLTagProcessor TR;
    public static final HTMLTagProcessor UL_OL;
    private static final long serialVersionUID = -959260811961222824L;

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.1 */
    static class C00481 implements HTMLTagProcessor {
        C00481() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) {
            tag = mapTag(tag);
            attrs.put(tag, null);
            worker.updateChain(tag, attrs);
        }

        public void endElement(HTMLWorker worker, String tag) {
            worker.updateChain(mapTag(tag));
        }

        private String mapTag(String tag) {
            if (HtmlTags.EM.equalsIgnoreCase(tag)) {
                return HtmlTags.f2I;
            }
            if (HtmlTags.STRONG.equalsIgnoreCase(tag)) {
                return HtmlTags.f1B;
            }
            if (HtmlTags.STRIKE.equalsIgnoreCase(tag)) {
                return HtmlTags.f4S;
            }
            return tag;
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.2 */
    static class C00492 implements HTMLTagProcessor {
        C00492() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) {
            worker.updateChain(tag, attrs);
            worker.flushContent();
        }

        public void endElement(HTMLWorker worker, String tag) {
            worker.processLink();
            worker.updateChain(tag);
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.3 */
    static class C00503 implements HTMLTagProcessor {
        C00503() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> map) {
            worker.newLine();
        }

        public void endElement(HTMLWorker worker, String tag) {
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.4 */
    static class C00514 implements HTMLTagProcessor {
        C00514() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
            worker.carriageReturn();
            if (worker.isPendingLI()) {
                worker.endElement(HtmlTags.LI);
            }
            worker.setSkipText(true);
            worker.updateChain(tag, attrs);
            worker.pushToStack(worker.createList(tag));
        }

        public void endElement(HTMLWorker worker, String tag) throws DocumentException {
            worker.carriageReturn();
            if (worker.isPendingLI()) {
                worker.endElement(HtmlTags.LI);
            }
            worker.setSkipText(false);
            worker.updateChain(tag);
            worker.processList();
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.5 */
    static class C00525 implements HTMLTagProcessor {
        C00525() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
            worker.carriageReturn();
            worker.pushToStack(worker.createLineSeparator(attrs));
        }

        public void endElement(HTMLWorker worker, String tag) {
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.6 */
    static class C00536 implements HTMLTagProcessor {
        C00536() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) {
            worker.updateChain(tag, attrs);
        }

        public void endElement(HTMLWorker worker, String tag) {
            worker.updateChain(tag);
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.7 */
    static class C00547 implements HTMLTagProcessor {
        C00547() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
            worker.carriageReturn();
            if (!attrs.containsKey(HtmlTags.SIZE)) {
                attrs.put(HtmlTags.SIZE, Integer.toString(7 - Integer.parseInt(tag.substring(1))));
            }
            worker.updateChain(tag, attrs);
        }

        public void endElement(HTMLWorker worker, String tag) throws DocumentException {
            worker.carriageReturn();
            worker.updateChain(tag);
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.8 */
    static class C00558 implements HTMLTagProcessor {
        C00558() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
            worker.carriageReturn();
            if (worker.isPendingLI()) {
                worker.endElement(tag);
            }
            worker.setSkipText(false);
            worker.setPendingLI(true);
            worker.updateChain(tag, attrs);
            worker.pushToStack(worker.createListItem());
        }

        public void endElement(HTMLWorker worker, String tag) throws DocumentException {
            worker.carriageReturn();
            worker.setPendingLI(false);
            worker.setSkipText(true);
            worker.updateChain(tag);
            worker.processListItem();
        }
    }

    /* renamed from: com.itextpdf.text.html.simpleparser.HTMLTagProcessors.9 */
    static class C00569 implements HTMLTagProcessor {
        C00569() {
        }

        public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
            worker.carriageReturn();
            if (!attrs.containsKey(HtmlTags.FACE)) {
                attrs.put(HtmlTags.FACE, BaseFont.COURIER);
            }
            worker.updateChain(tag, attrs);
            worker.setInsidePRE(true);
        }

        public void endElement(HTMLWorker worker, String tag) throws DocumentException {
            worker.carriageReturn();
            worker.updateChain(tag);
            worker.setInsidePRE(false);
        }
    }

    public HTMLTagProcessors() {
        put(HtmlTags.f0A, f6A);
        put(HtmlTags.f1B, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.BODY, DIV);
        put(HtmlTags.BR, BR);
        put(HtmlTags.DIV, DIV);
        put(HtmlTags.EM, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.FONT, SPAN);
        put(HtmlTags.H1, f7H);
        put(HtmlTags.H2, f7H);
        put(HtmlTags.H3, f7H);
        put(HtmlTags.H4, f7H);
        put(HtmlTags.H5, f7H);
        put(HtmlTags.H6, f7H);
        put(HtmlTags.HR, HR);
        put(HtmlTags.f2I, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.IMG, IMG);
        put(HtmlTags.LI, LI);
        put(HtmlTags.OL, UL_OL);
        put(HtmlTags.f3P, DIV);
        put(HtmlTags.PRE, PRE);
        put(HtmlTags.f4S, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.SPAN, SPAN);
        put(HtmlTags.STRIKE, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.STRONG, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.SUB, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.SUP, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.TABLE, TABLE);
        put(HtmlTags.TD, TD);
        put(HtmlTags.TH, TD);
        put(HtmlTags.TR, TR);
        put(HtmlTags.f5U, EM_STRONG_STRIKE_SUP_SUP);
        put(HtmlTags.UL, UL_OL);
    }

    static {
        EM_STRONG_STRIKE_SUP_SUP = new C00481();
        f6A = new C00492();
        BR = new C00503();
        UL_OL = new C00514();
        HR = new C00525();
        SPAN = new C00536();
        f7H = new C00547();
        LI = new C00558();
        PRE = new C00569();
        DIV = new HTMLTagProcessor() {
            public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
                worker.carriageReturn();
                worker.updateChain(tag, attrs);
            }

            public void endElement(HTMLWorker worker, String tag) throws DocumentException {
                worker.carriageReturn();
                worker.updateChain(tag);
            }
        };
        TABLE = new HTMLTagProcessor() {
            public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
                worker.carriageReturn();
                worker.pushToStack(new TableWrapper(attrs));
                worker.pushTableState();
                worker.setPendingTD(false);
                worker.setPendingTR(false);
                worker.setSkipText(true);
                attrs.remove(HtmlTags.ALIGN);
                attrs.put(HtmlTags.COLSPAN, "1");
                attrs.put(HtmlTags.ROWSPAN, "1");
                worker.updateChain(tag, attrs);
            }

            public void endElement(HTMLWorker worker, String tag) throws DocumentException {
                worker.carriageReturn();
                if (worker.isPendingTR()) {
                    worker.endElement(HtmlTags.TR);
                }
                worker.updateChain(tag);
                worker.processTable();
                worker.popTableState();
                worker.setSkipText(false);
            }
        };
        TR = new HTMLTagProcessor() {
            public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
                worker.carriageReturn();
                if (worker.isPendingTR()) {
                    worker.endElement(tag);
                }
                worker.setSkipText(true);
                worker.setPendingTR(true);
                worker.updateChain(tag, attrs);
            }

            public void endElement(HTMLWorker worker, String tag) throws DocumentException {
                worker.carriageReturn();
                if (worker.isPendingTD()) {
                    worker.endElement(HtmlTags.TD);
                }
                worker.setPendingTR(false);
                worker.updateChain(tag);
                worker.processRow();
                worker.setSkipText(true);
            }
        };
        TD = new HTMLTagProcessor() {
            public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException {
                worker.carriageReturn();
                if (worker.isPendingTD()) {
                    worker.endElement(tag);
                }
                worker.setSkipText(false);
                worker.setPendingTD(true);
                worker.updateChain(HtmlTags.TD, attrs);
                worker.pushToStack(worker.createCell(tag));
            }

            public void endElement(HTMLWorker worker, String tag) throws DocumentException {
                worker.carriageReturn();
                worker.setPendingTD(false);
                worker.updateChain(HtmlTags.TD);
                worker.setSkipText(true);
            }
        };
        IMG = new HTMLTagProcessor() {
            public void startElement(HTMLWorker worker, String tag, Map<String, String> attrs) throws DocumentException, IOException {
                worker.updateChain(tag, attrs);
                worker.processImage(worker.createImage(attrs), attrs);
                worker.updateChain(tag);
            }

            public void endElement(HTMLWorker worker, String tag) {
            }
        };
    }
}

package com.itextpdf.awt.geom;

import java.io.Serializable;

public class Point extends Point2D implements Serializable {
    private static final long serialVersionUID = -5276940640259749850L;
    public double f53x;
    public double f54y;

    public Point() {
        setLocation(0, 0);
    }

    public Point(int x, int y) {
        setLocation(x, y);
    }

    public Point(double x, double y) {
        setLocation(x, y);
    }

    public Point(Point p) {
        setLocation(p.f53x, p.f54y);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Point)) {
            return false;
        }
        Point p = (Point) obj;
        if (this.f53x == p.f53x && this.f54y == p.f54y) {
            return true;
        }
        return false;
    }

    public String toString() {
        return getClass().getName() + "[x=" + this.f53x + ",y=" + this.f54y + "]";
    }

    public double getX() {
        return this.f53x;
    }

    public double getY() {
        return this.f54y;
    }

    public Point getLocation() {
        return new Point(this.f53x, this.f54y);
    }

    public void setLocation(Point p) {
        setLocation(p.f53x, p.f54y);
    }

    public void setLocation(int x, int y) {
        setLocation((double) x, (double) y);
    }

    public void setLocation(double x, double y) {
        this.f53x = x;
        this.f54y = y;
    }

    public void move(int x, int y) {
        move((double) x, (double) y);
    }

    public void move(double x, double y) {
        setLocation(x, y);
    }

    public void translate(int dx, int dy) {
        translate((double) dx, (double) dy);
    }

    public void translate(double dx, double dy) {
        this.f53x += dx;
        this.f54y += dy;
    }
}

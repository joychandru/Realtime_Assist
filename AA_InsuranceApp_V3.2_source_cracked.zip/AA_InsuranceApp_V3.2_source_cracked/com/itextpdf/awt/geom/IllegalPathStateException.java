package com.itextpdf.awt.geom;

public class IllegalPathStateException extends RuntimeException {
    private static final long serialVersionUID = -5158084205220481094L;

    public IllegalPathStateException(String s) {
        super(s);
    }
}

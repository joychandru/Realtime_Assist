package com.itextpdf.awt.geom;

import com.itextpdf.awt.geom.misc.HashCode;
import com.itextpdf.awt.geom.misc.Messages;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.NoSuchElementException;

public abstract class Rectangle2D extends RectangularShape {
    public static final int OUT_BOTTOM = 8;
    public static final int OUT_LEFT = 1;
    public static final int OUT_RIGHT = 4;
    public static final int OUT_TOP = 2;

    class Iterator implements PathIterator {
        double height;
        int index;
        AffineTransform f57t;
        double width;
        double f58x;
        double f59y;

        Iterator(Rectangle2D r, AffineTransform at) {
            this.f58x = r.getX();
            this.f59y = r.getY();
            this.width = r.getWidth();
            this.height = r.getHeight();
            this.f57t = at;
            if (this.width < 0.0d || this.height < 0.0d) {
                this.index = 6;
            }
        }

        public int getWindingRule() {
            return Rectangle2D.OUT_LEFT;
        }

        public boolean isDone() {
            return this.index > 5;
        }

        public void next() {
            this.index += Rectangle2D.OUT_LEFT;
        }

        public int currentSegment(double[] coords) {
            if (isDone()) {
                throw new NoSuchElementException(Messages.getString("awt.4B"));
            } else if (this.index == 5) {
                return Rectangle2D.OUT_RIGHT;
            } else {
                int type;
                if (this.index != 0) {
                    type = Rectangle2D.OUT_LEFT;
                    switch (this.index) {
                        case Rectangle2D.OUT_LEFT /*1*/:
                            coords[0] = this.f58x + this.width;
                            coords[Rectangle2D.OUT_LEFT] = this.f59y;
                            break;
                        case Rectangle2D.OUT_TOP /*2*/:
                            coords[0] = this.f58x + this.width;
                            coords[Rectangle2D.OUT_LEFT] = this.f59y + this.height;
                            break;
                        case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                            coords[0] = this.f58x;
                            coords[Rectangle2D.OUT_LEFT] = this.f59y + this.height;
                            break;
                        case Rectangle2D.OUT_RIGHT /*4*/:
                            coords[0] = this.f58x;
                            coords[Rectangle2D.OUT_LEFT] = this.f59y;
                            break;
                        default:
                            break;
                    }
                }
                type = 0;
                coords[0] = this.f58x;
                coords[Rectangle2D.OUT_LEFT] = this.f59y;
                if (this.f57t == null) {
                    return type;
                }
                this.f57t.transform(coords, 0, coords, 0, (int) Rectangle2D.OUT_LEFT);
                return type;
            }
        }

        public int currentSegment(float[] coords) {
            if (isDone()) {
                throw new NoSuchElementException(Messages.getString("awt.4B"));
            } else if (this.index == 5) {
                return Rectangle2D.OUT_RIGHT;
            } else {
                int type;
                if (this.index != 0) {
                    type = Rectangle2D.OUT_LEFT;
                    switch (this.index) {
                        case Rectangle2D.OUT_LEFT /*1*/:
                            coords[0] = (float) (this.f58x + this.width);
                            coords[Rectangle2D.OUT_LEFT] = (float) this.f59y;
                            break;
                        case Rectangle2D.OUT_TOP /*2*/:
                            coords[0] = (float) (this.f58x + this.width);
                            coords[Rectangle2D.OUT_LEFT] = (float) (this.f59y + this.height);
                            break;
                        case PdfWriter.RUN_DIRECTION_RTL /*3*/:
                            coords[0] = (float) this.f58x;
                            coords[Rectangle2D.OUT_LEFT] = (float) (this.f59y + this.height);
                            break;
                        case Rectangle2D.OUT_RIGHT /*4*/:
                            coords[0] = (float) this.f58x;
                            coords[Rectangle2D.OUT_LEFT] = (float) this.f59y;
                            break;
                        default:
                            break;
                    }
                }
                coords[0] = (float) this.f58x;
                coords[Rectangle2D.OUT_LEFT] = (float) this.f59y;
                type = 0;
                if (this.f57t == null) {
                    return type;
                }
                this.f57t.transform(coords, 0, coords, 0, (int) Rectangle2D.OUT_LEFT);
                return type;
            }
        }
    }

    public static class Double extends Rectangle2D {
        public double height;
        public double width;
        public double f88x;
        public double f89y;

        public Double(double x, double y, double width, double height) {
            setRect(x, y, width, height);
        }

        public double getX() {
            return this.f88x;
        }

        public double getY() {
            return this.f89y;
        }

        public double getWidth() {
            return this.width;
        }

        public double getHeight() {
            return this.height;
        }

        public boolean isEmpty() {
            return this.width <= 0.0d || this.height <= 0.0d;
        }

        public void setRect(double x, double y, double width, double height) {
            this.f88x = x;
            this.f89y = y;
            this.width = width;
            this.height = height;
        }

        public void setRect(Rectangle2D r) {
            this.f88x = r.getX();
            this.f89y = r.getY();
            this.width = r.getWidth();
            this.height = r.getHeight();
        }

        public int outcode(double px, double py) {
            int code = 0;
            if (this.width <= 0.0d) {
                code = 0 | 5;
            } else if (px < this.f88x) {
                code = 0 | Rectangle2D.OUT_LEFT;
            } else if (px > this.f88x + this.width) {
                code = 0 | Rectangle2D.OUT_RIGHT;
            }
            if (this.height <= 0.0d) {
                return code | 10;
            }
            if (py < this.f89y) {
                return code | Rectangle2D.OUT_TOP;
            }
            if (py > this.f89y + this.height) {
                return code | Rectangle2D.OUT_BOTTOM;
            }
            return code;
        }

        public Rectangle2D getBounds2D() {
            return new Double(this.f88x, this.f89y, this.width, this.height);
        }

        public Rectangle2D createIntersection(Rectangle2D r) {
            Rectangle2D dst = new Double();
            Rectangle2D.intersect(this, r, dst);
            return dst;
        }

        public Rectangle2D createUnion(Rectangle2D r) {
            Rectangle2D dest = new Double();
            Rectangle2D.union(this, r, dest);
            return dest;
        }

        public String toString() {
            return getClass().getName() + "[x=" + this.f88x + ",y=" + this.f89y + ",width=" + this.width + ",height=" + this.height + "]";
        }
    }

    public static class Float extends Rectangle2D {
        public float height;
        public float width;
        public float f90x;
        public float f91y;

        public Float(float x, float y, float width, float height) {
            setRect(x, y, width, height);
        }

        public double getX() {
            return (double) this.f90x;
        }

        public double getY() {
            return (double) this.f91y;
        }

        public double getWidth() {
            return (double) this.width;
        }

        public double getHeight() {
            return (double) this.height;
        }

        public boolean isEmpty() {
            return this.width <= 0.0f || this.height <= 0.0f;
        }

        public void setRect(float x, float y, float width, float height) {
            this.f90x = x;
            this.f91y = y;
            this.width = width;
            this.height = height;
        }

        public void setRect(double x, double y, double width, double height) {
            this.f90x = (float) x;
            this.f91y = (float) y;
            this.width = (float) width;
            this.height = (float) height;
        }

        public void setRect(Rectangle2D r) {
            this.f90x = (float) r.getX();
            this.f91y = (float) r.getY();
            this.width = (float) r.getWidth();
            this.height = (float) r.getHeight();
        }

        public int outcode(double px, double py) {
            int code = 0;
            if (this.width <= 0.0f) {
                code = 0 | 5;
            } else if (px < ((double) this.f90x)) {
                code = 0 | Rectangle2D.OUT_LEFT;
            } else if (px > ((double) (this.f90x + this.width))) {
                code = 0 | Rectangle2D.OUT_RIGHT;
            }
            if (this.height <= 0.0f) {
                return code | 10;
            }
            if (py < ((double) this.f91y)) {
                return code | Rectangle2D.OUT_TOP;
            }
            if (py > ((double) (this.f91y + this.height))) {
                return code | Rectangle2D.OUT_BOTTOM;
            }
            return code;
        }

        public Rectangle2D getBounds2D() {
            return new Float(this.f90x, this.f91y, this.width, this.height);
        }

        public Rectangle2D createIntersection(Rectangle2D r) {
            Rectangle2D dst;
            if (r instanceof Double) {
                dst = new Double();
            } else {
                dst = new Float();
            }
            Rectangle2D.intersect(this, r, dst);
            return dst;
        }

        public Rectangle2D createUnion(Rectangle2D r) {
            Rectangle2D dst;
            if (r instanceof Double) {
                dst = new Double();
            } else {
                dst = new Float();
            }
            Rectangle2D.union(this, r, dst);
            return dst;
        }

        public String toString() {
            return getClass().getName() + "[x=" + this.f90x + ",y=" + this.f91y + ",width=" + this.width + ",height=" + this.height + "]";
        }
    }

    public abstract Rectangle2D createIntersection(Rectangle2D rectangle2D);

    public abstract Rectangle2D createUnion(Rectangle2D rectangle2D);

    public abstract int outcode(double d, double d2);

    public abstract void setRect(double d, double d2, double d3, double d4);

    protected Rectangle2D() {
    }

    public void setRect(Rectangle2D r) {
        setRect(r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }

    public void setFrame(double x, double y, double width, double height) {
        setRect(x, y, width, height);
    }

    public Rectangle2D getBounds2D() {
        return (Rectangle2D) clone();
    }

    public boolean intersectsLine(double x1, double y1, double x2, double y2) {
        double rx1 = getX();
        double ry1 = getY();
        double rx2 = rx1 + getWidth();
        double ry2 = ry1 + getHeight();
        return (rx1 <= x1 && x1 <= rx2 && ry1 <= y1 && y1 <= ry2) || ((rx1 <= x2 && x2 <= rx2 && ry1 <= y2 && y2 <= ry2) || Line2D.linesIntersect(rx1, ry1, rx2, ry2, x1, y1, x2, y2) || Line2D.linesIntersect(rx2, ry1, rx1, ry2, x1, y1, x2, y2));
    }

    public boolean intersectsLine(Line2D l) {
        return intersectsLine(l.getX1(), l.getY1(), l.getX2(), l.getY2());
    }

    public int outcode(Point2D p) {
        return outcode(p.getX(), p.getY());
    }

    public boolean contains(double x, double y) {
        if (isEmpty()) {
            return false;
        }
        double x1 = getX();
        double y1 = getY();
        double x2 = x1 + getWidth();
        double y2 = y1 + getHeight();
        if (x1 > x || x >= x2 || y1 > y || y >= y2) {
            return false;
        }
        return true;
    }

    public boolean intersects(double x, double y, double width, double height) {
        if (isEmpty() || width <= 0.0d || height <= 0.0d) {
            return false;
        }
        double x1 = getX();
        double y1 = getY();
        return x + width > x1 && x < x1 + getWidth() && y + height > y1 && y < y1 + getHeight();
    }

    public boolean contains(double x, double y, double width, double height) {
        if (isEmpty() || width <= 0.0d || height <= 0.0d) {
            return false;
        }
        double x1 = getX();
        double y1 = getY();
        return x1 <= x && x + width <= x1 + getWidth() && y1 <= y && y + height <= y1 + getHeight();
    }

    public static void intersect(Rectangle2D src1, Rectangle2D src2, Rectangle2D dst) {
        double x1 = Math.max(src1.getMinX(), src2.getMinX());
        double y1 = Math.max(src1.getMinY(), src2.getMinY());
        Rectangle2D rectangle2D = dst;
        rectangle2D.setFrame(x1, y1, Math.min(src1.getMaxX(), src2.getMaxX()) - x1, Math.min(src1.getMaxY(), src2.getMaxY()) - y1);
    }

    public static void union(Rectangle2D src1, Rectangle2D src2, Rectangle2D dst) {
        double x1 = Math.min(src1.getMinX(), src2.getMinX());
        double y1 = Math.min(src1.getMinY(), src2.getMinY());
        Rectangle2D rectangle2D = dst;
        rectangle2D.setFrame(x1, y1, Math.max(src1.getMaxX(), src2.getMaxX()) - x1, Math.max(src1.getMaxY(), src2.getMaxY()) - y1);
    }

    public void add(double x, double y) {
        double x1 = Math.min(getMinX(), x);
        double y1 = Math.min(getMinY(), y);
        setRect(x1, y1, Math.max(getMaxX(), x) - x1, Math.max(getMaxY(), y) - y1);
    }

    public void add(Point2D p) {
        add(p.getX(), p.getY());
    }

    public void add(Rectangle2D r) {
        union(this, r, this);
    }

    public PathIterator getPathIterator(AffineTransform t) {
        return new Iterator(this, t);
    }

    public PathIterator getPathIterator(AffineTransform t, double flatness) {
        return new Iterator(this, t);
    }

    public int hashCode() {
        HashCode hash = new HashCode();
        hash.append(getX());
        hash.append(getY());
        hash.append(getWidth());
        hash.append(getHeight());
        return hash.hashCode();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Rectangle2D)) {
            return false;
        }
        Rectangle2D r = (Rectangle2D) obj;
        if (getX() == r.getX() && getY() == r.getY() && getWidth() == r.getWidth() && getHeight() == r.getHeight()) {
            return true;
        }
        return false;
    }
}
